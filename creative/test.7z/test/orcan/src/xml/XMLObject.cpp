// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/XMLObject.hh>
#include <oc/Log.hh>
#include <oc/Util.hh>

// C++ includes

#include <algorithm>
#include <cassert>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>

#include <cstring>

oc::XMLObject::XMLObject(bool case_sensitive) 
    : mDocument(NULL)
    , mCaseSensitive( case_sensitive )
{
} 



oc::XMLObject::XMLObject( const char* rootname, bool case_sensitive ) 
    : mDocument(NULL)
    , mCaseSensitive( case_sensitive )
{
    mDocument = new AdvXMLParser::Document(rootname);
} 


oc::XMLObject::XMLObject( const char* rootname, const char* content,
                            bool case_sensitive )
    : mCaseSensitive( case_sensitive )
{
    try {
        AdvXMLParser::Parser parser;
        mDocument = parser.Parse(content, strlen(content), case_sensitive );        
    }
    catch(AdvXMLParser::ParsingException e) {
    
        OCERROR("Parseerror at line " << e.GetLine() << "; column " << e.GetColumn() );
	OCERROR("content=" << content);
        mDocument = NULL;

    }

}


oc::XMLObject::XMLObject( XMLObject const&)
{
    OCERROR("XMLObject copy-ctor. may not be used");
}


oc::XMLObject::~XMLObject() 
{
    if( mDocument != NULL ) {
        delete mDocument;
    }
}



bool 
oc::XMLObject::Load( const oc::File& filename ) 
{
    if( mDocument ) {
        delete mDocument;
        mDocument = NULL;
    }

    if( !filename.IsExistant() ) {
        OCERROR("File does not exist: " << filename.GetAbsoluteFile() );
        return false;
    }


    std::string fname = filename.GetAbsoluteFile();

    int bsize = filename.GetFileSize();

    FILE *fh = fopen(fname.c_str(),"rt");

    if( fh == NULL ) {
        OCERROR("Can not open file " << fname );
        return false;
    }

    uint8 *buffer = new uint8[bsize];
    int bnum = fread(buffer,1,bsize,fh);
    fclose(fh);

    if( bnum < bsize ) {
        buffer[bnum]=0; 
    }
    else if( bnum > bsize ) {
        OCERROR("Invalid filesize " << bnum << "; should be " << bsize << " while reading " << fname );
        delete [] buffer;
        return false;
    }

    try {
        AdvXMLParser::Parser parser;
        mDocument = parser.Parse((char *)buffer, bsize, mCaseSensitive );        
    }
    catch(AdvXMLParser::ParsingException e) {
    
        OCERROR("Parseerror at line " << e.GetLine() << "; column " << e.GetColumn() << " in " << fname );
        delete [] buffer;
        return false;

    }

    delete [] buffer;
    
    return true;
    
} 




bool
oc::XMLObject::Save( const oc::File& file ) 
{    
    if( mDocument == NULL ) {
        return false;
    }

    AdvXMLParser::String strXml;
    mDocument->GenerateXML(strXml);

    std::ofstream out(file.GetAbsoluteFile().c_str());

    out << strXml;

    return true;
}


bool 
oc::XMLObject::GetRootValue(const std::string& tag, bool& value) const
{
    if( mDocument == NULL ) {
        return false;
    }

    const AdvXMLParser::Element& config = GetRoot();
    if( config.IsNull() || config.IsEmpty() ) {
        return false;
    }
    const AdvXMLParser::Element& thetag = config(tag.c_str());
    if( thetag.IsNull() || thetag.IsEmpty() ) {
        return false;
    }
    std::string thevalue = thetag.GetValue();
    Util::ToLower( thevalue );

    if( thevalue == "true" ) {
        value = true;
        return true;
    }
    if( thevalue == "false" ) {
        value = false;
        return true;
    }
    return false;
} 


const AdvXMLParser::Element& 
oc::XMLObject::GetRoot() const
{
    if( mDocument == NULL ) {
        return AdvXMLParser::Element::null();
    }

    return mDocument->GetRoot();
} 


AdvXMLParser::Element& 
oc::XMLObject::GetRoot()
{
    if( mDocument == NULL ) {
        return AdvXMLParser::Element::null();
    }

    return mDocument->GetRoot();
} 

namespace oc {

    std::ostream& 
    operator<<(std::ostream& out, const oc::XMLObject& xmlobj)
    {
        if( xmlobj.mDocument == NULL ) {
            return out;
        }
        return (out << xmlobj.mDocument->GenerateXML());
    } 

}

