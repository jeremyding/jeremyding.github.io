
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/CPtr.hh>
#include <oc/InetAddress.hh>

// C include

#include <cstring>

#ifndef WIN32
#  include <rpc/types.h>
#  include <arpa/inet.h>
#  include <netdb.h>
#  include <unistd.h>
#  if defined(__FreeBSD__)
#    include <sys/param.h>
#  endif
#else
#  define MAXHOSTNAMELEN 1024
#endif


// *****************************************************************************
// *****************************************************************************
//
// CLASS: InetAddress
//
// *****************************************************************************
// *****************************************************************************

int 
oc::InetAddress::mInstanceCount = 0;

// *****************************************************************************
//
// Constructors:
//
//   InetAddress()
//   InetAddress( const InetAddress & source )
//
// Destructor:
//
//   ~InetAddress()
//
// *****************************************************************************

oc::InetAddress::InetAddress()
    : mHostName()
{
    mInAddr.s_addr = 0;
}



oc::InetAddress::InetAddress( const InetAddress & source )
    : mHostName( source.mHostName )
{
    ::memcpy( &mInAddr, &source.mInAddr, sizeof( struct in_addr ) );
}


oc::InetAddress::~InetAddress()
{
    // Intentional left empty
}


// *****************************************************************************
//
// Operators:
//
//   operator=()
//   operator==() const
//   operator!=() const
//
// *****************************************************************************

oc::InetAddress &
oc::InetAddress::operator=( const InetAddress & rhs )
{

    if( this != & rhs ) {

	::memcpy( &mInAddr, &rhs.mInAddr, sizeof( struct in_addr ) );

	mHostName = rhs.mHostName;
    }

    return *this;
}



bool
oc::InetAddress::operator==( const InetAddress & rhs ) const
{
    return (::memcmp( &mInAddr, &rhs.mInAddr, sizeof( struct in_addr ) ) == 0 );
}



bool
oc::InetAddress::operator!=( const InetAddress & rhs ) const
{
    return (::memcmp( &mInAddr, &rhs.mInAddr, sizeof( struct in_addr ) ) != 0 );
}






// *****************************************************************************
//
// Getter / Setter:
//
//   GetByName( std::string host )
//   GetLocalHost()
//   GetHostAddress() const
//   GetHostName() const
//
// *****************************************************************************

oc::InetAddress
oc::InetAddress::GetByName( const std::string & host )
{

    oc::InetAddress inetAddress; // Default: Null address

    // Do not try to handle hostnames that exceeds the maximum
    // permitted size.
    if( host.size() > MAXHOSTNAMELEN ) {

	OCDEBUG( "Can't handle host names longer than "
                   << MAXHOSTNAMELEN
                   << " characters." );
	return inetAddress;
    }

    // The host string can be given in two forms:
    //
    // 1. In the numbers-and-dots notation: "153.96.117.46"
    // 2. In the host name string notation: "eiche.iis-b.fhg.de"
    //
    // Both forms are accepted by gethostbyname()

    struct hostent * hostDbEntry = ::gethostbyname( host.c_str() );

    // Host found in host data base
    if( hostDbEntry != oc::CPtr<struct hostent>::Null ) {

	::memcpy( &inetAddress.mInAddr, hostDbEntry->h_addr_list[0], sizeof( struct in_addr ) );

	inetAddress.mHostName = hostDbEntry->h_name;
    }
    else {

	OCDEBUG( "Host \"" << host << "\" not found." );
    }

    return inetAddress;

}



oc::InetAddress
oc::InetAddress::GetLocalHost()
{
    Startup();

    char hostname[MAXHOSTNAMELEN+1];

    if( ::gethostname( hostname, MAXHOSTNAMELEN ) == 0 ) {

	return GetByName( std::string( hostname ) );
    }
    else {

	OCDEBUG( "Can't query local host name." );
    }

    return InetAddress();
}



std::string
oc::InetAddress::GetHostAddress() const
{
    Startup();

    if( IsNull() ) {

	return std::string();
    }

    return std::string( ::inet_ntoa( mInAddr ) );
}



const std::string &
oc::InetAddress::GetHostName() const
{
    return mHostName;
}


struct in_addr
oc::InetAddress::GetAddress() const
{
    return mInAddr;
}




// *****************************************************************************
//
// Query Methods:
//
//   IsNull() const
//
// *****************************************************************************

bool
oc::InetAddress::IsNull() const
{
    return (mInAddr.s_addr == 0);
}




void
oc::InetAddress::Startup()
{
#ifdef WIN32
    WSADATA wsaData;
  
    if( mInstanceCount == 0 ) {
        if( WSAStartup( MAKEWORD( 2, 2 ), &wsaData ) != 0 ) {
            OCERROR("could not initialize networking subsystem");
        }
    }
#endif
    mInstanceCount++;
}

void
oc::InetAddress::Cleanup()
{
    mInstanceCount--;
#ifdef WIN32
    if( mInstanceCount == 0 ) {
        WSACleanup();
    }
#endif
}

