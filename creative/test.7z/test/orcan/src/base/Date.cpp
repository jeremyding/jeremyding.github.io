// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

#include <oc/Date.hh>
#include <oc/Log.hh>

// C++ include

#include <iostream>
#include <algorithm>
#include <iomanip>
#include <string>
#include <sstream>
// C include

#include <ctime>

#include <oc/config.h>

oc::Date::Date()
{
    //    cout << "Constructor" << endl;
    mDay = 1;
    mMonth = 1;
    mYear = 0 ;
}

oc::Date::~Date()
{
    //    cout << "Destructor" << endl;
}

oc::Date::Date(oc::Date const & b)
{
    //cout << "KOPIE erstellt !!!" << endl;
    mDay = b.mDay;
    mMonth = b.mMonth;
    mYear = b.mYear;
}


oc::Date::Date(int d, int m, int y)
{
    mDay = d;
    mMonth = m;
    mYear = y;
}

oc::Date::Date(const std::string & d)
{
    SetDate(d);
}


oc::Date & 
oc::Date::operator = (oc::Date const & rhs)
{
    mDay = rhs.mDay;
    mMonth = rhs.mMonth;
    mYear = rhs.mYear;

    return *this;
}

bool 
oc::Date::IsLeapYear(int year)
{
    if (!(year%4) && ((!(year%400)) || year%100))
        return true;
    else
        return false;
}

bool 
oc::Date::IsLeapYear() const
{
    if (!(mYear%4) && ((!(mYear%400)) || mYear%100))
        return true;
    else
        return false;
}

bool
oc::Date::SetDate(const std::string & d)
{
    char pt1, pt2;
    std::istringstream dat(d);
    dat >> mDay >> pt1  >> mMonth >> pt2 >> mYear;
    SetDate(mDay, mMonth, mYear);
    return true;
}

int 
oc::Date::GetDaysOfYear() const
{
    if(IsLeapYear(mYear))
        {
        switch (mMonth)
            {
            case 1: return mDay; break;
            case 2: return 31 + mDay; break; 
            case 3: return 60 + mDay; break;
            case 4: return 91 + mDay; break; 
            case 5: return 121 + mDay; break;
            case 6: return 152 + mDay; break; 
            case 7: return 182 + mDay; break;
            case 8: return 213 + mDay; break; 
            case 9: return 244 + mDay; break;
            case 10: return 274 + mDay; break; 
            case 11: return 305 + mDay; break;
            case 12: return 335 + mDay; break; 
            default: OCERROR( "FEHLER in file " << __FILE__ << " in line " << __LINE__ );
                return 0;
                
            }
       }
    else
        {
            switch(mMonth)
                {
                    case 1: return mDay; break;
                case 2: return 31 + mDay; break; 
                case 3: return 59 + mDay; break;
                case 4: return 90 + mDay; break; 
                case 5: return 120 + mDay; break;
                case 6: return 151 + mDay; break; 
                case 7: return 181 + mDay; break;
                case 8: return 212 + mDay; break; 
                case 9: return 243 + mDay; break;
                case 10: return 273 + mDay; break; 
                case 11: return 304 + mDay; break;
                case 12: return 334 + mDay; break; 
                default: OCERROR( "FEHLER in file " << __FILE__ << " in line " << __LINE__ );
                    return 0;
                }
        }
}

oc::Date & 
oc::Date::SetNumberOfDays(int n)
{
    static bool first_call = true;
    static int MonthsLeapYear[366];
    static int DaysLeapYear[366];
    static int MonthsNormalYear[365];
    static int DaysNormalYear[365];

    while(n>365) {

        n -= IsLeapYear() ? 366 : 365;
        mYear++;
    }
            
    while(n<0) {

        n += IsLeapYear( GetYear()-1 ) ? 366 : 365;
        mYear--;
    }
    
    if(n==0) {
        mMonth=12;
        mDay=31;
        mYear--;
        return *this;
    }


    
    if (first_call) {
        InitialDate(MonthsLeapYear ,DaysLeapYear ,MonthsNormalYear ,DaysNormalYear);
        first_call = false;
    }        
       
        
    if(IsLeapYear())
        {
            mMonth = MonthsLeapYear[n-1];
            mDay   = DaysLeapYear[n-1];
        }
    else {
        mMonth = MonthsNormalYear[n-1];
        mDay   = DaysNormalYear[n-1];
        }
    
    return *this;
}

bool 
oc::Date::SetDate (int day, int month, int year)
{
    mYear = year;

    if (month < 0)
        month = -month;
    if (month == 0)
        month = 1;
    mMonth = std::min(12,std::max(1,month));
    
    if (day < 0)
        day = -day;
    
    if(day > 31 && (mMonth == 1 || mMonth == 3 || mMonth == 5 || mMonth == 7 || mMonth == 8 || mMonth == 10 || mMonth == 12))
       {
           mDay = 31 ;
       }
    else if (day > 30 && (mMonth == 4 || mMonth == 6 || mMonth == 9 || mMonth == 11 ))
        {
            mDay = 30;
        }
    else if (day == 0)
        mDay =1 ;
    else  mDay = day;

           
    if (mMonth ==2 && mDay > 28)
        {
            if (IsLeapYear(mYear))
                mDay = 29;
            else mDay = 28;
        }
 
    if(mYear != year || mMonth != month || mDay != day)
        return false;
    else return true;

           
}


int 
oc::Date::GetDay() const
{
    return mDay;
}

int 
oc::Date::GetMonth() const
{
    return mMonth;
}

int 
oc::Date::GetYear() const
{
    return mYear;
}


void 
oc::Date::Get(int & day, int & month, int & year) const
{
    day = mDay;
    month = mMonth;
    year = mYear;
}
    
std::ostream &
oc::operator<<( std::ostream & out, const oc::Date & d )
{
    out << std::setfill('0')
        << std::setw(2) << d.GetDay()   << "."
        << std::setw(2) << d.GetMonth() << "."
        << std::setw(4) << d.GetYear();
    
    return out;
}

std::istream &
oc::operator>>(std::istream & in, oc::Date & date)
{
    int day, month, year;
    char dot1, dot2;
    
    in >> day >> dot1 >> month >> dot2 >> year;

    if( dot1 == '.' && dot2 == '.' ) {

        date.SetDate( day, month, year );
    }

    return in;
}


oc::Date 
oc::Date::GetCurrent()
{

    time_t t;

    time( & t );

    struct tm * current_time = localtime( & t );

    oc::Date d( current_time->tm_mday,
           current_time->tm_mon + 1,
           current_time->tm_year + 1900 );

    return d;

}

bool 
oc::Date::operator==(oc::Date const & a)
{
    return (mMonth == a.mMonth &&  mDay == a.mDay && mYear == a.mYear);

}

bool 
oc::Date::operator<(oc::Date const & a)
{
    if(mYear<a.mYear) 
        return true;
    else if (mYear>a.mYear)
        return false;
    else 
        {
            if (GetDaysOfYear() < a.GetDaysOfYear())
                return true;
            else return false;
        }

    
}

bool 
oc::Date::operator>(oc::Date const & a)
{
    if(mYear>a.mYear)
        return true;
    else if (mYear<a.mYear)
             return false;
    else 
        {
            if(GetDaysOfYear() > a.GetDaysOfYear())
                return true;
            else return false;
        }

}

bool 
oc::Date::operator>=(oc::Date const & a)
{
    if(mYear>a.mYear)
        return true;
    else if (mYear<a.mYear)
             return false;
    else 
        {
            if(GetDaysOfYear()>=a.GetDaysOfYear())
                return true;
            else return false;
        }
}


bool 
oc::Date::operator<=(oc::Date const & a)
{
    if(mYear<a.mYear) {
        return true;
    }
    else if (mYear>a.mYear) {
        return false;
    }
    else {
        if(GetDaysOfYear()<=a.GetDaysOfYear()) {
            return true;
        }
        else {
            return false;
        }
    }
}
            
oc::Date 
oc::Date::operator+(int t)
{
    oc::Date tmp( *this );

    tmp.SetNumberOfDays(GetDaysOfYear() + t);

    return tmp;
}

oc::Date 
oc::Date::operator-(int t)
{
    oc::Date tmp( *this );

    tmp.SetNumberOfDays(GetDaysOfYear() - t);
    return tmp;
}  

oc::Date & 
oc::Date::operator+=(int t)
{
   SetNumberOfDays(GetDaysOfYear() + t);
   return *this;
}

oc::Date & 
oc::Date::operator-=(int t)
{
    SetNumberOfDays(GetDaysOfYear() - t);
    return *this;
}

oc::Date & 
oc::Date::operator++()
{
    SetNumberOfDays(GetDaysOfYear() +1);
    return *this;
}

oc::Date 
oc::Date::operator++(int)
{
    oc::Date tmp( *this );

    ++(*this);

    return tmp;

}

oc::Date & 
oc::Date::operator--()
{
    SetNumberOfDays(GetDaysOfYear() - 1);
   
    return  SetNumberOfDays(GetDaysOfYear() - 1);
}

oc::Date  
oc::Date::operator--( int )
{
    oc::Date tmp( *this );
    --(*this);
    return tmp;
}


void 
oc::Date::InitialDate(int * MonthsLeapYear, int * DaysLeapYear,int * MonthsNormalYear, int * DaysNormalYear)
{
    int i;
      for(i = 366; i > 0; --i) {
            if(i>335) {
                MonthsLeapYear[i-1]=12;
                DaysLeapYear[i-1]=i-335;
            }
            else if(i>305) {
                MonthsLeapYear[i-1]=11;
                DaysLeapYear[i-1] = i-305;
            }
            else if(i>274) {
                MonthsLeapYear[i-1]=10;
                DaysLeapYear[i-1] = i-274;
            }
            else if(i>244) {
                    MonthsLeapYear[i-1]=9;
                    DaysLeapYear[i-1] = i-244;
                } 
            else if(i>213) {
                    MonthsLeapYear[i-1]=8;
                    DaysLeapYear[i-1] = i-213;
                } 
            else if(i>182) {
                    MonthsLeapYear[i-1]=7;
                    DaysLeapYear[i-1] = i-182;
                }
            else if(i>152) {
                    MonthsLeapYear[i-1]=6;
                    DaysLeapYear[i-1] = i-152;
                }
            else if(i>121) {
                    MonthsLeapYear[i-1]=5;
                    DaysLeapYear[i-1] = i-121;
                }
           else if(i>91) {
                    MonthsLeapYear[i-1]=4;
                    DaysLeapYear[i-1] = i-91;
                }
           else if(i>60) {
                    MonthsLeapYear[i-1]=3;
                    DaysLeapYear[i-1] = i-60;
                }
           else if(i>31) {
                    MonthsLeapYear[i-1]=2;
                    DaysLeapYear[i-1] = i-31;
                }
           else {
                    MonthsLeapYear[i-1]=1;
                    DaysLeapYear[i-1] = i;
                } 
        } 

        for(i = 365; i > 0; --i) {
            if(i>334) {
                MonthsNormalYear[i-1]=12;
                DaysNormalYear[i-1]=i-334;
            }
            else if(i>304) {
                MonthsNormalYear[i-1]=11;
                DaysNormalYear[i-1] = i-304;
            }
            else if(i>273) {
                MonthsNormalYear[i-1]=10;
                DaysNormalYear[i-1] = i-273;
            }
            else if(i>243) {
                    MonthsNormalYear[i-1]=9;
                    DaysNormalYear[i-1] = i-243;
                } 
            else if(i>212) {
                    MonthsNormalYear[i-1]=8;
                    DaysNormalYear[i-1] = i-212;
                } 
            else if(i>181) {
                    MonthsNormalYear[i-1]=7;
                    DaysNormalYear[i-1] = i-181;
                }
            else if(i>151) {
                    MonthsNormalYear[i-1]=6;
                    DaysNormalYear[i-1] = i-151;
                }
            else if(i>120) {
                    MonthsNormalYear[i-1]=5;
                    DaysNormalYear[i-1] = i-120;
                }
           else if(i>90) {
                    MonthsNormalYear[i-1]=4;
                    DaysNormalYear[i-1] = i-90;
                }
           else if(i>59) {
                    MonthsNormalYear[i-1]=3;
                    DaysNormalYear[i-1] = i-59;
                }
           else if(i>31) {
                    MonthsNormalYear[i-1]=2;
                    DaysNormalYear[i-1] = i-31;
                }
           else {
                    MonthsNormalYear[i-1]=1;
                    DaysNormalYear[i-1] = i;
                } 
        }
} 
