// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

#include <oc/DateTime.hh>

#include <iostream>

oc::DateTime::DateTime()
    : mDate()
    , mTime()
{
}

oc::DateTime::DateTime( const DateTime & dt )
    : mDate( dt.mDate )
    , mTime( dt.mTime )
{
}


oc::DateTime::DateTime( const Date & d, const Time & t )
    : mDate( d )
    , mTime( t )
{
}

oc::DateTime::~DateTime()
{
}

oc::DateTime &
oc::DateTime::operator=(const oc::DateTime & rhs)
{
    mDate = rhs.mDate;
    mTime = rhs.mTime;

    return *this;
}

bool
oc::DateTime::operator==(const DateTime dt)
{
    if(mDate==dt.mDate && mTime==dt.mTime) {
        return true;
    }
    else {
        return false;
    }
}

bool
oc::DateTime::operator!=(const DateTime dt)
{
    if(mDate==dt.mDate && mTime==dt.mTime) {
        return false;
    }
    else {
        return true;
    }
}

bool
oc::DateTime::Set(const oc::Date & d)
{
    mDate = d;
    
    return true;
}

bool
oc::DateTime::Set(const oc::Time & t)
{
    mTime = t;
    return true;
}

bool 
oc::DateTime::Set( const oc::Date & d, const oc::Time & t )
{
    mTime = t;
    mDate = d;
    return true;
}

const oc::Date & 
oc::DateTime::GetDate() const
{
    return mDate;
}

const oc::Time & 
oc::DateTime::GetTime() const
{
    return mTime;
}

bool
oc::DateTime::Get( oc::Date & d, oc::Time & t ) const
{
    d = mDate;
    t = mTime;

    return true;
}

oc::DateTime
oc::DateTime::GetCurrent()
{
    return oc::DateTime( oc::Date::GetCurrent(), oc::Time::GetCurrent() );
}
                   

