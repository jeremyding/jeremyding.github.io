// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// -------

// ORCAN include

#include <oc/Log.hh>
#include <oc/Table.hh>
#include <oc/Util.hh>
#include <stdlib.h>

oc::TableCell::TableCell()
: mStrVal("")
{
}

oc::TableCell::TableCell(std::string const&strval)
{
    mStrVal = strval;
}

oc::TableCell::~TableCell()
{
}
        
std::string const& 
oc::TableCell::GetStringValue() const
{
    return mStrVal;
}

void
oc::TableCell::SetStringValue(std::string const& str)
{
    mStrVal = str;
}

oc::Table::Table()
: mTable(NULL)
, mNumRows(0)
, mNumCols(0)
, mRowSep(';')
, mColSep(':')
, mTitle("may not be empty")
{
}

oc::Table::Table( std::string const& title, int num_rows, int num_cols )
{

    mTable = new TableCell * [num_rows];
    for( int y=0; y<num_rows; y++ ) {
        mTable[y] = new TableCell[num_cols];
    }
    mNumRows = num_rows;
    mNumCols = num_cols;
    mTitle   = title;
    mRowSep  = ';';
    mColSep  = ':';
}

oc::Table::Table( std::string const& val )
{
    int num_rows = 1;
    int num_cols = 1;
    std::string title = "may not be empty";
    mTable = new TableCell * [num_rows];
    for( int y=0; y<num_rows; y++ ) {
        mTable[y] = new TableCell[num_cols];
    }
    mNumRows = num_rows;
    mNumCols = num_cols;
    mTitle   = title;
    mRowSep  = ';';
    mColSep  = ':';

    Scan(val);
}

oc::Table::Table( const Table& table )
{
    if( &table == this) { return; }

    Destroy();

    mTable = new TableCell * [table.mNumRows];
    for( int y=0; y<table.mNumRows; y++ ) {
        mTable[y] = new TableCell[table.mNumCols];
        for( int x=0; x<table.mNumCols; x++ ) {
            mTable[y][x] = table.mTable[y][x];
        }
    }

    mNumRows = table.mNumRows;
    mNumCols = table.mNumCols;
    mTitle   = table.mTitle;
    mRowSep  = table.mRowSep;
    mColSep  = table.mColSep;
}

oc::Table::~Table()
{

    Destroy();
}

void
oc::Table::Destroy()
{
    if( mTable ) {
        for( int y=0; y<mNumRows; y++ ) {
            if( mTable[y] ) {
                delete [] mTable[y];
            }
        }
        delete [] mTable;
    }
    mTable = NULL;
    mNumRows = mNumCols = 0;
}

oc::Table & 
oc::Table::operator=( const oc::Table & table )
{
    if( &table == this) { return *this; }

    Destroy();

    mTable = new TableCell * [table.mNumRows];
    for( int y=0; y<table.mNumRows; y++ ) {
        mTable[y] = new TableCell[table.mNumCols];
        for( int x=0; x<table.mNumCols; x++ ) {
            mTable[y][x] = table.mTable[y][x];
        }
    }

    mNumRows = table.mNumRows;
    mNumCols = table.mNumCols;
    mTitle   = table.mTitle;
    mRowSep  = table.mRowSep;
    mColSep  = table.mColSep;

    return *this;
}

void 
oc::Table::SetNumberOfRows( int num_rows )
{
    if( num_rows == mNumRows) {
        return;
    }
    if( num_rows == 0 ) {
        Destroy();
        return;
    }

    TableCell **newtable;
    newtable = new TableCell *[num_rows];
    
    int i,minrows = (num_rows < mNumRows) ? num_rows : mNumRows;
    for(i=0;i<minrows; i++ ) {
        newtable[i] = mTable[i];
    }
    if( minrows < num_rows ) {
        for(  ;i<num_rows; i++ ) {
            newtable[i] = new TableCell[mNumCols];   
        }
    }
    else {
        for(  ;i<mNumRows; i++ ) {
            delete [] mTable[i];
        }
    }

    mTable = newtable;
    mNumRows = num_rows;
}

void 
oc::Table::SetNumberOfCols( int num_cols )
{
    if( num_cols == mNumCols) {
        return;
    }
    if( num_cols == 0 ) {
        Destroy();
        return;
    }

    
    int y,mincols=(num_cols < mNumCols) ? num_cols : mNumCols;

    for(y=0;y<mNumRows; y++ ) {
        TableCell *oldcol = mTable[y];
        mTable[y] = new TableCell[num_cols];
        for(int x=0; x<mincols; x++ ) {
            mTable[y][x] = oldcol[x];
        }
        delete [] oldcol;
    }

    mNumCols = num_cols;
}

void
oc::Table::SetTitle( std::string const& title)
{
    if( title == "" ) {
        OCWARN("title may not be empty");
        return;
    }

    mTitle = title;
}

std::string const&
oc::Table::GetTitle() const
{
    return mTitle;
}

void 
oc::Table::SetCellStringValue( int x, int y, std::string const& val)
{
    if( (y < mNumRows) && (x < mNumCols) ) {
        mTable[y][x] = val;
    }
    else {
        OCWARN("no element defined at " << x << y );
    }
}

std::string const& 
oc::Table::GetCellStringValue(int x, int y) const
{
    static std::string NULLSTRING;

    if( (y < mNumRows) && (x < mNumCols) ) {
        return mTable[y][x].GetStringValue();
    }
    else {
        OCWARN("no element defined at " << x << y );
    }

    return NULLSTRING;
}
  
void 
oc::Table::SetCell( int x, int y, oc::TableCell const& val)
{
    if( (y < mNumRows) && (x < mNumCols) ) {
        mTable[y][x] = val;
    }
    else {
        OCWARN("no element defined at " << x << y );
    }
}

oc::TableCell const& 
oc::Table::GetCell(int x, int y) const
{
    static TableCell NULLCELL;

    if( (y < mNumRows) && (x < mNumCols) ) {
        return mTable[y][x];
    }
    else {
        OCWARN("no element defined at " << x << y );
    }

    return NULLCELL;
}

  
void 
oc::Table::Print( std::ostream & out ) const
{
    out << mRowSep << mColSep << mNumRows << mColSep << mNumCols << mColSep << mTitle << mRowSep;
    for( int y=0; y<mNumRows; y++ ) {
        for( int x=0; x<mNumCols; x++ ) {
            out << mTable[y][x].GetStringValue();
            if( x < mNumCols-1 ) {
                out << mColSep;
            }
        }
        out << mRowSep;
    }
}

void 
oc::Table::Scan( std::string const& val )
{
    if( val.size() <= 5 ) {
        OCWARN("must be at least :;0:0:;");
        return;
    }

    // first two chars are row and col separators
    uint8 rowsep = val[0];
    uint8 colsep = val[1];

    // next come the rows
    std::vector<std::string> rows = oc::Util::Tokenize(val.substr(2,val.size()-2),rowsep,true);
    
    // first row is number of rows and cols

    if( rows.empty() ) {
        OCWARN("empty rows");
        return;
    }

    std::vector<std::string> cols = oc::Util::Tokenize(rows[0],colsep,true);
    if( cols.size() != 3 ) {
        OCWARN("first row should be num_rows:num_cols:title");
        return;
    }

    uint32 numrows = atoi(cols[0].c_str());
    uint32 numcols = atoi(cols[1].c_str());
    mTitle         = cols[2];

    if( numrows != rows.size()-1 ) {
        OCWARN("number of rows does not match: should be " << numrows << " but is " << rows.size()-1 );
        return;
    }

    // get all rows and cols
    oc::TableCell **newtable = new TableCell *[numrows];
    for( int y=0; y<numrows; y++ ) {
        newtable[y] = new TableCell[numcols];
        std::vector<std::string> cols = oc::Util::Tokenize(rows[y+1],colsep,true);
        for( int x=0; x<numcols; x++ ) {
            if( x<cols.size() ) {
                newtable[y][x].SetStringValue(cols[x]);
            }
        }
    }

    if( mTable ) {
        Destroy();
    }

    mRowSep = rowsep;
    mColSep = colsep;
    mNumRows = numrows;
    mNumCols = numcols;
    mTable = newtable;


}
void 
oc::Table::Scan( std::istream & in )
{
    std::string val;
    in >> val;
    Scan(val);
}


std::ostream & 
oc::operator<<( std::ostream & out, const oc::Table & table )
{
    table.Print(out);
    return out;
}

std::istream &
oc::operator>>( std::istream & in, oc::Table & table )
{
    table.Scan(in);
    return in;
}


