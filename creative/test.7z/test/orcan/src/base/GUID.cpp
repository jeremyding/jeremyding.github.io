
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/GUID.hh>
#include <oc/Log.hh>

// C include

#include <cstdio>

#ifdef HAVE_LIBUUID
#  include <uuid/uuid.h>
#else
#  include <cstdlib>
#endif

#include <stdlib.h>

#ifdef WIN32
#  include <Rpc.h>
#  include <Rpcdce.h> // uuid generation
#endif

#ifdef MACOSX
#  include <Carbon/Carbon.h>
#endif

// *****************************************************************************
// *****************************************************************************
//
// CLASS: GUID
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   GUID()
//   GUID( const GUID & source )
//   GUID( const std::string & guid )
//   GUID( int first, int second, int third, int fourth, int fifth )
//
// Destructor:
//
//   ~GUID()
//
// *****************************************************************************

oc::GUID::GUID()
    : mStringValue( "00000000-0000-0000-0000-000000000000" )
{
    mValues[0] = 0;
    mValues[1] = 0;
    mValues[2] = 0;
    mValues[3] = 0;
    mValues[4] = 0;
}



oc::GUID::GUID( const GUID & source )
    : mStringValue( source.mStringValue )
{
    mValues[0] = source.mValues[0];
    mValues[1] = source.mValues[1];
    mValues[2] = source.mValues[2];
    mValues[3] = source.mValues[3];
    mValues[4] = source.mValues[4];
}



oc::GUID::GUID( const std::string & guid )
    : mStringValue( guid )
{

    // Scan stream
    int numValues = ::sscanf( guid.c_str(),
			      "%08x-%04x-%04x-%04x-%012x",
			      mValues+0,
			      mValues+1,
			      mValues+2,
			      mValues+3,
			      mValues+4 );

    // All values read?
    if( numValues != 5 ) {

	mStringValue = "00000000-0000-0000-0000-000000000000";
	mValues[0] = 0;
	mValues[1] = 0;
	mValues[2] = 0;
	mValues[3] = 0;
	mValues[4] = 0;
    }
}



oc::GUID::GUID( int first, int second, int third, int fourth, int fifth )
    : mStringValue( 37, '0' )
{
    mValues[0] = first;
    mValues[1] = second;
    mValues[2] = third;
    mValues[3] = fourth;
    mValues[4] = fifth;

    ::sprintf( & mStringValue[0],
	       "%08x-%04x-%04x-%04x-%012x",
	       mValues[0],
	       mValues[1],
	       mValues[2],
	       mValues[3],
	       mValues[4] );
}



oc::GUID::~GUID()
{
    // Intentional lefty emtpy
}





// *****************************************************************************
//
// Operators:
//
//   operator=( const GUID & rhs )
// 
// *****************************************************************************

oc::GUID &
oc::GUID::operator=( const GUID & rhs )
{

    // id = id;
    if( & rhs == this ) {

	return( * this );
    }

    mStringValue = rhs.mStringValue;

    mValues[0] = rhs.mValues[0];
    mValues[1] = rhs.mValues[1];
    mValues[2] = rhs.mValues[2];
    mValues[3] = rhs.mValues[3];
    mValues[4] = rhs.mValues[4];

    return *this;
}




// *****************************************************************************
//
// Static Methods:
//
//   Generate()
// 
// *****************************************************************************


oc::GUID
oc::GUID::Generate()
{

    // WINDOWS
#ifdef WIN32

    unsigned char *str_uid;
    std::string rstr_uid;

    UUID guid;

    if( UuidCreate(&guid) != RPC_S_OK ) {
        OCERROR("could not create GUID");
        return oc::GUID();
    }
    if( UuidToString(&guid,&str_uid) != RPC_S_OK ) {
        OCERROR("could not convert GUID to string");
        return oc::GUID();
    }
    rstr_uid=std::string((char*)str_uid);
    RpcStringFree(&str_uid); 

    return oc::GUID( rstr_uid );

#endif

    // LINUX with libuuid

#ifdef HAVE_LIBUUID

    uuid_t guid;

    ::uuid_generate( guid );

    char guidCString[37];

    ::uuid_unparse( guid, guidCString );

    return oc::GUID( std::string( (char *) guidCString ) );

#endif


    // MAC OS X

#ifdef MACOSX

    CFUUIDRef   myUUID       = CFUUIDCreate(kCFAllocatorDefault);
    CFStringRef myUUIDString = CFUUIDCreateString(kCFAllocatorDefault, myUUID);

    // This is the safest way to obtain a C string from a CFString.
    char strBuffer[100];
    CFStringGetCString(myUUIDString, strBuffer, 100, kCFStringEncodingASCII);

    return oc::GUID( strBuffer );

#endif

    // SGI

#ifdef __SGI__

# error Still not implemented.

#endif

    static int count=0;

    if( count == 0 ) {

        OCWARNCONT( "Global unique identifier is generated randomly."         );
        OCWARNCONT( "This is not a real GUID. Please install libuuid.so."     );
        OCWARN    ( "libuuid is part of the 'e2fsprogs' package under Linux." );
    }

    count++;

    return oc::GUID(count,rand(), rand(), rand(), rand());


}

// *****************************************************************************
//
// Getter / Setter:
//
//   GetString() const
//   GetFirst() const
//   GetSecond() const
//   GetThird() const
//   GetFourth() const
//   GetFifth() const
// 
// *****************************************************************************


const std::string &
oc::GUID::GetString() const
{
    return mStringValue ;
}



int
oc::GUID::GetFirst() const
{
    return mValues[0] ;
}



int
oc::GUID::GetSecond() const
{
    return mValues[1] ;
}



int
oc::GUID::GetThird() const
{
    return mValues[2] ;
}



int
oc::GUID::GetFourth() const
{
    return mValues[3] ;
}



int
oc::GUID::GetFifth() const
{
    return mValues[4] ;
}





// *****************************************************************************
//
// Query Methods:
//
//   IsNull() const
//
// *****************************************************************************

bool
oc::GUID::IsNull() const
{

    return ( (mValues[0] == 0) &&
             (mValues[1] == 0) &&
             (mValues[2] == 0) &&
             (mValues[3] == 0) );
}





// *****************************************************************************
//
// Operators:
//
//   operator==( const GUID & lhs, const GUID & rhs )
//   operator<<( std::ostream & out, const GUID & guid )
//
// *****************************************************************************

bool
oc::operator==( const GUID & lhs, const GUID & rhs )
{
    return  ( lhs.GetString() == rhs.GetString() );
}


std::ostream &
oc::operator<<( std::ostream & out, const GUID & guid )
{
    out << guid.GetString();
    return out;
}


