
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Errno.hh>

// C++ include

#include <sstream>

// C include

#include <cstring>




// *****************************************************************************
// *****************************************************************************
//
// CLASS: Errno
//
// *****************************************************************************
// *****************************************************************************





// *****************************************************************************
//
// Constructors:
//
//   Errno::Errno()
//   Errno::Errno( const Errno & err )
//   Errno::Errno( int errno )
//
// Destructor:
//
//    Errno::~Errno()
//
// *****************************************************************************

oc::Errno::Errno()
{

    mErrno = errno;

}

oc::Errno::Errno( const Errno & err )
    : mErrno( err.mErrno )
{
    // Intentional left empty
}

oc::Errno::Errno(int error_no)
{
    mErrno = error_no;
}

oc::Errno::~Errno()
    throw()
{
    // Intentional left empty
}


// *****************************************************************************
//
// Getter:
//
//   Errno::GetErrorNumber()
//   Errno::GetErrorString()
//
// *****************************************************************************

int
oc::Errno::GetErrorNumber()
{
    return( mErrno );
}


const std::string &
oc::Errno::GetErrorString()
{
    return( GetErrnoString( mErrno ) );
}



// *****************************************************************************
//
// Info:
//
//   Errno::what() const
//
// *****************************************************************************

const char *
oc::Errno::what() const
    throw()
{

    static char sDesc[1024];

    strncpy( sDesc, GetErrnoString( mErrno ).c_str(), 512 );

    return( sDesc );

} // Errno::what()




// *****************************************************************************
//
// Access operators:
//
//   Errno::operator=( const Errno & err )
//
// *****************************************************************************

oc::Errno &
oc::Errno::operator=( const Errno & err )
{

    mErrno = err.mErrno;

    return( *this );
}




// *****************************************************************************
//
// Static methods:
//
//   Errno::GetErrnoString( int errorNb )
//
// *****************************************************************************

const std::string &
oc::Errno::GetErrnoString( int errorNb )
{

    static std::string errno_string;

    errno_string = strerror( errorNb );

    return errno_string;

} // Errno::GetErrnoString()



