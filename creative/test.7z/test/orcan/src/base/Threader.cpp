// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCUDE
// ======

// ORCAN include

#include <oc/config.h>
#include <oc/Threader.hh>

#ifdef WIN32
#  include <oc/win32Thread.hh>
#  define OCTHREADIMPL oc::Win32Thread
#endif

typedef void (oc::Threader::*tDummyCallbackCall)(void);
typedef oc::Threader* tDummyCallbackPtr;


oc::Threader::Threader()
{
#ifdef OCTHREADIMPL
    mThreadImplementation = new OCTHREADIMPL(this);
#else
    mThreadImplementation = NULL;
#endif

}

oc::Threader::~Threader()
{
    if( mThreadImplementation != NULL ) {
        delete mThreadImplementation;
    }
}

bool 
oc::Threader::Run()
{
    if( mProperties.HasProperty("mInstancePtr") &&
        mProperties.HasProperty("mMethodPtr") ) {
        
        // run thread func
        tDummyCallbackPtr  ip = mProperties["mInstancePtr"](ip);
        tDummyCallbackCall ic = mProperties["mMethodPtr"](ic);
        (ip->*ic)();

        // report that thread has finished
        if( mProperties.HasProperty("mReportExitInstancePtr") &&
            mProperties.HasProperty("mReportExitMethodPtr") ) {
            
            mProperties["mReportExitInstancePtr"].SetRTTICheck(false);
            mProperties["mReportExitMethodPtr"].SetRTTICheck(false);
            ip = mProperties["mReportExitInstancePtr"](ip);
            ic = mProperties["mReportExitMethodPtr"](ic);
            (ip->*ic)();
        }

        return true;
    }
    return false;
}


bool
oc::Threader::Wait()
{
    if( mThreadImplementation == NULL )
        return false;
    
    return mThreadImplementation->Wait();
}

bool
oc::Threader::Suspend()
{
    if( mThreadImplementation == NULL )
        return false;
    
    return mThreadImplementation->Suspend();
}

bool
oc::Threader::Resume()
{
    if( mThreadImplementation == NULL )
        return false;
    
    return mThreadImplementation->Resume();
}

bool
oc::Threader::Kill()
{
    if( mThreadImplementation == NULL )
        return false;
    
    return mThreadImplementation->Kill();
}

bool
oc::Threader::SetPriority(uint32 priority100)
{
    if( mThreadImplementation == NULL )
        return false;
    
    return mThreadImplementation->SetPriority(priority100);
}

uint32 
oc::Threader::GetPriority()
{
    if( mThreadImplementation == NULL )
        return 101;
    
    return mThreadImplementation->GetPriority();
}


bool 
oc::Threader::IsRunning()
{
    if( mThreadImplementation == NULL )
        return false;

    return mThreadImplementation->IsRunning();
}

bool 
oc::Threader::IsSuspended()
{
    if( mThreadImplementation == NULL )
        return false;

    return mThreadImplementation->IsSuspended();
}

bool 
oc::Threader::IsAlive()
{
    if( mThreadImplementation == NULL )
        return false;

    return mThreadImplementation->IsAlive();
}


bool
oc::Threader::CreateAndRun()
{

    mProperties["mInstancePtr"].SetRTTICheck(false);
    mProperties["mMethodPtr"].SetRTTICheck(false);
    
    if( mThreadImplementation == NULL ) {
        return Run();
    }

    if( mThreadImplementation->CreateAndSuspend() ) {
        return mThreadImplementation->Resume();
    }
    return false;
}

bool
oc::Threader::CreateAndSuspend()
{
    mProperties["mInstancePtr"].SetRTTICheck(false);
    mProperties["mMethodPtr"].SetRTTICheck(false);

    if( mThreadImplementation == NULL ) {
        return true;
    }
    else { // ( mThreadImplementation != NULL ) {
        return mThreadImplementation->CreateAndSuspend();
    }
    return false;
}

