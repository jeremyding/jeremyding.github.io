
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/System.hh>
#include <oc/Log.hh>
#include <oc/File.hh>
#include <oc/InetAddress.hh>

// C include

#include <cerrno>
#include <cstring>
#include <cstdlib>

#ifdef WIN32
#  include <io.h>
#  include <direct.h>
#  include <windows.h>
#else
#  include <sys/types.h>
#  include <sys/stat.h>
#  include <fcntl.h>
#  include <unistd.h>
#endif


// CLASS STATIC
// ============

// ---------------------------
// System independent (part 1)
// ---------------------------

const char      oc::System::File::msSeparatorCharUnix  = '/';
const char      oc::System::File::msSeparatorCharWin32 = '\\';

const char      oc::System::Path::msSeparatorCharUnix  = ':';
const char      oc::System::Path::msSeparatorCharWin32 = ';';

// -----------------
// Microsoft Windows
// -----------------

#ifdef WIN32

const char      oc::System::File::msSeparatorChar   = oc::System::File::msSeparatorCharWin32;

const char      oc::System::Path::msSeparatorChar   = oc::System::Path::msSeparatorCharWin32;

const oc::File oc::System::Path::msTempDirectory   = oc::File( "C:\\TEMP" );

#else

// ------------
// UNIX (Linux)
// ------------

// System::File
const char       oc::System::File::msSeparatorChar   = oc::System::File::msSeparatorCharUnix;

// System::Path
const char       oc::System::Path::msSeparatorChar   = oc::System::Path::msSeparatorCharUnix;
const oc::File oc::System::Path::msTempDirectory   = oc::File( "/tmp" );

#endif



// ---------------------------
// System independent (part 2)
// ---------------------------

const int         oc::System::File::msMaxNameLength  = 256;
const std::string oc::System::File::msSeparator      = std::string( 1, oc::System::File::msSeparatorChar      );
const std::string oc::System::File::msSeparatorUnix  = std::string( 1, oc::System::File::msSeparatorCharUnix  );
const std::string oc::System::File::msSeparatorWin32 = std::string( 1, oc::System::File::msSeparatorCharWin32 );

const int         oc::System::Path::msMaxNameLength  = 512;
const std::string oc::System::Path::msSeparator      = std::string( 1, oc::System::Path::msSeparatorChar      );




// *****************************************************************************
// *****************************************************************************
//
// CLASS: System
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   System::System()
//   System::System( const System & system )
//
// Destructor:
//
//   System::~System()
//
// *****************************************************************************


oc::System::System()
{
    OCFATALCONT( "System::System()" << newl );
    OCFATAL    ( "Default constructor of System not allowed." );
}
   

oc::System::System( const System & system )
{
    OCFATALCONT( "System::System( const System & )" << newl );
    OCFATAL    ( "Copy constructor of System not allowed." );
}


oc::System::~System()
{
    OCFATALCONT( "System::~System()" << newl );
    OCFATAL    ( "Destructor of System not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   System::operator=( const System & system )
//
// *****************************************************************************

oc::System &
oc::System::operator=( const oc::System & system )
{
    OCFATALCONT( "System::operator=( const System & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}




void 
oc::System::Beep( uint32 freq, uint32 duration )
{
#ifdef WIN32
    ::Beep((DWORD)freq,(DWORD)duration);
#else
    std::cout << '\a' << std::endl;
#endif

}

void 
oc::System::Sleep( uint32 ms )
{
#ifdef WIN32
    ::Sleep(ms);
#else
    ::sleep( ms/1000 );
#endif
}


// *****************************************************************************
// *****************************************************************************
//
// CLASS: System::File
//
// *****************************************************************************
// *****************************************************************************




// *****************************************************************************
//
// Constructors:
//
//   System::File::File()
//   System::File::File( const System::File & file )
//
// Destructor:
//
//   System::File::~File()
//
// *****************************************************************************


oc::System::File::File()
{
    OCFATALCONT( "System::File::File()" << newl );
    OCFATAL    ( "Default constructor of System::File not allowed." );
}
   

oc::System::File::File( const System::File & file )
{
    OCFATALCONT( "System::File::File( const File & )" << newl );
    OCFATAL    ( "Copy constructor of System::File not allowed." );
}


oc::System::File::~File()
{
    OCFATALCONT( "System::File::~File()" << newl );
    OCFATAL    ( "Destructor of System::File not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   System::File::operator=( const System::File & file )
//
// *****************************************************************************

oc::System::File &
oc::System::File::operator=( const System::File & file )
{
    OCFATALCONT( "System::File::operator=( const System::File & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}


// *****************************************************************************
//
// Static methods:
//
//   System::File::CreateTempFile( const string & namePrefix,
//                                 const File   & directory )
//   System::File::GetTempFileDir()
//
// *****************************************************************************

oc::File
oc::System::File::CreateTempFile( const std::string & namePrefix,
                                  const oc::File   & directory)
{

    // The directory where we finally want to create the temp file.
    oc::File targetDir = oc::File::Null;

    // 1. User directory
    if( (! (directory == oc::File::Null)) &&
        (directory.IsDirectory()         ) &&
        (directory.IsWriteable()         ) ) {
        
        targetDir = directory;
    }

    // 2. System tmp directory
    else {

        targetDir = GetTempFileDir();

    }
    // No valid directory found => give it up
    if( targetDir == oc::File::Null ) {

	    return( targetDir );
    }

    // Create template name for mkstemp() function. The last six characters of
    // template name must be XXXXXX and these are replaced with a string that
    // makes the filename unique.

    char templateName[ oc::System::File::msMaxNameLength + 1 ];

    strncpy( templateName, targetDir.GetAbsoluteFile().c_str(),
	     oc::System::File::msMaxNameLength - namePrefix.size() - 7 );

    strcat( templateName, oc::File::GetSeparator().c_str() );
    strcat( templateName, namePrefix.c_str()                );
    strcat( templateName, "XXXXXX"                          );

    // Now create an empty temporary file
    oc::File result = oc::File::Null;

#ifdef WIN32
    char * fileName = _mktemp( templateName );

    if( fileName != (char *) NULL ) {

	FILE * fp = fopen( fileName, "w" );

	if( fp != (FILE *) NULL) {

	    result.Create( fileName );
	    fclose( fp );
	}
    }
#else
    int fd = mkstemp( templateName );

    // Initialize result file object and close temp file
    if( fd > 0 ) {

	result.Create( templateName );
	close( fd );
    }
#endif

    return( result );

} // System::File::CreateTempFile()



oc::File 
oc::System::File::GetTempFileDir()
{
    std::string value;
    oc::File    targetDir;

    // 1. System default temporary-directory
    if( System::Path::msTempDirectory.IsWriteable() ) {
        
        return System::Path::msTempDirectory;

    }

    // 2. TMP variable
    if( System::Env::GetProperty( std::string( "TMP"  ), value ) ) {
        
        targetDir = value;
        
        if( (targetDir.IsDirectory()) &&
            (targetDir.IsWriteable()) ) {
            return targetDir;
        }
    }

    // 3. TEMP variable
    if( System::Env::GetProperty( std::string( "TEMP" ), value ) ) {
        
        targetDir = value;
        
        if( (targetDir.IsDirectory()) ||
            (targetDir.IsWriteable()) ) {
            
            return targetDir;
        }
    }

    // 4. Current directory
    targetDir = System::Path::GetCurrentPath();
    
    if( targetDir.IsWriteable() ) {
        
        return targetDir;
    }

    return oc::File::Null;
}


// *****************************************************************************
// *****************************************************************************
//
// CLASS: System::Path
//
// *****************************************************************************
// *****************************************************************************




// *****************************************************************************
//
// Constructors:
//
//   System::Path::Path()
//   System::Path::Path( const System::Path & path )
//
// Destructor:
//
//   System::Path::~Path()
//
// *****************************************************************************


oc::System::Path::Path()
{
    OCFATALCONT( "System::Path::Path()" << newl );
    OCFATAL    ( "Default constructor of System::Path not allowed." );
}
   

oc::System::Path::Path( const System::Path & path )
{
    OCFATALCONT( "System::Path::Path( const Path & )" << newl );
    OCFATAL    ( "Copy constructor of System::Path not allowed." );
}


oc::System::Path::~Path()
{
    OCFATALCONT( "System::Path::~Path()" << newl );
    OCFATAL    ( "Destructor of System::Path not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   System::Path::operator=( const System::Path & path )
//
// *****************************************************************************

oc::System::Path &
oc::System::Path::operator=( const System::Path & path )
{
    OCFATALCONT( "System::Path::operator=( const System::Path & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}



// *****************************************************************************
//
// Static methods:
//
//   System::Path::GetCurrentPath()
//
// *****************************************************************************

std::string
oc::System::Path::GetCurrentPath()
    throw( oc::Errno )
{

    char currentPath[ oc::System::Path::msMaxNameLength ];

    if( getcwd( currentPath, oc::System::Path::msMaxNameLength ) == (char *)NULL )
	throw oc::Errno();

    return( std::string( (char *)currentPath ) );

} // System::Path::GetCurrentPath()





// *****************************************************************************
// *****************************************************************************
//
// CLASS: System::Env
//
// *****************************************************************************
// *****************************************************************************




// *****************************************************************************
//
// Constructors:
//
//   System::Env::Env()
//   System::Env::Env( const System::Env & env )
//
// Destructor:
//
//   System::Env::~Env()
//
// *****************************************************************************


oc::System::Env::Env()
{
    OCFATALCONT( "System::Env::Env()" << newl );
    OCFATAL    ( "Default constructor of System::Env not allowed." );
}
   

oc::System::Env::Env( const System::Env & env )
{
    OCFATALCONT( "System::Env::Env( const Env & )" << newl );
    OCFATAL    ( "Copy constructor of System::Env not allowed." );
}


oc::System::Env::~Env()
{
    OCFATALCONT( "System::Env::~Env()" << newl );
    OCFATAL    ( "Destructor of System::Env not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   System::Env::operator=( const System::Env & env )
//
// *****************************************************************************

oc::System::Env &
oc::System::Env::operator=( const System::Env & env )
{
    OCFATALCONT( "System::Env::operator=( const System::Env & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}



// *****************************************************************************
//
// Static Methods:
//
//   System::Env::GetProperty   ( const string & name,       string & value )
//   System::Env::SetProperty   ( const string & name, const string & value )
//   System::Env::RemoveProperty( const string & name )
//
// *****************************************************************************

bool
oc::System::Env::GetProperty( const std::string & name, std::string & value )
{

    // I am pessimist
    bool result = false;

    // Returns an empty string if variable doesn't exists
    value = "";

    // Empty environment variables make no sense
    if( ! name.empty() ) {

        // Query the environment list
        char * cvalue = getenv( name.c_str() );

        // Return found string
        if( cvalue != (char *)NULL ) {

            value  = cvalue;
            result = true;
        }
    }

    return( result );

} // System::Env::GetProperty( const string &, string &)



bool
oc::System::Env::SetProperty( const std::string & name, const std::string & value )
{

    // I am pessimist
    bool result = false;

    // Empty environment variables make no sense
    if( name.empty() ) {

        return( false );
    }

    // Set an already defined variable (overwrite = 1) or create a new variable
    // in the environment list. Fails if insufficient space in the environment.
#ifdef WIN32
    if( SetEnvironmentVariable( (LPCTSTR) name.c_str(),
                                (LPCTSTR) value.c_str() ) != 0 ) {
        result = true;
    }
#else
    if( setenv( name.c_str(), value.c_str(),
                1 /* overwrite if name already exists */ ) == 0 ) {
        result = true;
    }
#endif

    return( result );

} // System::Env::SetProperty( const string &, const string &)



bool
oc::System::Env::RemoveProperty( const std::string & name )
{

    // I am pessimist
    bool result = false;

    // Empty environment variables make no sense
    if( ! name.empty() ) {

        // Remove the variable from the environment list. unsetenv() returns
        // no status value, so it doesn't care about variable exists or not
        // or the variable could successfully removed from the environment.
#ifdef WIN32
        if( SetEnvironmentVariable( (LPCTSTR) name.c_str(), (LPCTSTR) NULL ) != 0 ) {
            result = true;
        }

#else

#  ifdef _AIX
        setenv(name.c_str(), (const char *) NULL, 1 )
#  else
        unsetenv( name.c_str() );
#  endif
        result = true;
#endif
    }

    return( result );

} // System::Env::RemoveProperty( const std::string & )








// *****************************************************************************
// *****************************************************************************
//
// CLASS: System::Net
//
// *****************************************************************************
// *****************************************************************************




// *****************************************************************************
//
// Constructors:
//
//   System::Net::Net()
//   System::Net::Net( const System::Net & net )
//
// Destructor:
//
//   System::Net::~Net()
//
// *****************************************************************************


oc::System::Net::Net()
{
    OCFATALCONT( "System::Net::Net()" << newl );
    OCFATAL    ( "Default constructor of System::Net not allowed." );
}
   

oc::System::Net::Net( const System::Net & net )
{
    OCFATALCONT( "System::Net::Net( const Net & )" << newl );
    OCFATAL    ( "Copy constructor of System::Net not allowed." );
}


oc::System::Net::~Net()
{
    OCFATALCONT( "System::Net::~Net()" << newl );
    OCFATAL    ( "Destructor of System::Net not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   System::Net::operator=( const System::Net & net )
//
// *****************************************************************************

oc::System::Net &
oc::System::Net::operator=( const System::Net & net )
{
    OCFATALCONT( "System::Net::operator=( const System::Net & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}



// *****************************************************************************
//
// Static Methods:
//
//   System::Net::GetHostname()
//   System::Net::GetOSName();
//
// *****************************************************************************

std::string
oc::System::Net::GetHostname()
{

    return InetAddress::GetLocalHost().GetHostName();
}



const std::string &
oc::System::Net::GetOSName()
{

#if   defined(WIN32)
    static std::string osName( "win32" );
#elif defined(_AIX)
    static std::string osName( "aix" );
#elif defined(MACOSX)
    static std::string osName( "macosx" );
#else
    static std::string osName( "linux" );
#endif

    return osName;
}


// *****************************************************************************
// *****************************************************************************
//
// CLASS: System::Directory
//
// *****************************************************************************
// *****************************************************************************


oc::System::Directory::Directory() 
{ // should never be called
}

oc::System::Directory::Directory( const oc::System::Directory & )
{ // should never be called
}

oc::System::Directory::~Directory()
{ // should never be called
}

oc::System::Directory& 
oc::System::Directory::operator=( const oc::System::Directory& )
{ // should never be called 
    return *this;
}

bool 
oc::System::Directory::CreateDir(std::string const& fullpath)
{
#ifdef WIN32
    return ( CreateDirectory(fullpath.c_str(),NULL) != 0 );
#else
    return ( mkdir( fullpath.c_str(), S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH ) == 0 );
#endif
    
    return false;
}

    
