
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Util.hh>
#include <oc/Log.hh>

// C include

#include <cctype>
#include <cstdio>

// C++ include

#include <algorithm>


// *****************************************************************************
// *****************************************************************************
//
// CLASS: Util
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   Util::Util()
//   Util::Util( const Util & util )
//   Util::operator=( const Util & util )
//
// Destructor:
//
//   Util::~Util()
//
// *****************************************************************************


oc::Util::Util()
{
    OCFATALCONT( "Util::Util()" << newl );
    OCFATAL    ( "Default constructor of Util not allowed." );
}
   

oc::Util::Util( const Util & util )
{
    OCFATALCONT( "Util::Util( const Util & )" << newl );
    OCFATAL    ( "Copy constructor of Util not allowed." );
}


oc::Util::~Util()
{
    OCFATALCONT( "Util::~Util()" << newl );
    OCFATAL    ( "Destructor of Util not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   Util::operator=( const Util & util )
//
// *****************************************************************************

oc::Util &
oc::Util::operator=( const Util & util )
{
    OCFATALCONT( "Util::operator=( const Util & )" << newl );
    OCFATAL    ( "Copy constructor of Util not allowed." );

    return( *this );
}



// *****************************************************************************
//
// Static methods:
//
//   Util::Tokenize( const std::string & s, char separator, bool allowEmptyTokens )
//   Util::Tokenize( const std::string & s, const std::string & separator, bool allowEmptyTokens )
//   Util::ToLower( std::string & s )
//   Util::ToLower( const std::string & s )
//   Util::ToUpper( std::string & s )
//   Util::ToUpper( const std::string & s )
//   Util::WidthInDigits()
//
// *****************************************************************************

std::vector<std::string>
oc::Util::Tokenize( const std::string & s, char separator, bool allowEmptyTokens )
{

    // The token array
    std::vector<std::string> tokens;

    // Start at the beginning of the string
    std::string::size_type last = 0;
    std::string::size_type next = 0;

    // Tokenize until no separator is left
    while( next != std::string::npos ) {

	// Find from the last position on the next separator
	next = s.find( separator, last );

	// Next separator found
	if( next != std::string::npos ) {

	    // Sequence of separators allowed?
	    if( ((next-last) >= 1) || allowEmptyTokens ) {

		// Add token to array
		tokens.push_back( s.substr( last, (next-last) ) );
	    }

	    // Step forward
	    last = next + 1;
	}
    }

    // Don't forget the last token if the string doesn't end with a separator
    if( last < s.size() ) {

	// Add last token to array
	tokens.push_back( s.substr( last ) );
    }

    return( tokens );

} // Util::Tokenize()




std::vector<std::string>
oc::Util::Tokenize( const std::string & s,
                    const std::string & separator,
                    bool allowEmptyTokens )
{
    // The token array
    std::vector<std::string> tokens;
    
    // Start at the beginning of the string
    std::string::size_type last = 0;
    std::string::size_type next = 0;
    
    // Tokenize until no separator is left
    while( next != std::string::npos ) {
        
        // Find from the last position on the next separator
        next = s.find_first_of( separator, last );
        
        // Next separator found
        if( next != std::string::npos ) {
            
            // Sequence of separators allowed?
            if( ((next-last) >= 1) || allowEmptyTokens ) {
                
                // Add token to array
                tokens.push_back( s.substr( last, (next-last) ) );
            }
            
            // Step forward
            last = next + 1;
        }
    }
    
    // Don't forget the last token if the string doesn't end with a separator
    if( last < s.size() ) {
        
        // Add last token to array
        tokens.push_back( s.substr( last ) );
    }
    
    return( tokens );
    
} // Util::Tokenize()



int
oc::Util::WidthInDigits( const int x )
{

    // do an unravelled binary search
    if( x < 10000 ) {
	if( x < 100 ) {
            if( x < 10 ) {
		return 1;
	    }
            else {
		return 2;
	    }
	}
	else {
            if( x < 1000 ) {
		return 3;
	    }
            else {
		return 4;
	    }
	}
    }

    else {
	if( x < 1000000 ) {
            if( x < 100000 ) {
		return 5;
	    }
            else {
		return 6;
	    }
	}
	else {
            if( x < 100000000 ) {
		if( x < 10000000 ) {
		    return 7;
		}
		else {
		    return 8;
		}
            }
	    else {
		if( x < 1000000000 ) {
		    return 9;
		}
		else {
		    return 10;
		}
	    }
	}
    }

} // Util::WidthInDigits()



std::string &
oc::Util::ToLower( std::string & s )
{

    std::transform( s.begin(),
		    s.end(),
		    s.begin(),
		    std::ptr_fun(::tolower) );

    return( s );
}



std::string 
oc::Util::ToLower( const std::string & s )
{

    std::string res(s.size(),' ');

    std::transform( s.begin(),
		    s.end(),
		    res.begin(),
		    std::ptr_fun(::tolower) );

    return( res );
}



std::string &
oc::Util::ToUpper( std::string & s )
{
    std::transform( s.begin(),
		    s.end(),
		    s.begin(),
		    std::ptr_fun(::toupper) );

    return( s );
}



std::string 
oc::Util::ToUpper( const std::string & s )
{

    std::string res(s.size(),' ');

    std::transform( s.begin(),
		    s.end(),
		    res.begin(),
                    std::ptr_fun(::toupper) );

    return( res );
}


bool 
oc::Util::ToBool( const std::string& s )
{
    
    std::string ls = oc::Util::ToLower(s);
    if( ls=="false" || ls=="0" || ls=="no") {
        return false;
    }
    return true;
}


bool 
oc::Util::IsDouble( std::string const& s)
{
    if( s.find('.') != std::string::npos ) {
        return true;
    }
    return false;
}

double 
oc::Util::ToDouble( std::string const& s )
{
    return oc::Util::ToDouble( s.c_str() );
}

double 
oc::Util::ToDouble( const char* s )
{
    return atof(s);
}

std::string 
oc::Util::ToString( double const& d )
{
    char buf[256];
    sprintf(buf,"%lf",d);
    return std::string(buf);
}

int
oc::Util::ToInt( std::string const& s )
{
    return oc::Util::ToInt( s.c_str() );
}

int 
oc::Util::ToInt( const char* s )
{
    return atoi(s);
}

std::string 
oc::Util::ToString(int const& i )
{
    char buf[256];
    sprintf(buf,"%d",i);
    return std::string(buf);
}


std::string 
oc::Util::ToStripped( std::string const& s )
{
    if( s.size() == 0 )
        return s;

    static char whitespaces[] = { 0x09,0x0A,0x0B,0x0C,0x0D,0x20,0x00 };
    char *ws;

    // is first-character a whitespace ?
    bool ws_leading = false; 
    ws = whitespaces;
    while( !ws_leading && *ws ) {
        ws_leading = (s[0] == *ws++ );
    }
    
    // is last-character a whitespace ?
    bool ws_trailing = false;
    ws = whitespaces;
    while( !ws_trailing && *ws ) {
        ws_trailing = (s[s.size()-1] == *ws++);
    }

    if( !ws_leading && !ws_trailing )
        return s;

    std::string::size_type pos0,pos1;
    if( ws_leading ) {
        pos0 = s.find_first_not_of( whitespaces );
    }
    else {
        pos0 = 0;
    }

    if( ws_trailing ) {
        pos1 = s.find_last_not_of( whitespaces );
    }
    else {
        pos1 = s.size()-1;
    }

    // string is made up of whitespaces only
    if( pos0 == std::string::npos ) { 
        return std::string("");
    }

    return s.substr(pos0,(pos1-pos0)+1);
}

std::string & 
oc::Util::ToStripped( std::string & s )
{
    s = ToStripped(const_cast<const std::string&>(s));
    return s;
}


