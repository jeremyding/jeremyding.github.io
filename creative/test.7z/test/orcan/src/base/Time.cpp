// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

#include <oc/Time.hh>
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>

#include <ctime>

#include <oc/config.h>

oc::Time::Time()
{
    mHour = 0;
    mMinute = 0;
    mSecond = 0;
}

oc::Time::~Time()
{
    
}

oc::Time::Time(int h, int m, int s)
{
    if( ! SetTime( h, m, s ) ) {

        mHour   = 0;
        mMinute = 0;
        mSecond = 0;
    }
}

oc::Time::Time(const std::string & t)
{
    SetTime(t);
}

oc::Time::Time(Time const & b)
{
    mHour = b.mHour;
    mMinute = b.mMinute;
    mSecond = b.mSecond;
}

oc::Time &
oc::Time::operator = (Time const & rhs)
{
    mHour = rhs.mHour;
    mMinute = rhs.mMinute;
    mSecond = rhs.mSecond;

    return *this;
}

bool
oc::Time::SetTime(const std::string & t)
{
    
    char pt1, pt2;
    std::istringstream dat(t);
    dat >> mHour >> pt1  >> mMinute >> pt2 >> mSecond;
    SetTime(mHour, mMinute, mSecond);
    return true;
}   

bool
oc::Time::SetTime(int hour, int minute, int second)
{
    if (hour<0)
        hour =-hour;
    
    if(hour>23) {
        mHour = 23;
    }
    else mHour = hour;

    if(minute < 0)
        minute =-minute;

    if(minute > 59) {
        mMinute = 59;
    }
    else mMinute = minute;
    
    if(second<0)
        second=-second;

    if(second > 59) {
        mSecond = 59;
    }
    else mSecond = second;

    if(mHour != hour || mMinute != minute || mSecond != second)
        return false;

    return true;
}

oc::Time &
oc::Time::SetSecondsOfDay(int n)
{
    n = n % 86400;
   
    if(n<0){
        n +=86400;
    }

    mHour = n / 3600;
    mMinute = (n%3600)/60;
    mSecond = (n%60);
    return *this;

}

int
oc::Time::GetSecondsOfDay() const
{
   return (mHour * 3600) + (mMinute * 60) + mSecond ;
}

int
oc::Time::GetHour() const
{
    return mHour;
}

int
oc::Time::GetMinute()const
{
    return mMinute;
}

int
oc::Time::GetSecond()const
{
    return mSecond;
}

std::ostream &
oc::operator<<(std::ostream & out , const oc::Time & b)
{
    out << std::setfill('0')
        << std::setw(2) << b.GetHour()   << ":"
        << std::setw(2) << b.GetMinute() << ":"
        << std::setw(2) << b.GetSecond();

    return out;
}
        
std::istream &
oc::operator>>(std::istream & in, oc::Time & time)
{
    int hour,minute,second;
    char dot1,dot2;
    
    in >> hour >> dot1 >> minute >> dot2 >> second;

    if(dot1 == ':' && dot2 == ':') {
        time.SetTime(hour, minute, second);
    }
       
    return in;
}

bool
oc::Time::operator>(oc::Time const & a)
{
    return GetSecondsOfDay() > a.GetSecondsOfDay();
}

bool
oc::Time::operator<(oc::Time const & a)
{
    return GetSecondsOfDay() < a.GetSecondsOfDay();
}

bool
oc::Time::operator==(oc::Time const & a)
{
    return GetSecondsOfDay() == a.GetSecondsOfDay();
}

bool
oc::Time::operator>=(oc::Time const & a)
{
    return GetSecondsOfDay() >= a.GetSecondsOfDay();
}

bool
oc::Time::operator<=(oc::Time const & a)
{
    return GetSecondsOfDay() <= a.GetSecondsOfDay();
}

oc::Time
oc::Time::operator + (int t)
{
    oc::Time tmp(*this);
    
    tmp.SetSecondsOfDay(GetSecondsOfDay() + t); 
    
    return tmp;
}

oc::Time
oc::Time::operator - (int t)
{
    oc::Time tmp(*this);
    tmp.SetSecondsOfDay(GetSecondsOfDay() - t); 
    
    return tmp;
    
}

oc::Time &
oc::Time::operator +=(int t)
{
   return SetSecondsOfDay(GetSecondsOfDay() + t);
}

oc::Time &
oc::Time::operator -=(int t)
{
    return SetSecondsOfDay(GetSecondsOfDay() - t);
}

oc::Time
oc::Time::GetCurrent()
{

    time_t t;

    time( & t );

    struct tm * current_time = localtime( & t );

    oc::Time d( current_time->tm_hour,
                current_time->tm_min,
                current_time->tm_sec );
    return d;

}

oc::Time &
oc::Time::operator++()
{
    SetSecondsOfDay(GetSecondsOfDay()+1);
    return *this;
}

oc::Time
oc::Time::operator++(int)
{   
    oc::Time tmp( *this);
    ++(*this);
    return tmp;
    
}

oc::Time &
oc::Time::operator--()
{
    SetSecondsOfDay(GetSecondsOfDay()-1);

    return *this;
}

oc::Time
oc::Time::operator--(int)
{
    oc::Time tmp( *this);
    --(*this);
    return tmp;
}
