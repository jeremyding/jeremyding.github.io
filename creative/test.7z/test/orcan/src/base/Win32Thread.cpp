
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

#include <oc/Log.hh>
#include <oc/win32Thread.hh>

oc::Win32Thread::Win32Thread() 
    : mPriority100(50)
{
}

DWORD WINAPI 
oc::Win32Thread::RunMe(void *arg)
{
    Win32Thread *timpl = (Win32Thread *)arg;
    if( timpl->CallThreadMethod() ) {
        return 1;
    }
    return 0;
}

bool 
oc::Win32Thread::CallThreadMethod()
{
    if( mThreader == NULL )
        return false;

    return mThreader->Run();
}

oc::Win32Thread::Win32Thread( oc::Threader *threader )
    : mThreader( threader )
    , mIsRunning(false)
    , mThreadHandle(0)
    , mThreadID(0)
{
}

oc::Win32Thread::~Win32Thread()
{
    Cleanup();
}


void 
oc::Win32Thread::Cleanup()
{
    if( mThreadHandle != 0 ) {
        
        if( IsAlive() ) {
            Kill();
        }
        
        CloseHandle(mThreadHandle);
        mThreadHandle = 0;
        mThreadID = 0;
        mIsRunning = false;
    }
}

bool 
oc::Win32Thread::CreateAndSuspend()
{
    if( mThreadHandle != 0 ) {
        Cleanup();
    }
    
    mThreadHandle = ::CreateThread(NULL,8192,Win32Thread::RunMe,
                                   (LPVOID)this,CREATE_SUSPENDED, &mThreadID );   
    
    if( mThreadHandle == 0 ) {
        OCERROR( "Could not create thread" );
        return false;
    }

    if( mPriority100 != 50 ) {
        SetPriority(mPriority100);
    }
    
    mIsRunning   = false;
    return true;
}

bool 
oc::Win32Thread::Suspend()
{
    // get suspendresume-count
    DWORD ret = ::SuspendThread(mThreadHandle);
    
    if( ret == (DWORD)-1 ) {
        OCERROR("Can not suspend thread "<< mThreadID);
        return false;
    }
    
    mIsRunning = false;
    
    return true;
}


bool 
oc::Win32Thread::Resume()
{
    // get suspendresume-count
    DWORD ret = ::ResumeThread(mThreadHandle);
    
    if( ret == (DWORD)-1 ) {
        OCERROR("Can not resume thread "<< mThreadID);
        return false;
    }
    
    if( ret <= 1 ) {
        mIsRunning = true;
    }
    else {
        mIsRunning = false;
    }
    return true;
}

bool 
oc::Win32Thread::Wait()
{
    if( ::WaitForSingleObject(mThreadHandle, INFINITE) != WAIT_OBJECT_0 ) {
        return false;
    }
    return true;
}

bool 
oc::Win32Thread::Kill()
{
    if(::TerminateThread(mThreadHandle, (DWORD)0) ) {
        return true;
    }
    return false;
}


bool
oc::Win32Thread::SetPriority(uint32 priority100)
{

    int p;
    if (priority100 <= 20)
        p = THREAD_PRIORITY_LOWEST;
    else if (priority100 <= 40)
        p = THREAD_PRIORITY_BELOW_NORMAL;
    else if (priority100 <= 60)
        p = THREAD_PRIORITY_NORMAL;
    else if (priority100 <= 80)
        p = THREAD_PRIORITY_ABOVE_NORMAL;
    else if (priority100 <= 100)
        p = THREAD_PRIORITY_HIGHEST;
    else
        p = THREAD_PRIORITY_NORMAL;


    if ( !::SetThreadPriority(mThreadHandle, p) ) {
        OCERROR("Can't set thread priority");
        mPriority100 = 101;
        return false;
    }
    mPriority100 = p;
    return true;
}

uint32 
oc::Win32Thread::GetPriority()
{
    return mPriority100;
}


bool 
oc::Win32Thread::IsRunning()
{
    return mIsRunning;
}

bool 
oc::Win32Thread::IsSuspended()
{
    return !mIsRunning;
}

bool 
oc::Win32Thread::IsAlive()
{
    DWORD ret;
    if( !::GetExitCodeThread( mThreadHandle, &ret ) ){
        OCERROR("Unable to get thread status");
        return false;
    }
    
    if( ret == STILL_ACTIVE ) {
        return true;
    }
    
    return false;
}



