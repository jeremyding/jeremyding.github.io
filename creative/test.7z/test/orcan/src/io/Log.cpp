// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/Util.hh>
#include <oc/Term.hh>

// C++ include

#include <sstream>

// C include

#include <cassert>

// Windows include
#ifdef WIN32
#include <windows.h>
#include <conio.h>
#endif





/* =============================
 * Log::ColorToEscSeq()
 * ============================= */

void
oc::Log::ColorToEscSeq()
{


    switch( GetColor() ) {

    case Log::RED:

	mColorEscSeq = oc::Term::EscSeq::msFgRed;
	break;

    case Log::GREEN:

	mColorEscSeq = oc::Term::EscSeq::msFgGreen;
	break;

    case Log::YELLOW:

	mColorEscSeq = oc::Term::EscSeq::msFgYellow;
	break;

    case Log::BLUE:
	    
	mColorEscSeq = oc::Term::EscSeq::msFgBlue;
	break;

    case Log::CYAN:
	    
	mColorEscSeq = oc::Term::EscSeq::msFgCyan;
	break;

    case Log::MAGENTA:

	mColorEscSeq = oc::Term::EscSeq::msFgMagenta;
	break;

    case Log::WHITE:

	mColorEscSeq = oc::Term::EscSeq::msFgWhite;
	break;

    case Log::BLACK:

	mColorEscSeq = oc::Term::EscSeq::msFgBlack;
	break;

    case Log::NORMAL:
	// Fall thru
    default:

	mColorEscSeq = oc::Term::EscSeq::msNormal;
	break;
    }

} // Log::ColorToEscSeq()


#ifdef WIN32
/* =============================
 * Log::Win32SetTextColor()
 * ============================= */

void
oc::Log::Win32SetTextColor(bool enable)
{
	HANDLE hcon = NULL;

	if( mOut == std::cerr )
	{
		hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	}
	else if ( mOut == std::cout )
	{
		hcon = GetStdHandle(STD_ERROR_HANDLE);
	}
	else
		return;

	if(!hcon)
		return;

	if(!enable) 
	{
		SetConsoleTextAttribute(hcon, 7);
		return;
	}

    switch( GetColor() ) {

    case Log::RED:
	SetConsoleTextAttribute(hcon, 12);
	break;

    case Log::GREEN:
	SetConsoleTextAttribute(hcon, 10);
	break;

    case Log::YELLOW:
	SetConsoleTextAttribute(hcon, 14);
	break;

    case Log::BLUE:
	SetConsoleTextAttribute(hcon, 9);
	break;

    case Log::CYAN:
	SetConsoleTextAttribute(hcon, 11);
	break;

    case Log::MAGENTA:
	SetConsoleTextAttribute(hcon, 13);
	break;

    case Log::WHITE:
	SetConsoleTextAttribute(hcon, 15);
	break;

    case Log::BLACK:
	SetConsoleTextAttribute(hcon, 7);
	break;

    case Log::NORMAL:
	// Fall thru
    default:

	SetConsoleTextAttribute(hcon, 7);
	break;
    }
} // Log::Win32SetTextColor()

#endif // WIN32


/* =============================
 * Log::PrintPrefix()
 * ============================= */

void
oc::Log::PrintPrefix()
{

    // The indent with spaces as width as the prefix string.
    static std::string indent;

    // Print 'normal' prefix
    // ---------------------
    if( mPrintPrefix ) {

        int prefixLength = 0;

        if( mPrefixEnabled ) {

            // Print the prefix
	    if( mColorEnabled ) {
#ifdef WIN32
			Win32SetTextColor(true);
			mOut << mPrefix << ' ';
			Win32SetTextColor(false);
#else
			mOut << mColorEscSeq << mPrefix << ' ';
#endif
	    }
	    else {
		mOut << mPrefix << ' ';
	    }

            // Calculate prefix length    
            prefixLength += mPrefix.size() + 1;
        }

        if( mPositionEnabled ) {

	    // Print the position
	    if( mColorEnabled ) {
#ifdef WIN32
			Win32SetTextColor(true);
			mOut << '[' << mFileName << ',' << mLineNumber << "] ";
			Win32SetTextColor(false);
#else
		mOut << mColorEscSeq << '[' << mFileName << ',' << mLineNumber << "] ";
#endif
	    }
	    else {
		mOut << '[' << mFileName << ',' << mLineNumber << "] ";
	    }

	    // Calculate position length
	    prefixLength += mFileName.size()                   +
                Util::WidthInDigits( mLineNumber ) +
                4;

	}

        // Do not print 'normal' prefix until 'endl' manipulator is used
        mPrintPrefix = false;

        // Assign spaces to indent string
        indent.assign( prefixLength, ' ' );
    }

    // Print only indent spaces
    // ------------------------
    else if( mPrintIndent ) {

	mOut << indent;

        mPrintIndent = false;
    }


} // Log::PrintPrefix()
    



/* =============================
 * Log::Log()
 * ============================= */

oc::Log::Log()
    : mOut( std::cerr ),
      mPrefix(),
      mFileName(),
      mLineNumber(),
      mColor( oc::Log::BLACK ),
      mColorEscSeq( oc::Term::EscSeq::msFgBlack ),
      mPrintPrefix( true ),
      mPrintIndent( false ),
      mEnabled( true ),
      mPrefixEnabled( true ),
      mPositionEnabled( true ),
      mColorEnabled( true )
{

    // Intentional left empty

} // Log::Log()

    

/* =============================
 * Log::Log()
 * ============================= */

oc::Log::Log( std::ostream      & out,
                const std::string & prefix,
                mtColor             color,
                bool                enablePrefix )
    : mOut          ( out ),
      mPrefix       ( prefix ),
      mFileName     (),
      mLineNumber   (),
      mColor        ( color ),
      mPrintPrefix  ( true ),
      mPrintIndent  ( false ),
      mEnabled      ( true ),
      mPrefixEnabled( enablePrefix ),
      mPositionEnabled( true ),
      mColorEnabled ( true )
{

    ColorToEscSeq();

} // Log::Log()

    

/* =============================
 * Log::Log()
 * ============================= */

oc::Log::Log( const Log & log )
    : mOut            ( log.mOut           ),
      mPrefix         ( log.mPrefix        ),
      mFileName       ( log.mFileName      ),
      mLineNumber     ( log.mLineNumber    ),
      mColor          ( log.mColor         ),
      mColorEscSeq    ( log.mColorEscSeq   ),
      mPrintPrefix    ( log.mPrintPrefix   ),
      mPrintIndent    ( log.mPrintIndent   ),
      mEnabled        ( log.mEnabled       ),
      mPrefixEnabled  ( log.mPrefixEnabled ),
      mPositionEnabled( log.mPositionEnabled ),
      mColorEnabled   ( log.mColorEnabled  )
{

    // Intentional left empty

} // Log::Log()

    

/* =============================
 * Log::~Log()
 * ============================= */

oc::Log::~Log()
{

    // Intentional left empty

} // Log::~Log()
    

/* =============================
 * Log::Enable()
 * ============================= */

void
oc::Log::Enable( bool enable )
{

    mEnabled = enable;

} // Log::Enable()
    

/* =============================
 * Log::IsEnabled()
 * ============================= */

bool
oc::Log::IsEnabled() const
{

    return( mEnabled );

} // Log::IsEnabled()
    

/* =============================
 * Log::EnablePrefix()
 * ============================= */

void
oc::Log::EnablePrefix( bool enable )
{

    mPrefixEnabled = enable;

} // Log::EnablePrefix()
    

/* =============================
 * Log::IsPrefixEnabled()
 * ============================= */

bool
oc::Log::IsPrefixEnabled() const
{

    return( mPrefixEnabled );

} // Log::IsPrefixEnabled()


/* =============================
 * Log::EnablePosition()
 * ============================= */

void
oc::Log::EnablePosition( bool enable )
{

    mPositionEnabled = enable;

} // Log::EnablePosition()


/* =============================
 * Log::IsPositionEnabled()
 * ============================= */

bool
oc::Log::IsPositionEnabled() const
{

    return( mPositionEnabled );

} // Log::IsPositionEnabled()


/* =============================
 * Log::EnableColor()
 * ============================= */

void
oc::Log::EnableColor( bool enable )
{

    mColorEnabled = enable;

    ColorToEscSeq();

} // Log::EnableColor()


/* =============================
 * Log::IsColorEnabled()
 * ============================= */

bool
oc::Log::IsColorEnabled() const
{

    return( mColorEnabled );

} // Log::IsColorEnabled()





/* =============================
 * Log::SetMessagePos()
 * ============================= */

bool
oc::Log::SetMessagePos( const char * fileName, int lineNumber )
{

    assert( fileName   != NULL );
    assert( lineNumber  > 0    );

    // Check for valid parameters.
    if( (fileName   == NULL) ||
	(lineNumber <= 0   ) ) {

	return( false );
    }

    // Set new attributes.
    mFileName   = fileName;
#ifdef WIN32
    std::string::size_type pos;
    if( (pos=mFileName.find_last_of('\\')) != std::string::npos ) {
        if( pos != mFileName.size() ) {
            mFileName = mFileName.substr(pos);
        }
    }
#endif
    mLineNumber = lineNumber;
    
    return( true );

} // Log::SetMessagePos()


/* =============================
 * Log::SetColor()
 * ============================= */

void
oc::Log::SetColor( mtColor color )
{

    // Set new attribute.
    mColor = color;

    // Set the color escape sequence attribute.
    ColorToEscSeq();

} // Log::SetColor()



/* =============================
 * Log::GetColor()
 * ============================= */

oc::Log::mtColor
oc::Log::GetColor() const
{

    return( mColor );

} // Log::GetColor()



/* =============================
 * Log::SetPrefix()
 * ============================= */

void
oc::Log::SetPrefix( const std::string & prefix )
{

    mPrefix = prefix;

} // Log::SetPrefix()



/* =============================
 * Log::GetPrefix()
 * ============================= */

const std::string &
oc::Log::GetPrefix() const
{

    return( mPrefix );

} // Log::GetPrefix()



/* =============================
 * Log::operator<<( manip )
 * ============================= */

oc::Log &
oc::Log::operator<<( Log & (*manip)( Log & ) )
{

    return( (*manip)(*this) );

}



/* =============================
 * endm()
 * ============================= */

oc::Log &
oc::endm( oc::Log & log )
{
    if( log.IsEnabled() ) {

	// Print new line and flush output stream.
	log.mOut.put( '\n' );
	log.mOut.flush();

	// Next time we have to print the prefix first.
	log.mPrintPrefix = true;
	log.mPrintIndent = false;
    }

    return( log );

} // endm()



/* =============================
 * newl()
 * ============================= */

oc::Log &
oc::newl( oc::Log & log )
{
    if( log.IsEnabled() ) {

	// Print new line and flush output stream.
	log.mOut.put( '\n' );
	log.mOut.flush();

	// Next time we have to print the prefix first.
	log.mPrintPrefix = false;
	log.mPrintIndent = true;
    }

    return( log );

} // newl()



/* =============================
 * flush()
 * ============================= */

oc::Log &
oc::flush( oc::Log & log )
{
    log.mOut.flush();

    return( log );

} // flush()









// *****************************************************************************
//
// ===========
// CLASS: LogG
// ===========
//
// *****************************************************************************


oc::LogG::~LogG()
{
    // Intentional left empty
}


oc::Log &
oc::LogG::Fatal()
{
    static Log fatal( std::cerr, std::string( "FATAL" ), oc::Log::RED, true );

    return( fatal );
}



oc::Log &
oc::LogG::Error()
{
    static Log error( std::cerr, std::string( "ERROR" ), oc::Log::RED, true );

    return( error );
}



oc::Log &
oc::LogG::Warn()
{
    static Log warn( std::cerr, std::string( "WARN " ), oc::Log::YELLOW, true );

    return( warn );
}



oc::Log &
oc::LogG::Info()
{
    static Log info( std::cerr, std::string( "INFO " ), oc::Log::GREEN, true );

    return( info );
}



oc::Log &
oc::LogG::Debug()
{
    static Log debug( std::cout, std::string( "DEBUG" ), oc::Log::CYAN, true );

    return( debug );
}



