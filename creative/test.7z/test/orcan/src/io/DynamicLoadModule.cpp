
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/File.hh>
#include <oc/config.h>
#include <oc/DynamicLoadModule.hh>

// C include

#include <cassert>

#ifndef WIN32
#  include <dlfcn.h>
#endif




// *****************************************************************************
// *****************************************************************************
//
// CLASS: DynamicLoadModule
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   DynamicLoadModule()
//   DynamicLoadModule( const oc::File & moduleFile )
//   DynamicLoadModule( const std::string & moduleFile )
//   DynamicLoadModule( const DynamicLoadModule & source )
//
// Destructor:
//
//   ~DynamicLoadModule()
//
// *****************************************************************************

oc::DynamicLoadModule::DynamicLoadModule()
    : mModuleHandle( NULL ),
      mModuleFile(),
      mSymbolTable()
{
    // Intentional left empty
}



oc::DynamicLoadModule::DynamicLoadModule( const oc::File & moduleFile )
    : mModuleHandle( NULL ),
      mModuleFile( moduleFile.GetAbsoluteFile() ),
      mSymbolTable()
{
    LoadModule();
}



oc::DynamicLoadModule::DynamicLoadModule( const std::string & moduleFile )
    : mModuleHandle( NULL ),
      mModuleFile( moduleFile ),
      mSymbolTable()
{
    LoadModule();
}



oc::DynamicLoadModule::DynamicLoadModule( const DynamicLoadModule & source )
    : mModuleHandle( source.mModuleHandle ),
      mModuleFile  ( source.mModuleFile   ),
      mSymbolTable ( source.mSymbolTable  )
{
    // Intentional left empty
}



oc::DynamicLoadModule::~DynamicLoadModule()
{
    UnloadModule();
}



// *****************************************************************************
//
// Creators:
//
//   Create( const oc::File   & moduleFile )
//   Create( const std::string & moduleFile )
//
// *****************************************************************************

bool
oc::DynamicLoadModule::Create( const oc::File & moduleFile )
{

    // Do not use this method if the instance is already initialized and
    // the corresponding module file is loaded.
    if( IsLoaded() ) {

	OCDEBUG( "Instance already initialized with module file \""
                   << moduleFile.GetAbsoluteFile()
                   << "\"" );
	return( false );
    }

    // Save the filename of the module
    mModuleFile = moduleFile.GetAbsoluteFile();

    // Load the module and return status
    return( LoadModule() );
}

bool
oc::DynamicLoadModule::Create( const std::string & moduleFile )
{

    // Do not use this method if the instance is already initialized and
    // the corresponding module file is loaded.
    if( IsLoaded() ) {

	OCDEBUG( "Instance already initialized with module file \""
                   << mModuleFile
                   << "\"" );
	return( false );
    }

    // Save the filename of the module
    mModuleFile = moduleFile;

    // Load the module and return status
    return( LoadModule() );
}




// *****************************************************************************
//
// Operators:
//
//   operator=( const DynamicLoadModule & source )
//
// *****************************************************************************

oc::DynamicLoadModule &
oc::DynamicLoadModule::operator=( const DynamicLoadModule & source )
{

    mModuleHandle = source.mModuleHandle;

    mModuleFile   = source.mModuleFile;

    mSymbolTable  = source.mSymbolTable;

    return( *this );

}

// *****************************************************************************
//
// Getters / Setters:
//
//   GetModuleFile()
//   GetSymbol()
//   GetSymbol() const
//   GetModuleHandle()
//
// *****************************************************************************

const oc::File &
oc::DynamicLoadModule::GetModuleFile() const
{
    return( mModuleFile );
}



oc::DynamicLoadModule::tSymbolPtr
oc::DynamicLoadModule::GetSymbol( const std::string & symbolName )
{

    // Module not loaded
    // -----------------
    if( ! IsLoaded() ) {

        OCWARN( "Module \""
                  << GetModuleFile()
                  << "\" not loaded." );
        return( tSymbolPtr::NullPtr );
    }

    // Because of the caching of already found symbols the lookup will be done
    // in two steps:
    // 1. Lookup in the symbol table mSymbolTable for already found symbols
    //    and if not found
    // 2. Lookup in the module symbol table of the system and save found symbol
    //    in local table mSymbolTable
    // ------------------------------------------------------------------------
    tSymbolPtr symbolPtr = tSymbolPtr::NullPtr;

    // 1. Lookup the symbol in the local symbol table
    OCDEBUGCONT( "Looking for symbol \""
                   << symbolName
                   << "\" ... " );

    tSymbolTable::iterator pos = mSymbolTable.find( symbolName );

    if( pos != mSymbolTable.end() ) {

        OCDEBUG( "cached" );

        symbolPtr = pos->second;
    }

    // 2. Lookup the symbol in the module's symbol table
    else {
#ifdef WIN32
        symbolPtr = (tSymbol *) GetProcAddress( GetModuleHandle(), symbolName.c_str() );
#else
#  ifdef HAVE_LIBDL
        symbolPtr = (tSymbol *) dlsym( GetModuleHandle(), symbolName.c_str() );
#  else
        OCERRORCONT( "No dynamic library loading support available." );
        OCERRORCONT( "Please run configure to enable dynamic library loading." );
        OCERROR( "See --with-libdl flags for the configure script.");
#  endif
#endif

        // Symbol found, save it in the local symbol table
        if( symbolPtr != tSymbolPtr::NullPtr ) {
            OCDEBUG( "found" );

            mSymbolTable[symbolName] = symbolPtr;
        }

        // Not found
        else {
            OCDEBUGCONT( "not found" << oc::newl );
#ifdef WIN32
            OCDEBUG( "system message: " << GetLastError() );
#else
#  ifdef HAVE_LIBDL
            OCDEBUG( "system message: " << dlerror() );
#  endif
#endif
        }
    }

    return( symbolPtr );
}



oc::DynamicLoadModule::tSymbolPtr
oc::DynamicLoadModule::GetSymbol( const std::string & symbolName ) const
{

    // Module not loaded
    // -----------------
    if( ! IsLoaded() ) {

        OCWARN( "Module \""
                  << GetModuleFile()
                  << "\" not loaded." );
        return( tSymbolPtr::NullPtr );
    }

    // Because of the caching of already found symbols the lookup will be done
    // in two steps:
    // 1. Lookup in the symbol table mSymbolTable for already found symbols
    //    and if not found
    // 2. Lookup in the module symbol table of the system and save found symbol
    //    in local table mSymbolTable
    // ------------------------------------------------------------------------
    tSymbolPtr symbolPtr = tSymbolPtr::NullPtr;

    // 1. Lookup the symbol in the local symbol table
    OCDEBUGCONT( "Looking for symbol \""
                   << symbolName
                   << "\" ... " );

    tSymbolTable::const_iterator pos = mSymbolTable.find( symbolName );

    if( pos != mSymbolTable.end() ) {

        OCDEBUG( "cached" );

        symbolPtr = pos->second;
    }

    // 2. Lookup the symbol in the module's symbol table
    else {
#ifdef WIN32
        symbolPtr = (tSymbol *) GetProcAddress( GetModuleHandle(), symbolName.c_str() );
#else
#  ifdef HAVE_LIBDL
        symbolPtr = (tSymbol *) dlsym( GetModuleHandle(), symbolName.c_str() );
#  else
        OCERRORCONT( "No dynamic library loading support available." );
        OCERRORCONT( "Please run configure to enable dynamic library loading." );
        OCERROR( "See --with-libdl flags for the configure script.");
#  endif
#endif

        // Symbol found
        if( symbolPtr != tSymbolPtr::NullPtr ) {

            OCDEBUG( "found" );
        }

        // Not found
        else {

            OCDEBUGCONT( "not found" << oc::newl );
#ifdef WIN32
            OCDEBUG    ( "system message: " << GetLastError() );
#else
#  ifdef HAVE_LIBDL
            OCDEBUG    ( "system message: " << dlerror() );
#  endif
#endif
        }
    }

    return( symbolPtr );
}


const oc::DynamicLoadModule::tModuleHandle &
oc::DynamicLoadModule::GetModuleHandle() const
{
    return( mModuleHandle );
}


// *****************************************************************************
//
// Helpers:
//
//   LoadModule()
//   UnloadModule()
//
// *****************************************************************************


bool
oc::DynamicLoadModule::LoadModule()
{

    // Module already loaded
    // --------------------

    if( IsLoaded() ) {

	OCDEBUG( "Module \""
                   << GetModuleFile()
                   << "\" already loaded." );
	return true;
    }

    // Try to load the module via dlopen()/LoadLibrary()
    // see Compat.hh
    // -------------------------------------------------

    OCDEBUGCONT( "Loading module \""
                   << GetModuleFile()
                   << "\" ... " );

#ifdef WIN32
    mModuleHandle = LoadLibrary( GetModuleFile().GetAbsoluteFile().c_str() );
#else
#  ifdef HAVE_LIBDL
    mModuleHandle = dlopen( GetModuleFile().GetAbsoluteFile().c_str(), RTLD_NOW );
#  else
    OCERRORCONT( "No dynamic library loading support available." );
    OCERRORCONT( "Please run configure to enable dynamic library loading." );
    OCERROR( "See --with-libdl flags for the configure script.");
#  endif
#endif

    // Failed to load
    if( mModuleHandle == (tModuleHandle) NULL ) {

	OCDEBUG( "failed" );

	OCWARNCONT( "Can't load module \""
                      << GetModuleFile()
                      << "\""
                      << oc::newl );
#ifdef WIN32
        OCWARN( "system message: " << GetLastError() );
#else
#  ifdef HAVE_LIBDL
        OCWARN( "system message: " << dlerror() );
#  endif
#endif
	return false;
    }
    // Successful loaded
    else{

	OCDEBUG( "ok" );
    }

    return true;

} // DynamicLoadModule::LoadModule()



bool
oc::DynamicLoadModule::UnloadModule()
{

    // Module not loaded
    // -----------------
    if( ! IsLoaded() ) {

	OCDEBUG( "Module \""
                   << GetModuleFile()
                   << "\" not loaded." );
	return true;
    }

    // Try to unload module
    // --------------------
    OCDEBUGCONT( "Unloading module \""
                   << GetModuleFile()
                   << "... " );
#ifdef WIN32
    FreeLibrary( GetModuleHandle() );
#else
#  ifdef HAVE_LIBDL
    dlclose( GetModuleHandle() );
#  else
    OCERRORCONT( "No dynamic library loading support available." );
    OCERRORCONT( "Please run configure to enable dynamic library loading." );
    OCERROR( "See --with-libdl flags for the configure script.");   
#  endif
#endif

    mModuleHandle = (tModuleHandle) NULL;

    OCDEBUG( "ok" );

    // Clear symbol table
    // ------------------
    mSymbolTable.clear();

    return true;

} // DynamicLoadModule::UnloadModule()



// *****************************************************************************
//
// Query Methods:
//
//   IsLoaded() const
//
// *****************************************************************************

bool
oc::DynamicLoadModule::IsLoaded() const
{

    return( GetModuleHandle() != (tModuleHandle) NULL );
}


