
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Term.hh>
#include <oc/Log.hh>


// CLASS STATIC
// ============

// Term::EscSeq for Windows

#ifdef WIN32

const std::string oc::Term::EscSeq::msFgGrey    = "";
const std::string oc::Term::EscSeq::msFgRed     = "";
const std::string oc::Term::EscSeq::msFgGreen   = "";
const std::string oc::Term::EscSeq::msFgYellow  = "";
const std::string oc::Term::EscSeq::msFgBlue    = "";
const std::string oc::Term::EscSeq::msFgMagenta = "";
const std::string oc::Term::EscSeq::msFgCyan    = "";
const std::string oc::Term::EscSeq::msFgWhite   = "";
const std::string oc::Term::EscSeq::msFgBlack   = "";

const std::string oc::Term::EscSeq::msBgGrey    = "";
const std::string oc::Term::EscSeq::msBgRed     = "";
const std::string oc::Term::EscSeq::msBgGreen   = "";
const std::string oc::Term::EscSeq::msBgYellow  = "";
const std::string oc::Term::EscSeq::msBgBlue    = "";
const std::string oc::Term::EscSeq::msBgMagenta = "";
const std::string oc::Term::EscSeq::msBgCyan    = "";
const std::string oc::Term::EscSeq::msBgWhite   = "";
const std::string oc::Term::EscSeq::msBgBlack   = "";


const std::string oc::Term::EscSeq::msBlinking  = "";
const std::string oc::Term::EscSeq::msUnderline = "";
const std::string oc::Term::EscSeq::msNormal    = "";

// #ifdef WIN32
#else

// Term::EscSeq for Unix

const std::string oc::Term::EscSeq::msFgGrey    = "\033[1;30m";
const std::string oc::Term::EscSeq::msFgRed     = "\033[1;31m";
const std::string oc::Term::EscSeq::msFgGreen   = "\033[1;32m";
const std::string oc::Term::EscSeq::msFgYellow  = "\033[1;33m";
const std::string oc::Term::EscSeq::msFgBlue    = "\033[1;34m";
const std::string oc::Term::EscSeq::msFgMagenta = "\033[1;35m";
const std::string oc::Term::EscSeq::msFgCyan    = "\033[1;36m";
const std::string oc::Term::EscSeq::msFgWhite   = "\033[1;37m";
const std::string oc::Term::EscSeq::msFgBlack   = "\033[1;38m";

const std::string oc::Term::EscSeq::msBgGrey    = "\033[1;47m";
const std::string oc::Term::EscSeq::msBgRed     = "\033[1;41m";
const std::string oc::Term::EscSeq::msBgGreen   = "\033[1;42m";
const std::string oc::Term::EscSeq::msBgYellow  = "\033[1;43m";
const std::string oc::Term::EscSeq::msBgBlue    = "\033[1;44m";
const std::string oc::Term::EscSeq::msBgMagenta = "\033[1;45m";
const std::string oc::Term::EscSeq::msBgCyan    = "\033[1;46m";
const std::string oc::Term::EscSeq::msBgWhite   = "\033[1;39m";
const std::string oc::Term::EscSeq::msBgBlack   = "\033[1;40m";


const std::string oc::Term::EscSeq::msBlinking  = "\033[1;5m";
const std::string oc::Term::EscSeq::msUnderline = "\033[1;4m";
const std::string oc::Term::EscSeq::msNormal    = "\033[0;0m";

#endif







// *****************************************************************************
// *****************************************************************************
//
// CLASS: Term
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   Term::Term()
//   Term::Term( const Term & term )
//
// Destructor:
//
//   Term::~Term()
//
// *****************************************************************************


oc::Term::Term()
{
    OCFATALCONT( "Term::Term()" << newl );
    OCFATAL    ( "Default constructor of Term not allowed." );
}
   

oc::Term::Term( const Term & term )
{
    OCFATALCONT( "Term::Term( const Term & )" << newl );
    OCFATAL    ( "Copy constructor of Term not allowed." );
}


oc::Term::~Term()
{
    OCFATALCONT( "Term::~Term()" << newl );
    OCFATAL    ( "Destructor of Term not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   Term::operator=( const Term & term )
//
// *****************************************************************************

oc::Term &
oc::Term::operator=( const oc::Term & term )
{
    OCFATALCONT( "Term::operator=( const Term & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}







// *****************************************************************************
// *****************************************************************************
//
// CLASS: Term::EscSeq
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   Term::EscSeq::EscSeq()
//   Term::EscSeq::EscSeq( const Term::EscSeq & escSeq )
//
// Destructor:
//
//   Term::EscSeq::~EscSeq()
//
// *****************************************************************************


oc::Term::EscSeq::EscSeq()
{
    OCFATALCONT( "Term::EscSeq::EscSeq()" << newl );
    OCFATAL    ( "Default constructor of Term::EscSeq not allowed." );
}
   

oc::Term::EscSeq::EscSeq( const Term::EscSeq & escSeq )
{
    OCFATALCONT( "Term::EscSeq::EscSeq( const EscSeq & )" << newl );
    OCFATAL    ( "Copy constructor of Term::EscSeq not allowed." );
}


oc::Term::EscSeq::~EscSeq()
{
    OCFATALCONT( "Term::EscSeq::~EscSeq()" << newl );
    OCFATAL    ( "Destructor of Term::EscSeq not allowed." );
}




// *****************************************************************************
//
// Access operators:
//
//   Term::EscSeq::operator=( const Term::EscSeq & escSeq )
//
// *****************************************************************************

oc::Term::EscSeq &
oc::Term::EscSeq::operator=( const Term::EscSeq & escSeq )
{
    OCFATALCONT( "Term::EscSeq::operator=( const Term::EscSeq & )" << newl );
    OCFATAL    ( "Assigment not allowed." );

    return( *this );
}



