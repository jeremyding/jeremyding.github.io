
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>
#include <oc/Errno.hh>
#include <oc/Log.hh>
#include <oc/System.hh>
#include <oc/Util.hh>
#include <oc/DirectoryStream.hh>

// C++ include

#include <algorithm>

// C include

#include <cctype>
#include <cstdio>
#include <cassert>
#include <cerrno>
#include <ctime>

#include <sys/stat.h>


#ifdef WIN32
#  include <io.h>
#else
#  include <unistd.h>
#endif


// COMPATIBILITY
// =============

#ifdef WIN32
#  define S_ISDIR(mode)   ((mode&S_IFMT) == S_IFDIR)
#  define S_ISREG(mode)   ((mode&S_IFMT) == S_IFREG)
#  define S_ISLNK(mode)   ((mode&S_IFMT) == S_IFREG)
#  define lstat  stat
#  define getcwd _getcwd
#  ifndef R_OK
#    define R_OK 4
#  endif
#  ifndef W_OK
#    define W_OK 2
#  endif
#  ifndef F_OK
#    define F_OK 0
#  endif
#endif


// CLASS STATIC
// ============

const oc::File oc::File::Null;





// *****************************************************************************
// *****************************************************************************
//
// CLASS: File
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   File::File()
//   File::File( const std::string & name )
//   File::File( const char * name )
//   File::File( const string & path, const string & file )
//   File::File( const File & file)
//
// Destructor:
//
//   File::~File()
//
// Creators:
//
//   File::Create( const string & name )
//   File::Create( const char * name )
//   File::Create( const string & path, const string & file )
//
// *****************************************************************************

oc::File::File() :
    mRootPrefix(),
    mNameSequence(),
    mAbsoluteFile()
{

    // Intentional left empty

} // File::File()


oc::File::File( const std::string & name ) :
    mRootPrefix(),
    mNameSequence(),
    mAbsoluteFile()
{

    Create( name );

} // File::File(const std::string &)


oc::File::File( const char * name ) :
    mRootPrefix(),
    mNameSequence(),
    mAbsoluteFile()
{

    Create( name );

} // File::File(const char *)


oc::File::File( const std::string & path, const std::string & file ) :
    mRootPrefix(),
    mNameSequence(),
    mAbsoluteFile()
{

    Create( path, file );

} // File::File(const std::string &, const std::string &)


oc::File::File( const File & file ) :
    mRootPrefix  ( file.mRootPrefix   ),
    mNameSequence( file.mNameSequence ),
    mAbsoluteFile( file.mAbsoluteFile )
{

    // Intentional left empty

} // File::File(const File &)



oc::File::~File()
{

    // Intentional left empty

} // File::~File()



bool
oc::File::Create( const std::string & name )
{

    // Empty names leave the instance uninitialized.
    if( name.empty() )
	return false;

    // Make working copy of name and remove leading white spaces.
    std::string::size_type start = name.find_first_not_of( " \t" );
    
    // Name contains only white spaces
    if( start == std::string::npos )
	return false;

    // The copy for further usage
    std::string nameCopy = name.substr( start );

    // Save original name
    std::string nameCopyOrig = nameCopy;

    // Convert all know possible separators to an unique,
    // on all systems not allowed character.

    char uniqueSep = '*';

    std::replace( nameCopy.begin(),
		  nameCopy.end(),
		  System::File::msSeparatorCharWin32,
		  uniqueSep );

    std::replace( nameCopy.begin(),
		  nameCopy.end(),
		  System::File::msSeparatorCharUnix,
		  uniqueSep );

    // Tokenize name into sequence of string names
    mNameSequence = Util::Tokenize( nameCopy, uniqueSep );

    // Extract root prefix:
    //
    //   UNIX     : /
    //   Win32    : <drive>:\
    //   Win32 UNC: \\<host>\<share>\
    //   relative : . or ..
    std::string::size_type pos = nameCopy.find( uniqueSep );

    // No separator found => relative path => add '.'
    // This simple check really do not cover all possible relative
    // pathes. A more exact check which finally covers all cases
    // (hopefully) will be done in the switch-case below.
    //
    // BUG: Can't handle pathnames of type "C:file.ext"
    if( pos == std::string::npos ) {

        nameCopy     = std::string( "." ) + GetSeparator() + nameCopy;
        nameCopyOrig = nameCopy;

        std::replace( nameCopy.begin(),
                      nameCopy.end(),
                      GetSeparatorChar(),
                      uniqueSep );

        mNameSequence = Util::Tokenize( nameCopy, uniqueSep );

        // Now we definitely have an separator
        pos = nameCopy.find( uniqueSep );
    }

    // Consider string before separator
    switch( pos ) {

        // UNIX '/' or Win32 UNC '\\'
    case 0:

        // Win32 UNC:
        if( (nameCopy.size() > 1) && (nameCopy[1] == uniqueSep) ) {

            mRootPrefix = std::string( 2, nameCopyOrig[0] );
        }
        // UNIX '/'
        else {

            mRootPrefix = std::string( 1, nameCopyOrig[0] );
        }

        break;

        // relative: '.'
    case 1:

        if( nameCopy[0] == '.' ) {

            mRootPrefix  = std::string( 1, nameCopyOrig[0] );
            mRootPrefix += System::File::msSeparatorChar;

            // This root prefix is also the first entry
            // in the tokens array. Remove it.
            mNameSequence.erase( mNameSequence.begin() );

        }
        else {
	    
            // This is the case, e.g. 'm/<more dirs>/file.txt', where
            // the above test "No separator found" fails but it is
            // a relative path anyway.

            mRootPrefix = std::string( "." );
            mRootPrefix += System::File::msSeparatorChar;
        }

        break;
  
        // Win32   : '<drive>:\'
        // relative: ..
    case 2:

        if( isalpha( nameCopy[0] ) && (nameCopy[1] == ':') ) {

            mRootPrefix  = nameCopy.substr( 0, 2 );
            mRootPrefix += System::File::msSeparatorCharWin32;

            // This root prefix is also the first entry
            // in the tokens array. Remove it.
            mNameSequence.erase( mNameSequence.begin() );
        }

        // relative: '..'
        else if( (nameCopy[0] == '.') && (nameCopy[1] == '.') ) {

            mRootPrefix  = nameCopy.substr( 0, 2 );
            mRootPrefix += System::File::msSeparatorChar;

            // This root prefix is also the first entry
            // in the tokens array. Remove it.
            mNameSequence.erase( mNameSequence.begin() );

        }
        else {

            // This is the case, e.g. 'mm/<more dirs>/file.txt', where
            // the above test "No separator found" fails but it is
            // a relative path anyway.

            mRootPrefix = std::string( "." );
            mRootPrefix += System::File::msSeparatorChar;
        }

        break;


        // This is the case, e.g. 'mmm/<more dirs>/file.txt', where
        // the above test "No separator found" fails but it is
        // a relative path anyway.
    default:

        mRootPrefix = std::string( "." );
        mRootPrefix += System::File::msSeparatorChar;
    }

    // Remove ".."

    std::vector<std::string> newNameSequence;

    int size = mNameSequence.size();

    for( int idx=0, nidx=0; idx<size; ++idx ) {

        if( mNameSequence[idx] == std::string( ".." )     &&
            nidx > 0                                      &&
            newNameSequence[nidx-1] != std::string( ".." ) ) {

            newNameSequence.pop_back();
            --nidx;
        }
        else {

            newNameSequence.push_back( mNameSequence[idx] );
            ++nidx;
        }
    }

    mNameSequence = newNameSequence;
    
    // Now we can build the absolute file string which is saved in mAbsolutFile
    BuildAbsoluteFile();


    return true;

} // File::Create( const std::string &)


bool
oc::File::Create( const char * name )
{

    assert( name != (const char *)NULL );

    return Create( std::string( name ) );

} // File::Create(const char *)


bool
oc::File::Create( const std::string & path, const std::string & file )
{

    std::string name( path );
  
    name += GetSeparator();
    name += file;

    return Create( name );

} // oc::File::Create(const string &, const string &)



// *****************************************************************************
//
// Static Methods:
//
//   File::GetSeparator()
//   File::GetSeparatorChar()
//   File::GetPathSeparator()
//   File::GetPathSeparatorChar()
//
// *****************************************************************************

const std::string &
oc::File::GetSeparator()
{

    return oc::System::File::msSeparator;
}

char
oc::File::GetSeparatorChar()
{
    return oc::System::File::msSeparatorChar;
}

const std::string &
oc::File::GetPathSeparator()
{
    return oc::System::Path::msSeparator;
}

char
oc::File::GetPathSeparatorChar()
{
    return oc::System::Path::msSeparatorChar;
}




// *****************************************************************************
//
// Getter / Setter:
//
//   File::GetAbsolutePath() const
//   File::GetAbsoluteFile() const
//   File::GetFileList( std::vector<File> & fileList,
//                      const std::string & fileMask ) const
//   File::GetFileSize() const
//   File::GetName() const
//   File::GetNameSequence() const
//   File::GetParent() const
//   File::GetRootPrefix() const
//   File::GetExtension( char sep ) const
//   File::GetLastAccess( Date & d, Time & t ) const
//   File::GetLastModification( Date & d, Time & t ) const
//   File::GetLastChange( Date & d, Time & t ) const
//
// *****************************************************************************

const std::string &
oc::File::GetAbsolutePath() const
{

    static std::string sAbsolutePath;

    // If it is already a directory, return it
    if( IsDirectory() ) {

	return GetAbsoluteFile();
    }

    // If not, remove the last name in sequence from absolute file
    if( GetNameSequence().size() == 0 ) {

	sAbsolutePath = "";

	return sAbsolutePath;
    }

    int length = GetAbsoluteFile().size();

    length -= GetNameSequence().back().size();

    // Remove also the separator before the last name except if
    // there is only one name in name sequence. E.g.: "/System.map"
    if( GetNameSequence().size() > 1 )
	length --;

    sAbsolutePath = GetAbsoluteFile().substr( 0, length );

    return sAbsolutePath;

} // File::GetAbsolutePath() const



const std::string &
oc::File::GetAbsoluteFile() const
{

    return mAbsoluteFile;

} // File::GetAbsoluteFile() const



bool
oc::File::GetFileList(std::vector<File> & fileList,
                        const std::string & fileMask) const
{

    // Only directories can be listed
    if( ! IsDirectory() ) {

	return false;
    }

    // Clear return file list
    fileList.clear();

    // Open directory stream
    oc::DirectoryStream reader;

    reader.Open( GetAbsoluteFile(), fileMask );

    if( ! reader ) {

	return false;
    }

    // Read file by file of directory list
    while( ! reader.EOD() ) {

	// Append new file object
	fileList.push_back( oc::File::Null );

	// Initialize file object with next file in directory list
	reader >> fileList.back();
    }

    // Close directory list
    reader.Close();

    return true;

} // File::GetFileList(vector<File> &, const string &) const



int
oc::File::GetFileSize() const
{

    int result = -1;

    // Does this abstract pathname has a representative in the file system?
    if( ! IsExistant() ) {

	return -1;
    }

    // This instance is a file, a directory or a link
    if( IsFile() || IsDirectory() || IsLink() ){

	struct stat sstat;

	// Query file information
	if( stat( GetAbsoluteFile().c_str(), & sstat ) == 0 ) {

	    result = sstat.st_size;
	}
	else {

	    result = -1;
	}
    } // It is a file

    // Instance is not a file, dir or link => no information
    else {

	result = -1;
    }

    return result;

} // File::GetFileSize() const



const std::string &
oc::File::GetName() const
{

    static const std::string sEmptyString;

    if( GetNameSequence().size() == 0 ) {

	return sEmptyString;
    }

    return GetNameSequence().back();

} // File::GetName() const



const std::vector<std::string> &
oc::File::GetNameSequence() const
{

    return mNameSequence;

} // File::GetNameSequence() const



oc::File
oc::File::GetParent() const
{

    const std::vector<std::string> & nameSeq = GetNameSequence();

    // Only the root directory didn't have an parent.
    if( nameSeq.size() == 0 ) {

	return oc::File::Null;
    }

    return File( GetAbsoluteFile().substr( 0, GetAbsoluteFile().rfind( GetName() ) ) );

} // oc::File::GetParent() const



const std::string &
oc::File::GetRootPrefix() const
{

    return mRootPrefix;

} // File::GetRootPrefix() const



std::string
oc::File::GetExtension( char sep ) const
{

    const std::string & name = GetName();

    std::string::size_type pos = name.rfind( sep );

    if( (pos == std::string::npos) ||
	(pos == 0                ) ) {

	return std::string( "" );
    }

    return name.substr( pos+1 );
}

bool
oc::File::GetLastAccess( Date & d, Time & t ) const
{
    
    if ( ! IsExistant() ) {

        return false;
    }

    struct stat sstat;
 
    if( stat( GetAbsoluteFile().c_str(), & sstat ) != 0 ) {
        
        return false;
    }

    struct tm * access_time = localtime( & (sstat.st_atime) );

    d.SetDate( access_time->tm_mday,
               access_time->tm_mon + 1,
               access_time->tm_year + 1900 );

    t.SetTime( access_time->tm_hour,
               access_time->tm_min,
               access_time->tm_sec );

     return true;
}

bool
oc::File::GetLastModification( Date & d, Time & t) const
{
    if( ! IsExistant() ) {
        return false;
    }

    struct stat sstat;

    if(stat (GetAbsoluteFile().c_str(), & sstat) != 0 ) {
        return false;
    }

    struct tm * modification_time = localtime( & (sstat.st_mtime) );

    d.SetDate( modification_time->tm_mday,
               modification_time->tm_mon + 1,
               modification_time->tm_year + 1900 );
    t.SetTime( modification_time->tm_hour,
               modification_time->tm_min,
               modification_time->tm_sec);
    return true;
  
}


bool
oc::File::GetLastChange( Date & d, Time & t) const
{
    if (! IsExistant() ) {
        return false;
    }

    struct stat sstat;

    if(stat (GetAbsoluteFile().c_str(), & sstat) != 0) {
        return false;
    }

    struct tm * change_time = localtime ( & (sstat.st_mtime) );

    d.SetDate( change_time->tm_mday,
               change_time->tm_mon + 1,
               change_time->tm_year + 1900 );

    t.SetTime( change_time->tm_hour,
               change_time->tm_min,
               change_time->tm_sec);
    
    return true;
}



// *****************************************************************************
//
// Query Methods:
//
//   File::IsDirectory() const
//   File::IsExistant() const
//   File::IsFile() const
//   File::IsLink() const
//   File::IsReadable() const
//   File::IsWriteable() const
//   File::IsRelative() const
//   File::IsAbsolute() const
//
// *****************************************************************************

bool
oc::File::IsDirectory() const
{

    bool result = false;

    // If it doesn't exist, it can't be a directory
    if( ! IsExistant() ) {

	return false;
    }

    // Get file information
    struct stat sstat;

    if( stat( GetAbsoluteFile().c_str(), & sstat ) == 0 ) {

	result = S_ISDIR( sstat.st_mode);
    }

#ifdef WIN32

    // Give Windows a second change to check whether it is a directory:
    // "Are you really sure it's not a directory?"
    // This problem arise with drive letters:
    // "D:\" ==> Not a directory
    
    if( (result == false) && ! IsFile() && ! IsLink() ) {

	File nul( GetAbsoluteFile(), std::string( "nul" ) );

	if( nul.IsExistant() ) {

	    result = true;
	}
    }
#endif

    return result;
  
} // File::IsDirectory() const



bool
oc::File::IsExistant() const
{

    if( access( GetAbsoluteFile().c_str(), F_OK ) == 0 ) {
   
	return true;
    }

    return false;

} // File::IsExistant() const



bool
oc::File::IsFile() const
{

    bool result = false;

    // If it doesn't exist, it can't be a file
    if( ! IsExistant() ) {

	return false;
    }

    // Get file information
    struct stat sstat;

    if( stat( GetAbsoluteFile().c_str(), & sstat ) == 0 ) {

	result = S_ISREG( sstat.st_mode);
    }

    return result;

} // File::IsFile() const



bool
oc::File::IsLink() const
{

    bool result = false;

    // If it doesn't exist, it can't be a link
    if( ! IsExistant() ) {

	return false;
    }

    // Get file information
    struct stat sstat;

    if( lstat( GetAbsoluteFile().c_str(), & sstat ) == 0 ) {

	result = S_ISLNK( sstat.st_mode);

#ifdef WIN32

	// On Windows systems the upper macro S_ISLNK() test only whether it is a file.
	// The next expressions tests the filename for the extention ".lnk".
	if( result == true ) {

	    result = false;

	    const std::string & filename = GetName();
	    int length = filename.size();
	    
	    if( length >= 4 ) {

		if( (         filename.at( length-4 )   == '.' ) &&
		    (tolower( filename.at( length-3 ) ) == 'l' ) &&
		    (tolower( filename.at( length-2 ) ) == 'n' ) &&
		    (tolower( filename.at( length-1 ) ) == 'k' ) ) {
		    result = true;
		}
	    }
	}

#endif

    }

    return result;

} // File::IsLink() const



bool
oc::File::IsReadable() const
{

    if( access( GetAbsoluteFile().c_str(), R_OK ) == 0 ) {
   
	return true;
    }

    return false;

} // File::IsReadable() const



bool
oc::File::IsWriteable() const
{

    if( access( GetAbsoluteFile().c_str(), W_OK ) == 0 ) {
   
	return true;
    }

    return false;

} // File::IsWriteable() const



bool
oc::File::IsRelative() const
{
    return GetRootPrefix()[0] == '.';
}


bool
oc::File::IsAbsolute() const
{
    return ! IsRelative();
}




// *****************************************************************************
//
// Access Methods:
//
//   File::Remove( bool recursive ) const
//   File::operator=( const oc::File & file )
//   File::operator=( const std::string & name )
//   File::operator=( const char * name )
//   File::operator!() const
//   File::operator bool() const
//
// *****************************************************************************

bool
oc::File::Remove( bool recursive ) const
{

    if( recursive ) {

        OCERROR( "recursive removing of directories still not implemented." );
    }
#ifdef WIN32
    int result = ::remove( GetAbsoluteFile().c_str() );
#else
    int result = std::remove( GetAbsoluteFile().c_str() );
#endif

    if( result != 0 ) {

        OCINFOCONT( "Couldn't remove file '" << *this << "'." );
        OCINFO( "System message was: " << oc::Errno::GetErrnoString(errno) );
    }

    return (result == 0);

} // File::Remove(bool recursive) const


bool
oc::File::MakeDirectory() const
{
	if( IsExistant() ) {
		return false;
	}
	return oc::System::Directory::CreateDir( GetAbsoluteFile().c_str() );
}


oc::File &
oc::File::operator=( const oc::File & file )
{

    mRootPrefix   = file.mRootPrefix;
    mNameSequence = file.mNameSequence;
    mAbsoluteFile = file.mAbsoluteFile;

    return *this;

} // File::operator=(const File &)



oc::File &
oc::File::operator=( const std::string & name )
{

    Create( name );

    return *this;

} // File::operator=(const string &)



oc::File &
oc::File::operator=( const char * name )
{

    assert( name != (const char *)NULL );

    Create( name );

    return *this;

} // File::operator=(const char *)


bool
oc::File::operator!() const
{
    return (*this == File::Null);
}


oc::File::operator bool() const
{
    return (*this != File::Null);
}





// *****************************************************************************
//
// Helpers:
//
//   File::Print()
//   File::Scan()
//   File::BuildAbsoluteFile()
//
// *****************************************************************************

void
oc::File::Print( std::ostream & out ) const
{
    out << GetAbsoluteFile();
}

void
oc::File::Scan( std::istream & in ) 
{
    std::string name;
    in >> name;
    Create(name);
}



void
oc::File::BuildAbsoluteFile()
{

    // Clear the string
    mAbsoluteFile = "";

    // Start with the root prefix
    mAbsoluteFile += GetRootPrefix();

    // Append name sequence
    const std::vector<std::string> & tokens = GetNameSequence();

    std::vector<std::string>::const_iterator it = tokens.begin();

    // token + separator
    while( it != tokens.end() ) {

	mAbsoluteFile += *it;
	mAbsoluteFile += GetSeparatorChar();

	++it;
    }

    // Last separator char to much => remove it
    if( tokens.begin() != tokens.end() ) {

	mAbsoluteFile.resize( mAbsoluteFile.size() - 1 );
    }

} // File::BuildAbsoluteFile()




// *****************************************************************************
//
// Friends:
//
//   operator< ( const File & file1, const File & file2 )
//   operator==( const File & file1, const File & file2 )
//   operator!=( const File & file1, const File & file2 )
//
// *****************************************************************************

bool
oc::operator<( const File & file1, const File & file2 )
{

    return file1.GetAbsoluteFile() < file2.GetAbsoluteFile();

} // operator<(const File &, const File &)



bool
oc::operator==( const File & file1, const File & file2 )
{

    return (( file1.GetRootPrefix()   == file2.GetRootPrefix()   ) &&
	    ( file1.GetAbsoluteFile() == file2.GetAbsoluteFile() )) ;

} // operator==(const File &, const File &)


bool
oc::operator!=( const File & file1, const File & file2 )
{

    return (( file1.GetRootPrefix()   != file2.GetRootPrefix()   ) ||
	    ( file1.GetAbsoluteFile() != file2.GetAbsoluteFile() )) ;

} // operator!=(const File &, const File &)


std::ostream &
oc::operator<<( std::ostream & out, const oc::File & file )
{
    file.Print( out );

    return out;
}

std::istream &
oc::operator>>( std::istream & in, oc::File & file )
{
    file.Scan( in );

    return in;
}
