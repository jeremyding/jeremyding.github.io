
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/DirectoryStream.hh>
#include <oc/System.hh>
#include <oc/Log.hh>

// C include

#include <cerrno>
#include <cassert>

#ifdef WIN32
#  include <io.h>
#endif


// CLASS STATIC
// ============

#ifdef WIN32

const std::string oc::DirectoryStream::msDefaultFileMask = std::string( "*.*" );

#else

const std::string oc::DirectoryStream::msDefaultFileMask = std::string( "*" );

#endif



// *****************************************************************************
// *****************************************************************************
//
// CLASS: DirectoryStream
//
// *****************************************************************************
// *****************************************************************************





// *****************************************************************************
//
// Constructors:
//
//   DirectoryStream::DirectoryStream()
//   DirectoryStream::DirectoryStream( const DirectoryStream & directory )
//   DirectoryStream( const oc::File   & directory,
//	              const std::string & fileMask );
//
// Destructor:
//
//    DirectoryStream::~DirectoryStream()
//
// *****************************************************************************

oc::DirectoryStream::DirectoryStream()
    : mDirectory(),
      mDirectoryHandle( OC_DIR_NULL_HANDLE ),
      mNextEntry()
{

    // Intentional left empty
}


oc::DirectoryStream::DirectoryStream( const oc::DirectoryStream & directory )
{

    OCFATALCONT( "DirectoryStream::DirectoryStream():" << newl );
    OCFATAL    ( "copy constructor not allowed"        );
}


oc::DirectoryStream::DirectoryStream( const oc::File   & directory,
                                        const std::string & fileMask )
    : mDirectory(),
      mDirectoryHandle( OC_DIR_NULL_HANDLE ),
      mNextEntry()
{

    Open( directory, fileMask );
}


oc::DirectoryStream::~DirectoryStream()
{

    if( !! (*this ) ) {

	Close();
    }
}



// *****************************************************************************
//
// Access Methods:
//
//   DirectoryStream::Open( const oc::File & directory, const std::string & fileMask )
//   DirectoryStream::Close()
//   DirectoryStream::GetNextFile( oc::File & file )
//   DirectoryStream::operator>> ( oc::File & file )
//   DirectoryStream::operator=( const DirectoryStream & directory )
//
// *****************************************************************************

bool
oc::DirectoryStream::Open( const oc::File   & directory,
                             const std::string & fileMask )
{

    errno = 0;

    // Is it a directory?
    if( ! directory.IsDirectory() ) {

	return( false );
    }

    // Close a previously opened directory
    if( mDirectoryHandle != OC_DIR_NULL_HANDLE ) {

	Close();
    }

    // Remember directory for later concatenation with directory entry.
    mDirectory  = directory.GetAbsoluteFile();
    mDirectory += oc::File::GetSeparator();

    // Open the directory
    // ------------------

#ifdef WIN32

    // Windows needs the directory with file mask in one string
    std::string directoryFileMask( directory.GetAbsoluteFile() );
    
    directoryFileMask += System::File::msSeparatorChar;
    directoryFileMask += fileMask;

    // Open the directory
    struct _finddata_t dummy;

    mDirectoryHandle = _findfirst( (char *) (directoryFileMask.c_str()), & dummy );

#else

    // Open the directory
    mDirectoryHandle = opendir( directory.GetAbsoluteFile().c_str() );

#endif

    // Directory open fails
    if( mDirectoryHandle == OC_DIR_NULL_HANDLE ) {
	return( false );
    }

    // Read the first entry
    ReadNextEntry();

    return( true );

} // DirectoryStream::Open( const File & directory, const string & )



bool
oc::DirectoryStream::Close()
{

    if( mDirectoryHandle != OC_DIR_NULL_HANDLE ) {

#ifdef WIN32
	_findclose( mDirectoryHandle );
#else
	closedir( mDirectoryHandle );
#endif
    }

    mDirectoryHandle = OC_DIR_NULL_HANDLE;

    return( true );

}



bool
oc::DirectoryStream::GetNextFile( oc::File & file )
{

    // No directory no entry; or
    // no next entry available
    if( ( ! (*this) ) || EOD() ) {

	return( false );
    }

    // Return the already prefetched entry
    file = (mDirectory + mNextEntry);

    // Prefetch next directory entry
    ReadNextEntry();

    return( true );

}



oc::DirectoryStream &
oc::DirectoryStream::operator>>( oc::File & file )
{

    GetNextFile( file );

    return( *this );

}



oc::DirectoryStream &
oc::DirectoryStream::operator=( const DirectoryStream & directory )
{

    OCFATALCONT( "DirectoryStream::operator=():" << newl );
    OCFATAL    ( "Assignment operator not allowed" );

    return( *this );
}



// *****************************************************************************
//
// Info Methods:
//
//   DirectoryStream::operator!() const
//   DirectoryStream::EOD() const
//
// *****************************************************************************

bool
oc::DirectoryStream::operator!() const
{

    return( mDirectoryHandle == OC_DIR_NULL_HANDLE );

}



bool
oc::DirectoryStream::EOD() const
{

    return( mNextEntry.empty() );

}




// *****************************************************************************
//
// Helpers:
//
//   DirectoryStream::ReadNextEntry()
//
// *****************************************************************************

bool
oc::DirectoryStream::ReadNextEntry()
{

    assert( !! (*this ) );

#ifdef WIN32

    struct _finddata_t dirEntry;

    if( _findnext( mDirectoryHandle, & dirEntry ) != 0 ) {

	mNextEntry = "";
	return( false );
    }

    mNextEntry = dirEntry.name;

#else

    struct dirent * dirEntry = readdir( mDirectoryHandle );

    if( dirEntry == (struct dirent *) NULL ) {

	mNextEntry = "";
	return( false );
    }

    mNextEntry = dirEntry->d_name;

#endif

    // Filter "." and ".." files out
    if( (mNextEntry.compare( "."  ) == 0 ) ||
	(mNextEntry.compare( ".." ) == 0 ) ) {

	return( ReadNextEntry() );
    }

    return( true );

} // DirectoryStream::ReadNextEntry()


