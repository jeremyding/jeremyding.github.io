// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/LogProgress.hh>


std::vector<oc::LogProgress::Listener *> oc::LogProgress::mListeners = 
std::vector<oc::LogProgress::Listener*>();

typedef std::vector<oc::LogProgress::Listener *>::iterator gtListenerPtrIt;


std::vector< std::pair< std::string, std::string > > oc::LogProgress::mStreams = 
std::vector< std::pair< std::string, std::string > >();

typedef std::vector< std::pair< std::string, std::string > >::iterator gtVecPairStrStrIt;


oc::LogProgress::Listener::Listener()
{
    AddListener(this);
}

oc::LogProgress::Listener::~Listener()
{
    RemoveListener(this);
}


oc::LogProgress::LogProgress(std::string const & name)
    : mName(name)
{
    AddStream( mName );
}

oc::LogProgress::~LogProgress()
{
    RemoveStream( mName );
}

bool 
oc::LogProgress::Report(std::string const & text)
{
    gtListenerPtrIt it,eit;
    for( it=mListeners.begin(), eit=mListeners.end(); it!=eit; ++it ) {
        (*it)->HaveReport(mName, text );
    }
    return true;
}


bool 
oc::LogProgress::AddListener(oc::LogProgress::Listener* l)
{
    mListeners.push_back(l);
    return true;
}

bool 
oc::LogProgress::RemoveListener(oc::LogProgress::Listener *l)
{
    gtListenerPtrIt it = std::find(mListeners.begin(),mListeners.end(),l);
    if( it==mListeners.end() ) {
        return false;
    }
    mListeners.erase( it );
    return true;
}

oc::LogProgress& 
oc::report( oc::LogProgress& lp )
{
    std::string msg;
    
    msg = oc::LogProgress::GetStream(lp.mName);
    oc::LogProgress::GetStream(lp.mName) = std::string("");

    gtListenerPtrIt it,eit;
    for( it=lp.mListeners.begin(), eit=lp.mListeners.end(); it!=eit; ++it ) {
        (*it)->HaveReport(lp.mName, msg );
    }
    return lp;
}


oc::LogProgress& 
oc::LogProgress::operator<<(oc::LogProgress& (*manip)(oc::LogProgress&) )
{
    return (*manip)(*this);
}



void 
oc::LogProgress::AddStream( std::string const& name)
{
    mStreams.push_back( std::pair<std::string, std::string >(name,std::string("")) );
}


std::string& 
oc::LogProgress::GetStream(std::string const& name)
{
    gtVecPairStrStrIt it,eit;
    for( it=mStreams.begin(), eit=mStreams.end(); it!=eit; ++it ) {
        if( it->first == name )
            return it->second;
    }
    return mStreams[0].second;
}

void 
oc::LogProgress::RemoveStream(std::string const& name)
{
    gtVecPairStrStrIt it,eit;
    for( it=mStreams.begin(), eit=mStreams.end(); it!=eit; ++it ) {
        if( it->first == name ) {
            mStreams.erase(it); 
            break;
        }
    }
   
}


