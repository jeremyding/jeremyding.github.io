#define YY_PropertyResourceRuleParser_h_included

/*  A Bison++ parser, made from ..\src\orcan\PropertyResourceRuleParser.y  */

 /* with Bison++ version bison++ Version 1.21-8, adapted from GNU bison by coetmeur@icdc.fr
  */


#line 1 "c:\\usr\\bin\\bison.cc"
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* HEADER SECTION */
#if defined( _MSDOS ) || defined(MSDOS) || defined(__MSDOS__) 
#define __MSDOS_AND_ALIKE
#endif
#if defined(_WINDOWS) && defined(_MSC_VER)
#define __HAVE_NO_ALLOCA
#define __MSDOS_AND_ALIKE
#endif

#ifndef alloca
#if defined( __GNUC__)
#define alloca __builtin_alloca

#elif (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc)  || defined (__sgi)
#include <alloca.h>

#elif defined (__MSDOS_AND_ALIKE)
#include <malloc.h>
#ifndef __TURBOC__
/* MS C runtime lib */
#define alloca _alloca
#endif

#elif defined(_AIX)
#include <malloc.h>
#pragma alloca

#elif defined(__hpux)
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */

#endif /* not _AIX  not MSDOS, or __TURBOC__ or _AIX, not sparc.  */
#endif /* alloca not defined.  */
#ifdef c_plusplus
#ifndef __cplusplus
#define __cplusplus
#endif
#endif
#ifdef __cplusplus
#ifndef YY_USE_CLASS
#define YY_USE_CLASS
#endif
#else
#ifndef __STDC__
#define const
#endif
#endif
#include <stdio.h>
#define YYBISON 1  

/* #line 73 "c:\\usr\\bin\\bison.cc" */
#line 85 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"
#line 43 "..\\src\\orcan\\PropertyResourceRuleParser.y"


#include <oc/config.h>
#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyResourceRuleScanner.hh>
#include <oc/Util.hh>

#include <cmath>
#include <iostream>
#include <string>
#include <vector>

#if defined(__GNUC__)
#  if OC_CHECK_GCC_VERSION(3, 0)
#    include <limits>
#  else
#    if defined(__FreeBSD__)
#      include <float.h>
#    else
#      include <values.h>
#    endif
#  endif
#endif


#if defined(MSDOS)
#  include <limits>
#endif


#line 80 "..\\src\\orcan\\PropertyResourceRuleParser.y"


using namespace oc;

#define YY_PropertyResourceRuleParser_CLASS_ACCESS  OC_DSOAPI
#define YY_PropertyResourceRuleParser_MEMBERS  private:                                                          \
                                                                                  \
    std::vector< std::string > mValueList;                                        \
    bool                       mResult;                                           \
    PropertyResourceRuleScanner mPropertyResourceRuleScanner;                     \
    PropertyResourceRuleParser();                                                 \
    PropertyResourceRuleParser( PropertyResourceRuleParser & prrParser );         \
    public:                                                                       \
    bool GetResult() { return mResult; };  
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM   std::istream & in
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_INIT    : mPropertyResourceRuleScanner( in )
#define YY_PropertyResourceRuleParser_PARSE        Parse
#define YY_PropertyResourceRuleParser_PARSE_PARAM  oc::PropertyMap & pmap
#define YY_PropertyResourceRuleParser_LEX_BODY  {                                       \
                    return( mPropertyResourceRuleScanner.Scan( *this ) ); \
                 }
#define YY_PropertyResourceRuleParser_ERROR_BODY  {                                      \
                      std::cerr << std::endl              \
                           << msg                         \
                           << ", Last token was <"        \
                           << (char *) mPropertyResourceRuleScanner.yytext \
                           << ">"                         \
                           << endl;                       \
                   }
#define YY_PropertyResourceRuleParser_LSP_NEEDED 

#line 147 "..\\src\\orcan\\PropertyResourceRuleParser.y"
typedef union {
  bool   boolean;
  char   string[4096];
} yy_PropertyResourceRuleParser_stype;
#define YY_PropertyResourceRuleParser_STYPE yy_PropertyResourceRuleParser_stype

#line 73 "c:\\usr\\bin\\bison.cc"
/* %{ and %header{ and %union, during decl */
#define YY_PropertyResourceRuleParser_BISON 1
#ifndef YY_PropertyResourceRuleParser_COMPATIBILITY
#ifndef YY_USE_CLASS
#define  YY_PropertyResourceRuleParser_COMPATIBILITY 1
#else
#define  YY_PropertyResourceRuleParser_COMPATIBILITY 0
#endif
#endif

#if YY_PropertyResourceRuleParser_COMPATIBILITY != 0
/* backward compatibility */
#ifdef YYLTYPE
#ifndef YY_PropertyResourceRuleParser_LTYPE
#define YY_PropertyResourceRuleParser_LTYPE YYLTYPE
#endif
#endif
#ifdef YYSTYPE
#ifndef YY_PropertyResourceRuleParser_STYPE 
#define YY_PropertyResourceRuleParser_STYPE YYSTYPE
#endif
#endif
#ifdef YYDEBUG
#ifndef YY_PropertyResourceRuleParser_DEBUG
#define  YY_PropertyResourceRuleParser_DEBUG YYDEBUG
#endif
#endif
#ifdef YY_PropertyResourceRuleParser_STYPE
#ifndef yystype
#define yystype YY_PropertyResourceRuleParser_STYPE
#endif
#endif
/* use goto to be compatible */
#ifndef YY_PropertyResourceRuleParser_USE_GOTO
#define YY_PropertyResourceRuleParser_USE_GOTO 1
#endif
#endif

/* use no goto to be clean in C++ */
#ifndef YY_PropertyResourceRuleParser_USE_GOTO
#define YY_PropertyResourceRuleParser_USE_GOTO 0
#endif

#ifndef YY_PropertyResourceRuleParser_PURE

/* #line 117 "c:\\usr\\bin\\bison.cc" */
#line 204 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"

#line 117 "c:\\usr\\bin\\bison.cc"
/*  YY_PropertyResourceRuleParser_PURE */
#endif

/* section apres lecture def, avant lecture grammaire S2 */

/* #line 121 "c:\\usr\\bin\\bison.cc" */
#line 213 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"

#line 121 "c:\\usr\\bin\\bison.cc"
/* prefix */
#ifndef YY_PropertyResourceRuleParser_DEBUG

/* #line 123 "c:\\usr\\bin\\bison.cc" */
#line 220 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"

#line 123 "c:\\usr\\bin\\bison.cc"
/* YY_PropertyResourceRuleParser_DEBUG */
#endif


#ifndef YY_PropertyResourceRuleParser_LSP_NEEDED

/* #line 128 "c:\\usr\\bin\\bison.cc" */
#line 230 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"

#line 128 "c:\\usr\\bin\\bison.cc"
 /* YY_PropertyResourceRuleParser_LSP_NEEDED*/
#endif



/* DEFAULT LTYPE*/
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
#ifndef YY_PropertyResourceRuleParser_LTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YY_PropertyResourceRuleParser_LTYPE yyltype
#endif
#endif
/* DEFAULT STYPE*/
      /* We used to use `unsigned long' as YY_PropertyResourceRuleParser_STYPE on MSDOS,
	 but it seems better to be consistent.
	 Most programs should declare their own type anyway.  */

#ifndef YY_PropertyResourceRuleParser_STYPE
#define YY_PropertyResourceRuleParser_STYPE int
#endif
/* DEFAULT MISCELANEOUS */
#ifndef YY_PropertyResourceRuleParser_PARSE
#define YY_PropertyResourceRuleParser_PARSE yyparse
#endif
#ifndef YY_PropertyResourceRuleParser_LEX
#define YY_PropertyResourceRuleParser_LEX yylex
#endif
#ifndef YY_PropertyResourceRuleParser_LVAL
#define YY_PropertyResourceRuleParser_LVAL yylval
#endif
#ifndef YY_PropertyResourceRuleParser_LLOC
#define YY_PropertyResourceRuleParser_LLOC yylloc
#endif
#ifndef YY_PropertyResourceRuleParser_CHAR
#define YY_PropertyResourceRuleParser_CHAR yychar
#endif
#ifndef YY_PropertyResourceRuleParser_NERRS
#define YY_PropertyResourceRuleParser_NERRS yynerrs
#endif
#ifndef YY_PropertyResourceRuleParser_DEBUG_FLAG
#define YY_PropertyResourceRuleParser_DEBUG_FLAG yydebug
#endif
#ifndef YY_PropertyResourceRuleParser_ERROR
#define YY_PropertyResourceRuleParser_ERROR yyerror
#endif
#ifndef YY_PropertyResourceRuleParser_PARSE_PARAM
#ifndef __STDC__
#ifndef __cplusplus
#ifndef YY_USE_CLASS
#define YY_PropertyResourceRuleParser_PARSE_PARAM
#ifndef YY_PropertyResourceRuleParser_PARSE_PARAM_DEF
#define YY_PropertyResourceRuleParser_PARSE_PARAM_DEF
#endif
#endif
#endif
#endif
#ifndef YY_PropertyResourceRuleParser_PARSE_PARAM
#define YY_PropertyResourceRuleParser_PARSE_PARAM void
#endif
#endif
#if YY_PropertyResourceRuleParser_COMPATIBILITY != 0
/* backward compatibility */
#ifdef YY_PropertyResourceRuleParser_LTYPE
#ifndef YYLTYPE
#define YYLTYPE YY_PropertyResourceRuleParser_LTYPE
#else
/* WARNING obsolete !!! user defined YYLTYPE not reported into generated header */
#endif
#endif
#ifndef YYSTYPE
#define YYSTYPE YY_PropertyResourceRuleParser_STYPE
#else
/* WARNING obsolete !!! user defined YYSTYPE not reported into generated header */
#endif
#ifdef YY_PropertyResourceRuleParser_PURE
#ifndef YYPURE
#define YYPURE YY_PropertyResourceRuleParser_PURE
#endif
#endif
#ifdef YY_PropertyResourceRuleParser_DEBUG
#ifndef YYDEBUG
#define YYDEBUG YY_PropertyResourceRuleParser_DEBUG 
#endif
#endif
#ifndef YY_PropertyResourceRuleParser_ERROR_VERBOSE
#ifdef YYERROR_VERBOSE
#define YY_PropertyResourceRuleParser_ERROR_VERBOSE YYERROR_VERBOSE
#endif
#endif
#ifndef YY_PropertyResourceRuleParser_LSP_NEEDED
#ifdef YYLSP_NEEDED
#define YY_PropertyResourceRuleParser_LSP_NEEDED YYLSP_NEEDED
#endif
#endif
#endif
#ifndef YY_USE_CLASS
/* TOKEN C */

/* #line 236 "c:\\usr\\bin\\bison.cc" */
#line 343 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"
#define	MATH_TAN	258
#define	MATH_SIN	259
#define	MATH_COS	260
#define	MATH_PI	261
#define	COMPARE_EQUAL	262
#define	COMPARE_UNEQUAL	263
#define	LOGICAL_AND	264
#define	LOGICAL_OR	265
#define	ASSIGN	266
#define	COMPARE_LESS	267
#define	COMPARE_LESS_OR_EQUAL	268
#define	COMPARE_GREATER	269
#define	COMPARE_GREATER_OR_EQUAL	270
#define	RANGE	271
#define	PROPSTATE	272
#define	REGEXP	273
#define	XMLEXP	274
#define	STRING	275
#define	QUOTE	276
#define	BOOL	277


#line 236 "c:\\usr\\bin\\bison.cc"
 /* #defines tokens */
#else
/* CLASS */
#ifndef YY_PropertyResourceRuleParser_CLASS
#define YY_PropertyResourceRuleParser_CLASS PropertyResourceRuleParser
#endif
#ifndef YY_PropertyResourceRuleParser_CLASS_ACCESS
#define YY_PropertyResourceRuleParser_CLASS_ACCESS
#endif
#ifndef YY_PropertyResourceRuleParser_INHERIT
#define YY_PropertyResourceRuleParser_INHERIT
#endif
#ifndef YY_PropertyResourceRuleParser_MEMBERS
#define YY_PropertyResourceRuleParser_MEMBERS 
#endif
#ifndef YY_PropertyResourceRuleParser_LEX_BODY
#define YY_PropertyResourceRuleParser_LEX_BODY  
#endif
#ifndef YY_PropertyResourceRuleParser_ERROR_BODY
#define YY_PropertyResourceRuleParser_ERROR_BODY  
#endif
#ifndef YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM
#endif
#ifndef YY_PropertyResourceRuleParser_CONSTRUCTOR_CODE
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_CODE
#endif
#ifndef YY_PropertyResourceRuleParser_CONSTRUCTOR_INIT
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_INIT
#endif
/* choose between enum and const */
#ifndef YY_PropertyResourceRuleParser_USE_CONST_TOKEN
#define YY_PropertyResourceRuleParser_USE_CONST_TOKEN 0
/* yes enum is more compatible with flex,  */
/* so by default we use it */ 
#endif
#if YY_PropertyResourceRuleParser_USE_CONST_TOKEN != 0
#ifndef YY_PropertyResourceRuleParser_ENUM_TOKEN
#define YY_PropertyResourceRuleParser_ENUM_TOKEN yy_PropertyResourceRuleParser_enum_token
#endif
#endif

class YY_PropertyResourceRuleParser_CLASS_ACCESS YY_PropertyResourceRuleParser_CLASS YY_PropertyResourceRuleParser_INHERIT
{
public: 
#if YY_PropertyResourceRuleParser_USE_CONST_TOKEN != 0
/* static const int token ... */

/* #line 283 "c:\\usr\\bin\\bison.cc" */
#line 416 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"
static const int MATH_TAN;
static const int MATH_SIN;
static const int MATH_COS;
static const int MATH_PI;
static const int COMPARE_EQUAL;
static const int COMPARE_UNEQUAL;
static const int LOGICAL_AND;
static const int LOGICAL_OR;
static const int ASSIGN;
static const int COMPARE_LESS;
static const int COMPARE_LESS_OR_EQUAL;
static const int COMPARE_GREATER;
static const int COMPARE_GREATER_OR_EQUAL;
static const int RANGE;
static const int PROPSTATE;
static const int REGEXP;
static const int XMLEXP;
static const int STRING;
static const int QUOTE;
static const int BOOL;


#line 283 "c:\\usr\\bin\\bison.cc"
 /* decl const */
#else
enum YY_PropertyResourceRuleParser_ENUM_TOKEN { YY_PropertyResourceRuleParser_NULL_TOKEN=0

/* #line 286 "c:\\usr\\bin\\bison.cc" */
#line 445 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"
	,MATH_TAN=258
	,MATH_SIN=259
	,MATH_COS=260
	,MATH_PI=261
	,COMPARE_EQUAL=262
	,COMPARE_UNEQUAL=263
	,LOGICAL_AND=264
	,LOGICAL_OR=265
	,ASSIGN=266
	,COMPARE_LESS=267
	,COMPARE_LESS_OR_EQUAL=268
	,COMPARE_GREATER=269
	,COMPARE_GREATER_OR_EQUAL=270
	,RANGE=271
	,PROPSTATE=272
	,REGEXP=273
	,XMLEXP=274
	,STRING=275
	,QUOTE=276
	,BOOL=277


#line 286 "c:\\usr\\bin\\bison.cc"
 /* enum token */
     }; /* end of enum declaration */
#endif
public:
 int YY_PropertyResourceRuleParser_PARSE (YY_PropertyResourceRuleParser_PARSE_PARAM);
 virtual void YY_PropertyResourceRuleParser_ERROR(char *msg) YY_PropertyResourceRuleParser_ERROR_BODY;
#ifdef YY_PropertyResourceRuleParser_PURE
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
 virtual int  YY_PropertyResourceRuleParser_LEX (YY_PropertyResourceRuleParser_STYPE *YY_PropertyResourceRuleParser_LVAL,YY_PropertyResourceRuleParser_LTYPE *YY_PropertyResourceRuleParser_LLOC) YY_PropertyResourceRuleParser_LEX_BODY;
#else
 virtual int  YY_PropertyResourceRuleParser_LEX (YY_PropertyResourceRuleParser_STYPE *YY_PropertyResourceRuleParser_LVAL) YY_PropertyResourceRuleParser_LEX_BODY;
#endif
#else
 virtual int YY_PropertyResourceRuleParser_LEX() YY_PropertyResourceRuleParser_LEX_BODY;
 YY_PropertyResourceRuleParser_STYPE YY_PropertyResourceRuleParser_LVAL;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
 YY_PropertyResourceRuleParser_LTYPE YY_PropertyResourceRuleParser_LLOC;
#endif
 int   YY_PropertyResourceRuleParser_NERRS;
 int    YY_PropertyResourceRuleParser_CHAR;
#endif
#if YY_PropertyResourceRuleParser_DEBUG != 0
 int YY_PropertyResourceRuleParser_DEBUG_FLAG;   /*  nonzero means print parse trace     */
#endif
public:
 YY_PropertyResourceRuleParser_CLASS(YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM);
public:
 YY_PropertyResourceRuleParser_MEMBERS 
};
/* other declare folow */
#if YY_PropertyResourceRuleParser_USE_CONST_TOKEN != 0

/* #line 317 "c:\\usr\\bin\\bison.cc" */
#line 502 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"
const int YY_PropertyResourceRuleParser_CLASS::MATH_TAN=258;
const int YY_PropertyResourceRuleParser_CLASS::MATH_SIN=259;
const int YY_PropertyResourceRuleParser_CLASS::MATH_COS=260;
const int YY_PropertyResourceRuleParser_CLASS::MATH_PI=261;
const int YY_PropertyResourceRuleParser_CLASS::COMPARE_EQUAL=262;
const int YY_PropertyResourceRuleParser_CLASS::COMPARE_UNEQUAL=263;
const int YY_PropertyResourceRuleParser_CLASS::LOGICAL_AND=264;
const int YY_PropertyResourceRuleParser_CLASS::LOGICAL_OR=265;
const int YY_PropertyResourceRuleParser_CLASS::ASSIGN=266;
const int YY_PropertyResourceRuleParser_CLASS::COMPARE_LESS=267;
const int YY_PropertyResourceRuleParser_CLASS::COMPARE_LESS_OR_EQUAL=268;
const int YY_PropertyResourceRuleParser_CLASS::COMPARE_GREATER=269;
const int YY_PropertyResourceRuleParser_CLASS::COMPARE_GREATER_OR_EQUAL=270;
const int YY_PropertyResourceRuleParser_CLASS::RANGE=271;
const int YY_PropertyResourceRuleParser_CLASS::PROPSTATE=272;
const int YY_PropertyResourceRuleParser_CLASS::REGEXP=273;
const int YY_PropertyResourceRuleParser_CLASS::XMLEXP=274;
const int YY_PropertyResourceRuleParser_CLASS::STRING=275;
const int YY_PropertyResourceRuleParser_CLASS::QUOTE=276;
const int YY_PropertyResourceRuleParser_CLASS::BOOL=277;


#line 317 "c:\\usr\\bin\\bison.cc"
 /* const YY_PropertyResourceRuleParser_CLASS::token */
#endif
/*apres const  */
YY_PropertyResourceRuleParser_CLASS::YY_PropertyResourceRuleParser_CLASS(YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM) YY_PropertyResourceRuleParser_CONSTRUCTOR_INIT
{
#if YY_PropertyResourceRuleParser_DEBUG != 0
YY_PropertyResourceRuleParser_DEBUG_FLAG=0;
#endif
YY_PropertyResourceRuleParser_CONSTRUCTOR_CODE;
};
#endif

/* #line 328 "c:\\usr\\bin\\bison.cc" */
#line 539 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"


#define	YYFINAL		73
#define	YYFLAG		32768
#define	YYNTBASE	30

#define YYTRANSLATE(x) ((unsigned)(x) <= 277 ? yytranslate[x] : 40)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    28,
    29,    23,    26,    27,    25,     2,    24,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22
};

#if YY_PropertyResourceRuleParser_DEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     6,    10,    11,    15,    17,    19,    21,
    23,    25,    27,    31,    35,    39,    43,    47,    52,    57,
    62,    66,    70,    74,    76,    78,    82,    86,    90,    94,
    98,   100,   102,   104,   106,   108,   110,   112,   114,   118
};

static const short yyrhs[] = {    34,
     0,    31,     0,    32,     0,    32,    27,    31,     0,     0,
    17,    11,    33,     0,    22,     0,    20,     0,     6,     0,
    19,     0,    21,     0,    17,     0,    28,    33,    29,     0,
    33,    23,    33,     0,    33,    24,    33,     0,    33,    25,
    33,     0,    33,    26,    33,     0,     5,    28,    33,    29,
     0,     4,    28,    33,    29,     0,     3,    28,    33,    29,
     0,    28,    34,    29,     0,    34,     9,    34,     0,    34,
    10,    34,     0,    35,     0,    36,     0,    33,    12,    33,
     0,    33,    13,    33,     0,    33,    14,    33,     0,    33,
    15,    33,     0,    17,    37,    39,     0,     7,     0,     8,
     0,    22,     0,    20,     0,    18,     0,    16,     0,    21,
     0,    38,     0,    38,    27,    39,     0,     0
};

#endif

#if YY_PropertyResourceRuleParser_DEBUG != 0
static const short yyrline[] = { 0,
   211,   212,   215,   219,   223,   229,   242,   246,   250,   254,
   258,   262,   277,   281,   290,   318,   327,   336,   340,   344,
   352,   356,   360,   364,   368,   375,   380,   385,   390,   397,
   461,   465,   471,   475,   479,   483,   487,   494,   495,   496
};

static const char * const yytname[] = {   "$","error","$illegal.","MATH_TAN",
"MATH_SIN","MATH_COS","MATH_PI","COMPARE_EQUAL","COMPARE_UNEQUAL","LOGICAL_AND",
"LOGICAL_OR","ASSIGN","COMPARE_LESS","COMPARE_LESS_OR_EQUAL","COMPARE_GREATER",
"COMPARE_GREATER_OR_EQUAL","RANGE","PROPSTATE","REGEXP","XMLEXP","STRING","QUOTE",
"BOOL","'*'","'/'","'-'","'+'","','","'('","')'","EXPRESSION","ASSIGNMENTLIST",
"ASSIGNMENT","PROPSTATEEXPRESSION","CONDITION","STATEREL","STATECOMP","COMPARISON",
"VALUE","VALUELIST",""
};
#endif

static const short yyr1[] = {     0,
    30,    30,    31,    31,    31,    32,    33,    33,    33,    33,
    33,    33,    33,    33,    33,    33,    33,    33,    33,    33,
    34,    34,    34,    34,    34,    35,    35,    35,    35,    36,
    37,    37,    38,    38,    38,    38,    38,    39,    39,    39
};

static const short yyr2[] = {     0,
     1,     1,     1,     3,     0,     3,     1,     1,     1,     1,
     1,     1,     3,     3,     3,     3,     3,     4,     4,     4,
     3,     3,     3,     1,     1,     3,     3,     3,     3,     3,
     1,     1,     1,     1,     1,     1,     1,     1,     3,     0
};

static const short yydefact[] = {     5,
     0,     0,     0,     9,    12,    10,     8,    11,     7,     0,
     2,     3,     0,     1,    24,    25,     0,     0,     0,    31,
    32,     0,    40,    12,     0,     0,     5,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    12,     0,     0,
     0,     0,     6,    36,    35,    34,    37,    33,    38,    30,
    13,    21,     0,     4,    26,    27,    28,    29,    14,    15,
    16,    17,    22,    23,     0,    20,    19,    18,    40,    39,
     0,     0,     0
};

static const short yydefgoto[] = {    71,
    11,    12,    13,    14,    15,    16,    23,    49,    50
};

static const short yypact[] = {    27,
   -15,   -12,   -11,-32768,    -5,-32768,-32768,-32768,-32768,    37,
-32768,    -1,    66,     1,-32768,-32768,    47,    47,    47,-32768,
-32768,    47,    77,    -3,    48,     5,    22,    47,    47,    47,
    47,    47,    47,    47,    47,    37,    37,-32768,    47,    59,
    78,    85,    12,-32768,-32768,-32768,-32768,-32768,    18,-32768,
-32768,-32768,    65,-32768,    12,    12,    12,    12,-32768,-32768,
-32768,-32768,     1,     1,    92,-32768,-32768,-32768,    77,-32768,
    70,    86,-32768
};

static const short yypgoto[] = {-32768,
    60,-32768,   -10,    -9,-32768,-32768,-32768,-32768,    25
};


#define	YYLAST		121


static const short yytable[] = {    25,
    26,    20,    21,    20,    21,    22,    40,    41,    42,    36,
    37,    43,    17,    36,    37,    18,    19,    55,    56,    57,
    58,    59,    60,    61,    62,    27,    63,    64,    65,     1,
     2,     3,     4,    52,    32,    33,    34,    35,    53,     1,
     2,     3,     4,     5,    69,     6,     7,     8,     9,     1,
     2,     3,     4,    24,    10,     6,     7,     8,     9,    28,
    29,    30,    31,    38,    10,     6,     7,     8,     9,    72,
    32,    33,    34,    35,    39,    22,    51,    28,    29,    30,
    31,    32,    33,    34,    35,    73,    54,    66,    32,    33,
    34,    35,    44,    70,    45,     0,    46,    47,    48,     0,
    32,    33,    34,    35,     0,     0,    67,    32,    33,    34,
    35,     0,     0,    68,    32,    33,    34,    35,     0,     0,
    51
};

static const short yycheck[] = {    10,
    10,     7,     8,     7,     8,    11,    17,    18,    19,     9,
    10,    22,    28,     9,    10,    28,    28,    28,    29,    30,
    31,    32,    33,    34,    35,    27,    36,    37,    39,     3,
     4,     5,     6,    29,    23,    24,    25,    26,    17,     3,
     4,     5,     6,    17,    27,    19,    20,    21,    22,     3,
     4,     5,     6,    17,    28,    19,    20,    21,    22,    12,
    13,    14,    15,    17,    28,    19,    20,    21,    22,     0,
    23,    24,    25,    26,    28,    11,    29,    12,    13,    14,
    15,    23,    24,    25,    26,     0,    27,    29,    23,    24,
    25,    26,    16,    69,    18,    -1,    20,    21,    22,    -1,
    23,    24,    25,    26,    -1,    -1,    29,    23,    24,    25,
    26,    -1,    -1,    29,    23,    24,    25,    26,    -1,    -1,
    29
};

#line 328 "c:\\usr\\bin\\bison.cc"
 /* fattrs + tables */

/* parser code folow  */


/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: dollar marks section change
   the next  is replaced by the list of actions, each action
   as one case of the switch.  */ 

#if YY_PropertyResourceRuleParser_USE_GOTO != 0
/* 
 SUPRESSION OF GOTO : on some C++ compiler (sun c++)
  the goto is strictly forbidden if any constructor/destructor
  is used in the whole function (very stupid isn't it ?)
 so goto are to be replaced with a 'while/switch/case construct'
 here are the macro to keep some apparent compatibility
*/
#define YYGOTO(lb) {yy_gotostate=lb;continue;}
#define YYBEGINGOTO  enum yy_labels yy_gotostate=yygotostart; \
                     for(;;) switch(yy_gotostate) { case yygotostart: {
#define YYLABEL(lb) } case lb: {
#define YYENDGOTO } } 
#define YYBEGINDECLARELABEL enum yy_labels {yygotostart
#define YYDECLARELABEL(lb) ,lb
#define YYENDDECLARELABEL  };
#else
/* macro to keep goto */
#define YYGOTO(lb) goto lb
#define YYBEGINGOTO 
#define YYLABEL(lb) lb:
#define YYENDGOTO
#define YYBEGINDECLARELABEL 
#define YYDECLARELABEL(lb)
#define YYENDDECLARELABEL 
#endif
/* LABEL DECLARATION */
YYBEGINDECLARELABEL
  YYDECLARELABEL(yynewstate)
  YYDECLARELABEL(yybackup)
/* YYDECLARELABEL(yyresume) */
  YYDECLARELABEL(yydefault)
  YYDECLARELABEL(yyreduce)
  YYDECLARELABEL(yyerrlab)   /* here on detecting error */
  YYDECLARELABEL(yyerrlab1)   /* here on error raised explicitly by an action */
  YYDECLARELABEL(yyerrdefault)  /* current state does not do anything special for the error token. */
  YYDECLARELABEL(yyerrpop)   /* pop the current state because it cannot handle the error token */
  YYDECLARELABEL(yyerrhandle)  
YYENDDECLARELABEL
/* ALLOCA SIMULATION */
/* __HAVE_NO_ALLOCA */
#ifdef __HAVE_NO_ALLOCA
int __alloca_free_ptr(char *ptr,char *ref)
{if(ptr!=ref) free(ptr);
 return 0;}

#define __ALLOCA_alloca(size) malloc(size)
#define __ALLOCA_free(ptr,ref) __alloca_free_ptr((char *)ptr,(char *)ref)

#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
#define __ALLOCA_return(num) \
            return( __ALLOCA_free(yyss,yyssa)+\
		    __ALLOCA_free(yyvs,yyvsa)+\
		    __ALLOCA_free(yyls,yylsa)+\
		   (num))
#else
#define __ALLOCA_return(num) \
            return( __ALLOCA_free(yyss,yyssa)+\
		    __ALLOCA_free(yyvs,yyvsa)+\
		   (num))
#endif
#else
#define __ALLOCA_return(num) return(num)
#define __ALLOCA_alloca(size) alloca(size)
#define __ALLOCA_free(ptr,ref) 
#endif

/* ENDALLOCA SIMULATION */

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (YY_PropertyResourceRuleParser_CHAR = YYEMPTY)
#define YYEMPTY         -2
#define YYEOF           0
#define YYACCEPT        __ALLOCA_return(0)
#define YYABORT         __ALLOCA_return(1)
#define YYERROR         YYGOTO(yyerrlab1)
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL          YYGOTO(yyerrlab)
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do                                                              \
  if (YY_PropertyResourceRuleParser_CHAR == YYEMPTY && yylen == 1)                               \
    { YY_PropertyResourceRuleParser_CHAR = (token), YY_PropertyResourceRuleParser_LVAL = (value);                 \
      yychar1 = YYTRANSLATE (YY_PropertyResourceRuleParser_CHAR);                                \
      YYPOPSTACK;                                               \
      YYGOTO(yybackup);                                            \
    }                                                           \
  else                                                          \
    { YY_PropertyResourceRuleParser_ERROR ("syntax error: cannot back up"); YYERROR; }   \
while (0)

#define YYTERROR        1
#define YYERRCODE       256

#ifndef YY_PropertyResourceRuleParser_PURE
/* UNPURE */
#define YYLEX           YY_PropertyResourceRuleParser_LEX()
#ifndef YY_USE_CLASS
/* If nonreentrant, and not class , generate the variables here */
int     YY_PropertyResourceRuleParser_CHAR;                      /*  the lookahead symbol        */
YY_PropertyResourceRuleParser_STYPE      YY_PropertyResourceRuleParser_LVAL;              /*  the semantic value of the */
				/*  lookahead symbol    */
int YY_PropertyResourceRuleParser_NERRS;                 /*  number of parse errors so far */
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
YY_PropertyResourceRuleParser_LTYPE YY_PropertyResourceRuleParser_LLOC;   /*  location data for the lookahead     */
			/*  symbol                              */
#endif
#endif


#else
/* PURE */
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
#define YYLEX           YY_PropertyResourceRuleParser_LEX(&YY_PropertyResourceRuleParser_LVAL, &YY_PropertyResourceRuleParser_LLOC)
#else
#define YYLEX           YY_PropertyResourceRuleParser_LEX(&YY_PropertyResourceRuleParser_LVAL)
#endif
#endif
#ifndef YY_USE_CLASS
#if YY_PropertyResourceRuleParser_DEBUG != 0
int YY_PropertyResourceRuleParser_DEBUG_FLAG;                    /*  nonzero means print parse trace     */
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif
#endif



/*  YYINITDEPTH indicates the initial size of the parser's stacks       */

#ifndef YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif


#if __GNUC__ > 1                /* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)       __builtin_memcpy(TO,FROM,COUNT)
#else                           /* not GNU C or C++ */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */

#ifdef __cplusplus
static void __yy_bcopy (char *from, char *to, int count)
#else
#ifdef __STDC__
static void __yy_bcopy (char *from, char *to, int count)
#else
static void __yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
#endif
#endif
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}
#endif

int
#ifdef YY_USE_CLASS
 YY_PropertyResourceRuleParser_CLASS::
#endif
     YY_PropertyResourceRuleParser_PARSE(YY_PropertyResourceRuleParser_PARSE_PARAM)
#ifndef __STDC__
#ifndef __cplusplus
#ifndef YY_USE_CLASS
/* parameter definition without protypes */
YY_PropertyResourceRuleParser_PARSE_PARAM_DEF
#endif
#endif
#endif
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YY_PropertyResourceRuleParser_STYPE *yyvsp;
  int yyerrstatus;      /*  number of tokens to shift before error messages enabled */
  int yychar1=0;          /*  lookahead token as an internal (translated) token number */

  short yyssa[YYINITDEPTH];     /*  the state stack                     */
  YY_PropertyResourceRuleParser_STYPE yyvsa[YYINITDEPTH];        /*  the semantic value stack            */

  short *yyss = yyssa;          /*  refer to the stacks thru separate pointers */
  YY_PropertyResourceRuleParser_STYPE *yyvs = yyvsa;     /*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  YY_PropertyResourceRuleParser_LTYPE yylsa[YYINITDEPTH];        /*  the location stack                  */
  YY_PropertyResourceRuleParser_LTYPE *yyls = yylsa;
  YY_PropertyResourceRuleParser_LTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YY_PropertyResourceRuleParser_PURE
  int YY_PropertyResourceRuleParser_CHAR;
  YY_PropertyResourceRuleParser_STYPE YY_PropertyResourceRuleParser_LVAL;
  int YY_PropertyResourceRuleParser_NERRS;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  YY_PropertyResourceRuleParser_LTYPE YY_PropertyResourceRuleParser_LLOC;
#endif
#endif

  YY_PropertyResourceRuleParser_STYPE yyval;             /*  the variable used to return         */
				/*  semantic values from the action     */
				/*  routines                            */

  int yylen;
/* start loop, in which YYGOTO may be used. */
YYBEGINGOTO

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    fprintf(stderr, "Starting parse\n");
#endif
  yystate = 0;
  yyerrstatus = 0;
  YY_PropertyResourceRuleParser_NERRS = 0;
  YY_PropertyResourceRuleParser_CHAR = YYEMPTY;          /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
YYLABEL(yynewstate)

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YY_PropertyResourceRuleParser_STYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
      YY_PropertyResourceRuleParser_LTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  YY_PropertyResourceRuleParser_ERROR("parser stack overflow");
	  __ALLOCA_return(2);
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) __ALLOCA_alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      __ALLOCA_free(yyss1,yyssa);
      yyvs = (YY_PropertyResourceRuleParser_STYPE *) __ALLOCA_alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
      __ALLOCA_free(yyvs1,yyvsa);
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
      yyls = (YY_PropertyResourceRuleParser_LTYPE *) __ALLOCA_alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
      __ALLOCA_free(yyls1,yylsa);
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YY_PropertyResourceRuleParser_DEBUG != 0
      if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  YYGOTO(yybackup);
YYLABEL(yybackup)

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* YYLABEL(yyresume) */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    YYGOTO(yydefault);

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (YY_PropertyResourceRuleParser_CHAR == YYEMPTY)
    {
#if YY_PropertyResourceRuleParser_DEBUG != 0
      if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
	fprintf(stderr, "Reading a token: ");
#endif
      YY_PropertyResourceRuleParser_CHAR = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (YY_PropertyResourceRuleParser_CHAR <= 0)           /* This means end of input. */
    {
      yychar1 = 0;
      YY_PropertyResourceRuleParser_CHAR = YYEOF;                /* Don't call YYLEX any more */

#if YY_PropertyResourceRuleParser_DEBUG != 0
      if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(YY_PropertyResourceRuleParser_CHAR);

#if YY_PropertyResourceRuleParser_DEBUG != 0
      if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
	{
	  fprintf (stderr, "Next token is %d (%s", YY_PropertyResourceRuleParser_CHAR, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, YY_PropertyResourceRuleParser_CHAR, YY_PropertyResourceRuleParser_LVAL);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    YYGOTO(yydefault);

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	YYGOTO(yyerrlab);
      yyn = -yyn;
      YYGOTO(yyreduce);
    }
  else if (yyn == 0)
    YYGOTO(yyerrlab);

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    fprintf(stderr, "Shifting token %d (%s), ", YY_PropertyResourceRuleParser_CHAR, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (YY_PropertyResourceRuleParser_CHAR != YYEOF)
    YY_PropertyResourceRuleParser_CHAR = YYEMPTY;

  *++yyvsp = YY_PropertyResourceRuleParser_LVAL;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  *++yylsp = YY_PropertyResourceRuleParser_LLOC;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  YYGOTO(yynewstate);

/* Do the default action for the current state.  */
YYLABEL(yydefault)

  yyn = yydefact[yystate];
  if (yyn == 0)
    YYGOTO(yyerrlab);

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
YYLABEL(yyreduce)
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


/* #line 814 "c:\\usr\\bin\\bison.cc" */
#line 1191 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"

  switch (yyn) {

case 3:
#line 216 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = true;
		;
    break;}
case 4:
#line 220 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = true;
		;
    break;}
case 5:
#line 224 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = true;
		;
    break;}
case 6:
#line 230 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            std::vector<std::string> tokens=oc::Util::Tokenize( yyvsp[-2].string , '.' );
            if( tokens.size() == 2 ) {
                if( pmap.HasProperty(tokens[0] ) ) {
					pmap[tokens[0]].GetResource().SetState(tokens[1],yyvsp[0].string);
					//std::cout << " " << tokens[0] << "." << tokens[1] << "=" << $3 << std::endl;
				}
			}
			yyval.boolean = true;
		;
    break;}
case 7:
#line 243 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy(yyval.string,yyvsp[0].string);
		;
    break;}
case 8:
#line 247 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy(yyval.string,yyvsp[0].string);
		;
    break;}
case 9:
#line 251 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy(yyval.string,"3.1415926535897932384626433832795");
		;
    break;}
case 10:
#line 255 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy(yyval.string,yyvsp[0].string);
		;
    break;}
case 11:
#line 259 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy(yyval.string,yyvsp[0].string);
		;
    break;}
case 12:
#line 263 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            std::vector<std::string> tokens=oc::Util::Tokenize( yyvsp[0].string , '.' );
            if( tokens.size() == 2 ) {
                if( pmap.HasProperty(tokens[0] ) ) {
                    if( pmap[tokens[0]].GetResource().HasState(tokens[1]) ) {

                        //std::cout << "checking " << tokens[0] << "." << tokens[1] << std::endl;
                        std::string val = pmap[tokens[0]].GetResource().GetState(tokens[1]);
						strcpy(yyval.string,val.c_str());
					}
				}
			}

		;
    break;}
case 13:
#line 278 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy(yyval.string,yyvsp[-1].string);			
		;
    break;}
case 14:
#line 282 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
		    if( oc::Util::IsDouble(yyvsp[-2].string) || oc::Util::IsDouble(yyvsp[0].string) ) {
				strcpy(yyval.string,oc::Util::ToString(oc::Util::ToDouble(yyvsp[-2].string)*oc::Util::ToDouble(yyvsp[0].string)).c_str() );
			}
			else {
				strcpy(yyval.string,oc::Util::ToString(oc::Util::ToInt(yyvsp[-2].string)*oc::Util::ToInt(yyvsp[0].string)).c_str() );
			}
		;
    break;}
case 15:
#line 291 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
		    if( oc::Util::IsDouble(yyvsp[-2].string) || oc::Util::IsDouble(yyvsp[0].string) ) {
				double d = oc::Util::ToDouble(yyvsp[0].string);
#if OC_CHECK_GCC_VERSION(3, 0) || defined(MSDOS)
				if( fabs(d) > std::numeric_limits<double>::min() )
#else
				if( fabs(d) > DBL_MIN )
#endif
                                {
					strcpy(yyval.string,oc::Util::ToString(oc::Util::ToDouble(yyvsp[-2].string)/d).c_str() );
				}
				else {
					OCERROR("division by zero: " << yyvsp[-2].string << '/' << yyvsp[0].string);
					strcpy(yyval.string,"0");
				}
			}
			else {
				int d = oc::Util::ToInt(yyvsp[0].string);
				if( d != 0 ) {
					strcpy(yyval.string,oc::Util::ToString(oc::Util::ToInt(yyvsp[-2].string)/d).c_str() );
				}
				else {
					OCERROR("division by zero: " << yyvsp[-2].string << '/' << yyvsp[0].string);
					strcpy(yyval.string,"0");
				}
			}
		;
    break;}
case 16:
#line 319 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
		    if( oc::Util::IsDouble(yyvsp[-2].string) || oc::Util::IsDouble(yyvsp[0].string) ) {
				strcpy(yyval.string,oc::Util::ToString(oc::Util::ToDouble(yyvsp[-2].string)-oc::Util::ToDouble(yyvsp[0].string)).c_str() );
			}
			else {
				strcpy(yyval.string,oc::Util::ToString(oc::Util::ToInt(yyvsp[-2].string)-oc::Util::ToInt(yyvsp[0].string)).c_str() );
			}
		;
    break;}
case 17:
#line 328 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
		    if( oc::Util::IsDouble(yyvsp[-2].string) || oc::Util::IsDouble(yyvsp[0].string) ) {
				strcpy(yyval.string,oc::Util::ToString(oc::Util::ToDouble(yyvsp[-2].string)+oc::Util::ToDouble(yyvsp[0].string)).c_str() );
			}
			else {
				strcpy(yyval.string,oc::Util::ToString(oc::Util::ToInt(yyvsp[-2].string)+oc::Util::ToInt(yyvsp[0].string)).c_str() );
			}
		;
    break;}
case 18:
#line 337 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{		
			strcpy( yyval.string, oc::Util::ToString( cos( oc::Util::ToDouble( yyvsp[-1].string ) ) ).c_str() );
		;
    break;}
case 19:
#line 341 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy( yyval.string, oc::Util::ToString( sin( oc::Util::ToDouble( yyvsp[-1].string ) ) ).c_str() );
		;
    break;}
case 20:
#line 345 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			strcpy( yyval.string, oc::Util::ToString( tan( oc::Util::ToDouble( yyvsp[-1].string ) ) ).c_str() );
		;
    break;}
case 21:
#line 353 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mResult = yyval.boolean = yyvsp[-1].boolean;
        ;
    break;}
case 22:
#line 357 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mResult = yyval.boolean = yyvsp[-2].boolean && yyvsp[0].boolean;
        ;
    break;}
case 23:
#line 361 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mResult = yyval.boolean = yyvsp[-2].boolean || yyvsp[0].boolean;
        ;
    break;}
case 24:
#line 365 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			mResult = yyval.boolean = yyvsp[0].boolean;
		;
    break;}
case 25:
#line 369 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mResult = yyval.boolean = yyvsp[0].boolean;
        ;
    break;}
case 26:
#line 376 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = oc::PropertyResourceRule::EvalStatetagRelation("<",yyvsp[-2].string,yyvsp[0].string);
			//std::cout << $1 << "<" << $3 << " == " << $$;
		;
    break;}
case 27:
#line 381 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = oc::PropertyResourceRule::EvalStatetagRelation("<=",yyvsp[-2].string,yyvsp[0].string);
			//std::cout << $1 << "<=" << $3 << " == " << $$;
		;
    break;}
case 28:
#line 386 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = oc::PropertyResourceRule::EvalStatetagRelation(">",yyvsp[-2].string,yyvsp[0].string);
			//std::cout << $1 << ">" << $3 << " == " << $$;
		;
    break;}
case 29:
#line 391 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			yyval.boolean = oc::PropertyResourceRule::EvalStatetagRelation(">=",yyvsp[-2].string,yyvsp[0].string);
			//std::cout << $1 << ">=" << $3 << " == " << $$;
		;
    break;}
case 30:
#line 398 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            std::vector<std::string> tokens=oc::Util::Tokenize( yyvsp[-2].string , '.' );
            if( tokens.size() == 2 ) {
                if( pmap.HasProperty(tokens[0] ) ) {
                    if( pmap[tokens[0]].GetResource().HasState(tokens[1]) ) {

                        //std::cout << "checking " << tokens[0] << "." << tokens[1] << std::endl;
                        std::string val = pmap[tokens[0]].GetResource().GetState(tokens[1]);
                        bool retval=false,actval;
                        for( int i=0; i<mValueList.size(); i++ ) {
                            switch( mValueList[i][0] ) {
								case 'q': { // copy through (does not make much sense here)
									actval = oc::PropertyResourceRule::EvalStatetagSingle( val, std::string( mValueList[i].c_str()+2 ) );
								} break;
                                case 'v': { // single value
                                    actval = oc::PropertyResourceRule::EvalStatetagSingle( val, std::string( mValueList[i].c_str()+2 ) );
                                } break;
								case 'b': { // single boolean
									actval = oc::PropertyResourceRule::EvalStatetagBool( val, std::string( mValueList[i].c_str()+2 ) );
								} break;
                                case 'r': { // range 
                                    actval = oc::PropertyResourceRule::EvalStatetagRange( val, std::string( mValueList[i].c_str()+2 ) );
                                } break;
                                case 'e': { // regular expression
                                    actval = oc::PropertyResourceRule::EvalStatetagRegexp( val, std::string( mValueList[i].c_str()+2 ) );
                                } break;
                            }

                            // valuelist value
                            if( !retval ) {
                                retval = actval;
                            }

                            //std::cout << "  against " << mValueList[i] << " = " << actval << std::endl;
                        }
                        if( !yyvsp[-1].boolean ) {
                            yyval.boolean = !retval;
                        } 
                        else {
                            yyval.boolean = retval;
                        }
                        mValueList.clear();
                         
                        //std::cout << "test: " << tokens[0] << "." << tokens[1] << " = " << (($$)?"true":"false") << std::endl;  
                    }
                    else {
                        OCERROR("no such state: " << tokens[1]);
                        ( yyvsp[-1].boolean ) ? yyval.boolean = false : yyval.boolean = true;
                    }
                }
                else {
                    OCERROR("no such property: " << tokens[0]);
                    ( yyvsp[-1].boolean ) ? yyval.boolean = false : yyval.boolean = true;
                }
            }
            else {
                OCERROR("expected: Property.state");
                ( yyvsp[-1].boolean ) ? yyval.boolean = false : yyval.boolean = true;
            }

        ;
    break;}
case 31:
#line 462 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            yyval.boolean = true;
        ;
    break;}
case 32:
#line 466 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            yyval.boolean = false;
        ;
    break;}
case 33:
#line 472 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mValueList.push_back("b:"+std::string(yyvsp[0].string));
		;
    break;}
case 34:
#line 476 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mValueList.push_back("v:"+std::string(yyvsp[0].string));
        ;
    break;}
case 35:
#line 480 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mValueList.push_back("e:"+std::string(yyvsp[0].string));
        ;
    break;}
case 36:
#line 484 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
            mValueList.push_back("r:"+std::string(yyvsp[0].string));
        ;
    break;}
case 37:
#line 488 "..\\src\\orcan\\PropertyResourceRuleParser.y"
{
			mValueList.push_back("q:"+std::string(yyvsp[0].string));
		;
    break;}
}

#line 814 "c:\\usr\\bin\\bison.cc"
   /* the action file gets copied in in place of this dollarsign  */
  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  yylsp -= yylen;
#endif

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = YY_PropertyResourceRuleParser_LLOC.first_line;
      yylsp->first_column = YY_PropertyResourceRuleParser_LLOC.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  YYGOTO(yynewstate);

YYLABEL(yyerrlab)   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++YY_PropertyResourceRuleParser_NERRS;

#ifdef YY_PropertyResourceRuleParser_ERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      YY_PropertyResourceRuleParser_ERROR(msg);
	      free(msg);
	    }
	  else
	    YY_PropertyResourceRuleParser_ERROR ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YY_PropertyResourceRuleParser_ERROR_VERBOSE */
	YY_PropertyResourceRuleParser_ERROR("parse error");
    }

  YYGOTO(yyerrlab1);
YYLABEL(yyerrlab1)   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (YY_PropertyResourceRuleParser_CHAR == YYEOF)
	YYABORT;

#if YY_PropertyResourceRuleParser_DEBUG != 0
      if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
	fprintf(stderr, "Discarding token %d (%s).\n", YY_PropertyResourceRuleParser_CHAR, yytname[yychar1]);
#endif

      YY_PropertyResourceRuleParser_CHAR = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;              /* Each real token shifted decrements this */

  YYGOTO(yyerrhandle);

YYLABEL(yyerrdefault)  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) YYGOTO(yydefault);
#endif

YYLABEL(yyerrpop)   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  yylsp--;
#endif

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

YYLABEL(yyerrhandle)

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    YYGOTO(yyerrdefault);

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    YYGOTO(yyerrdefault);

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	YYGOTO(yyerrpop);
      yyn = -yyn;
      YYGOTO(yyreduce);
    }
  else if (yyn == 0)
    YYGOTO(yyerrpop);

  if (yyn == YYFINAL)
    YYACCEPT;

#if YY_PropertyResourceRuleParser_DEBUG != 0
  if (YY_PropertyResourceRuleParser_DEBUG_FLAG)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = YY_PropertyResourceRuleParser_LVAL;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
  *++yylsp = YY_PropertyResourceRuleParser_LLOC;
#endif

  yystate = yyn;
  YYGOTO(yynewstate);
/* end loop, in which YYGOTO may be used. */
  YYENDGOTO
}

/* END */

/* #line 1013 "c:\\usr\\bin\\bison.cc" */
#line 1728 "..\\src\\orcan\\PropertyResourceRuleParser.cpp"
#line 500 "..\\src\\orcan\\PropertyResourceRuleParser.y"
