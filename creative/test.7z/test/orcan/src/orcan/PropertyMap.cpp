// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyResourceRule.hh>
#include <oc/Util.hh>


// C include

#include <cassert>





// *****************************************************************************
// *****************************************************************************
//
// CLASS: PropertyMap
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   PropertyMap()
//
// Destructor:
//
//   ~PropertyMap()
//
// *****************************************************************************

oc::PropertyMap::PropertyMap()
{
}

oc::PropertyMap::~PropertyMap()
{
    // hash_map (used for win32) does not call default destructor
    // (because it only stores pointer internally) so we have to
    // call NotifyListeners explictly
    oc::PropertyMap::iterator prop,end_prop;
    for( prop=begin(),end_prop=end(); prop!=end_prop; ++prop) {
        prop->second.NotifyListeners(true);
    }
    mMap.clear();

    std::vector<Field *>::iterator it,eit;

    for( it=mTmpFields.begin(),eit=mTmpFields.end(); it != eit; ++it ) {

        delete *it;
    }
    mTmpFields.clear();


}


// *****************************************************************************
//
// GetProperty:
//
//  GetProperty( unsigned int idx )
//  GetProperty( unsigned int idx ) const
//
// *****************************************************************************

oc::Property & 
oc::PropertyMap::GetProperty( unsigned int idx )
{
    if(idx>=mMap.size()) 
        return oc::Property::Null();
   
    iterator it=begin();
    while(idx--) { ++it; }
    return it->second;
}
    
oc::Property const & 
oc::PropertyMap::GetProperty( unsigned int idx ) const
{
    if(idx>=mMap.size()) 
        return oc::Property::Null();

    const_iterator it=begin();
    while(idx--) { ++it; }
    return it->second;
}

// *****************************************************************************
//
// Operators:
//
//  operator[]( std::string const & name )
//  operator[]( std::string const & name ) const
//
// *****************************************************************************

oc::Property &
oc::PropertyMap::operator[]( std::string const & name )
{
    tMap::iterator it;

    it = mMap.find(name);

    if( it != mMap.end() ) {

        return( it->second );
    }

    return oc::Property::Null();
}



oc::Property const &
oc::PropertyMap::operator[]( std::string const & name ) const
{
    tMap::const_iterator it;

    it = mMap.find(name);

    if( it != mMap.end() ) {

        return( it->second );
    }
    
    return oc::Property::Null();
}



// *****************************************************************************
//
// Query Methods:
//
//  HasProperty( std::string const & name ) const
//  HasPropertyRet( std::string const & name)
//  HasPropertyRet( std::string const & name) const
//  GetNumProperties() const
//
// *****************************************************************************

bool 
oc::PropertyMap::HasProperty( std::string const & name ) const
{
    return( mMap.find( name ) != mMap.end() );
} 

oc::Property &
oc::PropertyMap::HasPropertyRet( std::string const & name)
{
    tMap::iterator it = mMap.find(name);

    if( it != mMap.end() ) {

        return( (*it).second );
    }
    
    return oc::Property::Null();
}

const oc::Property &
oc::PropertyMap::HasPropertyRet( std::string const & name) const
{
    tMap::const_iterator it = mMap.find(name);

    if( it != mMap.end() ) {

        return( (*it).second );
    }
    
    return oc::Property::Null();
}



int
oc::PropertyMap::GetNumProperties() const
{
    return mMap.size();
}



// *****************************************************************************
//
// Access Methods:
//
// *****************************************************************************

bool 
oc::PropertyMap::AddProperty( Property const & p )
{

    if( mMap.find(p.GetName()) != mMap.end() ) {
        OCERROR("Property " << p.GetName() << " alread exists: remove old one first, then add new one");
        return false;
    }
    mMap[p.GetName()] = p;

    return true;
}

bool 
oc::PropertyMap::RemoveProperty( std::string const & name )
{
    tMap::iterator prop;

    if( (prop=mMap.find(name)) == mMap.end() ) {
        return false;
    }

    mMap.erase(prop);
    return true;
}




// *****************************************************************************
//
// I/O Methods:
//
// *****************************************************************************

std::ostream& 
oc::PropertyMap::DumpMap( std::ostream & out ) const
{
    tMap::const_iterator it=mMap.begin(),eit=mMap.end();
    
    int cnt=0;
    while( it != eit ) {
        ++cnt;
        try {
            out << cnt << ": ";
            out << (*it).first << " = "
                << (*it).second.GetStringValue() 
                << " ( " << (*it).second.GetType().name() << " ) " << '\n';
        }
        catch(...) {
            out << cnt << ": ";
            out << (*it).first << " = " 
                << "---" 
                << " ( " << (*it).second.GetType().name() << " ) " << '\n';
        }
        
        ++it;
    }
    
    return  out;
}

bool 
oc::PropertyMap::Write( AdvXMLParser::Element& root ) const
{
    AdvXMLParser::Element& pmap = root("propertymap");
    pmap("name") << mName.c_str();
   
    tMap::const_iterator it=mMap.begin(),eit=mMap.end();

    int cnt=0;
    while( it != eit ) {
        
        // don't write pointer values
        std::string ptype = it->second.GetType().name();
        
        if( (::strcmp(ptype.c_str(),typeid(signed   int).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(unsigned int).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(float).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(double).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(signed   char).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(unsigned char).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(int32).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(uint32).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(real32).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(real64).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(oc::File).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(std::string).name()) == 0) ||
            (::strcmp(ptype.c_str(),typeid(bool).name()) == 0) ) {
            
            
            pmap("properties")("property",cnt)("name")  << it->first.c_str();
            pmap("properties")("property",cnt)("value") << it->second.GetStringValue().c_str();
            //it->second.GetResource().Write(xml);
            cnt++;
        }
        it++; 
    }
  
    return true;
}

bool 
oc::PropertyMap::Read( AdvXMLParser::Element const& root )
{
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element>   elemit_const;
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Attribute> attribit_const;
	
    if( root.GetElement("propertymap").IsNull() ) {
        OCERROR("no propertymap tag found");
        return false;
    }
    AdvXMLParser::Element const& map = root.GetElement("propertymap");

    elemit_const it  = map.Begin();
    elemit_const eit = map.End();
    for( ; it!=eit; ++it) {
        if( it->GetName() == "name" ) {
            SetName( it->GetValue() );
        }
        else if( it->GetName() == "properties" ) {
            elemit_const git  = it->Begin();
            elemit_const geit = it->End();
            for( ; git!=geit; ++git ) {
                AdvXMLParser::Element const& prop = *git;
                std::string pname = prop.GetElement("name").GetValue();
                if( pname != "" ) {
                    mMap[pname].SetStringValue( prop.GetElement("value").GetValue() );
                }
            }
        }
    }
    
    return true;
}


std::ostream& 
oc::PropertyMap::Write( std::ostream& out ) const
{
    out << "'" << mName << "'\n";
    out << mMap.size() << "\n";
    tMap::const_iterator it=mMap.begin(),eit=mMap.end();

    int cnt=0;
    while( it != eit ) {
        out << ++cnt << "\n";
        out << (*it).first << "\n";
        out << (*it).second.GetStringValue() << "\n";
        it->second.GetResource().Write(out);
	    ++it;
    }

    out << "lspec\n";
    out << mLayoutSpec.size() << " ";
    out << "'" <<mLayoutSpec << "'\n";


    return out;
}

std::istream& 
oc::PropertyMap::Read( std::istream& in )
{
    std::string name;
    in >> name;
    if( !in || in.eof() ) {
        OCERROR("could no read PropertyMap");
        return in;
    }
    if( name.size() >= 2 ) {
        SetName(name.substr(1,name.size()-2));
    }
    else {
        OCERROR("invalid Property name" << name);
        return in;
    }
    int cnt;
    in >> cnt;
    if( !in || in.eof() ) {
        OCERROR("could no read PropertyMap");
        return in;
    }
    for(int i=1; i<=cnt && !in.eof(); i++ ) {
        int num; std::string name, value;
        in >> num;
        in >> name;
        in >> value;
        if( in ) {
            if( i!=num ) {
                OCERROR("expected Property " << i );
                return in;
            }
            mMap[name].SetStringValue(value);
            mMap[name].GetResource().Read(in);
        }
        else {
            OCERROR("could no read Property "<<i);
            return in;
        }
    }

    std::string lspecid;
    int lspecsize;

    in >> lspecid;
    if( lspecid == "lspec" ) {
        in >> lspecsize;
        char *lspec = new char[lspecsize+3];
        in.read( lspec, lspecsize+3 );
        mLayoutSpec = std::string(lspec+2,lspecsize);
        delete [] lspec;
    }
    
    return in;
}

void 
oc::PropertyMap::SetName( std::string const& name)
{
    mName = name;
}

std::string const& 
oc::PropertyMap::GetName() const
{
    return mName;
}


std::string const& 
oc::PropertyMap::GetResourceLayout()
{
    return mLayoutSpec;
}

void 
oc::PropertyMap::SetResourceLayout( std::string const& layout_spec )
{
    mLayoutSpec = layout_spec;
}



// *****************************************************************************
//
// Iterator Methods
//
//  begin()
//  end()
//  begin() const
//  end() const
//  rbegin()
//  rend()
//  rbegin() const
//  rend() const
//
// *****************************************************************************

oc::PropertyMap::iterator
oc::PropertyMap::begin()
{

    return mMap.begin();
}



oc::PropertyMap::iterator
oc::PropertyMap::end()
{

    return mMap.end();
}



oc::PropertyMap::const_iterator
oc::PropertyMap::begin() const
{
    return mMap.begin();
}



oc::PropertyMap::const_iterator
oc::PropertyMap::end() const
{
    return mMap.end();
}


#ifndef WIN32
oc::PropertyMap::reverse_iterator
oc::PropertyMap::rbegin()
{
    return mMap.rbegin();
}



oc::PropertyMap::reverse_iterator
oc::PropertyMap::rend()
{
    return mMap.rend();
}



oc::PropertyMap::const_reverse_iterator
oc::PropertyMap::rbegin() const
{
    return mMap.rbegin();
}



oc::PropertyMap::const_reverse_iterator
oc::PropertyMap::rend() const
{
    return mMap.rend();
}

#endif

// *****************************************************************************
//
// Operators
//
// *****************************************************************************

OC_DSOAPI std::ostream &
oc::operator << ( std::ostream & out, oc::PropertyMap const & map )
{
    return map.DumpMap(out);
}

// *****************************************************************************
//
// Rules 
//
// *****************************************************************************

int 
oc::PropertyMap::GetNumResourceRules() const
{
    return mRules.size();
}

oc::PropertyResourceRule const& 
oc::PropertyMap::GetResourceRule(int idx) const
{
    assert( idx < mRules.size() );
    return mRules[idx];
}

void 
oc::PropertyMap::AddResourceRule(PropertyResourceRule const& rule) 
{
    mRules.push_back( rule );
}

void 
oc::PropertyMap::EvalDefaults()
{
    // for all properties in the map
    // set value to resourcerule.value 
    tMap::iterator it=mMap.begin(),eit=mMap.end();

    while( it != eit ) {
        try {
            if( it->second.GetResource().HasState("value") ) {
                if( it->second.GetResource().HasStateChanged("value") ) {
                    std::string value = it->second.GetResource().GetState("value");
                    it->second.SetStringValue( value );
                }
            }
        }catch(...) {
        }
        ++it;
    }
    
}


void 
oc::PropertyMap::EvalRules()
{
    int irule,icase;

    for( irule=0; irule<GetNumResourceRules(); irule++ ) {

        // Eval Rule j
        //GetResourceRule(irule).Dump(std::cout);

        int num_cases = GetResourceRule(irule).GetNumCases();

        int num_else_cases = 0;
        // Are there else cases 
        for( icase=0; icase<num_cases; icase++ ) {
            if( GetResourceRule(irule).GetCaseCondition(icase) == std::string("") ) {
                num_else_cases++;
            }
        }
        
        //OCDEBUG("rule " << irule << " with " << num_cases << " cases (" << num_else_cases << "else cases)" );

        // Eval all normal cases 
        bool normal_case = false;
        for( icase=0; icase<num_cases; icase++ ) {
            // additional check; not obligatory
            if( GetResourceRule(irule).GetCaseCondition(icase) != std::string("") ) {
                bool istrue;
                std::string rule = GetResourceRule( irule ).GetCaseCondition(icase);
                if( oc::PropertyResourceRule::EvalRuleCondition(this,rule,istrue) ) {
                    if( istrue ) {
                        // this also sets the change flags in the lhs expressions
                        if( !oc::PropertyResourceRule::EvalRuleCaseActions(this,irule,icase) ) {
                            OCERROR("could not evaluate case actions !?");
                        }
                        normal_case = true;
                        break; 
                    }
                }
            }
        }


        // Eval all else cases
        for( icase=0; icase<num_cases && !normal_case; icase++ ) {
            if( GetResourceRule(irule).GetCaseCondition(icase) == std::string("") ) {
                if( !oc::PropertyResourceRule::EvalRuleCaseActions(this,irule,icase) ) {
                    OCERROR("could not evaluate case actions !? (no parser ?)");
                }
            }
        }
    
    } // for all rules
   
}

void 
oc::PropertyMap::PropertyHasChanged( Property& prop, 
                                     bool      about_to_be_deleted )
{

    if( about_to_be_deleted ) {
        prop.RemoveListener(this); 
    }
    else {
        if( prop.GetResource().GetState("value") != prop.GetStringValue() ) {
            prop.GetResource().SetState( "value", prop.GetStringValue() );
            EvalRules();
        }
    }

}


