// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN includes

#include <oc/Log.hh>
#include <oc/PropertyMapResourceHandler.hh>
#include <oc/PropertyResourceRule.hh>

// C includes

#include <cassert>




bool
oc::PropertyMapResourceHandler::LoadXMLResource( const oc::File & file, oc::XMLObject& obj )
{
    if( !obj.Load(file) ) {
        return false;
    }
    return true;
}

bool 
oc::PropertyMapResourceHandler::Assign( oc::XMLObject const& obj, oc::PropertyMap& map )
{

    // try to assign all resouces in the xml-object 
    //  to properties in the map.

    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element>   elemit_const;
    AdvXMLParser::Element const& root  = obj.GetRoot();

    if( root.GetName() != "resources" ) {
        OCERROR("expected 'resources' root-tag");
        return false;
    }

    // get all resources and layout
    elemit_const it  = root.Begin();
    elemit_const eit = root.End();
    for( ; it!=eit; ++it) {

        // get layout
        if( it->GetName() == "layout" ) {
            AddResourcesLayout( *it, map );  
        }

        // get rules
        else if( it->GetName() == "rules" ) {
            AddResourcesRules( *it, map );
            AddResourcesDefaults( *it, map );
        }

        // from here on we only accept resources
        if( it->GetName() != "resource" ) {
            continue;
        }

        // get resource name, description and domain
        elemit_const rit  = it->Begin();
        elemit_const reit = it->End();
        
        
        oc::PropertyResource res;
        
        std::string domain;
        for( ; rit!=reit; ++rit ) {
            if( rit->GetName()=="description" ) {
                
                std::string value;
                AdvXMLParser::GenerateContext gcvalue(value);
                rit->GenerateXML(gcvalue);
                
                res.SetLayout(value);
            }
            else if( rit->GetName()=="name") {
                std::string name;
                name = rit->GetValue();
                // resource must have a name
                if( name.size() == 0 ) {
                    OCWARN("found resource without a name");
                }
                res.SetName( name );
            }
            else {
                //domain
                std::string value;
                AdvXMLParser::GenerateContext gcvalue(value);
                rit->GenerateXML(gcvalue);
                
                domain+=value; 
            }
        }
        res.SetDomain(domain);

        // set resource
        if( !map.HasProperty(res.GetName()) ) {
            OCWARN("resource " << res.GetName() << " has no coresponding property");
        }
        else {

            // set default resource values
            int state, num_state = res.GetNumState();
            for( state=0; state<num_state; state++ ) {
                res.SetState( "value", map[res.GetName()].GetStringValue() );
            }

            map[res.GetName()].SetResource(res);
        }   

    } // for all resources



    return true;
}

bool 
oc::PropertyMapResourceHandler::AddResourcesLayout( AdvXMLParser::Element const& layout, 
                                                      PropertyMap& map)
{
    assert( layout.GetName() == "layout" );
    
    std::string value;
    AdvXMLParser::GenerateContext gcvalue(value);
    layout.GenerateXML(gcvalue);

    map.SetResourceLayout(value);

    return true;   
}

bool 
oc::PropertyMapResourceHandler::ParseRule(AdvXMLParser::Element const& xml, oc::PropertyResourceRule& rule)
{
    // for all elements of rule
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element>   elemit;
    elemit rit=xml.Begin();
    elemit reit=xml.End();
    rit = xml.Begin(),reit = xml.End();
    for( ; rit!=reit; ++rit ) {
        if( rit->GetName() == "if" ||
            rit->GetName() == "elseif" ||
            rit->GetName() == "else" ) {
            
            std::vector< std::string > actions; 
            elemit cit  = rit->Begin();
            elemit ceit = rit->End();
            std::string condition;
            for( ; cit!=ceit; ++cit ) {
                
                // get condition
                if( cit->GetName() == "condition" ) {
                    condition = cit->GetValue();
                }
                else if( cit->GetName() == "action" ) {
                    actions.push_back( cit->GetValue() );
                    
                }
            }
            rule.AddCase(condition,actions);
        }
    }
    return true;
}        

bool 
oc::PropertyMapResourceHandler::AddResourcesRules( AdvXMLParser::Element const& rules, 
                                                     PropertyMap& map)
{
    assert( rules.GetName() == "rules" );
 
        
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element> elem_it;

    // for all rules
    elem_it it  = rules.Begin();
    elem_it eit = rules.End();
    for( ; it != eit; ++it){

        
        if( it->GetName() == "rule" ) {


            oc::PropertyResourceRule rule;
            if( ParseRule(*it,rule) ) {
                map.AddResourceRule(rule);
            }

        }
    }

    return true;   
}



bool 
oc::PropertyMapResourceHandler::AddResourcesDefaults( AdvXMLParser::Element const& rules, 
                                                        oc::PropertyMap& map)
{
    // get resourcestate defaults
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element>   elemit_const;
    elemit_const rit  = rules.Begin();
    elemit_const reit = rules.End();
    
    for( ; rit!=reit; ++rit ) {
        if( rit->GetName()=="action" ) {
            if( !oc::PropertyResourceRule::EvalRuleAction(&map,rit->GetValue()) ) {
                OCERROR("can not evaluate default action: " << rit->GetValue() );
            }
        }
    }
    return true;
}

bool
oc::PropertyMapResourceHandler::LoadAndAssign( const File& file, PropertyMap& map )
{
    oc::PropertyMapResourceHandler ldr;
    oc::XMLObject                  obj(false);

    if( !ldr.LoadXMLResource(file,obj) ) { 
        OCERROR("unable to load xml-resource");
        return false;
    }
    if( !ldr.Assign( obj, map ) ) {
        OCERROR("unable to assign property");
        return false;
    }

    map.EvalDefaults();

    return true;
} // PropertyMapResourceHandler::LoadAndAssign


