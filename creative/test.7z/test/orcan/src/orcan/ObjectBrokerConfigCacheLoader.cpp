// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================
      

// INCLUDE
// =======

// ORCAN include
#include <oc/CPtr.hh>
#include <oc/Date.hh>
#include <oc/Time.hh>
#include <oc/DateTime.hh>
#include <oc/Log.hh>
#include <oc/Util.hh>
#include <oc/System.hh>
#include <oc/XMLObject.hh>
#include <oc/ObjectBrokerConfigCache.hh>
#include <oc/ObjectBrokerConfigCacheLoader.hh>
#include <oc/DLMObjectFactoryTrait.hh>
#include <oc/PropertyMap.hh>
#include <oc/GUID.hh>

#include <string>
#include <iterator>
#include <vector>


oc::ObjectBrokerConfigCacheLoader::ObjectBrokerConfigCacheLoader()
    : mInputXMLFile( NULL )
{
    mCache = new ObjectBrokerConfigCache();
}

oc::ObjectBrokerConfigCacheLoader::~ObjectBrokerConfigCacheLoader()
{
}

oc::ObjectBrokerConfigCacheLoader::ObjectBrokerConfigCacheLoader(const oc::ObjectBrokerConfigCacheLoader & cache)
    :  mInputXMLFile (cache.mInputXMLFile)
{
}

oc::ObjectBrokerConfigCacheLoader & 
oc::ObjectBrokerConfigCacheLoader::operator=( const oc::ObjectBrokerConfigCacheLoader & rhs)
{
    mInputXMLFile      = rhs.mInputXMLFile;
    return *this;
}

bool
oc::ObjectBrokerConfigCacheLoader::SetInput( const oc::File & xmlFile )
{
    mInputXMLFile = & xmlFile;

    return true;
}

bool
oc::ObjectBrokerConfigCacheLoader::Execute()
{
    if( mInputXMLFile == oc::CPtr<oc::File>::Null ) {

	OCERROR( "No input XML resource file specified." );

	return false;
    }
    //Load XML resource file
    //----------------------

    if(! (mInputXMLFile->IsExistant())) {
        OCWARN( "Input XML file \"" << *mInputXMLFile << "\" didn't exist." );
	return false;
    }
    
    if( ! mInputXMLFile->IsReadable() ) {

	OCWARN( "Input XML file \"" << *mInputXMLFile << "\" is not readable." );
	return false;
    }

    oc::XMLObject xmlObject;

    if( ! xmlObject.Load( *mInputXMLFile ) ) {

	OCWARN( "Can't load input XML file \"" << *mInputXMLFile << "\".");
	return false;
    }

    //Parse configuration
    //=====================

    AdvXMLParser::Element & xmlRoot = xmlObject.GetRoot();

    if( xmlRoot.IsNull() ) {

	OCINFO( "Can't get root node in XML file \"" << *mInputXMLFile << "\"/" );
	return false;
    }
    
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element> ElemIteratorConst;
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Attribute> AttribIteratorConst;

    ElemIteratorConst  rootIt = xmlRoot.Begin();
    ElemIteratorConst rootEit = xmlRoot.End();
    
    //Root: <cache> 
    //---------------
    std::string cache;
    
    for( ; rootIt != rootEit; ++rootIt) {
        cache = rootIt->GetName();
        
        //1.Level: <brokers>
        //------------------
        if(rootIt->GetName() == "brokers" ) {
            ElemIteratorConst  brokersIt = rootIt->Begin();
	    ElemIteratorConst brokersEit = rootIt->End();
            
            std::string brokers;
            
            for( ; brokersIt != brokersEit; ++ brokersIt ) {
                brokers = brokersIt->GetName();
            
                //2. Level: <broker>
                //------------------
                
                if( brokersIt->GetName() == "broker" ) {
                    ElemIteratorConst  brokerIt = brokersIt->Begin();
		    ElemIteratorConst brokerEit = brokersIt->End();

                     std::string broker;
                     std::string uri;
                     std::string time;
                     std::string date;
                     std::string component;
                     std::string realization;
                     std::string guid;
                     std::string vendor;  
                     std::string entry;
                     std::vector<oc::ObjectTrait *> objecttraitvector(0);
                     
                   
                     for( ; brokerIt!= brokerEit; ++brokerIt ) {
                         broker = brokerIt->GetName();
                         
                         //3.Level <uri> <date> <time> <entry>
                         //-----------------------------------
                          
                          //If it is uri
                          if(brokerIt->GetName() == "uri") {
                              uri = brokerIt->GetValue();
                          }
                          
                          //If it is date
                          else if(brokerIt->GetName() == "date") {
                              date = brokerIt->GetValue();
                          }
                          
                          //If it is time
                          else if(brokerIt->GetName() == "time") {
                              time = brokerIt->GetValue();
                          }
                          
                          //If it is an entry
                          else if( brokerIt->GetName() == "entry") {
                              ElemIteratorConst  entryIt = brokerIt->Begin();
                              ElemIteratorConst entryEit = brokerIt->End();
                             
                              
                              for( ; entryIt!=entryEit; ++ entryIt) {
                                  entry = entryIt->GetName();

                                  //4 Level <component> <realization>
                                  //---------------------------------
                                  
                                  if(entryIt->GetName() == "guid") {
                                      guid =entryIt->GetValue();
                                  }
                                  
                                  //if it is a realization
                                  else if(entryIt->GetName() == "realization") {
                                      realization = entryIt->GetValue();
                                  }

                                  //If it is a component
                                  else if(entryIt->GetName() == "component") {
                                      component = entryIt->GetValue();

                                  }
                                  
                                  //If it is a vendor
                                  else if(entryIt->GetName() == "vendor") {
                                      vendor = entryIt->GetValue();
                                  }
                              }//<realization> and <component>
                              
                              if(  ! (component.empty() || realization.empty() || guid.empty() || vendor.empty() ) ) {
                                  oc::ObjectTrait * objecttrait= new oc::ObjectTrait();
                              
                                  objecttrait->SetComponentName(component);
                                  
                                  objecttrait->SetRealizationName(realization);
                              
                                  oc::GUID g(guid);
                                  
                                  objecttrait->SetGUID(g);
                    
                                  objecttrait->SetVendor( vendor );

                                  objecttrait->SetObjectFactoryTrait( oc::DLMObjectFactoryTrait( uri ) );
                                 
                                  objecttraitvector.push_back(objecttrait);
                                                          
                              }  
                                                         
                          }//<entry>
                          

                     }//<broker>
                     
                     oc::File file(uri);
                     
                     oc::Date d(date);
                     oc::Time t(time);
                    
                     oc::DateTime datetime(d,t);
                     
                     mCache->Find(file).SetLastChanged(datetime);
                       
                     for(int i = 0; i<objecttraitvector.size() ; ++i ){
                         mCache->Find(file).AddObjectTrait(* objecttraitvector[i]);
                         objecttraitvector.pop_back();
                     }
                         
                }
                                                          
            }//<brokers>
        }
    }//<cache>
    return true;
}

bool
oc::ObjectBrokerConfigCacheLoader::SetOutput(oc::ObjectBrokerConfigCache & cache)
{
                
    mCache = & cache;

    return true;
}


