
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================
      

// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/Log.hh>
#include <oc/Util.hh>
#include <oc/System.hh>
#include <oc/XMLObject.hh>
#include <oc/ObjectTrait.hh>
#include <oc/ObjectBrokerConfigResourceLoader.hh>

// C include

#include <stdlib.h>
#include <cassert>




// *****************************************************************************
// *****************************************************************************
//
// CLASS: ObjectBrokerConfigResourceLoader
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   ObjectBrokerConfigResourceLoader()
//   ObjectBrokerConfigResourceLoader( const ObjectBrokerConfigResourceLoader & source )
//
// Destructor:
//
//   ~ObjectBrokerConfigResourceLoader()
//
// *****************************************************************************

oc::ObjectBrokerConfigResourceLoader::ObjectBrokerConfigResourceLoader()
    : mInputXMLFile( oc::CPtr<oc::File>::Null ) // Null Pointer
    , mOutputOBConfigPtr()                          // Null Pointer
{
    // Intentional left empty
}


oc::ObjectBrokerConfigResourceLoader::
ObjectBrokerConfigResourceLoader( const ObjectBrokerConfigResourceLoader & source )
    : mInputXMLFile     ( source.mInputXMLFile      )
    , mOutputOBConfigPtr( source.mOutputOBConfigPtr )
{
    // Intentional left empty
}


oc::ObjectBrokerConfigResourceLoader::~ObjectBrokerConfigResourceLoader()
{
    // Intentional left empty
}



// *****************************************************************************
//
// Operators:
//
//   operator=( const ObjectBrokerConfigResourceLoader & rhs )
//
// *****************************************************************************

oc::ObjectBrokerConfigResourceLoader &
oc::ObjectBrokerConfigResourceLoader::
operator=( const oc::ObjectBrokerConfigResourceLoader & rhs )
{

    mInputXMLFile      = rhs.mInputXMLFile;
    mOutputOBConfigPtr = rhs.mOutputOBConfigPtr;

    return *this;
}



// *****************************************************************************
//
// Command Methods:
//
//   SetInput( const oc::File & xmlResource )
//   SetOutput( ObjectBrokerConfig & obConfig )
//   Execute()
//
// *****************************************************************************

bool
oc::ObjectBrokerConfigResourceLoader::SetInput( const oc::File & xmlFile )
{
    mInputXMLFile = & xmlFile;

    return true;
}



bool
oc::ObjectBrokerConfigResourceLoader::SetOutput( oc::ObjectBrokerConfig & obConfig )
{
    mOutputOBConfigPtr = & obConfig;

    return true;
}



bool
oc::ObjectBrokerConfigResourceLoader::Execute()
{

    // Pre condition test
    // ==================

    // Input and output mesh available?

    assert( (mInputXMLFile       != oc::CPtr<oc::File>::Null              ) &&
	    (mOutputOBConfigPtr != oc::ObjectBrokerConfigPtr::NullPtr) );

    if( mInputXMLFile == oc::CPtr<oc::File>::Null ) {

	OCERROR( "No input XML resource file specified." );

	return false;
    }

    if( mOutputOBConfigPtr == oc::ObjectBrokerConfigPtr::NullPtr ) {

	OCERROR( "No output object broker config specified." );

	return false;
    }

    // Load XML resource file
    // ----------------------

    if( ! mInputXMLFile->IsExistant() ) {

	OCWARN( "Input XML file \"" << *mInputXMLFile << "\" didn't exist." );
	return false;
    }

    if( ! mInputXMLFile->IsReadable() ) {

	OCWARN( "Input XML file \"" << *mInputXMLFile << "\" is not readable." );
	return false;
    }

    oc::XMLObject xmlObject;

    if( ! xmlObject.Load( *mInputXMLFile ) ) {

	OCWARN( "Can't load input XML file \"" << *mInputXMLFile << "\".");
	return false;
    }

    // Parse configuration
    // ===================

    AdvXMLParser::Element & xmlRoot = xmlObject.GetRoot();

    if( xmlRoot.IsNull() ) {

	OCINFO( "Can't get root node in XML file \"" << *mInputXMLFile << "\"/" );
	return false;
    }

    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element> ElemIteratorConst;
    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Attribute> AttribIteratorConst;

    ElemIteratorConst  rootIt = xmlRoot.Begin();
    ElemIteratorConst rootEIt = xmlRoot.End();

    // Local system traits:
    std::string myHostname = oc::System::Net::GetHostname();
    std::string myOSName   = oc::System::Net::GetOSName();

#if defined(_DEBUG) || defined(DEBUG)
    std::string myRuntime    = "debug";
#else
    std::string myRuntime    = "release";
#endif

    // Root: <config>
    for( ; rootIt != rootEIt; ++rootIt) {

	// 1. Level: <brokers>
	// -------------------
	if( rootIt->GetName() == "brokers" ) {

	    ElemIteratorConst  brokersIt = rootIt->Begin();
	    ElemIteratorConst brokersEIt = rootIt->End();

	    for( ; brokersIt != brokersEIt; ++brokersIt ) {

		// 2. Level: <broker>
		// ------------------
		if( brokersIt->GetName() == "broker" ) {

		    ElemIteratorConst  brokerIt = brokersIt->Begin();
		    ElemIteratorConst brokerEIt = brokersIt->End();

		    std::string type;
		    std::string uri;

		    // 3. Level: <type> and <uri>
		    // --------------------------
		    for( ; brokerIt != brokerEIt; ++brokerIt ) {

			// Type:
			if( brokerIt->GetName() == "type" ) {
			    type = brokerIt->GetValue();
			}

			// URI:
			else if( brokerIt->GetName() == "uri" ) {

			    // Read all attributes of <uri>
			    AttribIteratorConst uriIt  = brokerIt->AttributesBegin();
			    AttribIteratorConst uriEIt = brokerIt->AttributesEnd();

			    std::string system;
			    std::string host;
			    std::string runtime;

			    for( ; uriIt != uriEIt; ++uriIt ) {
                                
                                if( uriIt->GetName() == "system" ) {
				    system = uriIt->GetValue();
				}
				else if( uriIt->GetName() == "host" ) {
				    host = uriIt->GetValue();
				}
				else if( uriIt->GetName() == "runtime" ) {
				    runtime = uriIt->GetValue();
				}
			    }

			    // Does the operating system, host and runtime version
			    // match our local system? Yes? Then use this URI.
			    if( (system.empty()   || (system   == myOSName)   ) &&
				(host.empty()     || (host     == myHostname) ) &&
				(runtime.empty()  || (runtime  == myRuntime)    ) ) {

				uri = brokerIt->GetValue();

				// Cut off prefix "file://"
				if( uri.substr(0,7) == "file://" ) {
				    uri = uri.substr(7);
				}
			    }
			}

		    } // 3. Level: <type> and <uri>


		    // Add broker to object broker config
		    // -----------------------------------
		    if( ! type.empty() && ! uri.empty() ) {

			if( type == "Module" ) {
			    OCDEBUG( "Adding dynamic load file " << uri );
			    mOutputOBConfigPtr->AddModuleFile( uri );
			}
			else if( type == "ModulePath" ) {
			    OCDEBUG( "Adding dynamic load path " << uri );
			    mOutputOBConfigPtr->AddModulePath( uri );
			}
			else if( type == "ModulePathEnv" ) {
			    OCDEBUG( "Adding dynamic load path env " << uri );
			    mOutputOBConfigPtr->AddModulePathEnv( uri );
			}
                        else {
                            OCWARN( "Unknown broker type '" << type << "'. Broker ignored." );
                        }
		    }

		} // 2. Level: <broker>

	    } // For all <brokers> elements

	} // 1. Level: <brokers>

	// 1. Level: <resources>
	// ---------------------
	if( rootIt->GetName() == "resources" ) {

	    ElemIteratorConst resourcesIt  = rootIt->Begin();
	    ElemIteratorConst resourcesEIt = rootIt->End();

	    for( ; resourcesIt != resourcesEIt; ++resourcesIt ) {

		// 2. Level: <resource>
		// --------------------
		if( resourcesIt->GetName() == "resource" ) {

		    ElemIteratorConst  resourceIt = resourcesIt->Begin();
		    ElemIteratorConst resourceEIt = resourcesIt->End();

                    std::string type;
		    std::string component;
		    std::string realization;
		    std::string uri;

		    // 3. Level: <type>, <component>, <realization> and <uri>
		    // ------------------------------------------------------
		    for( ; resourceIt != resourceEIt; ++resourceIt ) {

			// Type:
			if( resourceIt->GetName() == "type" ) {
			    type = resourceIt->GetValue();
			}

			// Component:
			if( resourceIt->GetName() == "component" ) {
			    component = resourceIt->GetValue();
			}

			// Realization:
			if( resourceIt->GetName() == "realization" ) {
			    realization = resourceIt->GetValue();
			}

			// URI:
			if( resourceIt->GetName() == "uri" ) {

			    // Read all attributes of <uri>
			    AttribIteratorConst uriIt  = resourceIt->AttributesBegin();
			    AttribIteratorConst uriEIt = resourceIt->AttributesEnd();

			    std::string system;
			    std::string host;

			    for( ; uriIt != uriEIt; ++uriIt ) {

				if( uriIt->GetName() == "system" ) {
				    system = uriIt->GetValue();
				}
				else if( uriIt->GetName() == "host" ) {
				    host = uriIt->GetValue();
				}
			    }

			    // Does the operating system and host match our
			    // local system? Yes? Then use this URI.
			    if( (system.empty()   || (system   == myOSName)   ) &&
				(host.empty()     || (host     == myHostname) ) ) {

				uri = resourceIt->GetValue();

				// Cut off prefix "file://"
				if( uri.substr(0,7) == "file://" ) {
				    uri = uri.substr(7);
				}
			    }

			}

		    } // 3. Level <type>, <component>, <realization> and <uri>


		    // Setting resource to object broker control
		    // -----------------------------------------

                    if( type.empty() || (type == "Resource") ) {

                        mOutputOBConfigPtr->SetResource( component, realization, uri );
                    }
                    else if( type == "ResourcePath" ) {

                        mOutputOBConfigPtr->SetResource( uri );
                    }
                    else {

                        OCWARN( "Unknown resource type '" << type << "'. Resource ignored." );
                    }
 
		} // 2. Level: <resource>

	    } // For all <resources> elements

	} // 1. Level: <resources>

	// 1. Level: <defaults>
	// --------------------
	if( rootIt->GetName() == "defaults" ) {

	    ElemIteratorConst defaultsIt  = rootIt->Begin();
	    ElemIteratorConst defaultsEIt = rootIt->End();

	    for( ; defaultsIt != defaultsEIt; ++defaultsIt ) {

		// 2. Level: <default>
		// -------------------
		if( defaultsIt->GetName() == "default" ) {

		    // Read all attributes of <default>
		    AttribIteratorConst attribIt  = defaultsIt->AttributesBegin();
		    AttribIteratorConst attribEIt = defaultsIt->AttributesEnd();

		    std::string component;

		    for( ; attribIt != attribEIt; ++attribIt ) {

			if( attribIt->GetName() == "component" ) {
			    component = attribIt->GetValue();
			}
		    } // Read all attributes of <default>

		    // 3. Level: <realization>
		    // -----------------------

		    ElemIteratorConst defaultIt  = defaultsIt->Begin();
		    ElemIteratorConst defaultEIt = defaultsIt->End();

		    std::string realization;

		    for( ; defaultIt != defaultEIt; ++defaultIt ) {

			if( defaultIt->GetName() == "realization" ) {
			    realization = defaultIt->GetValue();
			}
		    }

		    if( ! (component.empty() || realization.empty()) ) {

			OCDEBUG( "Setting default realization to \""
                                   << realization
                                   << "\" of component \""
                                   << component
                                   << "\"." );

			mOutputOBConfigPtr->SetDefault( component, realization );
		    }

		} // 2. Level: <default>

	    } // For all <defaults> elements

	} // 1. Level: <defaults>
    }

    return true;
}



