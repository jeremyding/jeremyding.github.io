// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyResourceRule.hh>
#include <oc/Regexp.hh>
#include <oc/Util.hh>
#include <oc/config.h>
#include <oc/PropertyResourceRuleParser.hh>

// C++ include

#include <string>
#include <sstream>



void
oc::PropertyResourceRule::AddCase(std::string const& cond,
                                    std::vector<std::string> const& actions )
{
    mtConditionActions ca;
    ca.condition = cond;
    ca.actions   = actions;

    mRules.push_back( ca );
} 

int 
oc::PropertyResourceRule::GetNumCases() const
{
    return mRules.size();
}

std::string const& 
oc::PropertyResourceRule::GetCaseCondition( int idx ) const
{
    assert( idx < mRules.size() );
    return mRules[idx].condition;
}


std::vector<std::string> const& 
oc::PropertyResourceRule::GetCaseActions( int idx ) const
{
    assert( idx < mRules.size() );
    return mRules[idx].actions;
}


std::ostream& 
oc::PropertyResourceRule::Dump( std::ostream& out) const
{
    int k,l;
    for( k=0; k<GetNumCases(); k++ ) {
        std::cout << " Case " << k << ": " << GetCaseCondition(k) << std::endl;
        std::vector<std::string> actions;
        actions = GetCaseActions(k);
        for( l=0; l<actions.size(); l++ ) {
            std::cout << "   changes " << actions[l] << std::endl;
        }
    }

    return out;
}

bool
oc::PropertyResourceRule::EvalRuleCondition(oc::PropertyMap* pmap, std::string const& rule, bool& result)
{

    std::stringstream icondition( rule );
    PropertyResourceRuleParser parser(icondition);

    try {
        parser.Parse(*pmap);
        result = parser.GetResult();
    }
    catch( ... ) {
        OCERROR("Parse Error while parsing rule: " <<  icondition.str() );
        return false;
    }
    //std::cout << "oc::PropertyResourceRule::EvalRuleCondition parsing " << rule << " results in " << result << std::endl;
    return true;
}

bool
oc::PropertyResourceRule::EvalRuleAction(oc::PropertyMap* pmap, std::string const& action)
{
    std::stringstream iaction( action );
    PropertyResourceRuleParser parser(iaction);
    //std::cout << "action parsing " << action << std::endl;

    try {
        parser.Parse(*pmap);
    }
    catch( ... ) {
        OCERROR("Parse Error while parsing action: " <<  iaction.str() );
        return false;
    }
    return true;
}



bool                    
oc::PropertyResourceRule::EvalRuleCaseActions(oc::PropertyMap* pmap, int index_rule, int index_case) 
{
    assert( index_rule < pmap->GetNumResourceRules() );
    assert( index_case < pmap->GetResourceRule(index_rule).GetNumCases() );

    std::vector<std::string> const& actions = pmap->GetResourceRule(index_rule).GetCaseActions(index_case);
    std::vector<std::string>::const_iterator action,last_action;

    // for all resources
    action = actions.begin(), last_action = actions.end();
    for( ; action != last_action; ++action ) {

        // eval action
        if( !EvalRuleAction(pmap,*action) ) {
            OCWARN("could not evaluate action: " << *action);
        }
        
    }

    return true;
}


bool
oc::PropertyResourceRule::EvalStatetagRange( std::string const& value, std::string const& range )
{
    std::vector<std::string> rangeelems = oc::Util::Tokenize(range,'-');

    if( rangeelems.size() != 2 ) {
        OCERROR("range must have FROM-TO syntax: " << range);
        return false;
    }
    // real values 
    if( (rangeelems[0].find('.') != std::string::npos) ||
        (rangeelems[1].find('.') != std::string::npos ) ||
        (value.find('.') != std::string::npos ) ) {

        double from=atof(rangeelems[0].c_str());
        double to=atof(rangeelems[1].c_str());
        double val=atof(value.c_str());
        return ( val >= from && val <= to );

    }
    // integer values 
    else {
        int from=atoi(rangeelems[0].c_str());
        int to=atoi(rangeelems[1].c_str());
        int val=atoi(value.c_str());
        return ( val >= from && val <= to );
    }


    return false;
}


bool 
oc::PropertyResourceRule::EvalStatetagBool( std::string const& value, std::string const& single )
{
    return (oc::Util::ToBool( value ) == oc::Util::ToBool( single ) );
}

bool 
oc::PropertyResourceRule::EvalStatetagSingle( std::string const& value, std::string const& single )
{
    return ( value==single );
}

bool 
oc::PropertyResourceRule::EvalStatetagRegexp( std::string const& value, std::string const& regexp )
{
    oc::Regexp re( regexp.c_str() );
    if( !re.HasCompiledOK() ) {
        OCERROR( "not a valid regular expression" );
        return false;
    }

    return re.Match( value.c_str() );
}


bool 
oc::PropertyResourceRule::EvalStatetagRelation( std::string const& rel, std::string const& val0, std::string const& val1 )
{
    //std::cout << "evaluating " << val0 << rel << val1 << std::endl;
    if(rel=="<") {
        // real values 
        if( (val0.find('.') != std::string::npos) ||
            (val1.find('.') != std::string::npos ) ) {
            
            double left=atof(val0.c_str());
            double right=atof(val1.c_str());
            return ( left < right  );
            
        }
        // integer values 
        else {
            int left=atoi(val0.c_str());
            int right=atoi(val1.c_str());
            return ( left < right  );
        }
    }
    else if(rel=="<=") {
        // real values 
        if( (val0.find('.') != std::string::npos) ||
            (val1.find('.') != std::string::npos ) ) {
            
            double left=atof(val0.c_str());
            double right=atof(val1.c_str());
            return ( left <= right  );
            
        }
        // integer values 
        else {
            int left=atoi(val0.c_str());
            int right=atoi(val1.c_str());
            return ( left <= right  );
        }
    }
    else if(rel==">") {
        // real values 
        if( (val0.find('.') != std::string::npos) ||
            (val1.find('.') != std::string::npos ) ) {
            
            double left=atof(val0.c_str());
            double right=atof(val1.c_str());
            return ( left > right  );
            
        }
        // integer values 
        else {
            int left=atoi(val0.c_str());
            int right=atoi(val1.c_str());
            return ( left > right  );
        }
    }
    else if(rel==">=") {
        // real values 
        if( (val0.find('.') != std::string::npos) ||
            (val1.find('.') != std::string::npos ) ) {
            
            double left=atof(val0.c_str());
            double right=atof(val1.c_str());
            return ( left >= right  );
            
        }
        // integer values 
        else {
            int left=atoi(val0.c_str());
            int right=atoi(val1.c_str());
            return ( left >= right  );
        }
    }
    return false;
}


