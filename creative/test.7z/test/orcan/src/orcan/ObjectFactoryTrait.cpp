
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/ObjectFactoryTrait.hh>






// *****************************************************************************
// *****************************************************************************
//
// CLASS: ObjectFactoryTrait
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   ObjectFactoryTrait()
//   ObjectFactoryTrait( const ObjectFactoryTrait & source )
//
// Destructor:
//
//   ~ObjectFactoryTrait()
//
// *****************************************************************************

oc::ObjectFactoryTrait::ObjectFactoryTrait( const std::string & name )
{
    mName = name;
}



oc::ObjectFactoryTrait::ObjectFactoryTrait( const ObjectFactoryTrait & source )
    : mName( source.mName )
{
    // Intentional left empty
}



oc::ObjectFactoryTrait::~ObjectFactoryTrait()
{
    // Intentional left empty
}




// *****************************************************************************
//
// Operators
//
//   operator=( const ObjectFactoryTrait & trait )
//
// *****************************************************************************

oc::ObjectFactoryTrait &
oc::ObjectFactoryTrait::operator=( const ObjectFactoryTrait & trait )
{

    mName = trait.mName;

    return *this;
}




// *****************************************************************************
//
// Getter / Setter:
//
//   GetName() const
//   SetName( const std::string & )
//
// *****************************************************************************

const std::string &
oc::ObjectFactoryTrait::GetName() const
{
    return mName;
}

bool
oc::ObjectFactoryTrait::SetName( const std::string & name )
{
    mName = name;

    return true;
}

