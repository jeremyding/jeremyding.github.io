
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/Util.hh>
#include <oc/DLMObjectFactory.hh>
#include <oc/DLMObjectFactoryTrait.hh>
#include <oc/Module.hh>

// C include

#include <cassert>






// *****************************************************************************
// *****************************************************************************
//
// CLASS: DLMObjectFactory
//
// *****************************************************************************
// *****************************************************************************


// *****************************************************************************
//
// Constructors:
//
//   DLMObjectFactory()
//   DLMObjectFactory( const oc::File & moduleFile )
//   DLMObjectFactory( const std::string & moduleFile )
//   DLMObjectFactory( const DLMObjectFactory & source )
//
// Destructor:
//
//   ~DLMObjectFactory()
//
// *****************************************************************************

oc::DLMObjectFactory::DLMObjectFactory()
    : ObjectFactory(),
      mDynamicLoadModule(),
      mModuleInfoPtr(),
      mModulePropertiesPtr(),
      mObjectTraitList()
{
    // Intentional left empty
}



oc::DLMObjectFactory::DLMObjectFactory( const oc::File & moduleFile )
    : ObjectFactory(),
      mDynamicLoadModule( moduleFile ),
      mModuleInfoPtr(),
      mModulePropertiesPtr(),
      mObjectTraitList()
{
    QueryModule();
}


oc::DLMObjectFactory::DLMObjectFactory( const std::string & moduleFile )
    : ObjectFactory(),
      mDynamicLoadModule( moduleFile ),
      mModuleInfoPtr(),
      mModulePropertiesPtr(),
      mObjectTraitList()
{
    QueryModule();
}



oc::DLMObjectFactory::DLMObjectFactory( const DLMObjectFactory & source )
    : ObjectFactory       ( source ),
      mDynamicLoadModule  ( source.mDynamicLoadModule   ),
      mModuleInfoPtr      ( source.mModuleInfoPtr       ),
      mModulePropertiesPtr( source.mModulePropertiesPtr ),
      mObjectTraitList    ( source.mObjectTraitList     )
{
    // Intentional left empty
}



oc::DLMObjectFactory::~DLMObjectFactory()
{
    // Delete all object traits
    mtObjectTraitList::iterator it  = mObjectTraitList.begin();
    mtObjectTraitList::iterator eit = mObjectTraitList.end();

    while( it != eit ) {

	delete *it;
	++it;
    }
}



// *****************************************************************************
//
// Creators:
//
//   Create( const oc::File  & moduleFile )
//   Create( const std::string & moduleFile )
//
// *****************************************************************************

bool
oc::DLMObjectFactory::Create( const oc::File & moduleFile )
{

    // Do not use this method if the instance is already initialized and
    // the corresponding module file is loaded.
    if( mDynamicLoadModule.IsLoaded() ) {

	OCDEBUG( "Instance already initialized with module file \""
                   << GetModuleFile()
                   << "\"" );
	return false;
    }

    // Load the module
    if( ! mDynamicLoadModule.Create( moduleFile ) ) {

	OCDEBUG( "Can't create DLM object factory from file \""
                   << GetModuleFile()
                   << "\"" );
	return false;
    }

    // Query the module for informative object and module properties.
    return QueryModule();
}



bool
oc::DLMObjectFactory::Create( const std::string & moduleFile )
{

    // Do not use this method if the instance is already initialized and
    // the corresponding module file is loaded.
    if( mDynamicLoadModule.IsLoaded() ) {

	OCDEBUG( "Instance already initialized with module file \""
                   << GetModuleFile()
                   << "\"" );
	return false;
    }

    // Load the module
    if( ! mDynamicLoadModule.Create( moduleFile ) ) {

	OCDEBUG( "Can't load dynamic load module \""
                   << moduleFile
                   << "\"" );
	return false;
    }

    // Query the module for informative object and module properties.
    return QueryModule();
}




// *****************************************************************************
//
// Operators:
//
//   operator=( const DLMObjectFactory & source )
//
// *****************************************************************************

oc::DLMObjectFactory &
oc::DLMObjectFactory::operator=( const DLMObjectFactory & source )
{

    ObjectFactory::operator=( source );

    mDynamicLoadModule     = source.mDynamicLoadModule;
    mModuleInfoPtr         = source.mModuleInfoPtr;
    mModulePropertiesPtr   = source.mModulePropertiesPtr;
    mObjectTraitList       = source.mObjectTraitList;

    return *this;
}

// *****************************************************************************
//
// Getters / Setters:
//
//   GetModuleFile() const
//   GetModuleInfo() const
//   GetModuleProperties() const
//   GetObjectTraitList() const
//
// *****************************************************************************

const oc::File &
oc::DLMObjectFactory::GetModuleFile() const
{
    return mDynamicLoadModule.GetModuleFile();
}


const oc::DLMObjectFactory::mtModuleInfoPtr &
oc::DLMObjectFactory::GetModuleInfo() const
{
    return mModuleInfoPtr;
}



const oc::DLMObjectFactory::mtModulePropertiesPtr &
oc::DLMObjectFactory::GetModuleProperties() const
{
    return mModulePropertiesPtr;
}



const oc::DLMObjectFactory::mtObjectTraitList &
oc::DLMObjectFactory::GetObjectTraitList() const
{
    return mObjectTraitList;
}




// *****************************************************************************
//
// Query Methods:
//
//   IsModuleLoaded() const
//
// *****************************************************************************

bool
oc::DLMObjectFactory::IsModuleLoaded() const
{
    return mDynamicLoadModule.IsLoaded();
}


// *****************************************************************************
//
// Access Methods:
//
//   NewObjectV( std::string & name )
//   DelObjectV( std::string & name, void * instance )
//
// *****************************************************************************

void *
oc::DLMObjectFactory::NewObjectV( const std::string & className )
{

    void * instance = (void *) NULL;

    // Get the GUID to this class name
    oc::GUID guid = GetGUID( className );

    if( guid.IsNull() ) {

	OCDEBUG( "Class \""
                   << className
                   << "\" not supported by module \""
                   << GetModuleFile()
                   << "\"." );
    }

    // Did the module has a property "New:<GUID>"?
    const oc::Property & property =
	(*mModulePropertiesPtr).HasPropertyRet( "New:"    +
						guid.GetString() );

    if( ! property.IsNull() ) {

	try {
	    instance = property(FIELD_ID(tNewObjectFPtr))();
	}
	catch( std::bad_cast & ) {

	    OCDEBUG( "Class \""
                       << className
                       << "\" not supported by module \""
                       << GetModuleFile()
                       << "\"." );
	}
    }
    // No such property
    else {

	OCDEBUG( "Module \""
                   << GetModuleFile()
                   << "\" didn't has property \"New:"
                   << guid
                   << "\"");
    }


    return instance;

} // DLMObjectFactory::NewObjectV()



bool
oc::DLMObjectFactory::DelObjectV( const std::string & className,
                                    const void        * instance )
{

    assert( instance != (void *) NULL );

    if( instance == (void *) NULL ) {

	OCDEBUG( "Null pointer passed." );

	return false;
    }

    // Get the GUID to this class name
    oc::GUID guid = GetGUID( className );

    if( guid.IsNull() ) {

	OCDEBUG( "Class \""
                   << className
                   << "\" not supported by module \""
                   << GetModuleFile()
                   << "\"." );
    }

    // Did the module has a property "Del:<GUID>"?
    const oc::Property & property =
	(*mModulePropertiesPtr).HasPropertyRet( "Del:"    +
						guid.GetString() );

    if( ! property.IsNull() ) {

	try {
	    property(FIELD_ID(tDelObjectFPtr))( instance );
	}
	catch( std::bad_cast & ) {

	    OCDEBUG( "Class \""
                       << className
                       << "\" not supported by module \""
                       << GetModuleFile()
                       << "\"." );
	    OCWARN( "The instance of class \""
                      << className
                      << "\" was not allocated by this module." );

	    return false;
	}
    }
    // No such property
    else {

	OCDEBUG( "Module \""
                   << GetModuleFile()
                   << "\" didn't has property \"Del:"
                   << guid.GetString()
                   << "\"");
    }

    return true;

} // DLMObjectFactory::DelObjectV()






// *****************************************************************************
//
// Helpers:
//
//   QueryModule()
//
// *****************************************************************************

bool
oc::DLMObjectFactory::QueryModule()
{

    // Module is not loaded.
    // ---------------------
    if( ! IsModuleLoaded() ) {

	OCWARN( "Method call unexpected. You have to load the module first "\
                  "before you can query for information about it.");

	return false;
    }
    
    // Get the module information
    tGetModuleInfoFPtr GetModuleInfoFPtr;

    if( ! mDynamicLoadModule.GetSymbol( "GetModuleInfo", GetModuleInfoFPtr ) ) {

	OCDEBUG( "Can't query module \"" 
                   << GetModuleFile()
                   << "\" for symbol \"GetModuleInfo\"." << oc::newl
                   << "Maybe no module info were linked to the library." );
	return false;
    }

    mModuleInfoPtr = (*GetModuleInfoFPtr)();

    if( mModuleInfoPtr == mtModuleInfoPtr::NullPtr ) {

	OCDEBUG( "Can't get module info from module \""
                   << GetModuleFile()
                   << "\"" );
	return false;
    }

    // Get the properties of the module from the module info
    mModulePropertiesPtr = & (mModuleInfoPtr->GetProperties() );

    // Get the runtime information to this module
    // ------------------------------------------
    if( mModulePropertiesPtr->HasProperty( "Runtime" ) ) {

	const std::string& moduleRuntime = (*mModulePropertiesPtr)["Runtime"](std::string());

#if defined(_DEBUG) || defined(DEBUG)
	std::string myRuntime( "debug" );
#else
	std::string myRuntime( "release" );
#endif
	if( moduleRuntime == myRuntime ) {

	    OCDEBUG( "Module has the same runtime specification (\""
                       << moduleRuntime
                       << "\")" );
	}
	else {

#ifdef WIN32
	    OCERROR( "Module has different runtime specification (\""
                       << moduleRuntime
                       << "\")" );

            return mDynamicLoadModule.UnloadModule();
#else
	    OCINFO( "Module has different runtime specification (\""
                      << moduleRuntime
                      << "\")" );
#endif
	}

    }

    // Iterate over properties and search for properties
    // which names starting with "Class:"
    oc::PropertyMap::const_iterator it = mModulePropertiesPtr->begin();
    oc::PropertyMap::const_iterator eit= mModulePropertiesPtr->end();

    while( it != eit ) {

	// Starts the name of the property with "Class:"
	if( (*it).first.substr( 0, 6) == std::string( "Class:" ) ) {

	    // Extract class name and GUID
	    tVecString propTokenized = oc::Util::Tokenize( (*it).first, ':' );

	    if( propTokenized.size() != 3 ) {

		OCINFO( "Class property does not have the format \"Class:<classname>:<GUID>\"" );
        
	    ++it;
		continue;
	    }

	    // Create an object trait to the found class.
	    oc::ObjectTrait * objectTrait =
		new oc::ObjectTrait( propTokenized[1],                     // Class name
                                       (*it).second(FIELD_ID(std::string)),  // Realization name
                                       propTokenized[2] );                   // GUID

	    objectTrait->SetVendor( mModuleInfoPtr->GetVendor() );

	    objectTrait->SetObjectFactoryTrait( oc::DLMObjectFactoryTrait( GetModuleFile() ) );

	    // Add object trait to list
	    mObjectTraitList.push_back(	objectTrait );
	}

	++it;
    } // Iterate over all properties

    return true;

} // DLMObjectFactory::QueryModule()




oc::GUID
oc::DLMObjectFactory::GetGUID( const std::string & className )
{

    // Search for the GUID to this class.
    mtObjectTraitList::iterator it  = mObjectTraitList.begin();
    mtObjectTraitList::iterator eit = mObjectTraitList.end();

    while( it != eit ) {

	if( (*it)->GetComponentName() == className ) {

	    return (*it)->GetGUID();
	}
	++it;
    }

    return oc::GUID();

}



