
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/Util.hh>
#include <oc/System.hh>
#include <oc/DirectoryStream.hh>
#include <oc/Module.hh>
#include <oc/DLMObjectFactory.hh>
#include <oc/ObjectBrokerConfig.hh>
#include <oc/ObjectBrokerConfigCacheLoader.hh>
#include <oc/Time.hh>



// *****************************************************************************
// *****************************************************************************
//
// CLASS: ObjectBrokerConfig
//
// *****************************************************************************
// *****************************************************************************





// *****************************************************************************
//
// Constructors:
//
//   ObjectBrokerConfig( const oc::File & )
//   ObjectBrokerConfig( const ObjectBrokerConfig & source )
//
// Destructor:
//
//   ~ObjectBrokerConfig()
//
// *****************************************************************************

oc::ObjectBrokerConfig::ObjectBrokerConfig( const oc::File & cacheFile )
    : mObjectTraitContainer()
    , mDefaultObjectTraitContainer()
#if defined WIN32
    , mDlmFileExtensions( "/dll/mod/" )
#elif defined MACOSX 
    , mDlmFileExtensions( "/dylib/mod/" )
#else
    , mDlmFileExtensions( "/so/mod/" )
#endif
    , mLogProgress( "ObjectBrokerConfig" )
    , mCache()
{

    if( cacheFile.IsExistant() && cacheFile.IsReadable() ) {

        oc::ObjectBrokerConfigCacheLoader cacheLoader;

        cacheLoader.SetInput( cacheFile);

        cacheLoader.SetOutput( mCache );

        cacheLoader.Execute();
    }
}

bool
oc::ObjectBrokerConfig::WriteCache(const oc::File & cacheFile)
{
    oc::File cache_file( "cache.xml" );
    
    // Open output file for cache.
    std::ofstream cache_output( cache_file.GetAbsoluteFile().c_str() );
    
    if( ! cache_output ) {
        
        OCWARN( "Can't open output file for ObjectBrokerConfig cache '" << cache_file << "'." );
        return false;
    }
    
    cache_output << mCache;
    
    cache_output.close();
    return true;
}

oc::ObjectBrokerConfig::~ObjectBrokerConfig()
{
 
}



// *****************************************************************************
//
// Access Methods:
//
//   AddModuleFile   ( const oc::File  & moduleFile )
//   AddModulePath   ( const oc::File  & modulePath )
//   AddModulePathEnv( const std::string & envVariable )
//
// *****************************************************************************


bool
oc::ObjectBrokerConfig::AddModuleFile( const oc::File & moduleFileParam )
{
      
    mLogProgress << "Inspecting module " << moduleFileParam << " ..." << oc::report;

    OCINFO( "Inspecting module \"" << moduleFileParam << "\"" );

    // Convert relative to absolute path
    // ---------------------------------
    File moduleFile;

    if( moduleFileParam.IsRelative() ) {
        moduleFile.Create( oc::System::Path::GetCurrentPath() +
                           oc::System::File::msSeparatorChar  +
                           moduleFileParam.GetAbsoluteFile() );
    }
    else {
        moduleFile = moduleFileParam;
    }

    // Is the file accessable for us?
    if( ! moduleFile.IsExistant() ) {

	OCINFO( "Module \"" << moduleFile << "\" doesn't exists." );
	return false;
    }

    if( ! moduleFile.IsReadable() ) {

	OCINFO( "Module \"" << moduleFile << "\" isn't readable." );
	return false;
    }

    // Get information about the module from cache.
    oc::ObjectBrokerConfigCache::BrokerDesc & desc = mCache.Find( moduleFile );

    // Is cache up to date?
    // ====================
    oc::Date d;
    oc::Time t;
    moduleFile.GetLastChange( d, t );

    oc::DateTime descDateTime = desc.GetLastChanged();
   
    // Use data from cache
    // -------------------
    if((d<=descDateTime.GetDate()) && (t<=descDateTime.GetTime()) ) {

        OCDEBUG( "Module : " << moduleFile << " cached." );

        oc::ObjectBrokerConfigCache::BrokerDesc::mtObjectTraitList const & objectTraitList =
            desc.GetObjectTraitList();

        oc::ObjectBrokerConfigCache::BrokerDesc::mtObjectTraitList::const_iterator it  = objectTraitList.begin();
        oc::ObjectBrokerConfigCache::BrokerDesc::mtObjectTraitList::const_iterator eit = objectTraitList.end();

        for( ; it!=eit; ++it ) {
            OCDEBUG( "Found (cached) object: "
                     << (*it)->GetComponentName()
                     << " realized as "
                     << (*it)->GetRealizationName() );

            // Add object trait to local container
            AddObjectTrait( (*it)->GetComponentName(), *(*it) );
        }            
    }

    // Update cache
    // ------------
    else {

        // Set the name of the module file. 
        desc.SetModuleName( moduleFile );
         
        //The actual date and time
        // of the file will be set automatically.
        desc.SetLastChanged(d , t);
        
         // Use an dynamic load module object factory
        // to load and query the module
        oc::DLMObjectFactory objectFactory;

        if( ! objectFactory.Create( moduleFile ) ) {
        
            OCDEBUG( "Can't create dynamic load module object factory from file \""
                     << moduleFile << "\"." );
            return false;
        }
   
        // Merge list of object factory with our own list.
        const oc::DLMObjectFactory::mtObjectTraitList & objectTraitList =
            objectFactory.GetObjectTraitList();

        // Iterators of DlmObjectFactory' object trait list
        oc::DLMObjectFactory::mtObjectTraitList::const_iterator it  = objectTraitList.begin();
        oc::DLMObjectFactory::mtObjectTraitList::const_iterator eit = objectTraitList.end();

        for( ; it != eit; ++it ) {

            OCDEBUG( "Found object: "
                     << (*it)->GetComponentName()
                     << " realized as "
                     << (*it)->GetRealizationName() );

            // Add object trait to cache
            desc.AddObjectTrait( *(*it) );

            // Add object trait to local container
            AddObjectTrait( (*it)->GetComponentName(), *(*it) );
        }
    }

    return true;

} // ObjectBrokerConfig::AddModuleFile( const oc::File & moduleFile )



bool
oc::ObjectBrokerConfig::AddModulePath( const oc::File & modulePath )
{

    OCINFO( "Inspecting path \"" << modulePath << "\" for modules." );

    // Is the directory accessable for us?
    if( ! modulePath.IsExistant() ) {

	OCINFO( "Module path \"" << modulePath << "\" doesn't exists." );
	return false;
    }

    if( ! modulePath.IsReadable() ) {

	OCINFO( "Module path \"" << modulePath << "\" isn't readable." );
	return false;
    }

    if( ! modulePath.IsDirectory() ) {

	OCINFO( "Module path \"" << modulePath << "\" isn't a directory." );
	return false;
    }

    std::vector<oc::File> fileList;

    modulePath.GetFileList( fileList, oc::DirectoryStream::msDefaultFileMask );

    for( int i=0; i<fileList.size(); ++i ) {

	std::string ext = '/' + fileList[i].GetExtension() + '/' ;

	if( ( (ext != "//") ) &&
	    ( mDlmFileExtensions.find( ext ) != std::string::npos ) ) {

	    AddModuleFile( fileList[i] );
	}
    }
	

    return true;
}



bool
oc::ObjectBrokerConfig::AddModulePathEnv( const std::string & envVariable )
{

    // Get the environment string from the environment variable
    std::string modulePathEnv;

    if( ! oc::System::Env::GetProperty( envVariable, modulePathEnv ) ) {

	OCINFO( "Can't query environment variable \"" << envVariable << "\"" << oc::newl
                  << "Maybe the variable doesn't exist." );
	return false;
    }

    // Extract pathes from environment string
    tVecString modulePathes = oc::Util::Tokenize( modulePathEnv,
                                                    oc::System::Path::msSeparatorChar );

    // Iterate over all pathes and search for modules in them
    tVecString::iterator it  = modulePathes.begin();
    tVecString::iterator eit = modulePathes.end();

    while( it != eit ) {

	AddModulePath( *it );
	++it;
    }
     

    return true;

}




// *****************************************************************************
//
// Getter/Setter:
//
//   SetDefault( const std::string &, const std::string & )
//   GetDefault( const std::string & )
//
// *****************************************************************************

bool
oc::ObjectBrokerConfig::SetDefault( const std::string & objectName,
                                       const std::string & realizationName )
{

    // Search for the object trait for the given component realization.
    mtObjectTraitVector objectTraitVector = Find( objectName,
						  realizationName );

    if( objectTraitVector.empty() ) {

	OCERROR( "No realization \""
                 << realizationName
                 << "\" for component \""
                 << objectName
                 <<"\" existant.");
	return false;
    }

    // Use the first (and only?) one.
    mDefaultObjectTraitContainer[objectName] = objectTraitVector[0];

    return true;

}


oc::ObjectTraitPtr
oc::ObjectBrokerConfig::GetDefault( const std::string & objectName )
{

    // 1. Search in the defaults container
    // -----------------------------------
    mtDefaultObjectTraitContainer::iterator pos =
	mDefaultObjectTraitContainer.find( objectName );

    if( pos != mDefaultObjectTraitContainer.end() ) {

	return pos->second;
    }

    // 2. Search for all object traits for the given component
    //    and use the first one.
    // -------------------------------------------------------
    mtObjectTraitVector objectTraitVector = Find( objectName );

    if( ! objectTraitVector.empty() ) {

	return objectTraitVector[0];
    }

    return oc::ObjectTraitPtr::NullPtr;

}



bool
oc::ObjectBrokerConfig::SetResource( std::string const & component,
                                     std::string const & realization,
                                     oc::File    const & xml_resource_param )
{

    if( component.empty() ) {

        OCWARN( "No component specification for resource '" << xml_resource_param << "'" );
        return false;
    }

    if( realization.empty() ) {

        OCWARN( "No realization specification of component '" << component
                << "' for resource '" << xml_resource_param << "'" );
        return false;
    }

    if( ! xml_resource_param.IsExistant() ) {

        OCWARN( "Resource file '" << xml_resource_param
                << "' of realization '" << realization
                << "' of component '" << component << "' don't exist." );
        return false;
    }

    // Convert relative to absolute path
    oc::File xml_resource;

    if( xml_resource_param.IsRelative() ) {

        xml_resource.Create( oc::System::Path::GetCurrentPath() +
                             oc::System::File::msSeparatorChar  +
                             xml_resource_param.GetAbsoluteFile() );
    }
    else {
        xml_resource = xml_resource_param;
    }

    // Setting resource to realization
    mtObjectTraitVector objectTraitVector = Find( component, realization );
  
    mtObjectTraitVector::iterator  it = objectTraitVector.begin();
    mtObjectTraitVector::iterator eit = objectTraitVector.end();

    for( ; it != eit; ++it ) {

        OCDEBUG( "Adding resource \""
                 << xml_resource
                 << "\" to realization \""
                 << realization
                 << "\" of component \""
                 << component
                 << "\"." );

        (*it)->SetResource( xml_resource );
    }

    return true;
}



bool
oc::ObjectBrokerConfig::SetResource( oc::File const & resource_path_param )
{

    if( ! resource_path_param.IsExistant() ) {

        OCINFO( "Resource path '" << resource_path_param << "' doesn't exist." );
        return false;
    }

    // Convert relative to absolute path
    std::string resource_path_string;

    if( resource_path_param.IsRelative() ) {

        resource_path_string =
            oc::System::Path::GetCurrentPath() +
            oc::System::File::msSeparatorChar  +
            resource_path_param.GetAbsoluteFile();
    }
    else {

        resource_path_string = resource_path_param.GetAbsoluteFile();
    }

    // Loop over all realizations. Check for existing resoure file.
    // ------------------------------------------------------------

    mtObjectTraitContainer::iterator  it = mObjectTraitContainer.begin();
    mtObjectTraitContainer::iterator eit = mObjectTraitContainer.end();
    
    for( ; it != eit; ++it ) {

        // Get realization name, cut off namespace and convert it to lower cases
        // 
        tVecString realization_tokens =
            oc::Util::Tokenize( it->second->GetRealizationName(), "::" );

        std::string realization =
            oc::Util::ToLower( realization_tokens[ realization_tokens.size()-1 ] );

        // Resource file: <resource path>/mod_<realization>.xml

        oc::File resource_file( resource_path_string              +
                                oc::System::File::msSeparatorChar +
                                "mod_"                            +
                                realization                       +
                                ".xml" );

        // Set resource file to component realization if file exist.
        if( resource_file.IsExistant() ) {

            OCDEBUG( "Adding resource \""
                     << resource_file
                     << "\" to realization \""
                     << it->second->GetRealizationName()
                     << "\" of component \""
                     << it->first
                     << "\"." );

            it->second->SetResource( resource_file );
        }
    }

    return true;
}






// *****************************************************************************
//
// Query Methods:
//
//   Find( string & objectName ) const
//
// *****************************************************************************

oc::ObjectBrokerConfig::mtObjectTraitVector
oc::ObjectBrokerConfig::Find( const std::string & objectName,
                              const std::string & realizationName ) const
{

    mtObjectTraitVector objectTraitVector;

    // Search for the first object with the given object name
    mtObjectTraitContainer::const_iterator it = mObjectTraitContainer.find( objectName );

    // Found: add all object traits to vector as long as they have
    //        the same object name and optional the same realization name

    mtObjectTraitContainer::const_iterator eit = mObjectTraitContainer.end();

    while( (it != eit) && (it->first == objectName) ) {


	if( realizationName.empty() ||
	    (it->second->GetRealizationName() == realizationName ) ) {

	    objectTraitVector.push_back( it->second );
	}

	++it;
    }

    return objectTraitVector;

}




// *****************************************************************************
//
// I/O Methods:
//
//   Dump( ostream & out )
//
// *****************************************************************************

std::ostream &
oc::ObjectBrokerConfig::Dump( std::ostream & out ) const
{

    mtObjectTraitContainer::const_iterator it  = mObjectTraitContainer.begin();
    mtObjectTraitContainer::const_iterator eit = mObjectTraitContainer.end();

    while( it != eit ) {

	oc::ObjectTrait * objectTrait = (*it).second;

	out << "Component:" << std::endl
	    << "----------" << std::endl
	    <<              std::endl;
	out << "Component   Name     : "
	    << objectTrait->GetComponentName() << std::endl;
	out << "Realization Name     : "
	    << objectTrait->GetRealizationName() << std::endl;
	out << "GUID                 : "
	    << objectTrait->GetGUID() << std::endl;
	out << "Object Factory Trait : "
	    << objectTrait->GetObjectFactoryTrait()->GetName() << std::endl;
	out << "Short Description    : "
	    << objectTrait->GetShortDescription() << std::endl;
	out << "Long Description     : "
	    << objectTrait->GetLongDescription() << std::endl;
	out << "Vendor               : "
	    << objectTrait->GetVendor() << std::endl;
	out << std::endl;


	++it;
    }

    return out;
}






// *****************************************************************************
//
// Helper Methods:
//
//   AddObjectTrait( string &, ObjectTrait & )
//
// *****************************************************************************

bool
oc::ObjectBrokerConfig::AddObjectTrait( std::string     const & componentName,
                                        oc::ObjectTrait const & objectTrait )
{

    // Iterators of our object trait container
    mtObjectTraitContainer::iterator pos  = mObjectTraitContainer.begin();
    mtObjectTraitContainer::iterator epos = mObjectTraitContainer.end();

    // Is object trait already in our container? Then break the loop
    // and don't iterate to end.
    for( ; pos != epos; ++pos ) {

        if( *(pos->second) == objectTrait ) {

            break;
        }
    }

    // Add object trait to container
    if( pos == epos ) {

        mObjectTraitContainer.insert( std::make_pair( componentName,
                                                      new oc::ObjectTrait( objectTrait ) ) );
    }

    return true;
}



