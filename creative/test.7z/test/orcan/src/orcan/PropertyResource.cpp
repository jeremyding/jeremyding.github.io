// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/PropertyResource.hh>
#include <oc/Regexp.hh>
#include <oc/Util.hh>


oc::PropertyResource::PropertyResource()
{
}

bool 
oc::PropertyResource::IsDefined() const
{
    return (mState.size() > 0);
}

void 
oc::PropertyResource::SetDomain( std::string const & v )
{
    SetState("domain",v);
}

std::string const & 
oc::PropertyResource::GetDomain() const
{
    return GetState("domain");
}

void 
oc::PropertyResource::SetLayout( std::string const & v )
{
    SetState("layout",v);
}

std::string const & 
oc::PropertyResource::GetLayout() const
{
    return GetState("layout");
}

void 
oc::PropertyResource::SetName( std::string const & n )
{
    mName = n;
}

std::string const & 
oc::PropertyResource::GetName() const
{
    return mName;
}

oc::PropertyResource::tState const& 
oc::PropertyResource::GetNullState()
{
    static tState nil;
    static bool first = true;
    if( first ) {
        nil.name = std::string("");
        nil.value = std::string("");
        nil.changed = false;
        first = false;
    }
    return nil;
}


bool
oc::PropertyResource::HasState( std::string const& tag ) const
{
    std::vector< tState >::const_iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->name == tag ) {
            return true;
        }
    }
    return false;
}

void 
oc::PropertyResource::SetState( std::string const& tag, std::string const& val )
{
    std::vector< tState >::iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->name == tag ) {
            state->value = val;
            state->changed = true;
            return;
        }
    }
    tState nstate;
    nstate.name = tag;
    nstate.value = val;
    nstate.changed = true;
    mState.push_back( nstate );
}

std::string const& 
oc::PropertyResource::GetState(std::string const& tag) const
{
    std::vector< tState >::const_iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->name == tag ) {
            return state->value;
        }
    }
    return GetNullState().name;
}


void 
oc::PropertyResource::SetStateChangeFlag( std::string const& tag)
{
    std::vector< tState >::iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->name == tag ) {
            state->changed=true;
            return;
        }
    }
}

void 
oc::PropertyResource::ClearStateChangeFlag( std::string const& tag )
{
    std::vector< tState >::iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->name == tag ) {
            state->changed=false;
            return;
        }
    }
}

void 
oc::PropertyResource::ClearStateChangedFlags()
{
    std::vector< tState >::iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        state->changed=false;
    }
}

bool 
oc::PropertyResource::HasStateChanged(std::string const& tag) const
{
    std::vector< tState >::const_iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->name == tag ) {
            return state->changed;
        }
    }
    return false;
}


bool 
oc::PropertyResource::HasStateChanged() const
{
    std::vector< tState >::const_iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state ) {
        if( state->changed ) {
            return true;
        }
    }
    return false;
}

int 
oc::PropertyResource::GetNumState() const
{
    return mState.size();
}

oc::PropertyResource::tState const &
oc::PropertyResource::GetState(int i) const
{
    assert( i<mState.size() );
    return mState[i];
}



std::ostream& 
oc::PropertyResource::DumpState( std::ostream& out)
{
    out << GetName() << std::endl;
    std::vector< tState >::const_iterator state,laststate;
    state = mState.begin(), laststate = mState.end();
    for( ;state!=laststate; ++state) {
        if( state->changed )
            out << " *";
        else 
            out << "  ";
        out << state->name << " = '" << state->value << "'" << std::endl; 
    }
    return out;
}


std::ostream& 
oc::PropertyResource::Write( std::ostream& out ) const
{
    out << "res\n";
    out << "'"<<GetName() << "'\n";
    int num_states = mState.size();
    out << num_states << "\n";
    for( int i=0; i<num_states; i++ ) {
        out << i << "\n";
        out << mState[i].name << "\n";
        out << mState[i].value << "\n";
    }
    return out;
}

std::istream& 
oc::PropertyResource::Read( std::istream& in )
{
    std::string res,rname,name,value;
    int cnt,num;

    in >> res;
    if( !in || in.eof() ) {
        OCERROR("could no read PropertyResource");
        return in;
    }
    if( res != "res" ) {
        OCERROR("expected a PropertyResource");
        return in;
    }
    in >> rname;
    if( !in || in.eof() ) {
        OCERROR("could no read PropertyResource");
        return in;
    }
    if( rname.size() < 2 ) {
        OCERROR("could no read PropertyResource; invalid name");
        return in;
    }
    SetName(rname.substr(1,rname.size()-2));
    in >> num;
    if( !in || in.eof() ) {
        OCERROR("could no read PropertyResource");
        return in;
    }
    for(int i=0; i<num && !in.eof(); i++ ) {
        in >> cnt;
        in >> name;
        in >> value;
        if( !in ) {
            OCERROR("could no read PropertyResource");
            return in;
        }
        if( i!=cnt ) {
            OCERROR("expected Resource " << i );
            return in;
        }

        tState nstate;
        nstate.name = name;
        nstate.value = value;
        nstate.changed = true;
        mState.push_back( nstate );
    }

    return in;
}

