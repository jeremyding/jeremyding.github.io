
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================
      

// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/Log.hh>
#include <oc/ObjectBroker.hh>
#include <oc/ObjectBrokerConfig.hh>
#include <oc/ObjectBrokerConfigResourceLoader.hh>
#include <oc/ObjectFactoryProxy.hh>



// CLASS STATIC
// ============

oc::File oc::ObjectBroker::msDefaultConfigFile = oc::File();


// *****************************************************************************
// *****************************************************************************
//
// CLASS: ObjectBroker
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   ObjectBroker()
//   ObjectBroker( const ObjectBroker & source )
//
// Destructor:
//
//   ~ObjectBroker()
//
// *****************************************************************************

oc::ObjectBroker::ObjectBroker()
    : mConfigPtr()   // Null Pointer
    , mObjects()
{
    // Intentional left empty
}



oc::ObjectBroker::ObjectBroker( const ObjectBroker & source )
{
    OCFATAL( "Copy constructor not allowed." );
}




oc::ObjectBroker::~ObjectBroker()
{
    // Intentional left empty
}




// *****************************************************************************
//
// Operators:
//
//   operator=( const ObjectBroker & )
//
// *****************************************************************************

oc::ObjectBroker &
oc::ObjectBroker::operator=( const ObjectBroker & assignee )
{
    OCFATAL( "Assignment operator not allowed." );

    return( *this );
}




// *****************************************************************************
//
// Static Methods:
//
//   Self()
//
// *****************************************************************************

oc::ObjectBroker &
oc::ObjectBroker::Self()
{

    static ObjectBrokerPtr sInstancePtr( NULL );

    // Allocate singleton instance at the first call
    // ---------------------------------------------

    if( sInstancePtr.IsNull() ) {

	sInstancePtr = new ObjectBroker();

        if( ! msDefaultConfigFile ) {

            msDefaultConfigFile = oc::File( "BrokerConfig.xml" );
        }

	// By default load the config XML file.
	if( msDefaultConfigFile.IsExistant() ) {

	    OCDEBUG( "Using \"" << msDefaultConfigFile << "\" to configure object broker.");

	    oc::ObjectBrokerConfigPtr obConfigXML = new oc::ObjectBrokerConfig();

	    oc::ObjectBrokerConfigResourceLoader xmlLoader;

	    xmlLoader.SetInput( msDefaultConfigFile );
	    xmlLoader.SetOutput( *obConfigXML );

	    xmlLoader.Execute();

	    sInstancePtr->SetConfig( obConfigXML );
	}
	else {

	    OCDEBUGCONT( "Can't load default config file \""
                           << msDefaultConfigFile
                           << "\" to configure object broker."
                           << oc::newl);
            OCDEBUG( "Using current directory as module path." );

            oc::ObjectBrokerConfigPtr obConfig = new oc::ObjectBrokerConfig();

            obConfig->AddModulePath( "./" );

	    sInstancePtr->SetConfig( obConfig );
	}
    }

    return( *sInstancePtr );
}




// *****************************************************************************
//
// Getter / Setter:
//
//   SetConfig( const oc::ObjectBrokerConfig & config )
//   GetConfig() const
//   GetModuleName()
//   HasRealization()
//
// *****************************************************************************

bool
oc::ObjectBroker::SetConfig( const oc::ObjectBrokerConfigPtr & config )
{

    // Valid Pointer?
    if( config.IsNull() ) {

	OCDEBUG( "Pointer to object broker config is Null." );
	return false;
    }

    // Store the config instance
    mConfigPtr = config;

    // Clear map of all objects and restart.
    // -------------------------------------
    mtObjectMap::iterator  it = mObjects.begin();
    mtObjectMap::iterator eit = mObjects.end();

    for( ; it != eit; ++it ) {

	delete it->second;
    }

    mObjects.clear();

    return true;
}



oc::ObjectBrokerConfigPtr
oc::ObjectBroker::GetConfig()
{
    return( mConfigPtr );
}



std::string
oc::ObjectBroker::GetModuleName( const std::string & className )
{

    std::string moduleName;

    oc::ObjectBrokerConfig::mtObjectTraitVector objectTraitVector =
	mConfigPtr->Find( className );

    if( objectTraitVector.size() > 0 ) {

	moduleName = objectTraitVector[0]->GetObjectFactoryTrait()->GetName();
    }

    return moduleName;
}



bool
oc::ObjectBroker::HasRealization( const std::string & componentName,
                                    const std::string & realizationName )
{

    return ! GetConfig()->Find( componentName, realizationName).empty();

}


