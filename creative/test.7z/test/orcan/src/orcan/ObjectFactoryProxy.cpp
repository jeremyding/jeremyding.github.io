
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/ObjectFactoryTrait.hh>
#include <oc/ObjectFactoryProxy.hh>

// C include

#include <cassert>



// *****************************************************************************
// *****************************************************************************
//
// CLASS: ObjectFactoryProxy
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   ObjectFactoryProxy()
//   ObjectFactoryProxy( const ObjectFactoryLink  & link   )
//   ObjectFactoryProxy( const ObjectFactoryProxy & source )
//
// Destructor:
//
//   ~ObjectFactoryProxy()
//
// *****************************************************************************

oc::ObjectFactoryProxy::ObjectFactoryProxy()
    : ObjectFactory(),
      mFactoryTraitPtr( oc::ObjectFactoryTraitPtr::NullPtr ),
      mRealFactoryPtr ( oc::ObjectFactoryPtr::NullPtr      )
{
    // Intentional left empty
}



oc::ObjectFactoryProxy::ObjectFactoryProxy( const ObjectFactoryTrait & trait )
    : ObjectFactory(),
      mFactoryTraitPtr( trait.Clone() ),
      mRealFactoryPtr ( oc::ObjectFactoryPtr::NullPtr )
{
    // Intentional left empty
}



oc::ObjectFactoryProxy::ObjectFactoryProxy( const ObjectFactoryProxy & source )
    : ObjectFactory( source ),
      mFactoryTraitPtr( source.mFactoryTraitPtr->Clone() ),
      mRealFactoryPtr ( source.mRealFactoryPtr           )
{
    OCERROR( "Copy constructor not allowed." );
}



oc::ObjectFactoryProxy::~ObjectFactoryProxy()
{
    if( IsConnected() ) {
	Disconnect();
    }

    mFactoryTraitPtr.Delete();
}





// *****************************************************************************
//
// Creators:
//
//   Create( const ObjectFactoryLink & link )
//
// *****************************************************************************

bool
oc::ObjectFactoryProxy::Create( const ObjectFactoryTrait & trait )
{

    // We can't initialize the instance with another
    // specification if the proxy is already connected.
    if( IsConnected() ) {

	OCWARN( "Can't initialize with new specification, "
                  << "proxy already connected." );
	return false;
    }

    // Delete old specification
    mFactoryTraitPtr.Delete();

    // Copy new specifiction
    mFactoryTraitPtr = trait.Clone();

    return( ! mFactoryTraitPtr.IsNull() );
}





// *****************************************************************************
//
// Operators:
//
//   operator=( const ObjectFactoryProxy & source )
//
// *****************************************************************************

oc::ObjectFactoryProxy &
oc::ObjectFactoryProxy::operator=( const ObjectFactoryProxy & source )
{

    OCERROR( "Assignment operator not allowed." );

    return( *this );
}





// *****************************************************************************
//
// Access Methods:
//
//   Connect()
//   Disconnect()
//   NewObject( const std::string & className )
//   DelObject( const std::string & className, const void * instance )
//
// *****************************************************************************

bool
oc::ObjectFactoryProxy::Connect()
{

    assert( ! mFactoryTraitPtr.IsNull() );

    // Let the factory trait create the object factory.
    if( ! IsConnected() ) {

	mRealFactoryPtr = mFactoryTraitPtr->NewObjectFactory();
    }

    return( IsConnected() );
}



bool
oc::ObjectFactoryProxy::Disconnect()
{

    // The specification had allocated the object factory, so
    // the specification has also to delete the object factory.
    if( IsConnected() ) {

	mFactoryTraitPtr->DelObjectFactory( mRealFactoryPtr.GetCPtr() );
	mRealFactoryPtr.SetNull();
    }

    return( ! IsConnected() );
}



void *
oc::ObjectFactoryProxy::NewObjectV( const std::string & className )
{

    // Welcome to the proxy:
    // Create the real object factory not until we need it and now we need it.
    if( ! IsConnected() ) {
	if( ! Connect() ) {
	    return( false );
	}
    }

    return( GetRealFactory().NewObjectV( className ) );
}



bool
oc::ObjectFactoryProxy::DelObjectV( const std::string & className,
                                      const void        * instance )
{

    // Nothing to delete.
    if( instance == (void *) NULL ) {

	OCDEBUG( "Null pointer passed." );
	return( false );
    }

    // Welcome to the proxy:
    // Create the real object factory not until we need it and now we need it.
    if( ! IsConnected() ) {
	if( ! Connect() ) {
	    return( false );
	}
    }

    return( GetRealFactory().DelObjectV( className, instance ) );
}





// *****************************************************************************
//
// Query Methods:
//
//   CanConnect()
//   IsConnected()
//
// *****************************************************************************

bool
oc::ObjectFactoryProxy::CanConnect( bool keepConnection )
{

    bool canConnect = false;

    // Already connected.
    if( IsConnected() ) {

	canConnect = true;
    }

    // Not connected.
    else {

	// Try to establish a connection and disconnect again.
	if( Connect() ) {

	    canConnect = true;

	    // Disconnect again.
	    if( ! keepConnection ) {

		Disconnect();
	    }
	}
    }

    return( canConnect );
}



bool
oc::ObjectFactoryProxy::IsConnected()
{
    return( mRealFactoryPtr != ObjectFactoryPtr::NullPtr );
}




// *****************************************************************************
//
// Getters / Setters
//
//   GetRealFactory()
//
// *****************************************************************************

oc::ObjectFactory &
oc::ObjectFactoryProxy::GetRealFactory()
{
    return( *mRealFactoryPtr );
}



