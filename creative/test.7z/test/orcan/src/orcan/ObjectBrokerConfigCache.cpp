
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include
#include <oc/ObjectBrokerConfigCache.hh>
#include <oc/DateTime.hh>
#include <oc/Date.hh>
#include <oc/Time.hh>
#include <oc/File.hh>
#include <vector>
#include <map>
#include <iterator>


oc::ObjectBrokerConfigCache::BrokerDesc::BrokerDesc()
    : mModuleName()
    , mLastChanged()
    , mObjectTraitList()
{
}

oc::ObjectBrokerConfigCache::BrokerDesc::~BrokerDesc()
{
    mtObjectTraitList::iterator it  = mObjectTraitList.begin();
    mtObjectTraitList::iterator eit = mObjectTraitList.end();

    for( ; it!=eit; ++it ) {

        delete *it;
    }
}

oc::DateTime const & 
oc::ObjectBrokerConfigCache::BrokerDesc::GetLastChanged() const
{
    return mLastChanged;
}

bool
oc::ObjectBrokerConfigCache::BrokerDesc::SetModuleName(oc::File const & name)
{
    mModuleName = name;

    return true;
}

bool 
oc::ObjectBrokerConfigCache::BrokerDesc::SetLastChanged(oc::Date const & d, oc::Time const & t) 
{
    mLastChanged.Set( d );
    mLastChanged.Set( t );
    
    return true;
}
bool
oc::ObjectBrokerConfigCache::BrokerDesc::SetLastChanged(oc::DateTime const & datetime)
{
    mLastChanged = datetime;
    
    return true;
}

oc::File const & 
oc::ObjectBrokerConfigCache::BrokerDesc::GetModuleName() const
{
    return mModuleName;
}


bool
oc::ObjectBrokerConfigCache::BrokerDesc::AddObjectTrait( oc::ObjectTrait const & objectTrait )
{
    mObjectTraitList.push_back( new oc::ObjectTrait( objectTrait ) );

    return true;
}

oc::ObjectBrokerConfigCache::BrokerDesc::mtObjectTraitList const &
oc::ObjectBrokerConfigCache::BrokerDesc::GetObjectTraitList() const
{
    return mObjectTraitList;
}

oc::ObjectBrokerConfigCache::ObjectBrokerConfigCache()
    : mCache()
{
}
        
oc::ObjectBrokerConfigCache::~ObjectBrokerConfigCache()
{
}                

oc::ObjectBrokerConfigCache::BrokerDesc & 
oc::ObjectBrokerConfigCache::Find( oc::File const & moduleName )
{
    if(mCache.find(moduleName) == mCache.end()) {

        BrokerDesc * help = new BrokerDesc();
    
        mCache.insert(std::make_pair(moduleName,help));

        help->SetModuleName(moduleName);
    }

    return * mCache[moduleName];
    
}   

std::ostream & 
oc::operator<<( std::ostream & out, ObjectBrokerConfigCache & cache )
{ 
    ObjectBrokerConfigCache::mtCacheContainer::iterator pos;
    out << "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n" << "<cache>\n" << "  <brokers>\n";
    
    for(pos = cache.mCache.begin(); pos !=cache.mCache.end() ; ++ pos) {
        out << "      <broker>\n" << "        <uri>" << pos->second->GetModuleName() << "</uri>\n" 
             << "        <date>"  <<         pos->second->GetLastChanged().GetDate() << "</date>\n"
             << "        <time>"  <<         pos->second->GetLastChanged().GetTime() << "</time>\n";
         for(int i = 0; i <pos->second->GetObjectTraitList().size() ; ++ i) {
             out<< "          <entry>\n" 
                << "            <guid>"        << pos->second->GetObjectTraitList()[i]->GetGUID().GetString() << "</guid>\n" 
                << "            <realization>" << pos->second->GetObjectTraitList()[i]->GetRealizationName()  << "</realization>\n" 
                << "            <component>"   << pos->second->GetObjectTraitList()[i]->GetComponentName()    << "</component>\n"
                << "            <vendor>"      << pos->second->GetObjectTraitList()[i]->GetVendor()           << "</vendor>\n"
                << "          </entry>\n" ; 
         }
         out << "      </broker>\n";
    }      
                                                           
    out << "  </brokers>\n"<< "</cache>\n";
    return out;
    
  
}


int 
oc::ObjectBrokerConfigCache::Update()
{
    mtCacheContainer::iterator pos;
    int count = 0;
    for(pos = mCache.begin(); pos !=mCache.end() ; ) {
        if( ! (pos->first.IsExistant())) {
            ++count;
            mCache.erase(pos++);
        }
        else {
            ++pos;
        }
    }

    return count;
}

