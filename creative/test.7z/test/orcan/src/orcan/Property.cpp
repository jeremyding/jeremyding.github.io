// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN includes

#include <oc/Property.hh>
#include <oc/Log.hh>
#include <oc/File.hh>
#include <oc/Table.hh>

// C++ includes

#include <algorithm>
#include <iostream>



// *****************************************************************************
// *****************************************************************************
//
// CLASS: Property
//
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
//
// Constructors and Destructors
//
// *****************************************************************************

oc::Property::Property()
    : mName("")
    , mTheField( NULL, (Field *) 0, true)
{
    mTheField.mProp = this; // 'this' can't be used in initializer list
}


oc::Property::Property( std::string const & name, Field * const & field )
    : mName(name)
    , mTheField( NULL, (Field *) field, true)
{
    mTheField.mProp = this; // 'this' can't be used in initializer list
}


oc::Property::~Property()
{
    if( mTheField.mPtr != NULL ) {
        NotifyListeners(true);
    }
    mTheField.mPtr  = NULL;
    mTheField.mProp = NULL;
}

oc::Property::Property( Property const& cp )
    : mTheField( NULL, (Field*)0, true )
{
    mTheField  = cp.mTheField;
    mTheField.mProp = this;
    mName      = cp.mName;
    mResource  = cp.mResource;
}



// *****************************************************************************
// Resources
// *****************************************************************************

bool 
oc::Property::SetResource(oc::PropertyResource const & res)
{
    mResource = res;
    return true;
}

oc::PropertyResource const & 
oc::Property::GetResource() const
{
    return mResource;
}

oc::PropertyResource & 
oc::Property::GetResource() 
{
    return mResource;
}

// *****************************************************************************
//
// Getter / Setter
//
// *****************************************************************************
void
oc::Property::SetRTTICheck( bool checkrtti ) 
{
    assert( mTheField.mPtr != NULL );

    mTheField.mCheckRTTI = checkrtti;
}

std::string &
oc::Property::GetName()
{
    return mName;
}

const std::string &
oc::Property::GetName() const
{
    return mName;
}


const std::type_info & 
oc::Property::GetType() const
{
    assert( mTheField.mPtr != NULL );

    return mTheField.mPtr->GetType();
}


std::string 
oc::Property::GetStringValue() const
{
    assert( mTheField.mPtr != NULL );

    return mTheField.mPtr->GetStringValue();
}


#define PROPERTY_PARSE( mtype )                                          \
(::strcmp(mTheField.mPtr->GetType().name(),typeid(mtype).name()) == 0) { \
   std::istringstream sstrm(strval);                                     \
   mtype tempval;                                                        \
   sstrm >> tempval;                                                     \
   mTheField.Assign(tempval,mName);                                      \
   return;                                                               \
}


void 
oc::Property::SetStringValue( std::string const& strval ) 
    throw ( std::bad_cast )
{
    // make sure we don't operate on an uninitialized field
    assert( mTheField.mPtr != NULL );

    const char*fieldtype = mTheField.mPtr->GetType().name();
    
    if(::strcmp(fieldtype,typeid(signed   int).name()) == 0) {
        signed int tempval = atoi(strval.c_str()); mTheField.Assign(tempval,mName);  return;                                                              
    }
    else if(::strcmp(fieldtype,typeid(unsigned int).name()) == 0) {
        unsigned int tempval = atoi(strval.c_str()); mTheField.Assign(tempval,mName);  return;                                                              
    }
    else if(::strcmp(fieldtype,typeid(float).name()) == 0) {
        float tempval = (float)atof(strval.c_str());  mTheField.Assign(tempval,mName); return; 
    }
    else if(::strcmp(fieldtype,typeid(double).name()) == 0) {
        double tempval = atof(strval.c_str());  mTheField.Assign(tempval,mName); return; 
    }
    else if(::strcmp(fieldtype,typeid(signed   char).name()) == 0) {
        mTheField.Assign((signed   char)*strval.c_str(),mName); return;
    }
    else if(::strcmp(fieldtype,typeid(unsigned char).name()) == 0) {
        mTheField.Assign((unsigned char)*strval.c_str(),mName); return;
    }
    else if(::strcmp(fieldtype,typeid(int32).name()) == 0) {
        int32  tempval = atoi(strval.c_str());  mTheField.Assign(tempval,mName); return; 
    }
    else if(::strcmp(fieldtype,typeid(uint32).name()) == 0) {
        uint32 tempval = atoi(strval.c_str());  mTheField.Assign(tempval,mName); return; 
    }
    else if(::strcmp(fieldtype,typeid(real32).name()) == 0) {
        mTheField.Assign((real32)atof(strval.c_str()),mName);return;
    }
    else if(::strcmp(fieldtype,typeid(real64).name()) == 0) {
        mTheField.Assign((real64)atof(strval.c_str()),mName); return;
    }
    else if(::strcmp(fieldtype,typeid(oc::Table).name()) == 0) {
        mTheField = oc::Table(strval); return;
    }
    else if(::strcmp(fieldtype,typeid(oc::File).name()) == 0) {
        mTheField = oc::File(strval); return;
    }
    else if( ::strcmp(fieldtype,typeid(std::string).name()) == 0) {
		mTheField.Assign((std::string)strval,mName); return; 
    }
    else if(::strcmp(fieldtype,typeid(bool).name()) == 0) {

        if(strval=="true" || strval=="TRUE" || strval=="1") {
            mTheField = (bool)true;
        }
        else if( strval=="false" || strval=="FALSE" || strval=="0") {
            mTheField = (bool)false;
        }

        return;
    }
    throw std::bad_cast();
}

#undef PROPERTY_PARSE


// *****************************************************************************
//
// Query Methods:
//
//	bool IsType(const std::type_info & info) const;
//      bool IsNull() const
//
// *****************************************************************************

bool 
oc::Property::IsType(const std::type_info & info) const
{
    assert( mTheField.mPtr != NULL );

    return mTheField.mPtr->IsType(info);
}


bool
oc::Property::IsNull() const
{
    return ((*this) == Null());
}


// *****************************************************************************
//
// Operators:
//
// *****************************************************************************

oc::Property& 
oc::Property::operator=( Property const& cp )
    throw( std::bad_cast )
{
    mTheField  = cp.mTheField;
    mTheField.mProp = this;
    mName      = cp.mName;
    mResource  = cp.mResource;
    return *this;
}


oc::Property::FieldPtr 
oc::Property::operator[]( int const & idx )
    throw( std::bad_cast )
{
    assert( mTheField.mPtr != NULL );

    if( mTheField.mCheckRTTI ) {
        if( ::strcmp( mTheField.mPtr->GetType().name(),
                      typeid( MField ).name()          ) != 0 ) {

            throw std::bad_cast();
        }
    }
    return FieldPtr( this, (*((MField*)(mTheField.mPtr)))[idx],mTheField.mCheckRTTI) ;
}


bool
oc::operator==( const oc::Property & lhs, const oc::Property & rhs )
{
    return ( lhs.GetName() == rhs.GetName() );
}



bool
oc::operator!=( const oc::Property & lhs, const oc::Property & rhs )
{
    return ( lhs.GetName() != rhs.GetName() );
}

// *****************************************************************************
//  Null Property
// *****************************************************************************

oc::Property &
oc::Property::Null()
{
    static oc::Property null_property( "NULL", (Field *) NULL );
    return null_property;
}

// *****************************************************************************
//  Listener
// *****************************************************************************

void 
oc::Property::AddListener( PropertyListener * l)
{   
    assert( mTheField.mPtr != NULL );

    mTheField.mPtr->AddListener(l);

}

void 
oc::Property::RemoveListener(oc::PropertyListener * l)
{
    assert( mTheField.mPtr != NULL );

    mTheField.mPtr->RemoveListener(l);

}

void 
oc::Property::NotifyListeners(bool about_to_be_deleted)
{
    if( mTheField.mPtr != NULL ) {
        mTheField.mPtr->NotifyListeners(*this,about_to_be_deleted);
    }
}
// *****************************************************************************
//  Callbacks
// *****************************************************************************

bool 
oc::Property::Callback( std::string const& val )
{
    typedef bool (PropertyCallback::*tPropertyCallbackCall)(std::string const& val);
    typedef PropertyCallback* tPropertyCallbackPtr;
    try {
        tPropertyCallbackPtr   cb = (*this)[0](FIELD_ID(tPropertyCallbackPtr));
        tPropertyCallbackCall  cc = (*this)[1](FIELD_ID(tPropertyCallbackCall));
        return (cb->*cc)(val);
    }
    catch(std::bad_cast&) {
        OCERROR("'bool oc::Property::Callback(std::string const& )' could not be called");
    }
    return false;

}

void 
oc::Property::Callback( void* val )
{
    typedef bool (PropertyCallback::*tPropertyCallbackCall)(void* val);
    typedef PropertyCallback* tPropertyCallbackPtr;
    try {
        tPropertyCallbackPtr   cb = (*this)[0](FIELD_ID(tPropertyCallbackPtr));
        tPropertyCallbackCall  cc = (*this)[1](FIELD_ID(tPropertyCallbackCall));
        (cb->*cc)(val);
    }
    catch(std::bad_cast&) {
        OCERROR("'void oc::Property::Callback(void*)' could not be called");
    }
}


