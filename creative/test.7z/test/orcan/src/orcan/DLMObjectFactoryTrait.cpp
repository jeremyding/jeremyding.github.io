
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/File.hh>
#include <oc/CPtr.hh>
#include <oc/DLMObjectFactory.hh>
#include <oc/DLMObjectFactoryTrait.hh>

// C include

#include <cassert>



// *****************************************************************************
// *****************************************************************************
//
// CLASS: DLMObjectFactoryTrait
//
// *****************************************************************************
// *****************************************************************************



// *****************************************************************************
//
// Constructors:
//
//   DLMObjectFactoryTrait()
//   DLMObjectFactoryTrait( const oc::File & library )
//   DLMObjectFactoryTrait( const std::string & library )
//   DLMObjectFactoryTrait( const DLMObjectFactoryTrait & source )
//
// Destructor:
//
//   ~DLMObjectFactoryTrait()
//
// *****************************************************************************

oc::DLMObjectFactoryTrait::DLMObjectFactoryTrait()
    : ObjectFactoryTrait(),
      mLibrary()
{
    // Intentional left empty
}



oc::DLMObjectFactoryTrait::DLMObjectFactoryTrait( const oc::File & library )
    : ObjectFactoryTrait( library.GetAbsoluteFile() ),
      mLibrary( library.GetAbsoluteFile() )
{
    // Intentional left empty
}



oc::DLMObjectFactoryTrait::DLMObjectFactoryTrait( const DLMObjectFactoryTrait & source )
    : ObjectFactoryTrait( source ),
      mLibrary( source.mLibrary )
{
    // Intentional left empty
}



oc::DLMObjectFactoryTrait::~DLMObjectFactoryTrait()
{
    // Intentional left empty
}




// *****************************************************************************
//
// Creators:
//
//   Create( const oc::File & library )
//   Create( const std::string & library )
//
// *****************************************************************************

bool
oc::DLMObjectFactoryTrait::Create( const oc::File & library )
{
    mLibrary = library.GetAbsoluteFile();

    SetName( mLibrary.GetAbsoluteFile() );

    return( true );
}



bool
oc::DLMObjectFactoryTrait::Create( const std::string & library )
{
    mLibrary = library;

    SetName( mLibrary.GetAbsoluteFile() );

    return( true );
}




// *****************************************************************************
//
// Operators
//
//   operator=( const DLMObjectFactoryTrait & link )
//
// *****************************************************************************

oc::DLMObjectFactoryTrait &
oc::DLMObjectFactoryTrait::operator=( const DLMObjectFactoryTrait & link )
{

    ObjectFactoryTrait::operator=( link );
    mLibrary = link.GetLibrary();

    return( *this );
}




// *****************************************************************************
//
// Getter / Setter
//
//   GetLibrary() const
//
// *****************************************************************************

const oc::File &
oc::DLMObjectFactoryTrait::GetLibrary() const
{
    return( mLibrary );
}




// *****************************************************************************
//
// Access Methods
//
//   Clone() const
//   NewObjectFactory()
//   DelObjectFactory( const ObjectFactory * factory )
//
// *****************************************************************************

oc::ObjectFactoryTrait *
oc::DLMObjectFactoryTrait::Clone() const
{
    return( new DLMObjectFactoryTrait( *this ) );
}



oc::ObjectFactory *
oc::DLMObjectFactoryTrait::NewObjectFactory() const
{

    OCDEBUG( "Try to create object factory (dynamic load module) \""
               << GetLibrary()
               << "\".");

    DLMObjectFactory * module = new DLMObjectFactory();

    if( module->Create( GetLibrary() ) ) {

	OCDEBUG( "Object factory creation successfully." );
    }
    else {

	delete module;
	module = DLMObjectFactoryPtr::Null;

	OCWARN( "Object factory creation failed." );
    }

    return( module );
}



bool
oc::DLMObjectFactoryTrait::DelObjectFactory( const ObjectFactory * factory ) const
{

    assert( factory != oc::CPtr<ObjectFactory>::Null );

    delete factory;

    OCDEBUG( "Object factory removed successfully." );

    return( true );
}



