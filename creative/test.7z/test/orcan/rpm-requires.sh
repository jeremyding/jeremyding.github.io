#!/bin/sh
#
# Checks libraries for 
#
# file:		rpm-requires.sh
# date:		Fri Aug 26 13:36:14 CEST 2005
# author:	Tim Fuehner<fuehner@iisb.fraunhofer.de>
# $Id: rpm-requires.sh,v 1.1 2005/08/26 15:33:26 dispyte Exp $
#

if test $# -lt 1 -o "x$1" = "--help" -o "x$1" = "-h"; then
	echo "Usage: `basename $0` <path-to-lib>+" 1>&2
	exit 1
fi


requires=""
libs=""

for i in $*; do
	libs="$libs `ldd $i | sed 's/.*=> //' | sed 's/(.*//'`"
done

for i in $libs; do
	if rpm -q --whatprovides $i 2>/dev/null 1>/dev/null; then
		#requires="$requires `rpm -q --whatprovides $i | sed 's/-[^-]*$//'`"
		requires="$requires `rpm -q --whatprovides $i | sed 's/-.*//'`"
	fi
done

result=""


for i in $requires; do
	ait="false"
	for j in $result; do
		if test "x$i" = "x$j"; then
			ait="true"
			break
		fi
	done
	test "x$ait" = "xfalse" && result="$result $i"
done


echo $result
