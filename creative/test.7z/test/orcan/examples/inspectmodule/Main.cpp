
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/DLMObjectFactory.hh>
#include <oc/ObjectBrokerConfig.hh>

// C++ include

#include <iostream>

// C include

#include <cstdlib>


void PrintUsage( int argc, char * argv[] )
{

    oc::File prog( argv[0] );

    std::cout << "Usage:   " << prog.GetName() << " [OPTION] MODULE" << std::endl;
    std::cout << "Inspects the MODULE file and prints information about contained components." << std::endl;
#ifdef WIN32
    std::cout << "Example: '" << prog.GetName() << " SimpleRealization.dll'"   << std::endl;
#else
    std::cout << "Example: '" << prog.GetName() << " libSimpleRealization.so'" << std::endl;
#endif
    std::cout << std::endl;
    std::cout << "-v LEVEL   verbose level (default: 2)" << std::endl;
    std::cout << "           0: print fatal   messages"  << std::endl;
    std::cout << "           1: print error   messages"  << std::endl;
    std::cout << "           2: print warning messages"  << std::endl;
    std::cout << "           3: print info    messages"  << std::endl;
    std::cout << "           4: print debug   messages"  << std::endl;
    std::cout << "According messages are printed only if the ORCAN library contains them." << std::endl;
    std::cout << "See OCPRINTALL, OCPRINTFATAL, OCPRINTERROR, etc. compiler flags." << std::endl;
    std::cout << std::endl;

}



int main( int argc, char * argv[] )
{

    // Usage
    // -----

    if( (argc != 2) && (argc != 4) ) {

        PrintUsage( argc, argv );
        return -1;
    }

    // Get options
    // -----------

    int verbose_level = 2;
    oc::File module_file;

    switch( argc ) {

    case 2:

        verbose_level = 2;
        module_file.Create( argv[1] );
        break;

    case 4:

        if( std::string(argv[1]) !=  std::string("-v") ) {

            PrintUsage( argc, argv );
            return -1;
        }

        verbose_level = atoi( argv[2] );
        module_file.Create( argv[3] );

        verbose_level = (verbose_level < 4 ) ? verbose_level : 4; 
        verbose_level = (verbose_level > 0 ) ? verbose_level : 0;

        break;

    default:

        std::cout << "Internal error: wrong number of parameters" << std::endl;
        return -1;
    }

    // Set verbose level
    // -----------------
    OCFATALENABLE(true);
    OCERRORENABLE(false);
    OCWARNENABLE(false);
    OCINFOENABLE(false);
    OCDEBUGENABLE(false);

    switch( verbose_level ) {

    case 4:
        OCDEBUGENABLE(true);
    case 3:
        OCINFOENABLE(true);
    case 2:
        OCWARNENABLE(true);
    case 1:
        OCERRORENABLE(true);
    }

    // Check module file access
    // ------------------------

    if( ! module_file.IsExistant() ) {

        std::cout << "Module " << module_file << " does not exist." << std::endl;
        return -1;
    }

    if( ! module_file.IsReadable() ) {

        std::cout << "Module " << module_file << " is not readable." << std::endl;
        return -1;
    }

    // Inspect module file via DLMObjectFactory
    // ----------------------------------------

    std::cout << std::endl;
    std::cout << "===========================================" << std::endl;
    std::cout << "Inspecting module file via DLMObjectFactory" << std::endl;
    std::cout << "===========================================" << std::endl;
    std::cout << std::endl;

    oc::DLMObjectFactory * of_ptr = new oc::DLMObjectFactory;

    if( of_ptr == oc::DLMObjectFactoryPtr::Null ) {

        std::cout << "Can't create DLMObjectFactory instance." << std::endl;
        return -1;
    }

    // 1. Step: load module

    std::cout << "1. Step: load module '" << module_file << "'" << std::endl;

   of_ptr->Create( module_file );

    if( ! of_ptr->IsModuleLoaded() ) {
        std::cout << "--> failed." << std::endl;
        std::cout << "Use '-v 4' to get more information." << std::endl;
        return -1;
    }
    else {
        std::cout << "--> succeeded." << std::endl;
    }

    // 2. Step: get module info pointer

    std::cout << "2. Step: get module info pointer" << std::endl;

    oc::DLMObjectFactory::mtModuleInfoPtr module_info_ptr = of_ptr->GetModuleInfo();

    if( ! module_info_ptr ) {

        std::cout << "--> failed" << std::endl;
        std::cout << "    You have to call the REGISTER_MODULE_INFO() macro in the module." << std::endl;
        return -1;
    }
    else {
        std::cout << "--> succeeded." << std::endl;
    }

    // 3. Step: get the module properties pointer

    std::cout << "3. Step: get the module properties pointer" << std::endl;

    oc::DLMObjectFactory::mtModulePropertiesPtr module_properties_ptr = of_ptr->GetModuleProperties();

    if( ! module_properties_ptr ) {

        std::cout << "--> failed" << std::endl;
        std::cout << "    Internal error: pointer should be available if the "
                  << "REGISTER_MODULE_INFO() macro was called in the module." << std::endl;
        return -1;
    }
    else {
        std::cout << "--> succeeded." << std::endl;
    }

    // 4. Step: dump property map

    std::cout << "4. Step: print properties of module" << std::endl;
    std::cout << std::endl;
    std::cout << "--------------- module properties begin" << std::endl;
    std::cout << std::endl;

    std::cout << *module_properties_ptr << std::endl;

    std::cout << "--------------- module properties end" << std::endl;
    std::cout << std::endl;

    // 5. Step: unload module file by deleting the object factory

    delete of_ptr;


    // Inspect module file via object broker config
    // --------------------------------------------

    std::cout << std::endl;
    std::cout << "===============================================" << std::endl;
    std::cout << "Inspecting module file via object broker config" << std::endl;
    std::cout << "===============================================" << std::endl;
    std::cout << std::endl;

    oc::ObjectBrokerConfig obc;

    obc.AddModuleFile( module_file );
    obc.Dump( std::cout );


    return 0;
}



