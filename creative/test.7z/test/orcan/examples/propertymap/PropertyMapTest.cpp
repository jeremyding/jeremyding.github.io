
#include <iostream>
#include <string>

#include <oc/CPtr.hh>
#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyMapResourceHandler.hh>
#include <oc/Table.hh>


typedef  int (*tI_IPPCCfunc)(int, char**); // typedef for function-pointer to myfunc
int myfunc(int argc, char** argv)
{
    std::cout << "im a sepp" << std::endl;
    return 0;
}




class  myclass 
{
public:

    virtual bool Callback(std::string const& val)
    {
        std::cout << "myclass::Call called with argument " << val << std::endl;
        return true;
    }

    virtual bool Call2(std::string const& val)
    {
        std::cout << "myclass::Call2 called with argument " << val << std::endl;
        return true;
    }

    virtual void Call3(void *val)
    {
        std::cout << "myclass::Call3 called with argument " << (char*)val << std::endl;
        return;
    }
};



class ChangeListener : public oc::PropertyListener
{
public:
    virtual void PropertyHasChanged(oc::Property& prop,bool about_to_be_deleted)
        {
        if( about_to_be_deleted) {
            std::cout << "property " << prop.GetName() << " is about to be deleted" << std::endl;
        }
        else {
                std::cout << "property " << prop.GetName() << " has changed" << std::endl;
        }
        }
   
};


void SetI( int& i )
{
    i = 5;
}







int main(int argc, char** argv)
{

    ChangeListener cl;
    ChangeListener cl2;
    
    myclass callbackclass;



    int   v1 = 5;
    float f1 = 2.5f;
    std::string s1 = "huhu";
    int   v2 = 6;
    bool  b1 = false;
    oc::File myfile("C:\\tmp\\test.txt");
    oc::Table mytable("",5,10);
    std::cout << mytable << std::endl;
    std::stringstream tstream(";:5:3:title;Vol1:1:bla;Vol2::bla;Vol4:0:bla;Vol3:0:bla;Vol5:0:bla;");
    tstream >> mytable;
    mytable.SetCellStringValue(0,0,"Volume1");
    std::cout << mytable << std::endl;

    oc::Property p0("pv1",new oc::SFieldRef<int>(v1));
    oc::Property p1("pf1",new oc::SFieldRef<float>(f1));
    oc::Property p2("ps1",new oc::SFieldRef<std::string>(s1));
    oc::Property p3("pv2",new oc::SField<int>(v2));


    // pv1=5 v1=5, pf1=2.5 f1=2.5, ps1=huhu s1=huhu, pv2=6  v2=6

    v1 = 2;
    f1 = 2.1f;
    s1 = std::string("aha");
    v2 = 3;

    // pv1=2 v1=2, pf1=2.1 f1=2.1, ps1=aha s1=aha, pv2=6  v2=3  

    p0.SetStringValue("10",FIELD_ID(int));
    p1.SetStringValue("10",FIELD_ID(float));
    p2.SetStringValue("10",FIELD_ID(std::string));
    p3.SetStringValue("10",FIELD_ID(int));

    p0.SetStringValue("10");

    std::cout << p0.GetStringValue() << std::endl;

    // pv1=10 v1=10, pf1=10 f1=10, ps1=10 s1=10, pv2=10  v2=3   

    p0 = 1;
    p1 = 3.14f;
    p2 = std::string("end");
    p3 = 42;

    try {
        p3 = 42.f;
    }catch(std::bad_cast&) {
        std::cout << "oops" << std::endl;
    }

    // pv1=1 v1=1, pf1=3.14 f1=3.14, ps1=end s1=end, pv2=42  v2=3


    // however you should always use a PropertyMap to store Propertys (!sic)
    // PropertyMap will hide all the annoying SField calls from you !!!!

    
    oc::PropertyMap pmap;

    pmap.AddProperty("pv1",v1);
    pmap.AddProperty("pf1",f1);
    pmap.AddProperty("ps1",s1);
    pmap.AddPropertyCopy("pm2", myfunc ); // you can also add function pointers
    pmap.AddProperty("pb1",b1);
    pmap.AddProperty("pF0",myfile);
    pmap.AddProperty("pT0",mytable);

    std::cout << pmap << std::endl;

    pmap["pb1"].SetStringValue("true");
    pmap["pv1"] = 3;    // assign int value (you'd get an exception if you would try to assign a non-int)
    pmap["pf1"] = 1.9f; // assign float value (you'd get an exception if you would try to assign a non-float)
    pmap["ps1"] = std::string("katsching"); // assign string value (you'd get an exception if you would try to assign a non-string)
    pmap["pm2"](FIELD_ID(tI_IPPCCfunc))(argc,argv);     // make function call
    pmap["pf1"].SetStringValue("2.0f",FIELD_ID(float)); // set value by string
    pmap["pF0"].SetStringValue("D:\\tmp\\test.txt");
    std::cout << pmap << std::endl;
    oc::File myfile2("E:\\tmp\\test.txt");
    pmap["pF0"] = myfile2;
    std::cout << pmap << std::endl;

    std::cout << "name = " << pmap["pv1"].GetName() << std::endl;


    p0.SetStringValue("11");
    p1.SetStringValue("11");
    p2.SetStringValue("11");
    p3.SetStringValue("11");

    std::cout << p0.GetStringValue() << std::endl;
    std::cout << p1.GetStringValue() << std::endl;
    std::cout << p2.GetStringValue() << std::endl;
    std::cout << p3.GetStringValue() << std::endl;
   
    oc::PropertyMap::iterator it,eit;
    for( it=pmap.begin(),eit=pmap.end(); it!=eit; ++it ) {
        std::cout << it->first << std::endl;
    }

    int i,n=pmap.GetNumProperties();
    for(i=0; i<n; i++ ) {
        std::cout << pmap.GetProperty(i).GetName() << std::endl;
    }

    pmap["pv1"].AddListener( &cl );
    pmap["pv1"].AddListener( &cl2 );

    pmap["pv1"] = 4;
    oc::Property copy_pv1 = pmap["pv1"];
    //std::cout << "name = " << copy_pv1.GetName() << std::endl;
    try {
        SetI(pmap["pv1"]); // Problem: keine Change-Notifcation
        i=(int)pmap["pv1"];
        std::cout << i << std::endl;
    }catch(...) {
        std::cout << "caught exception while autoconverting pv1 to int" << std::endl;
    }
    std::cout << v1 << std::endl;
    
    i = (int)pmap["pv1"];
    pmap["pv1"] = 7;
    std::cout << v1 << std::endl;

    pmap["pv1"].RemoveListener( &cl );

    copy_pv1.NotifyListeners();
    copy_pv1.RemoveListener( &cl2 );
    copy_pv1.RemoveListener( &cl );
    copy_pv1.AddListener( &cl );
    copy_pv1 = 2;
    copy_pv1.NotifyListeners();

    pmap.AddPropertyCallback( "callback",  &callbackclass,  &myclass::Callback );
    pmap.AddPropertyCallback( "callback2", &callbackclass,  &myclass::Call2 );
    pmap.AddPropertyCallback( "callback3", &callbackclass,  &myclass::Call3 );
    pmap["callback"].Callback("huhu");
    pmap["callback2"].Callback(std::string("haha"));
    pmap["callback3"].Callback((void*)"hihi");


    
    // rules - test

    std::cout << "================================" << std::endl;
    std::cout << "        testing rules           " << std::endl;
    std::cout << "================================" << std::endl;

    oc::PropertyMap rmap;
    int r0(111),r1(222),r2(333),r3(444);
    rmap.AddProperty("Parameter:r0",r0);
    rmap.AddProperty("Parameter:r1",r1);
    rmap.AddProperty("Parameter:r2",r2);
    rmap.AddProperty("Parameter:ApplyButton",r3);

    if( !oc::PropertyMapResourceHandler::LoadAndAssign( oc::File("test.xml"), rmap ) ) {
        std::cout << "failed loading resource file test.xml" << std::endl;        
    }

    int j=0;
    j=j;
 
    // evaluate the rules
/*
    std::cout << "Parameter:r0 State:" << std::endl;
    for( j=0; j<rmap["Parameter:r0"].GetResource().GetNumState(); j++ ) {
        std::cout << "  " << rmap["Parameter:r0"].GetResource().GetState(j).first << " = "; 
        std::cout << "  " << rmap["Parameter:r0"].GetResource().GetState(j).second << std::endl;    
    }
        
    rmap["Parameter:r0"].GetResource().SetState("value","afee,affe");
    std::string value("regexp:.ff.");
    if( rmap["Parameter:r0"].GetResource().EvalState("value",value) ) {
        std::cout << "Parameter:r0 has value " << value << std::endl;
    }
    else {
        std::cout << "Parameter:r0 does not have value " << value << std::endl;
    }
*/

    rmap["Parameter:r0"].GetResource().ClearStateChangedFlags();
    rmap["Parameter:r1"].GetResource().ClearStateChangedFlags();
    rmap["Parameter:r2"].GetResource().ClearStateChangedFlags();
    //rmap["Parameter:r0"].GetResource().DumpState(std::cout);
    //rmap["Parameter:r1"].GetResource().DumpState(std::cout);
    //rmap["Parameter:r2"].GetResource().DumpState(std::cout);

    //rmap["Parameter:r0"].GetResource().SetState("value","2");
    //rmap["Parameter:ApplyButton"].GetResource().SetState("set","true");
    rmap.EvalRules();    

    // for all properties
    { 
        if( rmap["Parameter:r2"].GetResource().HasStateChanged() ) {
            int numstate = rmap["Parameter:r2"].GetResource().GetNumState();
            for( int j=0; j<numstate; j++) {
                if( rmap["Parameter:r2"].GetResource().GetState(j).changed ) {
                    std::cout << "  changed " 
                        << rmap["Parameter:r2"].GetResource().GetState(j).name << " to " 
                        << rmap["Parameter:r2"].GetResource().GetState(j).value << std::endl;
                }
            }
        }
    }
    rmap["Parameter:ApplyButton"].GetResource().SetState("set","false");

    std::cout << rmap["Parameter:r0"].GetResource().GetState("domain") << std::endl;
    std::cout << rmap["Parameter:r0"].GetResource().GetState("layout") << std::endl;

    rmap["Parameter:r0"].GetResource().DumpState(std::cout);
    //rmap["Parameter:r1"].GetResource().DumpState(std::cout);
    //rmap["Parameter:r2"].GetResource().DumpState(std::cout);



    oc::PropertyMap *dmap = new oc::PropertyMap();
        
    int a = 0;
    dmap->AddProperty("Parameter:a",a);
    (*dmap)["Parameter:a"].AddListener( &cl );
    (*dmap)["Parameter:a"] = int(1);



    oc::CPtr<oc::PropertyMap> dmapptr(dmap);

#if 0

    rmap.AddProperty("Parameter:dmap",dmap);
    rmap.AddProperty("Parameter:dmapptr",dmapptr);

    rmap.DumpMap( std::cout );
    std::cout << "---------------------------" << std::endl;
    typedef oc::PropertyMap * tPMapPtr;
    typedef oc::CPtr<oc::PropertyMap> tPMapCPtr;

    oc::PropertyMap *the_dmap;
    oc::CPtr<oc::PropertyMap> the_dmapptr;

    the_dmap    = rmap["Parameter:dmap"](FIELD_ID(tPMapPtr));
    the_dmapptr = rmap["Parameter:dmapptr"](FIELD_ID(tPMapCPtr));

    std::cout << "111111111111111111111111111" << std::endl;
    the_dmap->DumpMap( std::cout );
    std::cout << "222222222222222222222222222" << std::endl;
    the_dmapptr->DumpMap( std::cout );

    delete the_dmap;
    //rmap.DumpMap(std::cout);
#endif
    std::cout << "---------------------------" << std::endl;

    rmap.SetName("RMAP");
    
    real64 *tst = NULL;
    rmap.AddProperty("Parameter:t0",tst);
    rmap.DumpMap(std::cout);

    oc::XMLObject xml("pmap",true);
    rmap.Write(xml.GetRoot());
    std::cout << xml << std::endl;
    //std::stringstream sout;
    //rmap.Write(sout);
    //rmap.Write(std::cout);

    std::cout << ">>>>>>>>>>>>>>>>>>>>>>>>>>>" << std::endl;

    oc::PropertyMap emptymap;
    emptymap.AddProperty("Parameter:r0",r0);
    emptymap.AddProperty("Parameter:r1",r1);
    emptymap.AddProperty("Parameter:r2",r2);
    emptymap.AddProperty("Parameter:ApplyButton",r3);

    emptymap.Read(xml.GetRoot());
    emptymap.DumpMap(std::cout);
    
    //emptymap.Read(sout);
    //emptymap.Write(std::cout);

    return 0;

}


