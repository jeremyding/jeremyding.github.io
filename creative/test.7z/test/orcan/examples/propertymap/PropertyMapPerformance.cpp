

#include <iostream>
#include <string>

#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/Timer.hh>
#include <oc/hash_map.hh>




class VirtualWrap
{
public:
    virtual void VirtSet( const int& idx, const double& val ) = 0;
};


class ArrayWrap : public VirtualWrap
{
private:
    double *mArray;
public:
    ArrayWrap( double *array );
    void Set( const int& idx, const double& val );
    virtual void VirtSet( const int& idx, const double& val );
};

ArrayWrap::ArrayWrap( double *array)
: mArray( array )
{
}

void 
ArrayWrap::Set( const int& idx, const double& val )
{
    mArray[idx]=val;
}

void 
ArrayWrap::VirtSet( const int& idx, const double& val )
{
    mArray[idx]=val;
}

class BrrayWrap : public  VirtualWrap
{
private:
    double *Brray;
public:
    BrrayWrap( double *array );
    void Set( const int& idx, const double& val );
    virtual void VirtSet( const int& idx, const double& val );

};

BrrayWrap::BrrayWrap( double *array)
: Brray( array )
{
}

void 
BrrayWrap::Set( const int& idx, const double& val )
{
    Brray[idx]=val;
}

void 
BrrayWrap::VirtSet( const int& idx, const double& val )
{
    Brray[idx]=val;
}


int 
main(int argc, char** argv)
{
    //------------------
    // Performance test
    //------------------
    oc::PropertyMap perfmap;

    const int maxnum(10000); 
    const int maxruns(5);
    double somedoubles[maxnum];
    std::string names[maxnum];
    int milliseconds[maxruns];
    int cnt,run,plot=0;
    double avg,stddev;
    oc::Timer timer;

    oc::hash_map<std::string, double> hmap;
    std::map<std::string, double> smap;


    // insert all doubles from maxnum to PropertyMap
    for( cnt=0; cnt<maxnum; cnt++ ) {
        std::stringstream pname;
        pname << cnt << std::ends;
        names[cnt] = pname.str();
        hmap[names[cnt]]=somedoubles[cnt];
        smap[names[cnt]]=somedoubles[cnt];
        perfmap.AddProperty( names[cnt], somedoubles[cnt] );
    }
    int *randomnumbers = new int[1000000];
    for( run=0; run<1000000; run++ ) {
        randomnumbers[run] = rand()%maxnum;

    }

    std::cout << "# each test performs 1000000 write operations to a random double value within" << std::endl;
    std::cout << "#  an array/map of 10000 values" << std::endl;   
    std::cout << "# each was repeated " << maxruns << " times" << std::endl;
    std::cout << "\n" << "# testnumber average standard-deviation" << std::endl;
    std::cout << std::endl;

//#if 0
    // random write access to doubles in PropertyMap with RTTI-check enabled
    std::cout << "# random write access to doubles in PropertyMap with RTTI-check enabled"  << std::endl;
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            perfmap[names[randomnumbers[run]]] = 1.0;
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0,avg=0.0; cnt<maxruns; cnt++ ) {
        avg+=milliseconds[cnt];
        //std::cout << milliseconds[cnt] << " ";
    }
    avg/=((double)maxruns);
    for( cnt=0,stddev=0.0; cnt<maxruns; cnt++ ) {
        stddev += ((avg-milliseconds[cnt])>0)?(avg-milliseconds[cnt]):(milliseconds[cnt]-avg);
    }
    stddev/=((double)maxruns);
    std::cout << plot++ << " " << avg << " " << stddev << std::endl;

    // turn RTTI-check off
    for( cnt=0; cnt<maxnum; cnt++ ) {
        perfmap[names[cnt]].SetRTTICheck(false);
    }


    // random write access to doubles in PropertyMap with RTTI-check disabled
    std::cout << "# random write access to doubles in PropertyMap with RTTI-check disabled"  << std::endl;
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            perfmap[names[randomnumbers[run]]] = 1.0;
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0,avg=0.0; cnt<maxruns; cnt++ ) {
        avg+=milliseconds[cnt];
        //std::cout << milliseconds[cnt] << " ";
    }
    avg/=((double)maxruns);
    for( cnt=0,stddev=0.0; cnt<maxruns; cnt++ ) {
        stddev += ((avg-milliseconds[cnt])>0)?(avg-milliseconds[cnt]):(milliseconds[cnt]-avg);
    }
    stddev/=((double)maxruns);
    std::cout << plot++ << " " << avg << " " << stddev << std::endl;
//#endif

    // random write access to doubles in an map
    std::cout << "# random write access to doubles in an map"  << std::endl;
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            hmap[names[randomnumbers[run]]] = 1.0;
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0,avg=0.0; cnt<maxruns; cnt++ ) {
        avg+=milliseconds[cnt];
        //std::cout << milliseconds[cnt] << " ";
    }
    avg/=((double)maxruns);
    for( cnt=0,stddev=0.0; cnt<maxruns; cnt++ ) {
        stddev += ((avg-milliseconds[cnt])>0)?(avg-milliseconds[cnt]):(milliseconds[cnt]-avg);
    }
    stddev/=((double)maxruns);
    std::cout << plot++ << " " << avg << " " << stddev << std::endl;

    // random write access to doubles in an array
    std::cout << "# random write access to doubles in an array"  << std::endl;
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            somedoubles[randomnumbers[run]] = 1.0;
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0,avg=0.0; cnt<maxruns; cnt++ ) {
        avg+=milliseconds[cnt];
        //std::cout << milliseconds[cnt] << " ";
    }
    avg/=((double)maxruns);
    for( cnt=0,stddev=0.0; cnt<maxruns; cnt++ ) {
        stddev += ((avg-milliseconds[cnt])>0)?(avg-milliseconds[cnt]):(milliseconds[cnt]-avg);
    }
    stddev/=((double)maxruns);
    std::cout << plot++ << " " << avg << " " << stddev << std::endl;

    

    /*
    // random write access to double in a std::map
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            smap[names[randomnumbers[run]]] = 1.0;
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0; cnt<maxruns; cnt++ )
        std::cout << milliseconds[cnt] << " ";
    std::cout << std::endl;
    */

    ArrayWrap awrap( somedoubles );
    BrrayWrap bwrap( somedoubles );
    bool alternate=false;



    // random write access to doubles in an array 'via' a method call
    ArrayWrap *awrapptr = &awrap;
    BrrayWrap *bwrapptr = &bwrap;
    std::cout << "# random write access to doubles in an array 'via' a method call" << std::endl;
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            if( alternate ) 
                awrapptr->Set( randomnumbers[run], 1.0 );
            else
                bwrapptr->Set( randomnumbers[run], 1.0 );
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0,avg=0.0; cnt<maxruns; cnt++ ) {
        avg+=milliseconds[cnt];
        //std::cout << milliseconds[cnt] << " ";
    }
    avg/=((double)maxruns);
    for( cnt=0,stddev=0.0; cnt<maxruns; cnt++ ) {
        stddev += ((avg-milliseconds[cnt])>0)?(avg-milliseconds[cnt]):(milliseconds[cnt]-avg);
    }
    stddev/=((double)maxruns);
    std::cout << plot++ << " " << avg << " " << stddev << std::endl;





    // random write access to doubles in an array 'via' a virtual method call
    std::cout << "# random write access to doubles in an array 'via' a virtual method call"  << std::endl;
    VirtualWrap *iface1 = &awrap;
    VirtualWrap *iface2 = &bwrap;
    for( cnt=0; cnt <maxruns; cnt++ ) {
        timer.Start();
        for( run=0; run<1000000; run++ ) {
            alternate = !alternate;
            if( alternate ) 
                iface1->VirtSet( randomnumbers[run], 1.0 );
            else
                iface2->VirtSet( randomnumbers[run], 1.0 );
        }
        timer.Stop();
        milliseconds[cnt] = timer.GetElapsedMS();
    }
    for( cnt=0,avg=0.0; cnt<maxruns; cnt++ ) {
        avg+=milliseconds[cnt];
        //std::cout << milliseconds[cnt] << " ";
    }
    avg/=((double)maxruns);
    for( cnt=0,stddev=0.0; cnt<maxruns; cnt++ ) {
        stddev += ((avg-milliseconds[cnt])>0)?(avg-milliseconds[cnt]):(milliseconds[cnt]-avg);
    }
    stddev/=((double)maxruns);
    std::cout << plot++ << " " << avg << " " << stddev << std::endl;

    delete [] randomnumbers;

    return 0;

}

