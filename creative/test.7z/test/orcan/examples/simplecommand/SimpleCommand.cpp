
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Command.hh>

// Local include

#include "SimpleCommand.hh"



// The simple command itself:
// ==========================

namespace sc
{

OC_BEGIN_COMMAND_IMPLEMENTATION( SimpleCommand )
    OC_BEGIN_OPERAND_IMPLEMENTATIONS( SimpleCommand )
        OC_IMPLEMENT_INPUT_OPERAND(  const oc::File  & program   )
        OC_IMPLEMENT_INPUT_OPERAND(  const std::string & cmd     )
        OC_IMPLEMENT_OUTPUT_OPERAND( std::ostream &      out     )
    OC_END_OPERAND_IMPLEMENTATIONS( SimpleCommand )
OC_END_COMMAND_IMPLEMENTATION( SimpleCommand )

}

    
