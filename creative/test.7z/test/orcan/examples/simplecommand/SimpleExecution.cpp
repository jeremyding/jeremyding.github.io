
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Module.hh>

// Local include

#include "SimpleExecution.hh"

// C++ include

#include <iostream>


// Register this realization
// =========================

OC_REGISTER_REALIZATION( SimpleCommand,
                         sr,
                         SimpleExecution,
                         "66926afe-380c-4f89-b4b6-74e880a1b43f",
                         "Realization of the simple command example." );




// Constructor/Destructor
// ======================

sr::SimpleExecution::SimpleExecution()
{

    std::cout << "--> SimpleExecution::SimpleExecution()" << std::endl;
}

sr::SimpleExecution::~SimpleExecution()
{
    std::cout << "--> SimpleExecution::~SimpleExecution()" << std::endl;
}



// Input
// =====

bool
sr::SimpleExecution::SetInput( oc::File const & program )
{
    std::cout << "--> SimpleExecution::SetInput( File const & );" << std::endl;
    return true;
}

bool
sr::SimpleExecution::SetInput( std::string const & cmd )
{
    std::cout << "--> SimpleExecution::SetInput()" << std::endl;
    return true;
}



// Output
// ======

bool
sr::SimpleExecution::SetOutput( std::ostream & out )
{
    std::cout << "--> SimpleExecution::SetOutput( std::ostream & out )" << std::endl;
    return true;
}



// Execute
// =======

bool
sr::SimpleExecution::Execute()
{
    std::cout << "--> SimpleExecution::Execute()" << std::endl;
    return true;
}


