
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

#include "SimpleCommand.hh"

class SimpleCommandListener : public sc::SimpleCommand::Listener
{
    public:

     virtual void ComponentCreated( sc::SimpleCommandRef instance )
     {
        std::cout << "Listener: new object of SimpleCommand created with realization '" << instance.GetObjectTrait()->GetRealizationName() << "'." << std::endl;
     }

     virtual void ComponentDeleted( sc::SimpleCommandRef instance )
     {
        std::cout << "Listener: object of SimpleCommand with realization '" << instance.GetObjectTrait()->GetRealizationName() << "' deleted." << std::endl;
     }

};


int main( int argc, char * argv[] )
{

    // Add listener
    SimpleCommandListener listener;

    sc::SimpleCommand::AddListener( listener );

    // Create instance of command
    // ---------------------------

    sc::SimpleCommandRef command = sc::SimpleCommand::New();

    if( command ) {

        command.SetInput( oc::File( "/bin/sh" ) );

        command.Execute();

        command.Delete();
    }

    // Remove listener
    sc::SimpleCommand::RemoveListener( listener );

    return 0;
}


