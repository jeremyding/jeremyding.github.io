
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>
#include <oc/Time.hh>
#include <oc/Date.hh>

// C++ include

#include <iostream>


int main( int argc, char * argv[] )
{


    std::cout << "Enter file name: ";

    std::string file_name;
    std::cin >> file_name;

    oc::File file( file_name );

    std::cout << "Absolute path: " << file.GetAbsolutePath() << std::endl;

    std::cout << "Absolute file: " << file.GetAbsoluteFile() << std::endl << std::endl;
    
    int n =  file.GetFileSize () ;

    std::cout<< "File size : " << n << std::endl;

    std::cout << "the name of the file or directory denoted by this abstract pathname : " << file.GetName() << std::endl;

    std::cout << "the pathname string of this abstract pathname's parent: " << file.GetParent() << std::endl << std::endl;

    std::cout << "The root prefix is: " << file.GetRootPrefix() << std::endl;
    char sep='.';
    std::cout << "The extention is: " << file.GetExtension(sep) << std::endl << std::endl;

    std::cout << "The seperator is: " << file.GetSeparator() << std::endl;

    std::cout << "The seperator is: " << file.GetSeparatorChar() << std::endl;

    std::cout << "The path seperator is: " << file.GetPathSeparator() << std::endl;

    std::cout << "The path seperator is: " << file.GetPathSeparatorChar() << std::endl << std::endl;

    std::cout << "------------Query methods------------------" << std::endl << std::endl;

    if(file.IsDirectory()) {
        std::cout <<"It is a dircetory" << std::endl;
    }

    if( ! (file.IsExistant())) {
        std::cout <<"It does not exist" << std::endl;
    }

    if(file.IsFile()) {
        std::cout <<"It is a file" << std::endl;
    }

    if(file.IsReadable()) {
        std::cout <<"It is readable" << std::endl;
    }

    if(file.IsLink()) {
        std::cout <<"It is a link" << std::endl;
    }

    if(file.IsWriteable()) {
        std::cout <<"It is writeable" << std::endl;
    }

    if(file.IsRelative()) {
        std::cout <<"It is relative" << std::endl;
    }

    if(file.IsAbsolute()) {
        std::cout <<"It is absolute" << std::endl;
    }

    oc::Date d;
    oc::Time t;

    if( file.GetLastAccess( d, t ) ) {
        std::cout<< "Last access      : " << d << " " << t << std::endl;
    }
    

    if( file.GetLastAccess( d, t)) {
        std::cout<< "Last modification: " << d << " " << t << std::endl;
    }
    
    if( file.GetLastChange( d, t)) {
        std::cout<< "Last change      : " << d << " " << t << std::endl;
    }
    
    return 0;
}



