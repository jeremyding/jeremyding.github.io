
#ifndef ISIMPLE_COMPONENT_BASE_HH
#define ISIMPLE_COMPONENT_BASE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>

// C++ include

#include <iostream>


// The interfaces of the simple component:
// =======================================

namespace sc
{

    /** INTERFACE: Init
     **/
    class ISimpleComponentBaseInit
    {

    public:

        /** Initialize instance.
         **/
        virtual bool Initialize() = 0;

    }; // Init Interface



    /** INTERFACE: Input
     **/
    class ISimpleComponentBaseInput
    {

    public:

        /** Read something from a file.
         **/
        virtual bool ReadFromFile( const oc::File & inputFile ) = 0;

        /** Read something from a stream.
         **/
        virtual bool ReadFromStream( std::istream & inputStream ) = 0;

    }; // Input Interface



    /** INTERFACE: Output
     **/
    class ISimpleComponentBaseOutput
    {

    public:

        /** Write something to file.
         **/
        virtual bool WriteToFile( const oc::File & outputFile ) = 0;

        /** Write something to stream.
         **/
        virtual bool WriteToStream( std::ostream & outputStream ) = 0;

    }; // Output Interface


    /** INTERFACE: Undo
     **/
    class ISimpleComponentBaseUndo
    {

    public:

        /** Undo last input
         **/
        virtual bool UndoInput() = 0;

        /** Undo last output.
         **/
        virtual bool UndoOutput() = 0;

    }; // Undo Interface

} // namespace sc

    

#endif

