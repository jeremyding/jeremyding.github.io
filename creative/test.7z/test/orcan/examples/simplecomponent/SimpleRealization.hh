
#ifndef SIMPLE_REALIZATION_HH
#define SIMPLE_REALIZATION_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// Local include

#include "SimpleComponent.hh"
#include "ISimpleComponentCancel.hh"


namespace sr
{

    /** This a simple realization to the simple component example.
     **/
    class SimpleRealization
        : public sc::SimpleComponent::BaseClass
        , public sc::SimpleComponent::Interfaces::Init
        , public sc::SimpleComponent::Interfaces::Input 
        , public sc::SimpleComponent::Interfaces::Output
        , public sc::ISimpleComponentCancel
    {

    public:

        // Constructor/Destructor
        // ======================

        /** Default constructor is the only one we need.
         **/
        SimpleRealization();

        /** Virtual destructor will be called automatically.
         **/
        virtual ~SimpleRealization();


        // INTERFACE: Init
        // ===============

        /** Initialize instance.
         **/
        virtual bool Initialize();


        // INTERFACE: Input
        // ================

        /** Read something from a file.
         **/
        virtual bool ReadFromFile( const oc::File & inputFile );

        /** Read something from a stream.
         **/
        virtual bool ReadFromStream( std::istream & inputStream );


        // INTERFACE: Output
        // =================

        /** Write something to file.
         **/
        virtual bool WriteToFile( const oc::File & outputFile );

        /** Write something to stream.
         **/
        virtual bool WriteToStream( std::ostream & outputStream );


        // INTERFACE: Input
        // ================

        virtual bool Cancel();

    }; // class SimpleRealization

} // namespace sr

#endif


