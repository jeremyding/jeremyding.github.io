
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Module.hh>

// Local include

#include "SimpleRealization.hh"

// C++ include

#include <iostream>


// Register this realization
// =========================

OC_REGISTER_REALIZATION( SimpleComponent,
                         sr,
                         SimpleRealization,
                         "85d2d32e-5ed8-40c8-a8fc-ba307f8b4c9f",
                         "Realization of the simple component example." );




// Constructor/Destructor
// ======================

sr::SimpleRealization::SimpleRealization()
{
    OC_REGISTER_INTERFACE( sc::SimpleComponent, Init   );
    OC_REGISTER_INTERFACE( sc::SimpleComponent, Input  );
    OC_REGISTER_INTERFACE( sc::SimpleComponent, Output );

    OC_ADD_INTERFACE( ISimpleComponentCancel, "Cancel" );

    std::cout << "--> SimpleRealization::SimpleRealization()" << std::endl;
}



sr::SimpleRealization::~SimpleRealization()
{
    std::cout << "--> SimpleRealization::~SimpleRealization()" << std::endl;
}


// Init Interface
// ==============

bool
sr::SimpleRealization::Initialize()
{
    std::cout << "--> SimpleRealization::Initialize()" << std::endl;
    return true;
}



// Input Interface
// ===============

bool
sr::SimpleRealization::ReadFromFile( const oc::File & inputFile )
{
    std::cout << "--> SimpleRealization::ReadFromFile( \"" << inputFile << "\" )" << std::endl;
    return true;
}

bool
sr::SimpleRealization::ReadFromStream( std::istream & inputStream )
{
    std::cout << "--> SimpleRealization::ReadFromStream()" << std::endl;
    return true;
}



// Output Interface
// ================

bool
sr::SimpleRealization::WriteToFile( const oc::File & outputFile )
{
    std::cout << "--> SimpleRealization::WriteToFile( \"" << outputFile << "\" )" << std::endl;
    return true;
}

bool
sr::SimpleRealization::WriteToStream( std::ostream & outputStream )
{
    std::cout << "--> SimpleRealization::WriteToFile()" << std::endl;
    return true;
}


bool
sr::SimpleRealization::Cancel()
{
    std::cout << "--> SimpleRealization::Cancel()" << std::endl;
    return true;
}
