
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

#include "SimpleComponent.hh"
#include "ISimpleComponentCancel.hh"

#include "SimpleRealization.hh"


class SimpleComponentListener : public sc::SimpleComponent::Listener
{
    public:

     virtual void ComponentCreated( sc::SimpleComponentRef instance )
     {
        std::cout << "Listener: new object of SimpleComponent created with realization '" << instance.GetObjectTrait()->GetRealizationName() << "'." << std::endl;
     }

     virtual void ComponentDeleted( sc::SimpleComponentRef instance )
     {
        std::cout << "Listener: object of SimpleComponent with realization '" << instance.GetObjectTrait()->GetRealizationName() << "' deleted." << std::endl;
     }
};


int main( int argc, char * argv[] )
{

    // Create listener
    // ---------------

    SimpleComponentListener listener;

    sc::SimpleComponent::AddListener( listener );

    // Create instance of component
    // ----------------------------

    sc::SimpleComponentRef component = sc::SimpleComponent::New();

    if( !component ) {
        OCERROR("can not create SimpleComponent");
        return 0;    
    }

    // Use the interfaces.
    // -------------------

    // Interface: Init
    if( component.I.InitPtr ) {

	sc::SimpleComponent::Interfaces::InitPtrType ptr = component.I.InitPtr;

        ptr->Initialize();
    }

    // Interface: Input
    if( component.I.InputPtr ) {

        component.I.InputPtr->ReadFromFile( oc::File( "config.in" ) );
        component.I.InputPtr->ReadFromStream( std::cin );
    }

    // Interface: Output
    if( component.I.OutputPtr ) {

        component.I.OutputPtr->WriteToFile( oc::File( "config.out" ) );
        component.I.OutputPtr->WriteToStream( std::cout );
    }

    // Interface: Undo
    if( component.I.UndoPtr ) {

        component.I.UndoPtr->UndoInput();
        component.I.UndoPtr->UndoOutput();
    }

    // Interface: Cancel
    sc::ISimpleComponentCancelPtr cancelPtr = component.GetInterface( "Cancel" );

    if( cancelPtr ) {

        cancelPtr->Cancel();
    }
    else {

        component.GetProperties().DumpMap(std::cout);
    }

#if 0
    sr::SimpleRealization * realization = new sr::SimpleRealization();

    oc::PropertyMap & map = realization->GetProperties();


    oc::OCInterfacePtr iptr = map["Interface:Cancel"](oc::OCInterfacePtr());

    sc::ISimpleComponentCancel * cptr = dynamic_cast<sc::ISimpleComponentCancel *>(iptr.GetCPtr());

    std::cout << "Type of iptr: " << typeid( iptr ).name() << std::endl;
    std::cout << "Type of cptr: " << typeid( cptr ).name() << std::endl;
    std::cout << "        iptr: " << iptr << std::endl;
    std::cout << "        cptr: " << cptr << std::endl;

    sc::SimpleComponentRef cref = new sr::SimpleRealization();

    cancelPtr = cref.GetInterface( "Cancel");
    if( cancelPtr ) {

        cancelPtr->Cancel();
    }
    else {

        component.GetProperties().DumpMap(std::cout);
    }
#endif

    // Delete instance of component
    // ----------------------------

    component.Delete();

    // Do not forget to remove all listeners.
    // --------------------------------------
    sc::SimpleComponent::RemoveListener( listener );

    return 0;
}


