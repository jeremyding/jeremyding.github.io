
#ifndef MODULE_INFO_HH
#define MODULE_INFO_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright (C) 2003 University Erlangen-Nuremberg                            
//                                                                              
//  This program is free software; you can redistribute it and/or modify        
//                                                                              
//  it under the terms of the GNU General Public License as published by        
//  the Free Software Foundation; either version 2 of the License, or           
//  (at your option) any later version.                                         
//                                                                              
//  This program is distributed in the hope that it will be useful,             
//  but WITHOUT ANY WARRANTY; without even the implied warranty of              
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               
//  GNU General Public License for more details.                                
//                                                                              
//  You should have received a copy of the GNU General Public License           
//  along with this program; if not, write to the Free Software                 
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/Module.hh>



namespace mi
{

    class ModuleInfo : public oc::ModuleInfo
    {

    public:

	virtual const std::string & GetVendor() const;

	virtual void GetVersion( int & major, int & minor ) const;

    };

} // namespace mi



#endif

