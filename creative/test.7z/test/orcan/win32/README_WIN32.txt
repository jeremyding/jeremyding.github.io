Overview
========

The workspace includes projects for building the
dll-version and the static-version of the
orcan-library.

orcan.dll  The release version of the dll (+ linker file orcan.lib)
orcan_d.dll  The debug version of the dll (+ linker file orcan_d.lib)
orcan_s.lib The release version of the static library
orcan_ds.lib The debug version of the static library

The release versions (dynamic and static) are using the Multithreaded-DLL runtime-library.
The debug versions (dynamic and static) are using the Multithreaded-DLL-Debug runtime-library.



                          

Compiling
=========

The orcan-library uses some external tools 
that must be found in %PATH%

flex++.exe
bison++.exe




Utility Project

===============


The 'win32_utility'-project in the workspace is used to source-code maintenance,
documentation, installation tasks etc. By 'right-clicking' on an entry in this
project and choosing 'Compile ...' custom build steps are executed. 



Utility_Convert_Dos2Unix:  convert textformat for all *.in,*.hh and *.cpp files 

                           from dos-format (CR/LF) to unix-format (CR)

Utility_Generated_Doxygen_Documentation: generate html-documentation (in doc/html)


The utility project are using the external tools
that must be found in %PATH%

doxygen.exe
dos2unix.exe



* flex++,bison++

The projects assumes the flex++,bison++ executables and their skeleton-files
(bison.cc, bison.h, flexskel.cc, flexskel.h) to be in the same directory.
If this is not the case in your installation use the -S and -H options to 
specify an alternate location of the skeleton-files.


Using the orcan-library
=====================

When linking against the static-version you have to define ORCAN_STATIC. 

Take care to use the right runtime-library: Multihreaded DLL { Debug }.

