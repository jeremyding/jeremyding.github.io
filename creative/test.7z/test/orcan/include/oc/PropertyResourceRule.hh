
#ifndef OC_PROPERTY_RESOURCE_RULE_HH
#define OC_PROPERTY_RESOURCE_RULE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/PropertyResource.hh>

// C++ include

#include <iostream>
#include <vector>



namespace oc {


    class PropertyMap;

    /** A PropertyResourceRule is a set of conditions and associated actions.
     ** A resource rule is something like:
     ** \code
     ** if     condition1 then actions1
     ** elseif condition2 then actions2
     ** elseif conditionX then actionsX
     ** else   'empty'    then actionsX+1
     ** \endcode
     ** A single 'if|elseif|else #condition# then #action#' is called a case.
     ** The order is important when adding cases. The first case will become
     ** the 'if' case. A case with an empty condition is an 'else' case.
     **
     **/
    class OC_DSOAPI PropertyResourceRule
    {


    private:

        typedef struct
        {
            std::string                   condition;
            std::vector<std::string>      actions;
        } mtConditionActions;

        std::vector< mtConditionActions > mRules;

    public:

        /** Cases are evaluated in the order they were added. 
         ** An optional else-case has an empty condition \n cond.
         ** \param cond logical combination of property values
         ** \param actions assignments to resource state-tag's
         **/
        void AddCase(std::string const& cond, 
                     std::vector< std::string > const& actions );

        /** Get the number of cases.
         **/
        int GetNumCases() const;

        /** Get the condition to be evaluated for the \n idx.th case.
         **/
        std::string const& GetCaseCondition( int idx ) const;

        /** Get the action for the \n idx.th case
         **/
        std::vector<std::string> const& GetCaseActions( int idx ) const;

        /** Print rule.
         **/
        std::ostream& Dump( std::ostream& out) const;

        /** Evaluate a condition.
         ** A condition
         ** is a test if a state of a property has a certain value. For example
         ** the condition: 'Parameter:myvariable.value == 5' tests if the state called
         ** 'value' of the property 'Parameter:myvariable' has the value '5'. Conditions
         ** can be grouped and comnbined using bracketing and 'AND' 'OR' operators.
         <br>
         The grammar for rules:
         <pre>
         RULE:       CONDITION |  '(' RULE ')'  |  RULE 'AND' RULE |  RULE 'OR' RULE;

         CONDITION:  NAME'.'STATE OP VALUELIST
          
         OP:         '==' | '!=' ;

         NAME:       \<string\>

         STATE:      'value' | 'enable' | 'defer' | 'trigger' | 'readonly' | 'domain' | 'set' | ...;

         VALUELIST:  VALUE |  VALUE ',' VALUELIST | ;
        
         VALUE:      SINGLEVAL | RANGEOFVALS | REGEXP;
     
         SINGLEVAL   :=  A    a single value (string, int, float)  
         RANGEOFVALS :=  A-B  two values describing ar range start to end (int,float)
         REGEXP      :=  "A"  a quoted regular expression
         </pre>
        */
        static bool EvalRuleCondition(oc::PropertyMap* pmap, std::string const& rule, bool& result);


        /** Evaluate an action.
         ** An action is an assignment to property state values. For example
         ** 'Parameter:myvariable.value = 3' assigns the value '3' to the state called
         ** 'value' of the property 'Parameter:myvariable'. The right hand side may contain
         ** other property state values.
         **/
        static bool EvalRuleAction( oc::PropertyMap* pmap, std::string const& rule );

        /** Evaluate rule actions.
         **/
        static bool EvalRuleCaseActions(oc::PropertyMap* pmap, int index_rule, int index_case);

        /** \name Rule Helpers (used by parser)
         ** \{
         **/

        /** test if value is inside rangestart-rangeend.
         **/
        static bool EvalStatetagRange( std::string const& value, std::string const& range );
    
        /** evaluate value==single.
         **/
        static bool EvalStatetagSingle( std::string const& value, std::string const& single );
  
    
        /** evaluate value==single for values of type boolean 
         **/
        static bool EvalStatetagBool( std::string const& value, std::string const& single );
    
        /** test if regular expression matches value
         **/
        static bool EvalStatetagRegexp( std::string const& value, std::string const& regexp );
   
        /** test if value is matched by relation
         **/
        static bool EvalStatetagRelation( std::string const& rel, std::string const& val0, std::string const& val1 );
    
        /** \}
         **/ 
    };

} // namespace oc


#endif


