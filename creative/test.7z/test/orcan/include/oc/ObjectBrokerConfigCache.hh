

#ifndef OC_OBJECT_BROKER_CONFIG_CACHE_HH
#define OC_OBJECT_BROKER_CONFIG_CACHE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>
#include <oc/DateTime.hh>
#include <oc/ObjectTrait.hh>

#include <iterator>
#include <map>

namespace oc
{

    class ObjectBrokerConfigCache
    {

    public:

        class BrokerDesc
        {

        public:

            typedef std::vector< oc::ObjectTrait * > mtObjectTraitList;

        private:

            /** Module name of broker.
             **/
            oc::File mModuleName;

            /** Date and time of last change.
             **/
            oc::DateTime mLastChanged;

            /** List of all realizations/components implemented
             ** by the broker.
             **/
            mtObjectTraitList mObjectTraitList;

        public:

            /** \name Constructors/Destructor
             ** \{
             **/

            /** Default constructor
             **/
            BrokerDesc();

        private:

            /** Copy constructor
             **/
            BrokerDesc( BrokerDesc const & source );

        public:

            /** Destructor
             **/
            ~BrokerDesc();

            /** \}
             **/


            /** \name Operators
             ** \{
             **/

        private:
        
            /** Assignment operator
             **/
            BrokerDesc & operator=( BrokerDesc const & rhs );

            /** \}
             **/



            /** \name Getter/Setter
             ** \{
             **/

        public:

            /** Sets the module name of the broker
             **/
            bool SetModuleName( oc::File const & name );

            /** Sets the time of the last change of the broker
             **/
            bool SetLastChanged(oc::Date const & d, oc::Time const & t);

            bool SetLastChanged(oc::DateTime const & datetime);

            /** Returns the module name of the broker
             **/
            oc::File const & GetModuleName() const;

            /** Returns the date and time of the last change of
             ** the module file.
             **/
            oc::DateTime const & GetLastChanged() const;


            /** Adds an object trait to the description.
             **/
             bool AddObjectTrait( oc::ObjectTrait const & objectTrait );

            /** Returns all object traits of the description.
             **/
            mtObjectTraitList const & GetObjectTraitList() const;

            /** \}
             **/


        }; // class BrokerDesc

    public:

        typedef std::map< oc::File, BrokerDesc *> mtCacheContainer;
       
    private:

        mtCacheContainer mCache;

    public:

        ObjectBrokerConfigCache();

        ~ObjectBrokerConfigCache();

    private:

        /** Copy constructor not implemented.
         **/
        ObjectBrokerConfigCache( ObjectBrokerConfigCache const & );

        /** Assignment operator not implemented.
         **/
        ObjectBrokerConfigCache & operator=( ObjectBrokerConfigCache const & );

    public:
        
        BrokerDesc & Find( oc::File const & moduleName );

        /** 
         ** \return Number of removed brokers.
         **/
        int Update();

        friend std::ostream & operator<<( std::ostream & out, ObjectBrokerConfigCache & cache );

    }; // class ObjectBrokerConfigCache

    std::ostream & operator<<( std::ostream & out, ObjectBrokerConfigCache & cache );

} // namespace oc


#endif

