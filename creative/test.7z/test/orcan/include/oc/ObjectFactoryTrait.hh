
#ifndef OC_OBJECT_FACTORY_TRAIT_HH
#define OC_OBJECT_FACTORY_TRAIT_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/config.h>

// C++ include

#include <string>


namespace oc
{

    // PROTOTYPES
    // ==========

    class ObjectFactory;

    /** This pure abstract class is designed for usage in conjunction with
     ** ObjectFactoryProxy. An object factory specification is a definition of
     ** a special kind of an object factory and holds all necessary information
     ** to create an instance of the described object factory. Necessary
     ** information are for example the file name for a dynamic loadable module
     ** or the hostname and port for a CORBA object server.
     **
     ** There are three important methods of this specification class:
     ** - Clone() makes a copy of an specification instance.
     **
     ** - NewObjectFactory() creates an instance of the object factory from the
     **   specification.
     **
     ** - DelObjectFactory() frees a previously allocated object factory instance.
     **
     ** \b Example:
     **
     ** See DynamicLoadModuleTrait
     ** 
     ** \author Michael Kellner
     ** \date 3.3.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI ObjectFactoryTrait
    {

	/** \name Attributes
	 ** \{
	 **/

    public:

	/** The name of the object factory trait. This can be an arbitrary
	 ** string which may be used to describe the corresponding object
	 ** factory in a more or less unique way. For example the filename
	 ** of a .dll/.so plugin file or the CORBA server.
	 **/
	std::string mName;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor and constructor with name string.
	 **/
	ObjectFactoryTrait( const std::string & name = "" );

	/** The copy constructor didn't need to copy anything.
	 ** \param source The instance which will be copied.
	 **/
	ObjectFactoryTrait( const ObjectFactoryTrait & source );

	/** The destructor has nothing to delete.
	 **/
	virtual ~ObjectFactoryTrait();

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** The assignment operator overwrites a specification with another
	 ** specification \c trait.
	 **
	 ** \param trait The specification which overwrites this one.
	 ** \return The overwritten specification.
	 **/
	ObjectFactoryTrait & operator=( const ObjectFactoryTrait & trait );

	/** \}
	 **/

	/** \name Access Methods
	 ** \{
	 **/

	/** This pure virtual method have to return a copy of the current
	 ** specification and must be implemented in derived classes.
	 **
	 ** \return Copy of current specification.
	 **/
	virtual ObjectFactoryTrait * Clone() const = 0;

	/** This pure virtual method creates an object factory instance from
	 ** the specification. The method must be implemented in each derived
	 ** classes and is one of two important methods of this class. Use it
	 ** to create one (or more) instance(s) to the same specification.
	 **
	 ** \return Instance of object factory for the actual specification as
	 **         pointer to the base class on success,
	 **         \c ObjectFactory::NullPtr on failure.
	 **
	 ** \see DelObjectFactory()
	 **/
	virtual ObjectFactory * NewObjectFactory() const = 0;

	/** This pure virtual method deletes an previously thru this class
	 ** allocated object factory. The method must be implemented in each
	 ** derived classes and is one of the two important methods of this
	 ** class. 
	 **
	 ** \param  factory The object factory to delete.
	 ** \return \c true if the factory was successfully removed, \c false
	 **         otherwise.
	 **
	 **/
	virtual bool DelObjectFactory( const ObjectFactory * factory ) const = 0;

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

	/** Return the name of the object factory trait.
	 **
	 ** \see mName
	 **/
	virtual const std::string & GetName() const;

	/** Set the name of the object factory trait.
	 **
	 ** \see mName
	 **/
	virtual bool SetName( const std::string & name );

	/** \}
	 **/

    }; // class ObjectFactoryTrait


    /** A C-pointer to an object factory trait.
     **/
    typedef oc::CPtr<ObjectFactoryTrait> ObjectFactoryTraitPtr;

} // namespace oc



#endif

