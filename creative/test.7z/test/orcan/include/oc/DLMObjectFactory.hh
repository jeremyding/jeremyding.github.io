
#ifndef OC_DLM_OBJECT_FACTORY_HH
#define OC_DLM_OBJECT_FACTORY_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/GUID.hh>
#include <oc/DynamicLoadModule.hh>
#include <oc/ObjectFactory.hh>
#include <oc/DLMObjectFactoryInfo.hh>
#include <oc/ObjectTrait.hh>
#include <oc/config.h>


namespace oc
{

    /** This object factory let one create and destroy objects to any kind of
     ** class from external modules. External modules are shared object
     ** libraries \e .so under UNIX/Linux and dynamic load libraries \e .dll
     ** under Windows. This kind of libraries can be loaded during runtime when
     ** they are needed by the application. Another advantage is that they can
     ** also be unloaded during runtime and dynamically replaced by another
     ** implementation.
     **
     ** But care must be taken if one wants to unload the module during runtime.
     ** All instances allocated by this module must be deleted by the module
     ** before the module can savely be unloaded. If not all instances are
     ** deleted before unload, the application will fail in using this instance,
     ** in particular when it calles the destructor for the instance. There is
     ** no reference counting implemented in this class.
     **
     ** For loading the module on demand use the ObjectFactoryProxy class. It
     ** uses DLMObjectFactorySpec as specification of a dynamic loadable module
     ** and instantiates a DLMObjectFactory first if it is referenced.
     **
     ** For more detailed usage description of this class and some examples see
     ** documentation of the base class ObjectFactory.
     **
     ** \b Examples:
     **
     ** see ObjectFactory
     **
     ** \see ObjectFactory, DLMObjectFactorySpec, ObjectFactoryProxy
     **
     ** \author Michael Kellner
     ** \date 28.2.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI DLMObjectFactory : public ObjectFactory
    {

	/** \name Class Types
	 ** \{
	 **/

    public:

	/** Pointer to an object which holds all information about
	 ** the loaded module.
	 **
	 ** \see GetModuleInfo()
	 **/
	typedef oc::CPtr<const DLMObjectFactoryInfo> mtModuleInfoPtr;

	/** Pointer to the module properties.
	 **/
	typedef oc::CPtr<const oc::PropertyMap> mtModulePropertiesPtr;

	/** List of object traits found in the loaded module.
	 **/
	typedef std::vector< oc::ObjectTrait * > mtObjectTraitList;

    protected:

	/** The function signature in the module to allocate a new
	 ** object.
	 **
	 ** \see tDelObjectFPtr
	 **/
	typedef void * (*tNewObjectFPtr)(void);

	/** The function signature in the module to delete an object.
	 **
	 ** \see tNewObjectFPtr
	 **/
	typedef bool (*tDelObjectFPtr)(const void *);

	/** \}
	 **/

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The dynamic loadable module.
	 **/
	oc::DynamicLoadModule mDynamicLoadModule;

	/** The information object of the module.
	 **/
	mtModuleInfoPtr mModuleInfoPtr;

	/** The properties of the module.
	 **/
	mtModulePropertiesPtr mModulePropertiesPtr;

	/** List of object traits found the loaded module.
	 **/
	mtObjectTraitList mObjectTraitList;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor leaves the object uninitialized. You must
	 ** use the method Create() to initialize the instance.
	 **
	 ** \see Create(), DLMObjectFactory( const oc::File & )
	 **/
	DLMObjectFactory();

	/** This constructor loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsModuleLoaded() for the valid state.
	 **
	 ** \param moduleFile File name of the dynamic loadable module.
	 ** \see Create( const oc::File & ),
	 **      DLMObjectFactory( const std::string & )
	 **/
	DLMObjectFactory( const oc::File & moduleFile );

	/** This constructor loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsModuleLoaded() for the valid state.
	 **
	 ** \param moduleFile File name of the dynamic loadable module.
	 ** \see Create( const std::string & ),
	 **      DLMObjectFactory( const oc::File & )
	 **/
	DLMObjectFactory( const std::string & moduleFile );

	/** The copy constructor makes a copy all class attributes. Use the
	 ** copy constructor with care because only the actual state of the
	 ** module will be copied and not the module itself. That means if the
	 ** destructor of one of the two DLMObjectFactory instances are invoked
	 ** the module will be unloaded and so the system handle of the other
	 ** instance get invalid.
	 **
	 ** \param source The instance which will be copied.
	 ** \see ~DLMObjectFactory()
	 **/
	DLMObjectFactory( const DLMObjectFactory & source );

	/** The destructor unloads the module. One must pay attention that the
	 ** module should only be unloaded if all thru this module allocated
	 ** instances are already deleted by this module
	 **
	 ** \see UnloadModule()
	 **/
	virtual ~DLMObjectFactory();

	/** \}
	 **/

	/** \name Creators
	 ** \{
	 **/

    public:

	/** This creator loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsModuleLoaded() for the valid state.
	 ** Do not use this method if the instance is already initialized, e. g.
	 ** IsModuleLoaded() returns \c true.
	 **
	 ** \param moduleFile File name of the dynamic loadable module.
	 ** \return \c true if the module file could be loaded, \c false on
	 **         failure.
	 ** \see DLMObjectFactory(),
	 **      DLMObjectFactory( const oc::File & )
	 **      Create( const std::string & )
	 **/
	bool Create( const oc::File & moduleFile );

	/** This creator loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsModuleLoaded() for the valid state.
	 ** Do not use this method if the instance is already initialized, e. g.
	 ** IsModuleLoaded() returns \c true.
	 **
	 ** \param moduleFile File name of the dynamic loadable module.
	 ** \return \c true if the module file could be loaded, \c false on
	 **         failure.
	 ** \see DLMObjectFactory(),
	 **      DLMObjectFactory( const std::string & ),
	 **      Create( const oc::File & )
	 **/
	bool Create( const std::string & moduleFile );

	/** \}
         **/

	/** \name Operators
	 ** \{
	 **/

    protected:

	/** The assignment operator makes a copy all class attributes. Use the
	 ** assignment operator with care because only the actual state of the
	 ** module will be copied and not the module itself. That means if the
	 ** destructor of one of the two DLMObjectFactory instances are invoked
	 ** the module will be unloaded and so the system handle of the other
	 ** instance get invalid.
	 **
	 ** \param source The instance which will be assigned.
	 ** \return The assigned dynamic load module instance.
	 **/
	DLMObjectFactory & operator=( const DLMObjectFactory & source );

	/** \}
	 **/

	/** \name Getters / Setters
	 ** \{
	 **/

    public:

	/** Returns the file name of the module.
	 **
	 ** \return The file name of the module.
	 **/
	const oc::File & GetModuleFile() const;

	/** Returns information about the dynamic loadable module like the
	 ** version and the vendor of the module. This method is only valid
	 ** if the module is loaded.
	 **
	 ** \return Information object on success, \c CPtr::NullPtr on failure.
	 ** \see DLMObjectFactoryInfo, IsModuleLoaded(), GetModuleProperties()
	 **/
	const mtModuleInfoPtr & GetModuleInfo() const;

	/** Returns the properties about of the dynamic loadable module. This
	 ** method is only valid if the module is loaded.
	 **
	 ** \see IsModuleLoaded(), GetModuleInfo()
	 **/
	const mtModulePropertiesPtr & GetModuleProperties() const;

	/** Returns a list of object traits which are found in the loaded
	 ** module.
	 **/
	const mtObjectTraitList & GetObjectTraitList() const;

	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

	/** Checks whether the module file is loaded.
	 **
	 ** \return \c true if the module file was loaded successfully,
	 **         \c false otherwise.
	 **/
	bool IsModuleLoaded() const;

        /** \}
         **/

	/** \name Access Methods
	 ** \{
	 */

    public:

	/** This method overrides the corresponding method of the base
	 ** class ObjectFactory. For detailed description see
	 ** ObjectFactory::NewObjectV().
	 **
	 ** \b Example:
	 **
	 ** See ObjectFactory::NewObjectV()
	 **
	 ** \param  className An object of this class will be created.
	 ** \return Pointer to allocated instance on success, \c NULL on
	 **         failure.
	 **/
	virtual void * NewObjectV( const std::string & className );

	/** This method overrides the corresponding method of the base
	 ** class ObjectFactory. For detailed description see
	 ** ObjectFactory::DelObjectV().
	 **
	 ** \b Example:
	 **
	 ** See ObjectFactory::DelObjectV()
	 **
	 ** \param className An object of this class will be deleted.
	 ** \param instance  The previously allocated instance to delete.
	 ** \return \c true on success, \c false on failure
	 **/
	virtual bool DelObjectV( const std::string & className,
				 const void        * instance );

	/** \}
	 **/

	/** \name Helpers
	 ** \{
	 */

    private:

	/** Queries the module for the provided information and properties.
	 ** This method searches for in the module for the function
	 ** \c GetModuleInfo() which return a pointer to an informative
	 ** object which itselfs provides properties about the module.
	 ** The pointer to the informative object and the pointer to the
	 ** module properties are saved in the attributes \c mModuleInfoPtr
	 ** and \c mModulePropertiesPtr.
	 **
	 ** \see GetModuleInfo(), GetModuleProperties()
	 ** \return \c true if informative object and module properties could
	 **         be queried and saved, \c false otherwise.
	 **/
	bool QueryModule();

	/** Returns the global unique id to the given class name \p className.
	 ** To find the GUID the method searches for the \p className in all
	 ** object traits contained in the \p mObjectTraitList.
	 ** 
	 ** \param className [IN] Class name for which the GUID will be returned
	 ** \return The GUID to the given class name. 
	 **/
	oc::GUID GetGUID( const std::string & className );

	/** \}
	 **/
	

    }; // DLMObjectFactory

    /** A C-Pointer to a dynamic load module object factory.
     **/
    typedef oc::CPtr<DLMObjectFactory> DLMObjectFactoryPtr;

} // namespace oc



#endif

