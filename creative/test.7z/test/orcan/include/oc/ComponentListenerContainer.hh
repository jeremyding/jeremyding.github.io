
#ifndef OC_COMPONENT_LISTENER_CONTAINER_HH
#define OC_COMPONENT_LISTENER_CONTAINER_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>

// C++ include

#include <list>


namespace oc
{
   
    // =====================================
    // COMPONENT LISTENER CONTAINER template
    // =====================================

    /** Container template for listeners.
     **/
    template < class T >
    class ComponentListenerContainer
    {

    public:

        class Listener;

    private:

        /** The container for the listener instances.
         **/
        static std::list< Listener * > msListeners;

    public:

        /** The listener class (pure virtual).
         **/
        class Listener
        {
        public:

            /** New object of component created.
             **/
            virtual void ComponentCreated( T instance ) = 0;

            /** Component object about to be deleted.
             **/
            virtual void ComponentDeleted( T instance ) = 0;

        }; // class Listener


        /** Adds a new listener to the container.
         **/
        static bool Add( Listener & l )
        {
            msListeners.push_back( & l );
            return true;
        }

        /**  Remove a listener from the container.
         **/
        static bool Remove( Listener & l )
        {
            msListeners.remove( & l );
            return true;
        }

        /** Notify all listeners for new object creation.
         **/
        static void NotifyForCreation( T instance )
        {
            if( ! msListeners.empty() ) {

                typename std::list< Listener * >::iterator it, eit;

                for( it=msListeners.begin(), eit=msListeners.end(); it!=eit; ++it ) {

                    (*it)->ComponentCreated( instance );
                }
            }
        }

        /** Notify all listeners for object deletion.
         **/
        static void NotifyForDeletion( T instance )
        {
            if( ! msListeners.empty() ) {

                typename std::list< Listener * >::iterator it, eit;

                for( it=msListeners.begin(), eit=msListeners.end(); it!=eit; ++it ) {

                    (*it)->ComponentDeleted( instance );
                }
            }
        }

    }; // class ComponentListenerContainer

    template < typename T >
    std::list< OC_TYPENAME ComponentListenerContainer<T>::Listener * > ComponentListenerContainer<T>::msListeners = std::list< OC_TYPENAME ComponentListenerContainer<T>::Listener * >();

} // namespace oc

#endif

