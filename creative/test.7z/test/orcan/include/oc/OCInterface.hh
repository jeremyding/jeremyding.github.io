
#ifndef OC_OC_INTERFACE_HH
#define OC_OC_INTERFACE_HH


//==============================================================================
//
//  Crystal Growth Laboratory
//
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft
//  Department of Material Science         Institute of Integrated Circuits
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)
//  Martensstrasse 7                       Schottkystrasse 10
//  91058 Erlangen                         91058 Erlangen
//  Germany                                Germany
//
//  In cooperation with
//
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg
//  Department of Computer Science 9       Department of Computer Science 10
//  Computer Graphics                      System Simulation Group
//  Am Weichselgarten 9                    Cauerstra�e 6
//  91058 Erlangen                         91058 Erlangen
//  Germany                                Germany
//
//------------------------------------------------------------------------------
//
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//
//==============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>

// C++ include

#include <typeinfo>


namespace oc
{

    /** OC interface class is the base class of all interface which are not
     ** fixed assigned to a component.
     **
     ** \author Michael Kellner
     ** \date 09.12.2004
     **/
    class OCInterface
    {

    public:

        /** Default constructor.
         **/
        OCInterface()
        {}

        /** Copy constructor.
         **/
        OCInterface( OCInterface const & )
        {}

        /** Destructor.
         **/
        virtual ~OCInterface()
        {}

        /** Assignment operator.
         **/
        OCInterface & operator=( OCInterface const & rhs )
        {
            return *this;
        }
        
    }; // class OCInterface

    /** Pointer to OC interface.
     **/
    typedef oc::CPtr<OCInterface> OCInterfacePtr;
    

    /** Template to define interface pointers to subclasses of OC interfaces.
     **
     ** \author Michael Kellner
     ** \date 09.12.2004
     **/
    template <class T>
    class InterfacePtr : public CPtr<T>
    {

    public:

        /** Default constructor.
         **/
        InterfacePtr()
            : CPtr<T>()
        {}

        /** Copy constructor.
         **/
        InterfacePtr( InterfacePtr const & source )
            : CPtr<T>( source )
        {}

        /** Constructor with OCInterfacePtr
         **/
        InterfacePtr( OCInterfacePtr const & source )
            : CPtr<T>( static_cast<T *>( const_cast<OCInterface *>(source.GetCPtr()) ) )
        {}

        /** Destructor.
         **/
        ~InterfacePtr()
        {}

        /** Assignment operator with a OC interface pointer.
         **/
        InterfacePtr & operator=( OCInterfacePtr const & rhs )
        {
            CPtr<T>::operator=( static_cast<T *>( const_cast<OCInterface *>(rhs.GetCPtr()) ) );
            return *this;
        }

        /** Assignment operator with an interface pointer.
         **/
        InterfacePtr & operator=( InterfacePtr const & rhs )
        {
            CPtr<T>::operator=( rhs.GetCPtr() );
            return *this;
        }

    }; // class InterfacePtr
    

} // namespace oc

#endif

