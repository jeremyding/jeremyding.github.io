
#ifndef OC_INET_ADDRESS
#define OC_INET_ADDRESS

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================
      

// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>

// C++ include

#include <string>

// C include

#ifdef WIN32
#  include <Winsock2.h>
#else
#  include <sys/types.h>
#  include <netinet/in.h>
#endif



namespace oc
{

    /** This class represents an Internet Protocol (IP) address. Applications
     ** should use the methods GetLocalHost or GetByName to create a new
     ** InetAddress instance.
     **
     ** \author Michael B. Kellner
     **
     ** \nosubgrouping
     **/
    class InetAddress
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** System structure for holding an internet address.
	 **/
	struct in_addr mInAddr;

	/** The official name of the host.
	 **/
	std::string mHostName;


        /** Number of InetAddr instances.
         **/
        static int mInstanceCount;

	/** \}
	 **/

	/** \name Startup/Cleanup
	 ** \{
	 **/

        /** Startup networking subsystem.
         ** Must be called on WIN32 systems before any other networking operation.
         **/
        static void Startup();

        /** Cleanup networking subsystem.
         ** Must be called on WIN32 systems!.
         **/
        static void Cleanup();

	/** \}
	 **/
 

	/** \name Constructors / Destructor
	 ** \{
	 **/

    private:

	/** Default constructor not allowed. Use the static methods GetLocalHost
	 ** or GetByName to get an InetAddress.
	 **/
	InetAddress();

    public:

	/** Copy constructor
	 **/
	InetAddress( const InetAddress & source );

	/** Destructor
	 **/
	~InetAddress();

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

	/** Assignment operator
	 **/
	InetAddress & operator=( const InetAddress & rhs );

	/** Tests if two InetAddress instances refer to the same IP address.
	 **/
	bool operator==( const InetAddress & rhs ) const;

	/** Tests if two InetAddress instances refer to different IP addresses.
	 **/
	bool operator!=( const InetAddress & rhs ) const;

	/** \}
	 **/

	/** \name Static Methods
	 ** \{
	 **/

	/** Determines the IP address of a host, given the host's name. The host
	 ** name can either be a machine name, such as "eiche.iis-b.fhg.de", or
	 ** a string representing its IP address, such as "153.96.117.46". If the
	 ** host can not be resolved into an IP address the returned InetAddress
	 ** is Null (see IsNull).
	 **
	 ** \param host The specified host, or empty string for the local host.
	 ** \return An IP address for the given host name.
	 **/
	static InetAddress GetByName( const std::string & host );

	/** Returns the local host.
	 **
	 ** \return The IP address of the local host.
	 **/
	static InetAddress GetLocalHost();

	/** \}
	 **/


    
	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** Returns the IP address string "%d.%d.%d.%d".
	 **
	 ** \return The raw IP address in a string format.
	 **/
	std::string GetHostAddress() const;

	/** Gets the host name for this IP address.
	 **
	 ** \return The host name for this IP address.
	 **/
	const std::string & GetHostName() const;

	/** Gets the system structure of the address.
	 **/
	struct in_addr GetAddress() const;

	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

	/** Test if the address is the Null address.
	 **/
	bool IsNull() const;

	/** \}
	 **/


    }; // class InetAddress

} // namespace oc


#endif

