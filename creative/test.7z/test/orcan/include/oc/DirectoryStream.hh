
#ifndef OC_DIRECTORY_STREAM_HH
#define OC_DIRECTORY_STREAM_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/System.hh>
#include <oc/File.hh>
#include <oc/config.h>

// STL include

#include <string>


// DEFINES
// =======

// Microsoft Windows specific
// --------------------------
#ifdef WIN32

#define OC_DIR_HANDLE      long
#define OC_DIR_NULL_HANDLE (-1)

// UNIX specific
// -------------
#else

#include <dirent.h>

#define OC_DIR_HANDLE      DIR *
#define OC_DIR_NULL_HANDLE ( (DIR *) NULL)

#endif


namespace oc
{

    /** This class reads the entries of a directory in a
     ** system-independent way. The usage is similar to C++ stream handling, see
     ** <a href="#EXAMPLE">example</a> below. Error handling is done via
     ** <tt>bool</tt> return values and errno.
     **
     ** \b Bugs:
     **
     ** - %File mask is only supported on MS-Windows platforms.
     **
     ** <a name="EXAMPLE">Example:</a>
     ** <pre>
     ** DirectoryStream din;
     **
     ** din.Open( File( "/tmp" ) );
     ** 
     ** if( ! din ) {
     **   cerr << "Can't open directory \"tmp\" for listing." << endl;
     **   if( errno != 0 )
     **     cerr << "Reason: " << System.GetErrnoString( errno ) << endl;
     **   return( -1 );
     ** }
     ** 
     ** File file;
     **
     ** while( ! din.EOD() ) {
     **
     **   din >> file;
     **
     **   cout << "File: " << file.GetAbsoluteFile() << endl;
     ** }
     **
     ** din.Close();
     **
     ** </pre>
     **
     ** \author Michael B. Kellner
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI DirectoryStream
    {

        /** \name Static Attributes
         ** \{
         **/

    public:

	/** The default file mask for file listing.
	 **/
	static const std::string msDefaultFileMask;


        /** \}
         **/

        /** \name Attributes
         ** \{
         **/

    private:

	/** The directory which will be listed.
	 **/
	std::string mDirectory;

	/** The system-dependent directory handle.
	 */
	OC_DIR_HANDLE mDirectoryHandle;

	/** The next file in directory listing. If no next file exists it is the
	 ** empty string.
	 **/
	std::string mNextEntry;

        /** \}
         **/


        /** \name Constructors / Destructor
         ** \{
         **/

    public:

	/** Default constructor. Leaves the instance in an uninitialized state.
	 ** Use the <i>Open()</i> method or another constructor to
	 ** initialization the instance. To check whether an object of this
	 ** class is initialized use the ! operator.
	 **/
	DirectoryStream();

	/** Opens the given directory for reading the file list of file names
	 ** satisfying the file mask specification. To check whether the object
	 ** is initialized successfully use the ! operator.
	 ** @param directory Directory which files wants to be listed
	 ** @param fileMask Only files satisfying this mask will be read (only
	 **        Windows); if no mask is given the system-dependent default
	 **        file mask <tt>sDefaultFileMask</tt> will be used
	 **/
	DirectoryStream( const oc::File   & directory,
			 const std::string & fileMask = msDefaultFileMask );

	/** Destructor closes directory stream if neccessary.
	 **/
	~DirectoryStream();

    private:

	/** Copy constructor not allowed.
	 **/
	DirectoryStream( const DirectoryStream & directory );

        /** \}
         **/


	/** \name Access Methods
         ** \{
         **/

    public:

	/** Opens the given directory for reading the file list of file names
	 ** satisfying the file mask specification.
	 ** @param directory Directory which files wants to be listed
	 ** @param fileMask Only files satisfying this mask will be read (only
	 **        Windows); if no mask is given the system-dependent default
	 **        file mask <tt>sDefaultFileMask</tt> will be used
	 ** @return <tt>true</tt> if directory could be opened successfully;
	 **         <tt>false</tt> otherwise.
	 **/
	bool Open( const oc::File   & directory,
		   const std::string & fileMask = msDefaultFileMask );

	/** Close the previously opened directory.
	 **/
	bool Close();

	/** Reads the next file in the directory. As long as <tt>EOD()</tt>
	 ** returns <tt>true</tt> the call to <tt>GetNextFile()</tt> will be
	 ** successfully. See <a href="#EXAMPLE">example</a>.
	 ** @param file The next file in the directory as output parameter
	 ** @return <tt>true</tt> if there is a next file; <tt>false</tt>
	 **         otherwise
	 **/
	bool GetNextFile( oc::File & file );

	/** Reads the next file in the directory. As long as <tt>EOD()</tt>
	 ** returns <tt>true</tt> the call to this operator will be
	 ** successfully. See <a href="#EXAMPLE">example</a>.
	 ** @param file The next file in the directory or <tt>File::Null</tt>
	 **        if end of directory (EOD) already reached before calling
	 **        this function
	 ** @return Reference to the instance after reading
	 **/
	DirectoryStream & operator>>( oc::File & file );

    private:

	/** Assigment ot allowed.
	 **/
	DirectoryStream & operator=( const DirectoryStream & directory );

        /** \}
         **/


	/** \name Info Methods
         ** \{
         **/

    public:

	/** Check whether the instance refers to a successfully opened
	 ** directory. Note: It doesn't check for the end of directory (EOD)
	 ** state.
	 ** @return <tt>true</tt> if instance refers to a valid opened
	 **         directory; <tt>false</tt> otherwise
	 **/
	bool operator!() const;

	/** Check whether the end of directory (EOD) state has been reached.
	 ** @return <tt>true</tt> if there is another file in file list;
	 **         <tt>false</tt> otherwise
	 **/
	bool EOD() const;

        /** \}
         **/

	/** \name Helpers
         ** \{
         **/

    private:

	/** Read the next file in directory and saves it in the class attribute
	 ** <tt>mNextEntry</tt>. If no next file exists <tt>mNextEntry</tt> is
	 ** the empty string.
	 ** @return <tt>true</tt> if next entry could be read; <tt>false</tt>
	 **         otherwise
	 **/
	bool ReadNextEntry();

        /** \}
         **/

    }; // class DirectoryStream

} // namespace oc



#endif

