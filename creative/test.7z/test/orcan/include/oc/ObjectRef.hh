
#ifndef OC_OBJECT_REF_HH
#define OC_OBJECT_REF_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/CPtr.hh>
#include <oc/config.h>
#include <oc/OCInterface.hh>
#include <oc/ObjectTrait.hh>
#include <oc/PropertyMap.hh>
#include <oc/ObjectFactory.hh>




namespace oc
{

    /** This template class is a wrapper to an arbitrary object instance. It
     ** is used to separate the creation of an object from its usage. This class
     ** is mainly used by oc::ObjectFactory which creates the "important"
     ** objects of \em CrysVUn3D. 
     **
     ** \b Note:
     **
     ** The only method the template parameter class must provide is
     ** \em GetProperties() which should return a oc::PropertyMap. The
     ** properties will be accessed by the methods:
     **
     ** - HasProperty()
     ** - GetProperty()
     **
     ** \b Example:
     **
     ** \code
     **
     ** // Create a new mesh object ...
     ** Mesh3DRef mesh = Mesh3D::New();
     **
     ** // ... and use the "Creation" interface if existant.
     ** if( mesh.I.CreatePtr ) {
     **
     **     mesh.I.CreatePtr->CreateVertex( 0.f, 0.f, 0.f );
     **     mesh.I.CreatePtr->CreateVertex( 1.f, 2.f, 3.f );
     **     mesh.I.CreatePtr->CreateVertex( 4.f, 5.f, 6.f );
     **     mesh.I.CreatePtr->CreateVertex( 3.f, 2.f, 1.f );
     ** }
     **
     ** mesh.Delete();
     ** 
     ** \endcode
     **
     ** \author Michael Kellner
     ** \date 03.4.2003
     **
     ** \nosubgrouping
     **/
    template < class Object >
    class ObjectRef
    {

        /** \name Class Types
         ** \{
         **/

    public:

        /** The type of the embedded object.
         **/
        typedef Object ObjectType;

        /** The type of the instantiated template class.
         **/
        typedef ObjectRef<Object> SelfType;

        /** The type of the pointer to the embedded object.
         **/
        typedef oc::CPtr<Object> ObjectPtr;

        /** \}
         **/

        /** \name Attributes
         ** \{
         **/

    private:

        /** The instance which is managed by this class.
         **/
        ObjectPtr mInstancePtr;

        /** The object characteristic.
         **/
        oc::ObjectTraitPtr mObjectTraitPtr;

        /** The object factory which has created the object instance.
         **/
        oc::ObjectFactoryPtr mObjectFactoryPtr;

        /** \}
         **/


        /** \name Constructors / Destructor
         ** \{
         **/

    public:

        /** Default constructor leaves the instance uninitialized. Use creator
         ** methods or assignment operators to initialize the instance.
         **
         ** \see Create( Object & )
         **      Create( oc::CPtr<Object> &,
         **              oc::ObjectTraitPtr,
         **              oc::ObjectFactoryPtr )
         **      operator=( Object & )
         **/
        ObjectRef()
            : mInstancePtr(),
              mObjectTraitPtr(),
              mObjectFactoryPtr()
        {}

        /** Initialize the instance with an object \a instance to manage,
         ** the object trait description and the object factory which
         ** created the instance.
         **
         ** \param instance Object instance to manage.
         ** \param objectTrait Description to this object kind.
         ** \param objectFactory Factory which has created the instance.
         **
         ** \see Create( Object & )
         **/
        ObjectRef( oc::CPtr<Object> &   instance,
                   oc::ObjectTraitPtr   objectTrait = oc::ObjectTraitPtr(),
                   oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr())
            : mInstancePtr     ( instance      ),
              mObjectTraitPtr  ( objectTrait   ),
              mObjectFactoryPtr( objectFactory )
        {
        }

        /** Initialize the instance with an object \a instance to manage,
         ** the object trait description and the object factory which
         ** created the instance.
         **
         ** \param instance Object instance to manage.
         ** \param objectTrait Description to this object kind.
         ** \param objectFactory Factory which has created the instance.
         **
         ** \see Create( Object & )
         **/
        ObjectRef( Object *               instance,
                   oc::ObjectTraitPtr   objectTrait = oc::ObjectTraitPtr(),
                   oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr())
            : mInstancePtr     ( instance      ),
              mObjectTraitPtr  ( objectTrait   ),
              mObjectFactoryPtr( objectFactory )
        {
        }

        /** The copy constructor did not make a copy of the instance (of
         ** course), it copies only the reference to it.
         **
         ** \param source Object reference from which a copy will be made off.
         **/
        ObjectRef( const ObjectRef & source )
            : mInstancePtr     ( source.mInstancePtr      ),
              mObjectTraitPtr  ( source.mObjectTraitPtr   ),
              mObjectFactoryPtr( source.mObjectFactoryPtr )
        {}

        /** The destructor is empty, it does not need to free any resources.
         **/
        virtual ~ObjectRef()
        {}

        /** \}
         **/


        /** \name Creators / Deletion
         ** \{
         **/

    public:

        /** Initialize the instance with the given object \a instance to manage. If the
         ** object reference has already an instance, this instance will NOT be
         ** deleted. The user is responsible for deletion.
         **
         ** \param instance      Object instance to manage.
         ** \param objectTrait   Object trait which describes the instance.
         ** \param objectFactory Object factory which has created the instance.
         ** \return \c true if the initialization was successfully, \c false
         **         otherwise.
         **
         ** \see ObjectRef( Object &,
         **                 oc::ObjectTraitPtr,
         **                 oc::ObjectFactoryPtr )
         **      Create( oc::CPtr<Object> & )
         **/
        bool Create( Object &              instance,
                     oc::ObjectTraitPtr   objectTrait   = oc::ObjectTraitPtr::NullPtr,
                     oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr::NullPtr )
        {
            mInstancePtr      = instance;
            mObjectTraitPtr   = objectTrait;
            mObjectFactoryPtr = objectFactory;

            return ! (*this);
        }


        /** Initialize the instance with the given object \a instance to manage,
         ** the object trait description and the object factory which has
         ** created the instance. If the object reference has already an
         ** instance, this instance will NOT be deleted. The user is
         ** responsible for deletion.
         **
         ** \param instance Object instance to manage.
         ** \param objectTrait   Object trait which describes the instance.
         ** \param objectFactory Object factory which has created the instance.
         ** \return \c true if the initialization was successfully, \c false
         **         otherwise.
         **
         ** \see ObjectRef( oc::CPtr<Object> & )
         **      Create( Object & )
         **/
        bool Create( oc::CPtr<Object> &   instance,
                     oc::ObjectTraitPtr   objectTrait   = oc::ObjectTraitPtr::NullPtr,
                     oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr::NullPtr )
        {

            mInstancePtr      = instance;
            mObjectTraitPtr   = objectTrait;
            mObjectFactoryPtr = objectFactory;

            return ! (*this);
        }

        /** Delete the managed instance. If an object factory is specified the instance
         ** will be deleted by this factory, if not the normal C++ delete operator will
         ** be called.
         **/
        bool Delete()
        {
            if( mInstancePtr.IsNull() ) {
            
                return false;
            }

            // If possible the object factory delete  the instance.
            bool success=true;

            if( ! mObjectFactoryPtr.IsNull() ) {
            
                if( ! mObjectTraitPtr.IsNull() ) {
                
                    success = mObjectFactoryPtr->DelObject( mObjectTraitPtr->GetComponentName(),
                                                            mInstancePtr );
                }
                else {
                
                    success = mObjectFactoryPtr->DelObject( std::string( "" ),
                                                            mInstancePtr );
                }
            }

            // Instance could not be deleted via object factory.
            if( ! success ) {
                mInstancePtr.Delete();
            }

            // Reset reference
            SetNull();

            return true;
        }

        /** \}
         **/


        /** \name Operators
         ** \{
         **/

    public:

        /** Initialize the instance with the given object \a instance to manage. If the
         ** object reference has already an instance, this instance will NOT be
         ** deleted. The user is responsible for deletion.
         **
         ** \param instance Object instance to manage.
         ** \return Reference to assigned object.
         **
         ** \see Create( Object & )
         **/
        ObjectRef & operator=( Object & instance )
        {
            mInstancePtr      = instance;
            mObjectTraitPtr   = oc::ObjectTraitPtr::NullPtr;
            mObjectFactoryPtr = oc::ObjectFactoryPtr::NullPtr;

            return *this;
        }

        /** Assignes the reference to one object to another reference, so both
         ** instances references to the same object after assignment. If the
         ** object reference has already an instance, this instance will NOT be
         ** deleted. The user is responsible for deletion.
         **
         ** \param assignee Object reference assigned.
         ** \return Reference to assigned object.
         **
         ** \see Create( const ObjectRef & )
         **/
        ObjectRef & operator=( const ObjectRef & assignee )
        {
            mInstancePtr      = assignee.GetInstancePtr();
            mObjectTraitPtr   = assignee.GetObjectTrait();
            mObjectFactoryPtr = assignee.GetObjectFactory();

            return *this;
        }

        /** Checks whether the instance is well initialized.
         **
         ** \return \c true if instance is not NULL, \c false otherwise.
         **/
        operator bool() const
        {
            return mInstancePtr != oc::CPtr<Object>::NullPtr;
        }

        /** Negativ check whether the instance is well initialized.
         **
         ** \return \c true if instance is NULL, \c false otherwise.
         **/
        bool operator!() const
        {
            return mInstancePtr == oc::CPtr<Object>::NullPtr;
        }

        /** Returns a reference to the managed object instance.
         **
         ** \return Reference to managed object.
         **/
        Object & operator*()
        {
            return mInstancePtr.GetRef();
        }

        /** Returns a pointer to the managed object instance.
         **
         ** \return Pointer to managed object.
         **/
        Object * operator->()
        {
            return mInstancePtr.GetCPtr();
        }

        /** \}
         **/


        /** \name Query Methods
         ** \{
         **/

    public:

        /** Query if property with name \a name exits.
         **
         ** \param name Property name to query for.
         ** \return \c true if object has the property, \c false otherwise.
         **
         ** \see GetProperty(), HasInterface()
         **/
        bool HasProperty( const std::string & name ) const
        {
            if( ! (*this) ) {

                OCDEBUG( "No instance to query." );
                return false;
            }

            return GetInstancePtr()->GetProperties().HasProperty( name );
        }
                

        /** Query if object implements the interface with name \a name. If an
         ** object implements an interface a property "Interface:&lt;name&gt;"
         ** exists.
         **
         ** \param name Interface name to query for.
         ** \return \c true if object has the interface, \c false otherwise.
         **
         ** \see GetInterface(), HasProperty()
         **/
        bool HasInterface( const std::string & name ) const
        {
            if( ! (*this) ) {

                OCDEBUG( "No instance to query." );
                return false;
            }

            return GetInstancePtr()->GetProperties().HasProperty( "Interface:"
                                                                  + name );
        }
        
        /** \}
         **/


        /** \name Getters / Setters
         ** \{
         **/

    public:

        /** Get PropertyMap of this object.
         **
         **/
        oc::PropertyMap& GetProperties()
        {
            if( ! (*this) ) {
                OCDEBUG( "No instance to query." );
            
            }

            return GetInstancePtr()->GetProperties();
        }


        /** Get readonly PropertyMap of this object.
         **
         **/
        oc::PropertyMap const& GetProperties() const
        {
            if( ! (*this) ) {
                OCDEBUG( "No instance to query." );
            }

            return GetInstancePtr()->GetProperties();
        }


        /** Returns a reference to the managed object instance.
         **
         ** \return Reference to managed object.
         **/
        oc::CPtr<Object> & GetInstancePtr()
        {
            return mInstancePtr;
        }

        /** Returns a constant reference to the managed object instance.
         **
         ** \return Reference to managed object.
         **/
        const oc::CPtr<Object> & GetInstancePtr() const
        {
            return mInstancePtr;
        }

        /** Returns the object characteristic description of the object.
         **/
        oc::ObjectTraitPtr GetObjectTrait() const
        {
            return mObjectTraitPtr;
        }

        /** Set the object characteristic description of the object.
         **/
        bool SetObjectTrait(  oc::ObjectTraitPtr objectTrait )
        {
            mObjectTraitPtr = objectTrait;
            return true;
        }

        /** Returns the object factory which has created the object instance.
         **/
        oc::ObjectFactoryPtr GetObjectFactory() const
        {
            return mObjectFactoryPtr;
        }

        /** Set the object factory which has created the object instance.
         **/
        bool SetObjectFactory( oc::ObjectFactoryPtr objectFactory )
        {
            mObjectFactoryPtr = objectFactory;
            return true;
        }

        /** Return the property named \a name.
         **
         ** \param name Property name.
         ** \return \c oc::Property::Null() on error.
         **/
        oc::Property const & GetProperty( const std::string & name ) const
        {
            if( ! (*this) ) {

                OCDEBUG( "No instance to query." );
                return oc::Property::Null();
            }

            if( !GetInstancePtr()->GetProperties().HasProperty(name) ) {
                
                OCDEBUG( "Property not defined." );
                return (bool &) oc::Property::Null();

            }
            return GetInstancePtr()->GetProperties()[name];
        }

        /** Return the interface named \a name.
         **
         ** \param name Interface name.
         ** \return Interface pointer if existant, Null pointer otherwise.
         **/
        oc::OCInterfacePtr GetInterface( const std::string & name ) const
        {
            if( ! (*this) ) {

                OCDEBUG( "No instance to query." );
                return oc::OCInterfacePtr::NullPtr;
            }

            if( ! GetInstancePtr()->GetProperties().HasProperty( "Interface:" + name ) ) {

                return oc::OCInterfacePtr();
            }

            return GetInstancePtr()->GetProperties()["Interface:" + name]( oc::OCInterfacePtr() );
        }


        /** Returns the associated resource file.
         **/
        const oc::File & GetResource() const
        {
            static const oc::File nullFile = oc::File::Null;

            if( ! mObjectTraitPtr.IsNull() ) {
                return mObjectTraitPtr->GetResource();
            }

            return nullFile;
        }

        /** Returns the name of the embedded object.
         **/
        static std::string GetName()
        {
            return Object::GetName();
        }

        /** Unreference instance.
         **/
        void SetNull()
        {
            mInstancePtr.SetNull();
            mObjectTraitPtr.SetNull();
            mObjectFactoryPtr.SetNull();
        }
            
        /** \}
         **/

        /** \name Comparison
         ** \{
         **/

        inline bool IsEqual( ObjectRef const& rhs) const
        {
            return (this->GetInstancePtr() == rhs.GetInstancePtr());
        }

        inline bool operator == (ObjectRef const&rhs) const
        {
            return this->IsEqual(rhs);   
        }
        
        inline bool operator != (ObjectRef const&rhs) const
        {
            return !this->IsEqual(rhs);   
        }

        /** \}
         **/

    }; // class ObjectRef

} // namespace oc


#endif
