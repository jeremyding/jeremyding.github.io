
#ifndef OC_OBJECT_BROKER_CONFIG_HH
#define OC_OBJECT_BROKER_CONFIG_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/File.hh>
#include <oc/LogProgress.hh>
#include <oc/ObjectTrait.hh>
#include <oc/ObjectBrokerConfigCache.hh>

// C++ include

#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <fstream>



namespace oc
{

    /** The object broker config gathers all possible objects which can be
     ** found in a file \p AddModuleFile, in all files in a directory
     ** \p AddModulePath or in all files in all directories listed by an
     ** environment variable AddModulePathEnv. Each object that can be found is
     ** represented by an object trait instance and is stored. The object
     ** broker which will be attached to this config can search for a
     ** specific kind of object.
     **
     ** \author Michael Kellner
     ** \date 28.10.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI ObjectBrokerConfig
    {

	/** \name Class Types
	 ** \{
	 **/

    public:

	/** The container type for object traits which are managed by this config.
	 **/
	typedef std::multimap< std::string, oc::ObjectTrait * > mtObjectTraitContainer;

	/** The container type for object traits which are defined as the default
	 ** realizations of a component.
	 **/
	typedef std::map< std::string, oc::ObjectTrait * > mtDefaultObjectTraitContainer;

	/** The container type for object traits which are returned by the find method.
	 **/
	typedef std::vector< oc::ObjectTrait * > mtObjectTraitVector;

	/** \}
	 **/

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** Container with all known objects which can be created by an object
	 ** factories.
	 **/
	mtObjectTraitContainer mObjectTraitContainer;

	/** Container with all default component realizations. These are set thru
	 ** the SetDefault() method and returned by the GetDefault() method. The
	 ** method is used by the object broker to find a default component
	 ** realization if no special realization name is given for the
	 ** ObjectBroker::New*() call.
	 **/
	mtDefaultObjectTraitContainer mDefaultObjectTraitContainer;
	

	/** Comma separated list of valid extensions of the dynamic load module
	 ** file. Usually <tt>dll</tt> under Windows and <tt>so</tt> under Unix. In
	 ** addition we use <tt>mod</tt> on both systems.
	 **/
	std::string mDlmFileExtensions;

	/** The log progress to report the 'important' messages during startup.
	 **/
	oc::LogProgress mLogProgress;

        /** 
         **/
        oc::ObjectBrokerConfigCache mCache;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor.
	 **/
	ObjectBrokerConfig( const oc::File & cache = "cache.xml" );

        bool WriteCache(const oc::File & cacheFile);

	/** Destructor.
	 **/
	~ObjectBrokerConfig();

    private:

	/** Copy constructor not allowed.
	 **/
	ObjectBrokerConfig( const ObjectBrokerConfig & source );


	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    private:

	/** Assignment operator not allowed.
	 **/
	ObjectBrokerConfig & operator=( const ObjectBrokerConfig & rhs );

	/** \}
	 **/


	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** Adds a dynamic load module to the object broker config. The method
         ** will load the module file and queries all neccessary information
         ** about contained components.
	 **
	 ** \param moduleFile [IN] Dynamic load module file
	 ** \return \c true on success, \c false otherwise
	 **/
	bool AddModuleFile( const oc::File & moduleFile );

	/** Adds all dynamic load modules which can be found in the given
	 ** \p path to the object broker config.
	 **
	 ** \param modulePath [IN] Path which will be searched for modules.
	 ** \return \c true on success, \c false otherwise
	 **/
	bool AddModulePath( const oc::File & modulePath );

	/** Adds all dynamic load modules from the paths which are given
	 ** in the environment variable \p envVariable.
	 **
	 ** \param envVariable [IN] Environment variable containing path
	 **                         specifications to modules.
	 ** \return \c true on success, \c false otherwise
	 **/
	bool AddModulePathEnv( const std::string & envVariable );

	/** \}
	 **/

	/** \name Getter/Setter
	 ** \{
	 **/

	/** Set the default realization \p realizationName of the component
	 ** \p objectName. This will be returned by the object broker if
	 ** no realization name is given for the ObjectBroker::New*() method.
	 **
	 ** \param objectName name of the component
	 ** \param realizationName name of the component realization
	 ** \return \c true if the component and the realization exists,
	 **         \c false otherwise.
	 **/
	bool SetDefault( const std::string & objectName,
			 const std::string & realizationName );

	/** Returns the object trait for the default realization of the
	 ** component \p objectName. This is defined explicitly by the
	 ** SetDefault() method or implicitly as the first object trait
	 ** that is found by the ObjectBrokerConfig::Find() method.
	 **
	 ** \param objectName name of the component
	 ** \return Object trait for the default realization. If no
	 **         default value could be found the returned pointer
	 **         is null; use IsNull() method to test for null.
	 **/
	oc::ObjectTraitPtr GetDefault( const std::string & objectName );


        /** Set the XML file \p xml_resource as resource to the 
         ** \p component and \p realization.
         **/
        bool SetResource( std::string const & component,
                          std::string const & realization,
                          oc::File    const & xml_resource );

        /** Set the given \p resource_path as path to resource files. The
         ** method will search in the path for XML resource files matching
         ** one of the module names defined by AddModule*().
         **/
        bool SetResource( oc::File const & resource_path );


	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

	/** Search for a specific kind of object. Returns a vector of all
	 ** found object traits with the given \p objectName.
	 **
	 ** \b Note:
	 **
	 ** The namespace in which the realization is defined is part of
	 ** the realization name.
	 **
	 ** \param objectName      [IN] name of the object to search
	 ** \param realizationName [IN] name of the object realization to search
	 **                             (optional)
	 **/
	mtObjectTraitVector Find( const std::string & objectName,
				  const std::string & realizationName = "" ) const;

	/** \}
	 **/

	/** \name I/O Methods
	 ** \{
	 **/

	/** Print all object traits in the \p mObjectTraitContainer to the
	 ** given ouput stream \p out.
	 **/
	std::ostream & Dump( std::ostream & out ) const;

	/** \}
	 **/


        /** \name Helper Methods
         ** \{
         **/
    private:

        /** Adds a new object/component description to the object container.
         **/
        bool AddObjectTrait( std::string     const & componentName,
                             oc::ObjectTrait const & objectTrait );

        /** \}
         **/


    }; // class ObjectBrokerConfig

    /** A C-Pointer type to an object broker config.
     **/
    typedef oc::CPtr< oc::ObjectBrokerConfig > ObjectBrokerConfigPtr;

} // namespace oc


#endif
