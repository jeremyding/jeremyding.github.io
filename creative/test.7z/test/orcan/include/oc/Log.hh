#ifndef OC_LOG_HH
#define OC_LOG_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/System.hh>
#include <oc/Term.hh>

// STL include

#include <string>

// C++ include

#include <iostream>


namespace oc
{

    // CLASS Log
    // =========


    /** This class provides an interface to a simple log message output. You
     ** can define a prefix which will be printed at each new line. A new message
     ** starts after the <i>endm</i> manipulator. A <i>newl</i> in the message
     ** stream starts new line but no prefix will be printed instead the
     ** message will indent by the prefix width. The prefix is a concatination
     ** of the prefix string, i. e. <i>ERROR</i>, and the position (<tt>__FILE__
     ** and __LINE__</tt>) where the log message was printed. The printing of
     ** the whole prefix or parts of it (prefix string or position) can be
     ** enabled/disabled separately, see EnablePrefix() and EnablePosition().
     ** <br><br>
     ** There are five predefined log stream available:
     ** <ol>
     **   <li><tt>gFatal</tt></li>
     **   <li><tt>gError</tt></li>
     **   <li><tt>gWarn</tt></li>
     **   <li><tt>gInfo</tt></li>
     **   <li><tt>gDebug</tt></li>
     ** </ol>
     ** For convenience and for efficiency use the macros <tt>OCFATAL*</tt>,
     ** <tt>OCERROR*</tt>, ... They can be enabled/disabled the macros during
     ** compilation via the define flags OCPRINTFATAL, OCPRINTERROR, ... To
     ** enable all use <tt>OCPRINTALL</tt>, by default all except
     ** <tt>OCDEBUG*</tt> are enabled.
     ** <br><br>
     ** <b>Example:</b>
<pre>
Class::Open( File & theFile )
{
     if( ! theFile.IsExistant() ) {

         OCINFOCONT( "Can't open file: " << theFile.GetAbsoluteFile() << newl );
         OCINFO    ( "The file doesn't exists!" );
     }

     ...
}

Compilation with

 g++ -DPRINTALL ...

results as output:

INFO [Class.cpp, 346] Can't open file: /usr/share/doc/config.txt
                      The file doesn't exists!
</pre>
     ** See also the testsuite for this class in the folder <tt>test/Log</tt>.
     **/
    class Log
    {

    public:

	/** The available colors for the log messages.
	 ** @see SetColor
	 **/
	typedef enum {

	    GREY,
	    RED,
	    GREEN,
	    YELLOW,
	    BLUE,
	    MAGENTA,
	    CYAN,
	    WHITE,
	    BLACK,
	    NORMAL

	} mtColor;

    private:

	/** The stream were all output will be printed.
	 **/
	std::ostream & mOut;

	/** The prefix will appear at the beginning of each new line.
	 **/
	std::string mPrefix;

	/** The file were the log message was printed.
	 **/
	std::string mFileName;

	/** The line number were the log message was printed.
	 **/
	int mLineNumber;

	/** The color of the log message.
	 **/
	mtColor mColor;

	/** The color as escape sequence.
	 **/
	std::string mColorEscSeq;

	/** The prefix will only be printed at the beginning of
	 ** a message. This attribute indicates whether we are at the
	 ** the beginning of a new message (immediately after <i>endm</i>)
	 ** and we have to print the prefix with the next output
	 ** statement.
	 **/
	bool mPrintPrefix;

	/** The indent will only be printed at the beginning of a
	 ** new line but not at the beginning of a message. This
	 ** attribute indicates whether we are at the this point
	 ** (immdiately after <i>newl</i>) and we have to print the
	 ** indent with the next output statement.
	 **/
	bool mPrintIndent;

	/** The output can be enabled and disabled. This attributes
	 ** indicates the current status.
	 ** @see Enable
	 **/
	bool mEnabled;

	/** The prefix can be enabled and disabled. This attributes
	 ** indicates the current status.
	 ** @see EnablePefix
	 **/
	bool mPrefixEnabled;

        /** The position output can be enabled and disabled. This attributes
         ** indicates the current status.
         ** @see EnablePosition
         **/
        bool mPositionEnabled;

	/** The colored output can be enabled and disabled. This attribute
	 ** indicates the current status.
	 ** @see EnableColor
	 **/
	bool mColorEnabled;

	// HELPER
	// ------

	/** Create the new color escape sequence, stored in <i>mColorEscSeq</i>,
	 ** from the value <i>mColor</i>. This is neccessary if the color is
	 ** changed via <i>SetColor()</i>.
	 **/
	OC_DSOAPI void ColorToEscSeq();

	/** Print the prefix depending on the <i>endl</i> manipulator. If the
	 ** last output command was the <i>endl</i> manipulator the flag
	 ** <i>mPrintPrefix</i> is set to <tt>true</tt> and the prefix must be
	 ** printed first. The flag <i>mPrintPrefix</i> will be reset to
	 ** <tt>false</tt> afterwards.<br>
	 ** Note: It does not check for the flag <i>mEnabled</i>.
	 ** @see mPrintPrefix, mEnabled, IsEnabled, endl
	 **/
	OC_DSOAPI void PrintPrefix();

#ifdef WIN32
	/** Set the text color on Win32 Systems
     ** @author Simon Triebenbacher
	 **/

	OC_DSOAPI void Win32SetTextColor(bool enable);
#endif

    protected:

    public:

	// CONSTRUCTOR / DESTRUCTOR
	// ------------------------

	/** Default constructor uses as output stream <tt>cerr</tt>.
	 **/
	OC_DSOAPI Log();

	/** Constructor with stream for output, prefix and color.
	 **/
	OC_DSOAPI Log( std::ostream       & out,
                         const std::string  & prefix       = std::string(""),
                         mtColor              color        = Log::GREEN,
                         bool                 enablePrefix = false );

	/** Copy constructor.
	 **/
	OC_DSOAPI Log( const Log & log );

	/** Destructor.
	 **/
	OC_DSOAPI ~Log();

	// MODIFIER
	// --------

	/** Enable or disable the output stream.
	 ** @param enable Set it <tt>true</tt> to enable message output,
         **               <tt>false</tt> to disable it.
         **               <i>default:</i> <tt>true</tt>
	 **/
	OC_DSOAPI void Enable( bool enable );

	/** Checks whether the stream is enabled or disabled.
	 ** @return <tt>true</tt> if the stream is enabled,
	 **         <tt>false</tt> otherwise.
	 **/
	OC_DSOAPI bool IsEnabled() const;

	/** Enable or disable the prefix.
	 ** @param enable Set it <tt>true</tt> to enable prefix output
         **               <tt>false</tt> to disable it.
         **               <i>default:</i> <tt>true</tt>
	 **/
	OC_DSOAPI void EnablePrefix( bool enable );

	/** Checks whether the prefix is enabled or disabled.
	 ** @return <tt>true</tt> if the prefix is enabled,
	 **         <tt>false</tt> otherwise.
	 **/
	OC_DSOAPI bool IsPrefixEnabled() const;

        /** Enable or disable the position output.
         ** @param enable Set it <tt>true</tt> to enable position output
         **               <tt>false</tt> to disable it.
         **               <i>default:</i> <tt>true</tt>
         **/
        OC_DSOAPI void EnablePosition( bool enable );

        /** Checks whether the position is enabled or disabled.
         ** @return <tt>true</tt> if the position is enabled,
         **         <tt>false</tt> otherwise.
         **/
        OC_DSOAPI bool IsPositionEnabled() const;

        /** Enable or disable colored output.
         ** @param enable Set it <tt>true</tt> to enable colored output
         **               <tt>false</tt> to disable it.
         **               <i>default:</i> <tt>true</tt>
         **/
        OC_DSOAPI void EnableColor( bool enable );

        /** Checks whether the colored output is enabled or disabled.
         ** @return <tt>true</tt> if the colored output is enabled,
         **         <tt>false</tt> otherwise.
         **/
        OC_DSOAPI bool IsColorEnabled() const;

	

	// SETTER / GETTER
	// ---------------

	/** Set the 'position' of the log message ouput
	 ** by file name and line number were the message
	 ** was printed.
	 ** @param fileName   The name of the file, usually <tt>__FILE__</tt>
	 ** @param lineNumber The line in the file, usually <tt>__LINE__</tt>
	 ** @return <tt>false</tt> if <i>fileName</i> is <tt>NULL</tt> pointer
	 **         or <i>lineNumber</i> is not positive,
                    <tt>true</tt> on success.
	 **/
	OC_DSOAPI bool SetMessagePos( const char * fileName, int lineNumber );

	/** Set the color for the log message.
	 ** @param color The message color.
	 **/
	OC_DSOAPI void SetColor( mtColor color );

	/** Get the color for the log message.
	 ** @return The message color.
	 **/
	OC_DSOAPI mtColor GetColor() const;

	/** Set the prefix string which shall appear at the beginning of
	 ** each new message line.
	 ** @param prefix The prefix string.
	 **/
	OC_DSOAPI void SetPrefix( const std::string & prefix );

	/** Get the prefix string.
	 ** @return The prefix string.
	 **/
	OC_DSOAPI const std::string & GetPrefix() const;

	// OPERATORS
	// ---------

	/** The operator for manipulators. We need this kind of operator
	 ** in order that the friend functions like <i>endl</i> can work
	 ** as manipulators on this stream.
	 ** <p>
	 ** <b>Literature:</b>
	 ** Nicolai M. Josuttis,
	 ** <i>"The C++ Standard Library, A Tutorial and Reference"</i>
	 ** page 612 ff, Addision-Wesley, 2000
	 ** </p>
	 ** @see endl
	 **/
	OC_DSOAPI Log & operator<<( Log & (*manip)( Log & ) );

	/** Print a class type value.
	 ** @param value The value to print.
	 ** @return The stream instance on which the value was printed.
	 **/
	template<class T>
	Log & operator<<( const T & value )
	{
	    if( IsEnabled() ) {
		PrintPrefix();
		if( IsColorEnabled() ) {
		    mOut << oc::Term::EscSeq::msNormal << value;
		}
		else {
		    mOut << value;
		}
	    }
	    return( *this );
	}

	// FRIENDS
	// -------

	// Manipulator 'endm'
	friend OC_DSOAPI Log & endm( Log & log );

	// Manipulator 'newl'
	friend OC_DSOAPI Log & newl( Log & log );

	// Manipulator 'flush'
	friend OC_DSOAPI Log & flush( Log & log );

    }; // class Log

    // MANIPULATORS
    // ============

    /** The new line manipulator starts a new line and flushs the
     ** output stream. With the next message output the defined prefix
     ** will be printed first.
     ** @param log The stream instance to manipulate.
     ** @return The manipulated stream instance.
     ** @see operator<<
     **/
    OC_DSOAPI Log & endm( Log & log );

    /** The new tab manipulator starts a new line and flushs the
     ** output stream. With the next message output instead of the
     ** prefix the message will be indented by the prefix with.
     ** @param log The stream instance to manipulate.
     ** @return The manipulated stream instance.
     ** @see operator<<
     **/
    OC_DSOAPI Log & newl( Log & log );


    /** This will flush the output stream. All buffered data will be
     ** written.
     ** @param log The stream instance to manipulate.
     ** @return The manipulated stream instance.
     **/
    OC_DSOAPI Log & flush( Log & log );




    // CLASS LogG
    // ==========


    /** This class contains predefined Log streams with different
     ** priorities. To access this streams use the static method of this
     ** class.
     **
     ** \b Predefined \b Log \b Streams:
     **
     ** - \b Fatal Print fatal messages.
     **
     ** - \b Error Print error messages.
     **
     ** - \b Warn Print warnings.
     **
     ** - \b Info Print messages to inform the user.
     **
     ** - \b Debug Print debug messages for the developer.
     **
     ** You can use the macros OCFATAL, etc. and OCFATALCONT, etc. to print
     ** on this streams.
     **/
    class LogG
    {

    private:

	/** No default constructor allowed.
	 **/
	LogG();

    public:

	/** Copy constructor can't be used because no instance of the class can
	 ** be created.
	 **/
	LogG( const LogG & source );

	/** Destructor can't be used because all constructors of the class are
	 ** private.
	 **/
	~LogG();

	/** Returns the fatal log stream.
	 **/
	OC_DSOAPI static Log & Fatal();

	/** Returns the error log stream.
	 **/
	OC_DSOAPI static Log & Error();

	/** Returns the warn log stream.
	 **/
	OC_DSOAPI static Log & Warn();

	/** Returns the info log stream.
	 **/
	OC_DSOAPI static Log & Info();

	/** Returns the debug log stream.
	 **/
	OC_DSOAPI static Log & Debug();


    }; // class LogG


} // namespace oc


// DEFINE
// ======

// For compatible reasons we provide also the old style with 'CGL' as prefix.

// FATAL, ERROR, WARN, INFO, DEBUG macros
// --------------------------------------

// By default print fatal, error and warn messages

#if ! defined(CGLPRINTFATAL) && ! defined(CGLPRINTERROR) && ! defined(CGLPRINTWARN) && ! defined(CGLPRINTINFO) && ! defined(CGLPRINTDEBUG)
# define CGLPRINTDEFAULT
#endif

#ifdef CGLPRINTDEFAULT
# define CGLPRINTFATAL
# define CGLPRINTERROR
# define CGLPRINTWARN
# define CGLPRINTINFO
#endif

#ifdef CGLPRINTALL
# define CGLPRINTFATAL
# define CGLPRINTERROR
# define CGLPRINTWARN
# define CGLPRINTINFO
# define CGLPRINTDEBUG
#endif

// Alias to the macros
#define CGL_FATAL        CGLFATAL
#define CGL_FATAL_CONT   CGLFATALCONT
#define CGL_FATAL_ENABLE CGLFATALENABLE

#define CGL_ERROR        CGLERROR
#define CGL_ERROR_CONT   CGLERRORCONT
#define CGL_ERROR_ENABLE CGLERRORENABLE

#define CGL_WARN        CGLWARN
#define CGL_WARN_CONT   CGLWARNCONT
#define CGL_WARN_ENABLE CGLWARNENABLE

#define CGL_INFO        CGLINFO
#define CGL_INFO_CONT   CGLINFOCONT
#define CGL_INFO_ENABLE CGLINFOENABLE

#define CGL_DEBUG        CGLDEBUG
#define CGL_DEBUG_CONT   CGLDEBUGCONT
#define CGL_DEBUG_ENABLE CGLDEBUGENABLE

// FATAL macros
#ifdef CGLPRINTFATAL
# ifdef CGLFATALCONT
#  error "[cgl/Log.hh] CGLFATAL_CONT already defined."
# else
#  define CGLFATALCONT(msg) { cgl::LogG::Fatal().SetMessagePos( __FILE__, __LINE__ ); \
                                    cgl::LogG::Fatal() << msg; }
# endif

# ifdef CGLFATAL
#  error "[cgl/Log.hh] CGLFATAL already defined."
# else
#  define CGLFATAL(msg) CGLFATALCONT(msg << cgl::endm)
# endif

# ifdef CGLFATALENABLE
#  error "[cgl/Log.hh] CGLFATALENABLE already defined."
# else
#  define CGLFATALENABLE(state) cgl::LogG::Fatal().Enable(state);
# endif
#else
# define CGLFATAL(msg)
# define CGLFATALCONT(msg)
# define CGLFATALENABLE(state)
#endif


// ERROR macros
#ifdef CGLPRINTERROR
# ifdef CGLERRORCONT
#  error "[cgl/Log.hh] CGLERROR_CONT already defined."
# else
#  define CGLERRORCONT(msg) { cgl::LogG::Error().SetMessagePos( __FILE__, __LINE__ ); \
                                    cgl::LogG::Error() << msg; }
# endif

# ifdef CGLERROR
#  error "[cgl/Log.hh] CGLERROR already defined."
# else 
#  define CGLERROR(msg) CGLERRORCONT(msg << cgl::endm)
# endif

# ifdef CGLERRORENABLE
#  error "[cgl/Log.hh] CGLERRORENABLE already defined."
# else
#  define CGLERRORENABLE(state) cgl::LogG::Error().Enable(state);
# endif
#else
# define CGLERROR(msg)
# define CGLERRORCONT(msg)
# define CGLERRORENABLE(state)
#endif


// WARN macros
#ifdef CGLPRINTWARN
    #ifdef CGLWARNCONT
        #error "[cgl/Log.hh] CGLWARN_CONT already defined."
    #else
        #define CGLWARNCONT(msg) { cgl::LogG::Warn().SetMessagePos( __FILE__, __LINE__ ); \
                                   cgl::LogG::Warn() << msg; }
    #endif

    #ifdef CGLWARN
        #error "[cgl/Log.hh] CGLWARN already defined."
    #else 
        #define CGLWARN(msg) CGLWARNCONT(msg << cgl::endm)
    #endif

    #ifdef CGLWARNENABLE
        #error "[cgl/Log.hh] CGLWARNENABLE already defined."
    #else
        #define CGLWARNENABLE(state) cgl::LogG::Warn().Enable(state);
    #endif
#else
    #define CGLWARN(msg)
    #define CGLWARNCONT(msg)
    #define CGLWARNENABLE(state)
#endif


// INFO macros
#ifdef CGLPRINTINFO
# ifdef CGLINFOCONT
#  error "[cgl/Log.hh] CGLINFOCONT already defined."
# else
#  define CGLINFOCONT(msg) { cgl::LogG::Info().SetMessagePos( __FILE__, __LINE__ ); \
                                   cgl::LogG::Info() << msg; }
# endif

# ifdef CGLINFO
#  error "[cgl/Log.hh] CGLINFO already defined."
# else 
#  define CGLINFO(msg) CGLINFOCONT(msg << cgl::endm)
# endif

# ifdef CGLINFOENABLE
#  error "[cgl/Log.hh] CGLINFOENABLE already defined."
# else
#  define CGLINFOENABLE(state) cgl::LogG::Info().Enable(state);
# endif
#else
# define CGLINFO(msg)
# define CGLINFOCONT(msg)
# define CGLINFOENABLE(state)
#endif


// DEBUG macros
#ifdef CGLPRINTDEBUG
# ifdef CGLDEBUG_CONT
#  error "[cgl/Log.hh] CGLDEBUG_CONT already defined."
# else
#  define CGLDEBUGCONT(msg) { cgl::LogG::Debug().SetMessagePos( __FILE__, __LINE__ ); \
                                    cgl::LogG::Debug() << msg; }
# endif

# ifdef CGLDEBUG
#  error "[cgl/Log.hh] CGLDEBUG already defined."
# else 
#  define CGLDEBUG(msg) CGLDEBUGCONT(msg << cgl::endm);
# endif

# ifdef CGLDEBUGENABLE
#  error "[cgl/Log.hh] CGLDEBUGENABLE already defined."
# else
#  define CGLDEBUGENABLE(state) cgl::LogG::Debug().Enable(state);
# endif
#else
# define CGLDEBUG(msg)
# define CGLDEBUGCONT(msg)
# define CGLDEBUGENABLE(state)
#endif




// FATAL, ERROR, WARN, INFO, DEBUG macros
// --------------------------------------

// By default print fatal, error and warn messages

#if ! defined(OCPRINTFATAL) && ! defined(OCPRINTERROR) && ! defined(OCPRINTWARN) && ! defined(OCPRINTINFO) && ! defined(OCPRINTDEBUG)
# define OCPRINTDEFAULT
#endif

#ifdef OCPRINTDEFAULT
# define OCPRINTFATAL
# define OCPRINTERROR
# define OCPRINTWARN
# define OCPRINTINFO
#endif

#ifdef OCPRINTALL
# define OCPRINTFATAL
# define OCPRINTERROR
# define OCPRINTWARN
# define OCPRINTINFO
# define OCPRINTDEBUG
#endif

// Alias to the macros
#define OC_FATAL        OCFATAL
#define OC_FATAL_CONT   OCFATALCONT
#define OC_FATAL_ENABLE OCFATALENABLE

#define OC_ERROR        OCERROR
#define OC_ERROR_CONT   OCERRORCONT
#define OC_ERROR_ENABLE OCERRORENABLE

#define OC_WARN        OCWARN
#define OC_WARN_CONT   OCWARNCONT
#define OC_WARN_ENABLE OCWARNENABLE

#define OC_INFO        OCINFO
#define OC_INFO_CONT   OCINFOCONT
#define OC_INFO_ENABLE OCINFOENABLE

#define OC_DEBUG        OCDEBUG
#define OC_DEBUG_CONT   OCDEBUGCONT
#define OC_DEBUG_ENABLE OCDEBUGENABLE

// FATAL macros
#ifdef OCPRINTFATAL
# ifdef OCFATALCONT
#  error "[oc/Log.hh] OCFATAL_CONT already defined."
# else
#  define OCFATALCONT(msg) { oc::LogG::Fatal().SetMessagePos( __FILE__, __LINE__ ); \
                                    oc::LogG::Fatal() << msg; }
# endif

# ifdef OCFATAL
#  error "[oc/Log.hh] OCFATAL already defined."
# else
#  define OCFATAL(msg) OCFATALCONT(msg << oc::endm)
# endif

# ifdef OCFATALENABLE
#  error "[oc/Log.hh] OCFATALENABLE already defined."
# else
#  define OCFATALENABLE(state) oc::LogG::Fatal().Enable(state);
# endif
#else
# define OCFATAL(msg)
# define OCFATALCONT(msg)
# define OCFATALENABLE(state)
#endif


// ERROR macros
#ifdef OCPRINTERROR
# ifdef OCERRORCONT
#  error "[oc/Log.hh] OCERROR_CONT already defined."
# else
#  define OCERRORCONT(msg) { oc::LogG::Error().SetMessagePos( __FILE__, __LINE__ ); \
                                    oc::LogG::Error() << msg; }
# endif

#ifdef OCERROR
# error "[oc/Log.hh] OCERROR already defined."
#else 
# define OCERROR(msg) OCERRORCONT(msg << oc::endm)
#endif

#ifdef OCERRORENABLE
# error "[oc/Log.hh] OCERRORENABLE already defined."
#else
# define OCERRORENABLE(state) oc::LogG::Error().Enable(state);
# endif
#else
# define OCERROR(msg)
# define OCERRORCONT(msg)
# define OCERRORENABLE(state)
#endif


// WARN macros
#ifdef OCPRINTWARN
# ifdef OCWARNCONT
#  error "[oc/Log.hh] OCWARN_CONT already defined."
# else
#  define OCWARNCONT(msg) { oc::LogG::Warn().SetMessagePos( __FILE__, __LINE__ ); \
                                   oc::LogG::Warn() << msg; }
# endif

# ifdef OCWARN
#  error "[oc/Log.hh] OCWARN already defined."
# else 
#  define OCWARN(msg) OCWARNCONT(msg << oc::endm)
# endif

# ifdef OCWARNENABLE
#  error "[oc/Log.hh] OCWARNENABLE already defined."
# else
#  define OCWARNENABLE(state) oc::LogG::Warn().Enable(state);
# endif
#else
# define OCWARN(msg)
# define OCWARNCONT(msg)
# define OCWARNENABLE(state)
#endif


// INFO macros
#ifdef OCPRINTINFO
# ifdef OCINFOCONT
#  error "[oc/Log.hh] OCINFOCONT already defined."
# else
#  define OCINFOCONT(msg) { oc::LogG::Info().SetMessagePos( __FILE__, __LINE__ ); \
                                   oc::LogG::Info() << msg; }
# endif

# ifdef OCINFO
#  error "[oc/Log.hh] OCINFO already defined."
# else 
#  define OCINFO(msg) OCINFOCONT(msg << oc::endm)
# endif

# ifdef OCINFOENABLE
#  error "[oc/Log.hh] OCINFOENABLE already defined."
# else
#  define OCINFOENABLE(state) oc::LogG::Info().Enable(state);
# endif
#else
# define OCINFO(msg)
# define OCINFOCONT(msg)
# define OCINFOENABLE(state)
#endif


// DEBUG macros
#ifdef OCPRINTDEBUG
# ifdef OCDEBUG_CONT
#  error "[oc/Log.hh] OCDEBUG_CONT already defined."
# else
#  define OCDEBUGCONT(msg) { oc::LogG::Debug().SetMessagePos( __FILE__, __LINE__ ); \
                                    oc::LogG::Debug() << msg; }
# endif

# ifdef OCDEBUG
#  error "[oc/Log.hh] OCDEBUG already defined."
# else 
#  define OCDEBUG(msg) OCDEBUGCONT(msg << oc::endm);
# endif

# ifdef OCDEBUGENABLE
#  error "[oc/Log.hh] OCDEBUGENABLE already defined."
# else
#  define OCDEBUGENABLE(state) oc::LogG::Debug().Enable(state);
# endif
#else
# define OCDEBUG(msg)
# define OCDEBUGCONT(msg)
# define OCDEBUGENABLE(state)
#endif


#endif
