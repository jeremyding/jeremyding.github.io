
#ifndef OC_XMLOBJECT_HH
#define OC_XMLOBJECT_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN includes 

#include <oc/AdvXMLParser.h>
#include <oc/File.hh>

// C++ includes

#include <iostream>
#include <sstream>


namespace oc
{

    /** XML-Object to load/save/query and create xml-files based on AdvXMLParser by Sebastien Andrivet.
     **
     ** <h3> create new xml object with root tag named "root" and save it </h3>
     ** <pre>
     **   // create new xml object with root tag named "root"
     **   oc::XMLObject xml("root");
     **
     **   AdvXMLParser::Element& root = xml.GetRoot(); 
     **   AdvXMLParser::Element& group = root("group");
     **   root("group")("element", 0) << "null";
     **   root("group")("element", 1) << "eins";
     **   root("group")("element", 2) << "zwei";
     **   root("group")("element", 3) << "drei";
     **   root("else") << "s.th.";
     **   root("group")("element", 0)["attrib"] << "a";
     **   root("group")("element", 1)["attrib"] << "b";
     **   xml.Save( oc::File("test.xml") );
     ** </pre>
     **
     ** Output:
     ** <pre>
     **   &lt;?xml version="1.0" encoding="iso-8859-1"?&gt;
     **   &lt;root&gt;
     **     &lt;group&gt;
     **       &lt;element attrib="a"&gt;null&lt;/element&gt;
     **       &lt;element attrib="b"&gt;eins&lt;/element&gt;
     **       &lt;element&gt;zwei&lt;/element&gt;
     **       &lt;element&gt;drei&lt;/element&gt;
     **     &lt;/group&gt;
     **     &lt;else&gt;s.th.&lt;/else&gt;
     **   &lt;/root&gt;
     ** </pre>
     **
     ** <h3> load xml file  </h3>
     **  <pre>
     **    // load file
     **    oc::XMLObject x2;
     **    x2.Load(oc::File("test.xml"));
     **    // std::cout << x2 << std::endl;
     **  </pre>
     **
     **  <h3> access the value of a specific tag </h3>
     **  <pre>
     **    // access value of element 2 in group and of non-existing element 4
     **    if( !x2.GetRoot().GetElement("group").IsNull() ) { 
     **        if( !x2.GetRoot()("group").GetElement("element",2).IsNull() ) {
     **            std::cout << x2.GetRoot()("group")("element",2).GetValue() << std::endl;
     **        }
     **        if( !x2.GetRoot()("group").GetElement("element",4).IsNull() ) {
     **            std::cout << x2.GetRoot()("group")("element",4).GetValue() << std::endl;
     **        }
     **    }
     **  </pre>
     **  
     ** Output:
     **  <pre>
     **  &gt; zwei
     **  </pre>
     **
     **
     **
     ** <h3> access value of an element at root-level</h3>
     **
     ** <pre>
     ** std::string val;
     ** x2.GetRootValue("else",val);
     ** std::cout << val << std::endl;
     ** </pre>
     ** Output:
     **  <pre>
     **  &gt; s.th.
     **  </pre>
     **
     **  <h3> enumerate elements and attributes </h3>
     **  <pre>
     **    // enumerate all element in root-tag
     **    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Element>   elemit_const;
     **    typedef AdvXMLParser::ConstIterator<AdvXMLParser::Attribute> attribit_const;
     **	   AdvXMLParser::Element& x2root  = x2.GetRoot();
     **
     **    elemit_const it  = x2root.Begin();
     **    elemit_const eit = x2root.End();
     **    for( ; it!=eit; ++it) {
     **        std::cout << it->GetName() << ":" << std::endl;
     **        std::cout << "\t";
     **        if( it->GetName() == "group" ) {
     **            elemit_const git  = it->Begin();
     **            elemit_const geit = it->End();
     **            for( ; git!=geit; ++git ) {
     **                std::cout << git->GetValue() << '[';
     **                attribit_const ait  = git->AttributesBegin();
     **                attribit_const aeit = git->AttributesEnd();
     **                for( ; ait!=aeit; ++ait ) {
     **                    std::cout << ait->GetName() << '=' << ait->GetValue();
     **                }
     **                std::cout << ']';
     **            }
     **            std::cout << std::endl;
     **        }
     **        else {
     **            std::cout << it->GetValue() << std::endl;
     **        }
     **    }
     **  </pre>
     ** Output:
     **  <pre>
     **  group:
     **      null[attrib=a]eins[attrib=b]zwei[]drei[]
     **  else:
     **      s.th.
     **  </pre>
     **
     **  <h3> create xml-object from string </h3>
     **  <pre>
     **   oc::XMLObject test("root","<range><start>0</start><end>1</end><step>0.1</step></range>");
     **   std::cout << test << std::endl;
     **
     **   std::cout << test.GetRoot().GetName() << std::endl;
     **   if( !test.GetRoot().GetElement("start").IsNull() ) {
     **       std::cout << test.GetRoot().GetElement("start").GetValue() << std::endl;
     **   }
     **   if( !test.GetRoot().GetElement("end").IsNull() ) {
     **       std::cout << test.GetRoot().GetElement("end").GetValue() << std::endl;
     **   }
     **   if( !test.GetRoot().GetElement("step").IsNull() ) {
     **       std::cout << test.GetRoot().GetElement("step").GetValue() << std::endl;
     **   }
     **  </pre>
     **
     **	\author	Horst Hadler
     ** \see	AdvXMLParser 1.1.4c by Sebastien Andrivet (AdvXMLParser.h)
     ** \nosubgrouping
     **/
    class OC_DSOAPI XMLObject  
    {
    private:
        /** pointer to AdvXMLParser::Document.
         ** http://www.garshol.priv.no/download/xmltools/prod/SmallXMLParser.html
         **/
        AdvXMLParser::Document* mDocument;

        /** test tags case sensitive.
         **/
        bool mCaseSensitive;

    private:

        /// hidden copy ctor.
        XMLObject( XMLObject const& obj);

    public:

	/** \name Constructors / Destructors 
	 ** \{
	 **/
    
        /** Default ctor.
         ** \param case_sensitive by default all tags (NOT values) are converted to lowercase;
         **        turn this on to match tags casesensitive.
         **/
        XMLObject( bool case_sensitive=false);

        /** Create xml object. 
         ** \param rootname name of root tag
         ** \param case_sensitive by default all tags (NOT values) are converted to lowercase;
         **        turn this on to match tags casesensitive.
         **/
        XMLObject( const char* rootname, bool case_sensitive=false );


        /** Create xml object; content given by string.
         ** \param rootname name of root tag (ignored!)
         ** \param content xml content
         ** \param case_sensitive by default all tags (NOT values) are converted to lowercase;
         **        turn this on to match tags casesensitive.
         **/
        XMLObject( const char* rootname, const char* content, bool case_sensitive=false );


        /** Dtor
         **/
        virtual ~XMLObject();

        /** /}
         **/

	/** \name Load / Save 
	 ** \{
	 **/
 
        /** Load xml file 
         ** \param file file
         ** \return false on error
         **/
        bool Load( const oc::File& file);

        /** Save xml file
         ** \param file file
         ** \return false on error
         **/
        bool Save( const oc::File& file);

        /** /}
         **/

	/** \name Getters 
	 ** \{
	 **/

        /** Get the root element of the XML-object (read-only)
         ** \return const root-element 
         **/
        const AdvXMLParser::Element& GetRoot() const;

        /** Get the root element of the XML-object
         ** \return root-element 
         **/
        AdvXMLParser::Element& GetRoot();


        /** Get the value of boolean type tag ('true'|'false')at root-level.
         ** \param tag [IN] name of tag
         ** \param value [OUT] tag value
         ** \return true if value exists and could be parsed
         **/
        bool GetRootValue(const std::string& tag, bool& value) const;

        /** Get the value of a tag at root-level and interpret it as type T.
         ** \param tag [IN] name of tag
         ** \param value [OUT] tag value
         ** \return true if value exists and could be parsed
         **/
        template <class T>
        bool GetRootValue(std::string const& tag, T& value ) const
        {
            if( mDocument == NULL ) {
                return false;
            }

            const AdvXMLParser::Element& root = GetRoot();
            if( root.IsNull() || root.IsEmpty() ) {
                return false;
            }
            const AdvXMLParser::Element& thetag = root(tag.c_str());
            if( thetag.IsNull() || thetag.IsEmpty() ) {
                return false;
            }
            std::stringstream sstrm(thetag.GetValue().c_str());
            sstrm >> value;
            return true;

        }

        /** /}
         **/

	/** \name Stream dump
	 ** \{
	 **/
        /// Output operator (friend)
        OC_DSOAPI friend std::ostream& operator<<(std::ostream& out, const XMLObject& xmlobj);

        /** /}
         **/

    }; // XMLObject

} // namespace oc


#endif

