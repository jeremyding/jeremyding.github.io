
#ifndef OC_PROPERTYMAP_RESOURCE_HANDLER_HH
#define OC_PROPERTYMAP_RESOURCE_HANDLER_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/File.hh>
#include <oc/PropertyMap.hh>
#include <oc/XMLObject.hh>

// C include

#include <cassert>

// C++ include

#include <string>



namespace oc
{

    /** Load, validate and assign PropertyResource elements.
     **
     ** \author Horst Hadler
     ** \date 9.10.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI PropertyMapResourceHandler
    {
    private:

        /** Helper: parse single rule
         **/
        bool ParseRule(AdvXMLParser::Element const& xml, oc::PropertyResourceRule& rule);



        /** Helper: add layout section
         **/
        bool AddResourcesLayout( AdvXMLParser::Element const& layout, 
                                 PropertyMap& map);

        /** Helper: add rules section
         **/
        bool AddResourcesRules( AdvXMLParser::Element const& rules, 
                                PropertyMap& map);

        /** Helper: set defaults resourcestate's from rules section
         **/
        bool AddResourcesDefaults( AdvXMLParser::Element const& rules, 
                                   PropertyMap& map);
    public:

        /** Load xml resource file. 
         ** \param file [IN] file
         ** \param obj  [OUT] xml object
         ** \return false on error
         **/
        bool LoadXMLResource( const File & file, XMLObject& obj );

        /** Assign resources to properties.
         ** \param obj [IN]  xml object
         ** \param map [OUT] propertymap with resources set
         ** \return false on error
         **/
        bool Assign( XMLObject const& obj, PropertyMap& map ); 


        /** Load xml resources from file and assign them to the propertymap.
         **/
        static bool LoadAndAssign( const File& file, PropertyMap& map );
     
    }; // class PropertyMapResourceHandler


} // namespace oc


#endif


