
#ifndef OC_PROPERTY_RESOURCE_HH
#define OC_PROPERTY_RESOURCE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN includes

#include <oc/config.h>

// C++ includes

#include <algorithm>
#include <cassert>
#include <string>
#include <vector>


namespace oc
{

    /** Resources of a Property: description, values, state, etc..
     **
     ** \author Horst Hadler
     ** \date 9.10.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI PropertyResource 
    {

	/** \name Private Attributes
	 ** \{
	 **/

    private:
    
        /** Name of the resource
         **/
        std::string mName;

    public:

        /** a single state
         **/
        typedef struct {
            std::string name;
            std::string value;
            bool        changed;
        } tState;

    private:

        /** states
         **/
        std::vector< tState > mState;

	/** \}
	 **/

	/** \name Helper 
	 ** \{
	 **/

    private:

        /** Empty state-tag value.
         **/
        static tState const& GetNullState(); 

	/** \}
	 **/

	/** \name Constructor 
	 ** \{
	 **/

    public:

        /** Create empty resource (undefined).
         **/
        PropertyResource();

	/** \}
	 **/


	/** \name Get/Set Name, Domain and Description
	 ** \{
	 **/

    public:


	/** Set the name of the resource.
	 ** \param n name.
	 **/
        void SetName( std::string const & n );

	/** Get the name of the resource.
	 ** \return name.
	 **/
        std::string const & GetName() const;

        /** Are there values in the resource?
         **/
        bool IsDefined() const;

	/** Set a special state called 'domain' which is xml-string describing the property's domain.
	 ** \param v domain string.
	 **/
	void SetDomain( std::string const & v );

	/** Get the 'domain' state xml-string describing the property's domain.
	 ** \return domain string.
	 **/
	std::string const & GetDomain() const;

        /** Set a special state called 'layout' which is a xml-string describing the property's layout.
         ** \param v value string.
	 **/
	void SetLayout( std::string const & v );

	/** Get the 'layout' state xml-string describing the property's layout.
	 ** \return value string.
	 **/
	std::string const & GetLayout() const;
	/** \}
	 **/

        /** \name Resource State
	 ** \{
	 **/

        /** Does the state \n tag exist?.
         **/
        bool HasState( std::string const& tag) const;

        /** Add (tag,value)-pairs and Set the value of state \n tag.
         ** This automatically calls SetStateChangeFlag !
         **/
        void SetState( std::string const& tag, std::string const& val );

        /** Get the value of state \n tag.
         **/
        std::string const& GetState(std::string const& tag) const;

        /** The state \n tag has changed.
         **/
        void SetStateChangeFlag( std::string const& tag);

        /** Clear state \n tag changed flag i.e. to unchanged.
         **/
        void ClearStateChangeFlag( std::string const& tag );

        /** Clear all state \n tag changed flags.
         **/
        void ClearStateChangedFlags();

        /** Has the state tag \n tag changed?
         **/
        bool HasStateChanged(std::string const& tag ) const;

        /** Has any of the state tags changed?
         **/
        bool HasStateChanged() const;

        /** Get number of state tags.
         **/
        int GetNumState() const;

        /** Get i.th (state-tag,value) pair.
         **/
        tState const &GetState(int i) const;

        /** Print state.
         **/
        std::ostream& DumpState( std::ostream& out);

        /** Serialization -  write resources to stream.
         **/
        std::ostream& Write( std::ostream& out ) const;

        /** Deserialization -  read resources from stream.
         **/
        std::istream& Read( std::istream& in );

	/** \}
	 **/

     
    }; // class PropertyResource


} // namespace oc


#endif
