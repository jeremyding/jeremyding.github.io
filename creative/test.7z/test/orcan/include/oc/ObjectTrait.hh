
#ifndef OC_OBJECT_TRAIT_HH
#define OC_OBJECT_TRAIT_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/GUID.hh>
#include <oc/File.hh>
#include <oc/ObjectFactoryTrait.hh>

// C++ include

#include <string>



namespace oc
{

    /** An object trait descibes the characteristic of an object that can be
     ** created by an object factory which in turn is used by the object broker
     ** to provide objects to the application. The object name \p mObjectName
     ** is the class name (interface) how it is used by the application, the
     ** real name \p mRealizationName is the class name of the actual
     ** implementation of the interface. The object factory from which this
     ** kind of object can be created is specified by \p mObjectFactoryTraitPtr.
     ** A short \p mShortDescription and a long description \p mLongDescription
     ** as well as a vendor string \p mVendor can be attached and queried.
     ** This class is mainly used by the ObjectBroker and ObjectBrokerConfig.
     **
     ** An object trait contains the following information:
     **
     ** \li <b>Object name:</b> VolMesh
     ** \li <b>Realization name:</b> SimpleMesh
     ** \li <b>Resource name:</b> config/mod_simpleMesh.xml
     ** \li <b>GUID:</b> acf70825-c1dc-4948-a918-9a2f98faf512
     ** \li <b>Object factory name:</b> C:\\Program Files\\CrysVUn3D\\Modules
     ** \li <b>Object factory link:</b> Use it to create the object factory
     ** \li <b>Short description:</b> A Simple Mesh Implementation.
     ** \li <b>Long description:</b> This volumetric mesh class implements all
     **       defined interfaces but the performance is may be not optimized.
     **
     ** <table>
     **   <tr><td><b>Name</b></td>
     **       <td><b>Description</b></td>
     **       <td><b>Example</b></td>
     **   </tr>
     **   <tr><td>Object Name</td>
     **       <td>Name of the component object</td>
     **       <td>VolMesh</td>
     **   </tr>
     **   <tr><td>Realization Name</td>
     **       <td>Name of the actual realization</td>
     **       <td>SimpleMesh</td>
     **   </tr>
     **   <tr><td>Resource File</td>
     **       <td>The resource file</td>
     **       <td>config/mod_simplemesh.xml</td>
     **   </tr>
     **   <tr><td>GUID</td>
     **       <td>global unique identification</td>
     **       <td>acf70825-c1dc-4948-a918-9a2f98faf512</td>
     **   </tr>
     **   <tr><td>Object Factory Name</td>
     **       <td>Name of the object factory which provides this object</td>
     **       <td>C:\\Program Files\\CrysVUn3D\\Modules</td>
     **   </tr>
     **   <tr><td>Object Factory Trait</td>
     **       <td></td>
     **       <td></td>
     **   </tr>
     **   <tr><td></td>
     **       <td></td>
     **       <td></td>
     **   </tr>
     ** </table>
     **
     ** \author Michael Kellner
     ** \date 28.10.2003
     **
     ** \nosubgrouping
     **/
    class ObjectTrait
    {

	/** \name Class Types
	 ** \{
	 **/

    public:

	/** The descriptive part of an object.
	 **
	 ** \author Michael Kellner
	 ** \date 28.10.2003
	 **
	 ** \nosubgrouping
	 **/
	class Desc
	{

	    /** \name Attribute
	     ** \{
	     **/

	public:

	    /** The name of the component, for example \e VolMesh.
	     **/
	    std::string mComponentName;

	    /** The name of the actual realization of the component, for example
	     ** \e SimpleVolMesh.
	     **/
	    std::string mRealizationName;

	    /** The resource file, for example \e mod_simplevolmesh.xml.
	     **/
	    oc::File mResourceFile;

	    /** A short description of the object.
	     **/
	    std::string mShortDescription;

	    /** A long description of the object.
	     **/
	    std::string mLongDescription;

	    /** The vendor string of the object.
	     **/
	    std::string mVendor;

	    /** \}
	     **/

	    /** \name Constructors / Destructor
	     ** \{
	     **/

	public:

	    /** Default constructor
	     **/
	    Desc()
		: mComponentName(),
		  mRealizationName(),
		  mResourceFile(),
		  mShortDescription(),
		  mLongDescription(),
		  mVendor()
	    {}

	    /** Copy constructor
	     **/
	    Desc( const Desc & source )
		: mComponentName   ( source.mComponentName    ),
		  mRealizationName ( source.mRealizationName  ),
		  mResourceFile    ( source.mResourceFile     ),
		  mShortDescription( source.mShortDescription ),
		  mLongDescription ( source.mLongDescription  ),
		  mVendor          ( source.mVendor           )
	    {}

	    /** Destructor
	     **/

	    ~Desc()
	    {}

	    /** \}
	     **/

	    /** \name Operators
	     ** \{
	     **/

	    /** Assignment operator
	     **/
	    Desc & operator=( const Desc & rhs )
	    {
		mComponentName    = rhs.mComponentName;
		mRealizationName  = rhs.mRealizationName;
		mResourceFile     = rhs.mResourceFile;
		mShortDescription = rhs.mShortDescription;
		mLongDescription  = rhs.mLongDescription;
		mVendor           = rhs.mVendor;
                return *this;
	    }

	    /** \}
	     **/


	};


	/** \}
	 **/

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The description of the object.
	 **/
	Desc mDesc;

	/** The global unique identifier of this object trait. A new GUID will
	 ** be generated if no one is given by the user.
	 **/
	oc::GUID mGUID;

	/** The object factory specification for instantiation of an object
	 ** of this kind.
	 **/
	oc::ObjectFactoryTraitPtr mObjectFactoryTraitPtr;

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor
	 **/
	ObjectTrait()
	    : mDesc(),
	      mGUID( oc::GUID::Generate() ),
	      mObjectFactoryTraitPtr()
	{}

	/** Constructs an object trait with component and realization name.
	 **/
	ObjectTrait( const std::string & componentName,
		     const std::string & realizationName,
		     const oc::GUID  & guid = oc::GUID::Generate() )
	    : mDesc(),
	      mGUID( guid )
	{
	    mDesc.mComponentName   = componentName;
	    mDesc.mRealizationName = realizationName;
	}

	/** Copy constructor
	 **/
	ObjectTrait( const ObjectTrait & source )
	    : mDesc                  ( source.mDesc                  ),
	      mGUID                  ( source.mGUID                  ),
	      mObjectFactoryTraitPtr ( source.mObjectFactoryTraitPtr )
	      
	{
	    // We have to make a real copy of the object factory trait
	    if( ! mObjectFactoryTraitPtr.IsNull() ) {
		mObjectFactoryTraitPtr = mObjectFactoryTraitPtr->Clone();
	    }
	}

	/** Destructor
	 **/
	~ObjectTrait()
	{}

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** Assignment operator.
	 **/
	ObjectTrait & operator=( const ObjectTrait & rhs )
	{

	    mDesc = rhs.mDesc;

	    mGUID = rhs.mGUID;

	    mObjectFactoryTraitPtr.Delete();

	    if( rhs.mObjectFactoryTraitPtr.IsNull() ) {
		mObjectFactoryTraitPtr = rhs.mObjectFactoryTraitPtr;
	    }
	    else {
		mObjectFactoryTraitPtr = rhs.mObjectFactoryTraitPtr->Clone();
	    }

	    return *this;
	}

	/** \}
	 **/


	/** \name Setter / Getter
	 ** \{
	 **/

    public:

	/** Set the component name.
	 **/
	void SetComponentName( const std::string & componentName )
	{
	    mDesc.mComponentName = componentName;
	}

	/** Get the component name.
	 **/
	const std::string & GetComponentName() const
	{
	    return mDesc.mComponentName;
	}

	/** Set the realization name.
	 **/
	void SetRealizationName( const std::string & realizationName )
	{
	    mDesc.mRealizationName = realizationName;
	}

	/** Get the realization name.
	 **/
	const std::string & GetRealizationName() const
	{
	    return mDesc.mRealizationName;
	}

	/** Set the resource file.
	 **/
	void SetResource( const oc::File & resourceFile )
	{
	    mDesc.mResourceFile = resourceFile;
	}

	/** Get the resource file.
	 **/
	const oc::File & GetResource() const
	{
	    return mDesc.mResourceFile;
	}

	/** Set the GUID.
	 **/
	void SetGUID( const oc::GUID & guid )
	{
	    mGUID = guid;
	}

	/** Get the GUID.
	 **/
	const oc::GUID & GetGUID() const
	{
	    return mGUID;
	}

	/** Set the object factory trait.
	 **/
	void SetObjectFactoryTrait( const oc::ObjectFactoryTrait & objectFactoryTrait )
	{
	    mObjectFactoryTraitPtr.Delete();

	    mObjectFactoryTraitPtr = objectFactoryTrait.Clone();
	}

	/** Get the object factory trait.
	 **/
	const oc::ObjectFactoryTraitPtr & GetObjectFactoryTrait() const
	{
	    return mObjectFactoryTraitPtr;
	}

	/** Set the short description.
	 **/
	void SetShortDescription( const std::string & shortDescription )
	{
	    mDesc.mShortDescription = shortDescription;
	}

	/** Get the short description.
	 **/
	const std::string & GetShortDescription() const
	{
	    return mDesc.mShortDescription;
	}

	/** Set the long description.
	 **/
	void SetLongDescription( const std::string & longDescription )
	{
	    mDesc.mLongDescription = longDescription;
	}

	/** Get the long description.
	 **/
	const std::string & GetLongDescription() const
	{
	    return mDesc.mLongDescription;
	}

	/** Set the vendor string.
	 **/
	void SetVendor( const std::string & vendor )
	{
	    mDesc.mVendor = vendor;
	}

	/** Get the vendor string.
	 **/
	const std::string & GetVendor() const
	{
	    return mDesc.mVendor;
	}


	/** \}
	 **/


    }; // class ObjectTrait


    /** Equality operator. Two object traits are equal if they have the same
     ** object names, the same realization names and the same object factory
     ** trait name.
     **/
    inline bool operator==( const oc::ObjectTrait & lhs, const oc::ObjectTrait & rhs )
    {
        return( ( lhs.GetComponentName()                == rhs.GetComponentName()                  ) &&
                ( lhs.GetRealizationName()              == rhs.GetRealizationName()                ) &&
                ( lhs.GetObjectFactoryTrait()->GetName() == rhs.GetObjectFactoryTrait()->GetName() ) );
    }


    /** Pointer to an object trait.
     **/
    typedef oc::CPtr< oc::ObjectTrait > ObjectTraitPtr;

} // namespace oc


#endif


     
