
#ifndef OC_TIMER_HH
#define OC_TIMER_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE 
// =======

// ORCAN include

#include <oc/config.h>

// System include

#include <time.h>

#ifdef WIN32
# include "windows.h"
#endif



namespace oc {

    /** Timer object. Measure elapsed time.
     **/
    class OC_DSOAPI Timer
    {

    private:
        int mStartCnt;
#ifdef WIN32
        SYSTEMTIME mStart;
        SYSTEMTIME mStop;
#endif

        time_t mStartTime;
        time_t mEndTime;

    protected:
    public:
        /** Create timer.
         **/
        Timer();

        /** Start timer.
         **/
        void Start();

        /** Stop timer.
         **/
        void Stop();

        /** Get time elapsed in nano-seconds.
         **/
        int  GetElapsedNS();

        /** Get time elapsed in milli-seconds.
         **/
        int  GetElapsedMS();

        /** Get time elapsed in seconds.
         **/
        int  GetElapsedS();

        /** Get a the elapsed time printed to a string.
         **/
        std::string GetElapsedTime();

    }; // class Timer

} // namespace oc



#endif

