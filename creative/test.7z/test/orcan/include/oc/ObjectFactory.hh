
#ifndef OC_OBJECT_FACTORY_HH
#define OC_OBJECT_FACTORY_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/config.h>

// C++ include

#include <string>


namespace oc
{

    /** This is the abstract base class for all factories which let one create
     ** and destroy objects to any kind of class. Basically there are two
     ** methods for object handling:
     ** - template method NewObject() creates a new instance of the template
     **   class
     ** - template method DelObject() deletes a previously via NewObject()
     **   created instance.
     **
     ** The user of this class should only use this two template methods for
     ** object creation and deletion.
     * <br><br>
     ** Because of the deficiency of C++ that template methods can't be defined
     ** \c virtual there are additional pure virtual methods (no template)
     ** NewObjectV() and DelObjectV() which take a class name as parameter to
     ** handle object creation and deletetion. This two methods will be called
     ** from the template methods and must be overriden by the derived class.
     ** <br><br>
     ** Due to the deficiency of C++ that no runtime type information of a
     ** class can be queried without any downsides, in this case here the class
     ** name as string without additional namemangling characters, the user must
     ** also provide the class name as parameter to the template methods
     **
     ** All instances allocated by the object factory must be deleted by the
     ** object factory before the factory get destroyed. Otherwise the
     ** application may become unstable.
     **
     ** \b Design \b Pattern: Factory Method
     **
     ** E. Gamma, R. Helm, R. Johnson, J. Vlissides, \e Design \e Patterns,
     ** Elements of Reusable Object-Oriented Software, Addison Wesley, 1995,
     ** p: 107-116.
     **
     ** \b Example \b 1:
     **
     ** \code
     **
     ** // Create object factory
     ** ObjectFactory * factory = new DlmObjectFactory( "Mesh.so" );
     **
     ** CPtr<Mesh> mesh = CPtr<Mesh>::NullPtr;
     **
     ** // Create new instance
     ** factory->NewObject( #Mesh, mesh );
     **
     ** // Invoke method on new instance
     ** mesh->Create();
     **
     ** // Delete instance
     ** factory->DelObject( #Mesh, mesh );
     **
     ** // Remove object factory
     ** delete factory;
     **
     ** \endcode
     **
     ** \author Michael Kellner
     ** \date 28.2.2003
     **
     ** \nosubgrouping
     **/
    class ObjectFactory
    {

	/** \name Constructors / Destructor
	 ** \{
	 **/

    protected:

	/** The default constructor is empty.
	 **/
	ObjectFactory();

	/** The copy constructor is empty.
	 **/
	ObjectFactory( const ObjectFactory & source );

    public:

	/** The destructor is empty.
	 **/
	virtual ~ObjectFactory();

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** The assignment operator is empty.
	 **/
	OC_DSOAPI ObjectFactory & operator=( const ObjectFactory & source );

	/** \}
	 **/

	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** This pure virtual method can be used to allocate a new instance
	 ** of the class named \e className. The allocated instance will be
	 ** returned as \c void \c * and the calling program is responsible
	 ** to cast this pointer to the correct class. For more convenience
	 ** it is recommend to use the template version of this overloaded
	 ** method. Do \b not free the allocate instance via \c delete, instead
	 ** you have to call DelObject() or DelObjectV().
	 **
	 ** This method will also be used by the correspondig template version.
	 **
	 ** \b Example:
	 **
	 ** \code
	 **
	 ** Mesh * mesh = static_cast<Mesh *>(factory.NewObjectV( #Mesh ) );
	 **
	 ** \endcode
	 **
	 ** \param  className An object of this class will be created.
	 ** \return Pointer to allocated instance on success, \c NULL on
	 **         failure.
	 **
	 ** \see NewObject()
	 **/
	virtual void * NewObjectV( const std::string & className ) = 0;

	/** This template method should be used to allocate a new instance
	 ** of the class \e ClassT named \e className. The allocated instance
	 ** will be returned as the correct class pointer. Do \b not free the
	 ** allocated instance via \c delete, instead you have to call
	 ** DelObject() or DelObjectV().
	 **
	 ** \param  className An object of this class will be created.
	 ** \param  instance  The allocated instance on success, \c NULL on
	 **                   failure.
	 ** \return \c true on success, \c false on failure
	 **
	 ** \see NewObjectV()
	 **/
	template <class ClassT>  
	bool NewObject( const std::string & className, oc::CPtr<ClassT> & instance )
	{

	    instance = static_cast<ClassT *>(NewObjectV( className ) );

	    return( instance != oc::CPtr<ClassT>::NullPtr );
	}

	/** This pure virtual method can be used to delete via NewObject() or
	 ** NewObjectV() previously allocated instances.
	 **
	 ** This method will also be used by the correspondig template version.
	 **
	 ** \b Example:
	 **
	 ** \code
	 **
	 ** // Allocate new instance
	 ** void * mesh = factory.NewObjectV( #Mesh );
	 **
	 ** // Delete instance
	 ** factory.DelObjectV( #Mesh, mesh);
	 **
	 ** \endcode
	 **
	 ** \param className An object of this class will be deleted.
	 ** \param instance  The previously allocated instance to delete.
	 ** \return \c true on success, \c false on failure
	 **
	 ** \see DelObject()
	 **/
	virtual bool DelObjectV( const std::string & className, const void * instance ) = 0;

	/** This method can be used to delete via NewObject() or NewObjectV()
	 ** previously allocated instances.
	 **
	 ** \param className An object of this class will be deleted.
	 ** \param instance  The previously allocated instance to delete.
	 ** \return \c true on success, \c false on failure
	 **
	 ** \see DelObjectV()
	 **/
	template <class ClassT> 
	bool DelObject( const std::string & className, const oc::CPtr<ClassT> & instance )
	{
	    if( instance == oc::CPtr<ClassT>::NullPtr ) {
		return( false );
	    }

	    return( DelObjectV( className, static_cast<const void *>(instance.GetCPtr()) ) );
	}

	/** \}
	 **/

    }; // ObjectFactory

    /** C-Pointer type to an object factory.
     **/
    typedef oc::CPtr< oc::ObjectFactory> ObjectFactoryPtr;

} // namespace oc



#endif


