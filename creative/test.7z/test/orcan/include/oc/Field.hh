
#ifndef OC_FIELD_HH
#define OC_FIELD_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN includes

#include <oc/PropertyListener.hh>

// STL includes

#include <algorithm>
#include <string>
#include <cstring>
#include <typeinfo>
#include <vector>


/** To access values in Fields you have to provide a type. The FIELD_ID macro
 ** can be used for this purpose.
 **
 ** \b Usage:
 ** \code
 **
 ** Field * f;
 **
 ** // from somewhere (you know it's a float; if not you 'll get an exception)
 ** f->GetRef( FIELD_ID(float) ) *= 2.f;
 **
 ** \endcode
 **/
#define FIELD_ID( fieldname ) fieldname()


/** Helper macro to simply calls to funtions that are stored in Fields
 ** (SField / SFieldRef)
 **
 ** instead of writing:
 **
 ** \code
 **
 ** fields[8]->GetRef(FIELD_ID(tMyFunction))(std::string("function argument"));
 **
 ** \endcode
 **
 ** use:
 **
 ** \code
 **
 ** FIELD_FCALL(tMyFunction,fields[8])(std::string("function argument"));
 **
 ** \endcode
 **/
#define FIELD_FCALL(sfft,sffp)    \
 (sffp->IsRef() ?                 \
 SFieldRef<sfft>::GetRef(sffp) :  \
 SField<sfft>::GetRef(sffp))


/** Helper macro to simply calls to member-functions that are stored in
 ** Fields (SField / SFieldRef)
 **
 ** instead of writing:
 **
 ** \code
 **
 ** (fields[11]->GetRef(FIELD_ID(tMyClassPtr))->*(fields[10]->GetRef(FIELD_ID(tMyClassDoSomething))))("method argument");
 **
 ** \endcode
 **
 ** use:
 **
 ** \code
 **
 ** FIELD_MCALL(tMyClassPtr,fields[11],tMyClassDoSomething,fields[10])("method argument");
 **
 ** \endcode
 **/
#define FIELD_MCALL(sft,sfp,sfmt,sfmp)                         \
 (sfp->IsRef() ?                                               \
 SFieldRef<sft>::GetRef(sfp)->*(SField<sfmt>::GetRef(sfmp)) :  \
 SField<sft>::GetRef(sfp)->*(SField<sfmt>::GetRef(sfmp)))




namespace oc
{

    /** \brief Wrapper Class to store and access values and functions using RTTI.
     **
     ** Field provides access to SField (single-value) and MField (multi-value)
     ** classes. The Field class allows values of arbitrary types to be accessed
     ** via a single-interface. The Field class provides this access but does
     ** not store the values; storing the values is up to classes that derive
     ** from Field (i.e. SField and MField)
     **
     ** \b Application:
     **
     ** By communicating with class Field, two modules can exchange
     ** information (and call methods of each other) without providing a
     ** declaration of the others interface at compile-time.
     **
     ** For example module A1 gets a Field-pointer from module A2 that can
     ** point to an \c int or a \c float. The Field is used to tell module
     ** A2 the value of some  variable v:
     **
     ** \code
     **
     ** bool
     ** A1::GetValue( Field * fromA2 )
     ** {
     **     try {
     **         if( fromA2->IsType( typeid( int ) ) {
     **             *fromA2 = (int) v;
     **         }
     **         else if( fromA2->IsType( typeid( float ) ) {
     **             *fromA2 = (float) v;
     **         }
     **     }
     **     catch( const std::bad_cast & ) {
     **         return( false );
     **     }
     **     return( true );
     ** }
     **
     ** \endcode
     **
     ** \b Note:
     ** You can, but you shouldn't use Field-Pointers to communicate between
     ** models; better use a PropertyMap
     **    
     ** \b Design:
     **
     ** The basic idea is to have a single interface-class Field, which
     ** provides access to values of arbitrary-types in a type-safe manner. 
     ** The values are stored in classes that derive from Field and that are
     ** implemented as templates. 
     **
     ** The Field class provides methods
     ** 
     ** - to query the type of the object it represents use:
     **   \code
     **   std::type_info & GetType()
     **   bool IsType( const std::type_info & info )
     **   \endcode
     **
     ** - to get a string-representation of the object use:
     **   \code
     **   std::string GetStringValue()
     **   \endcode
     **
     ** - to get a reference of type T to the object represented by the Field
     **   use:
     **   \code
     **   template <typename T> T & GetRef( T const & dummy ) throw( std::bad_cast )
     **   template <typename T> T & operator()( T const & dummy ) throw( std::bad_cast)
     **   \endcode
     **
     ** - to assign a value of type T to the object represented by the Fields
     **   use:
     **   \code
     **   template <typename T> T & operator=( T const & v ) throw( std::bad_cast )
     **   \endcode
     **
     ** A \c std::bad_cast exception will be thrown if the object represented by
     ** the Field is referenced using another type than it really has.
     **
     ** Additionally, if the Field represents a MField (i.e. a Field that
     ** contains other Fields) the method \c GetField() can be used to access
     ** the sub-fields
     ** \code
     ** Field * GetField( const int & idx)
     ** \endcode
     **
     ** \b Derived-Classes
     **
     ** - SField     field with a single value
     **
     ** - SFieldRef  field with a pointer to a single value
     **
     ** - MField     field of Field-pointers
     **
     ** \b Example:
     **
     ** \code
     **
     ** SField<int>   myint( 2 );
     ** SField<float> myfloat( 2.f );
     **
     ** int v = 2;
     ** SFieldRef<int> myrint( v );
     **
     ** // from here on we are working with Field-Pointers
     ** Field * pa[3];
     ** pa[0] = &myint;
     ** pa[1] = &myfloat;
     ** p2[2] = &myrint;
     **
     ** *pa[0] = 3;   // ok: int
     ** *pa[1] = 3.f; // ok: float
     ** *pa[2] = 3;   // ok: int
     **
     ** std::cout << (*pa[0])(FIELD_ID(int))   << std::endl;
     ** std::cout << (*pa[1])(FIELD_ID(float)) << std::endl;
     ** std::cout << (*pa[2])(FIELD_ID(int))   << std::endl;
     **
     ** // will throw std::bad_cast-exception (using float on int-Field)
     ** //(*pa[0]) = 3.f;
     **
     ** if( pa[0]->GetType() == typeid( float ) ) {
     **     *pa[0] = 3.f;
     ** }
     ** else if( pa[0]->GetType() == typeid( int ) ) {
     **     *pa[0] = 3;
     ** }
     **
     ** \endcode
     **
     ** \b Compiler \b Notes:
     **
     ** Class Field and it's derived classes compile successfully with gcc
     ** V2.95.3 or higher  on LINUX and with the the VisualStudio6-Compiler
     ** on Windows. Some restrictions apply for the code to be portable:
     **
     ** - The code for all member templates has to be inside the class
     **    declarations.
     **
     ** - See PropertyMap about using \c std::map in dlls
     **
     ** \author Horst Hadler
     ** \date 5.4.2002
     **
     ** \nosubgrouping
     **/
    
    class Field
    {

	/** \name Getter / Setter
	 ** \{
	 **/

    private:

	/** Get the reference to the contained field value.
	 **
	 ** \return Pointer to field value
	 **/
	virtual void * GetReference() = 0;

        /** Listeners are notified the contained value changes.
         **/
        std::vector< PropertyListener* > mListeners;

    public:

	/** Get Field Type
	 **
	 ** \return Type info of contained field value.
	 **/
	virtual const std::type_info & GetType() const = 0; 

	/** Get Field value as string.
	 **
	 ** \return Contained field value as string.
	 **/
	virtual std::string GetStringValue() const = 0;
    
	/** Get the i.-th. subfield of a MField (returns this for SFields)
	 **
	 ** \param idx Index of idx.-th. subfield.
	 ** \return Pointer to idx.-th. Field or NULL if index out of range.
	 **/
	virtual inline Field * GetField( const int & idx );

	/** Get a reference to the field's value including a type-check.
	 **
	 ** \param dummy Unused; needed for typed argument
	 ** \return Reference to field value.
	 ** \exception throws \c std::bad_cast if the cast is incompatible with
	 **            this fields type
         **/
	template <typename T>
	inline T & GetRef( T const & dummy )
	    throw( std::bad_cast )
	{
	    // std::cout << "Need Type: " << typeid(T).name() << std::endl
	    //           << "Have Type: " << GetType().name() << std::endl;

	    if( ::strcmp( GetType().name(),
			  typeid(T).name()  ) != 0 ) {

		throw std::bad_cast();
	    }

	    return( *((T*)GetReference()) );
	}


	/** Get a reference to the field's value omitting a type-check.
	 **
	 ** \param dummy Unused; needed for typed argument
	 ** \return Reference to field value.
         **/
	template <typename T>
	inline T & GetRefForced( T const & dummy )
	{
	    // std::cout << "Need Type: " << typeid(T).name() << std::endl

	    return *((T*)GetReference());
	}

	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

    public:

	/** Returns \c true if field is a reference-field i.e. when it stores
	 ** a pointer to a value.
	 **
	 ** \return \c true if field is a reference-field, \c false otherwise.
	 **/
	virtual bool IsRef() = 0;

	/** Test if this field has the type given.
	 **
	 ** \param info Test field for this type.
	 ** \return \c true if field has given type, \c false otherwise.
	 **/
	bool inline IsType( const std::type_info & info );

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

	/** Assign field value.
	 **
	 ** \param v Value to assign.
	 ** \return Assigned value.
	 **/
	template <typename T>
	inline T & operator=( T & v )
	    throw( std::bad_cast )
	{
		if( ((T*)&v) == ((T*)this) ) 
			return v;
	    return( GetRef(FIELD_ID(T)) = v );
	}


	/** Get a reference to the field's value including a type-check.
	 **
	 ** \param dummy Unused; needed for typed argument
	 ** \return Reference to field value.
	 ** \exception throws \c std::bad_cast if the cast is incompatible with
	 **            this fields type
	 **/
	template <typename T>
	inline T & operator()( T const & dummy )
	    throw( std::bad_cast )
	{
	    return( GetRef(dummy) );
	}

	/** \}
	 **/

        /** \name Change Listener.
         ** \{
         **/

    public:
        /** Add a listener.
         **/
        inline void AddListener(PropertyListener * l);

        /** Remove a listener.
         **/
        inline void RemoveListener(PropertyListener * l);

        /** Call HasChanged on all listeners 
         ** \param prop the property that has changed
         ** \param about_to_be_deleted true if the field is about to be deleted.
         **/
        inline void NotifyListeners(oc::Property& prop,bool about_to_be_deleted);

	/** \}
	 **/


    }; // class Field

} // namespace oc


// Include the template implementation

#include "Field.in"


#endif

