
#ifndef OC_FILE_HH
#define OC_FILE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// -------

// ORCAN include

#include <oc/config.h>
#include <oc/Date.hh>
#include <oc/Time.hh>

// STL include

#include <string>
#include <vector>
#include <iostream>


namespace oc
{

    /** An abstract representation of file and directory pathnames.
     ** User interfaces and operating systems use system-dependent pathname
     ** strings to name files and directories. This class presents an abstract,
     ** system-independent view of hierarchical pathnames. An abstract pathname
     ** has two components:
     **
     ** - An optional system-dependent prefix string, such as a disk-drive
     **   specifier, \c "/" for the UNIX root directory, or \c "\\" for a Win32
     **   UNC pathname, or a relative path specification like '.' or '..', and
     **
     ** - A sequence of zero or more string names.
     **
     ** Each name in an abstract pathname except for the last denotes a
     ** directory; the last name may denote either a directory or a file. The
     ** empty abstract pathname has no prefix and an empty name sequence.
     ** 
     ** The conversion of a pathname string to or from an abstract pathname is
     ** inherently system-dependent. When an abstract pathname is converted into
     ** a pathname string, each name is separated from the next by a single copy
     ** of the default separator character. The default name-separator character
     ** is defined by <em>oc::System::File.msSeparator</em>, and is made available
     ** in the public static fields sSeparator and sSeparatorChar of this class.
     ** When a pathname string is converted into an abstract pathname, the names
     ** within it may be separated by the default name-separator character or by
     ** any other name-separator character that is supported by the underlying
     ** system.
     ** 
     ** A pathname, whether abstract or in string form is absolute or relative.
     ** An absolute pathname is complete in that no other information is required
     ** in order to locate the file that it denotes. A relative pathname is based
     ** on the current working directory from which its starts to locate the file
     ** that it denotes.
     ** 
     ** The prefix concept is used to handle root directories on UNIX platforms,
     ** and drive specifiers, root directories and UNC pathnames on Win32
     ** platforms, as follows:
     ** 
     ** - For UNIX platforms, the prefix of an absolute pathname is always
     **   \c "/". The abstract pathname denoting the root directory
     **   has the prefix \c "/" and an empty name sequence.
     **
     ** - For Win32 platforms, the prefix of a pathname that contains a
     **   drive specifier consists of the drive letter followed by
     **   \c ":" and possibly followed by \c "\" if the pathname
     **   is absolute. The prefix prefix of a UNC pathname is \c "\\";
     **   the hostname and the share name are the first two names in the
     **   name sequence.
     **
     ** Instances of the File class are immutable; that is, once created,
     ** the abstract pathname represented by a File object will never change.
     **
     ** \b BUGS:
     **
     ** - Can't handle pathnames of type "C:file.ext".
     **
     ** - File mask in GetFileList() only works on Windows platforms.
     ** 
     ** \author Michael B. Kellner
     ** \date 8.1.2003
     **
     ** \nosubgrouping
     **/

    class OC_DSOAPI File
    { 

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The prefix concept is used to handle root directories
	 ** system-dependent. It is defined for root directories on UNIX
	 ** platforms, and drive specifiers, root directories and UNC pathnames
	 ** on Win32 platforms as follows:
	 **
	 ** - For UNIX platforms, the prefix of an absolute pathname is
	 **   always \c "/". The abstract pathname denoting the root
	 **   directory has the prefix \c "/" and an empty name sequence.
	 **
	 ** - For Win32 platforms, the prefix of a pathname that contains a
	 **   drive specifier consists of the drive letter followed by
	 **   \c ":" and possibly followed by "\" if the pathname is absolute.
	 **   The prefix of a UNC pathname is \c "\\"; the hostname and the
	 **   share name are the first two names in the name sequence.
	 **/
	std::string mRootPrefix;

	/** An abstract pathname has two components, a prefix string and
	 ** sequence of zero or more string names. This attribute holds the
	 ** sequence of names.
	 ** 
	 ** Each name in an abstract pathname except for the last denotes a
	 ** directory; the last name may denote either a directory or a file.
	 ** The empty abstract pathname has no prefix and an empty name
	 ** sequence.
	 ** 
	 ** On Win32 platforms the hostname and the share name are the first
	 ** two names in the name sequence.
	 **/
	std::vector<std::string> mNameSequence;

	/** The absolute pathname denoting the same file or directory as the
	 ** abstract pathname hold by the instance.
	 **/
	std::string mAbsoluteFile;

    public:

	/** The class static \c Null is used to refer to an
	 ** undefined/uninitialized class instance. The "Null" file is useful
	 ** in expressions like
	 **
	 ** \code
	 **
	 ** File myFile = System::File::CreateTempFile();
	 ** 
	 ** if( myFile == File::Null ) {
	 ** 
	 ** // do something
	 ** 
	 ** }
	 **
	 ** \endcode
	 **/
	static const oc::File Null;

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor. Leaves the instance in an uninitialized state.
	 ** Use the Create() methods or another constructor for
	 ** initialization of the instance.
	 ** 
	 ** The comparision with File::Null will return \c true for
	 ** an uninitialized instance.
	 **/
	File();

	/** Initialize the instance with the given name. If the name contains
	 ** no path the current path will be used.
	 **
	 ** \param name File name with or without path
	 **/
	File( const std::string & name );

	/** Initialize the instance with the given name. If the name contains
	 ** no path the current path will be used.
	 **
	 ** \param name File name with or without path
	 **/
	File( const char * name );

	/** Initialize the instance with the given absolut path and file.
	 ** Relative paths are still not supported.
	 **
	 ** \param path Absolut path to file
	 ** \param file File name without path
	 **/
	File( const std::string & path, const std::string & file );

	/** Creates a new File instance as copy from an existing instance.
	 **
	 ** \param file Existing instance
	 **/
	File( const File & file);

	/** Destructor is empty.
	 **/
	virtual ~File();

	/** \}
	 **/


	/** \name Creators
	 ** \{
	 **/

	/** Initialize the instance with the given name. If the name contains
	 ** no path the current path will be used.
	 **
	 ** \param name File name with or without path
	 **/
	bool Create( const std::string & name );
 
	/** Initialize the instance with the given name. If the name contains
	 ** no path the current path will be used.
	 **
	 ** \param name Filename with or without path
	 **/
	bool Create( const char * name );

	/** Initialize the instance with the given absolut path and file.
	 ** Relative paths are still not supported.
	 **
	 ** \param path Absolut path to file
	 ** \param file Filename without path
	 **/
	bool Create( const std::string & path, const std::string & file );

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** The system-dependent default name-separator character, represented
	 ** as a string for convenience. This string contains a single
	 ** character, namely sSeparatorChar. The method returns the value of
	 ** oc::System::File::sSeparator. On UNIX systems the value of
	 ** this field is \c '/'; on Win32 systems it is \c '\'.
	 **
	 ** \return The value of oc::System::File::msSeperator
	 **/
	static const std::string & GetSeparator();

	/** The system-dependent default name-separator character. The method
	 ** returns the value of oc::System::File.sSeparatorChar. On
	 ** UNIX systems the value of this field is \c '/'; on Win32
	 ** systems it is \c '\'.
	 **
	 ** \return The value of oc::System::File::msSeparatorChar
	 **/
	static char GetSeparatorChar();

	/** The system-dependent default path-separator character, represented
	 ** as a string for convenience. This string contains a single
	 ** character, namely sPathSeparatorChar. The method returns the
	 ** value of oc::System::Path::sSeparator. On UNIX systems the
	 ** value of this field is \c ':'; on Win32 systems it is \c ';'.
	 **
	 ** \return The value of oc::System::Path::msSeparator
	 **/
	static const std::string & GetPathSeparator();

	/** The system-dependent default path-separator character. The method
	 ** returns the value of oc::System::Path.sSeparatorChar. On
	 ** UNIX systems the value of this field is \c ':'; on Win32
	 ** systems it is \c ';'.
	 **
	 ** \return The value of oc::System::Path::msSeparatorChar
	 **/
	static char GetPathSeparatorChar();


    public:

	/** Returns the absolute pathname string of this abstract pathname. If
	 ** the absolute pathname denotes already a directory, that is if
	 ** IsDirectory() returns \c true, than the absolute form of the
	 ** abstract pathname is returned, same as calling GetAbsoluteFile().
	 **
	 ** \return The absolute pathname string denoting the same file or
	 **         directory as this abstract pathname
	 **/
	const std::string & GetAbsolutePath() const;

	/** Returns the absolute form of this abstract pathname. The absolute
	 ** form of the abstract pathname is the concatenation of the root
	 ** prefix and the name sequence conntected by the system-dependent
	 ** separated.
	 **
	 ** \return The absolute abstract pathname denoting the same file or
	 **         directory as this abstract pathname
	 **/
	const std::string & GetAbsoluteFile() const;

	/** Returns an array of abstract pathnames denoting the files in the
	 ** directory denoted by this abstract pathname.
	 ** 
	 ** If this abstract pathname does not denote a directory, then this
	 ** method returns an empty array. Otherwise an array of <i>File</i>
	 ** objects is returned, one for each file or directory in the
	 ** directory. Pathnames denoting the directory itself and the
	 ** directory's parent directory are not included in the result. Each
	 ** resulting abstract pathname is constructed from this abstract
	 ** pathname using the File( const std::string &, const std::string &)
	 ** constructor.
	 ** 
	 ** There is no guarantee that the name strings in the resulting array
	 ** will appear in any specific order; they are not, in particular,
	 ** guaranteed to appear in alphabetical order. But you can sort the
	 ** array by the STL sort algoritm using the "<" operator defined with
	 ** this File class.
	 **
	 ** \b BUGS:
	 **
	 ** - File mask works only on Windows platforms.
	 **
	 ** \param fileList Array of abstract pathnames on return
	 ** \param fileMask Only files matching this file mask are listed;
	 **        use oc::DirectoryStream::msDefaultFileMask to list all files
	 ** \return \c true if abstract pathname is a directory and can be
	 **         listed, \c false otherwise
	 **/
	bool GetFileList( std::vector<File> & fileList,
			  const std::string & fileMask ) const;

	/** Return the size of the file in bytes. The size of a symbolic link is
	 ** NOT the size of linked file but the length of the pathname it
	 ** contains.
	 **
	 ** \return Size of file in bytes if existant, \c -1 if file
	 **         doesn't exists
	 **/
	int GetFileSize() const;

	/** Returns the name of the file or directory denoted by this abstract
	 ** pathname. This is just the last name in the pathname's name
	 ** sequence.
	 **
	 ** \return The name of the file or directory denoted by this abstract
	 **         pathname
	 **/
	const std::string & GetName() const;

	/** Returns an array of strings denoting the pathname's name sequence.
	 ** For a Win32 UNC pathname the hostname and the share name are the
	 ** first two names in the name sequence.
	 ** @return Sequence of name strings
	 **/
	const std::vector<std::string> & GetNameSequence() const;

	/** Returns the pathname string of this abstract pathname's parent, or
	 ** File::Null if this pathname does not name a parent directory.
	 ** 
	 ** The parent of an abstract pathname consists of the pathname's
	 ** prefix,if any, and each name in the pathname's name sequence except
	 ** for the last. If the name sequence is empty then the pathname does
	 ** not name a parent directory.
	 ** 
	 ** \return The pathname string of the parent directory named by this
	 **         abstract pathname, or File::Null if this pathname
	 **         does not name a parent 
	 **/
	File GetParent() const;

	/** The prefix concept is used to handle root directories
	 ** system-dependent. It is defined for root directories on UNIX
	 ** platforms, and drive specifiers, root directories and UNC
	 ** pathnames on Win32 platforms as follows:
	 ** 
	 ** - For UNIX platforms, the prefix of an absolute pathname is
	 **   always \c "/". The abstract pathname denoting the root
	 **   directory has the prefix \c "/" and an empty name sequence.
	 **
	 ** - For Win32 platforms, the prefix of a pathname that contains a
	 **   drive specifier consists of the drive letter followed by
	 **   \c ":" and possibly followed by <tt>"\"</tt> if the pathname
	 **   is absolute. The prefix of a UNC pathname is \c "\\"; the
	 **   hostname and the share name are the first two names in the
	 **   name sequence.
	 **
	 ** \return The system-dependent prefix string
	 **/
	const std::string & GetRootPrefix() const;

	/** Returns the extension of the file name.
	 **
	 ** The extension of the file name is the string after the last
	 ** separator character defined by \a sep. If no separator could be
	 ** found the extension is the empty string. Only the last name in
	 ** the pathname's name sequence will be searched for the extension,
	 ** this is the string what GetName() returns.
	 **/
	std::string GetExtension( char sep='.' ) const;

        /** Returns the date and the time of the last access to the file. 
         **/
        bool GetLastAccess(Date & d, Time & t ) const;

        /** Returns the date and the time of the last modification of the file.
         **/
        bool GetLastModification( Date & d, Time & t ) const;

        /** Returns the date and the time of the last change of the file. 
         **/
        bool GetLastChange( Date & d, Time & t ) const;

	/** \}
	 **/


	/** \name Query Methods
	 ** \{
	 **/

    public:

	/** Tests whether the file denoted by this abstract pathname is a
	 ** directory.
         **
         ** \note
         ** If the file is a link - IsLink() returns \c true - and the link
         ** points to a directory, this method returns also \c true.
	 **
	 ** \return \c true if and only if the file denoted by this abstract
	 **         pathname exists and is a directory; \c false otherwise.
	 **/
	bool IsDirectory() const;

	/** Tests whether the file denoted by this abstract pathname exists.
	 **
	 ** \return \c true if and only if the file denoted by this abstract
	 **         pathname exists; \c false otherwise
	 **/
	bool IsExistant() const;

	/** Tests whether the file denoted by this abstract pathname exists and
	 ** is a normal file. Directories and symbolic links are not normal
	 ** files.
         **
         ** \note
         ** If the file is a link - IsLink() returns \c true - and the link
         ** points to a file, this method returns also \c true.
	 **
	 ** \return \c true if and only if the file denoted by this abstract
	 **         pathname exists and is a normal file; \c false otherwise.
	 **/
	bool IsFile() const;

	/** Tests whether the file denoted by this abstract pathname exists and
	 ** is a symbolic link. 
	 **
         ** \note
         ** If it is a link and the link points to a file/directory the
         ** methods IsFile() / IsDirectory() returns also \c true.
         **
	 ** \return \c true if and only if the file denoted by this abstract
	 **         pathname exists and is a symbolic link; \c false otherwise.
	 **/
	bool IsLink() const;

	/** Tests whether the application can read the file denoted by this
	 ** abstract pathname.
	 **
	 ** \return \c true if and only if the file specified by this abstract
	 **         pathname exists and can be read by the application; \c false
	 **         otherwise
	 **/
	bool IsReadable() const;

	/** Tests whether the application can modify to the file denoted by this
	 ** abstract pathname.
	 **
	 ** \return \c true if and only if the file specified by this abstract
	 **         pathname exists and the application is allowed to write to
	 **         the file; \c false otherwise.
	 **/
	bool IsWriteable() const;

	/** Tests whether the abstract pathname is a relative specification. A
	 ** pathname is relative if it begins with '.' or '..'.
	 **
	 ** \return \c true if abstract pathname is a relative specification,
	 **         \c false otherwise.
	 **/
	bool IsRelative() const;

	/** Tests whether the abstract pathname is an absolute specification. A
	 ** pathname is absolute if it is not relative what means it begins
	 ** with a '/', '\' or '&lt;drive&gt;:'.
	 **
	 ** \return \c true if abstract pathname is an absolute specification,
	 **         \c false otherwise.
	 **/
	bool IsAbsolute() const;

	/** \}
	 **/

	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** Deletes the file or directory denoted by this abstract pathname. If
	 ** this pathname denotes a directory and the recursive flag is set than
	 ** all files and subdirectories will be removed. If the recursive flag
	 ** is unset (default) than the directory will only be removed if it is
	 ** empty.
	 **
	 ** \param recursive This parameter applies only for directories; if
	 **        recursive is \c false (default) then directories will
	 **        only be deleted if it is empty; if recursive is \c true
	 **        then all files and directories within the directory will also
	 **        be deleted
	 ** \return \c true if file or directory was removed successfully,
	 **         \c false otherwise.
	 **/
	bool Remove( bool recursive = false ) const;

	/** Create a directory at the position specified by this file.
	 ** \author Horst Hadler
	 ** \return true on success
	 **/
	bool MakeDirectory() const;

	/** \}
	 **/


	/** \name Operators
	 ** \{
	 **/

	/** Assigns a given file object. After assignment a complete independent
	 ** copy of the assigned file object will exists in this instance.
	 **
	 ** \param file File object assigned.
	 **/
	File & operator=( const oc::File & file );

	/** Initialize the instance with the given name. If the name contains no
	 ** path the current path will be used.
	 **
	 ** \param name File name with or without path.
	 **/
	File & operator=( const std::string & name );

	/** Initialize the instance with the given name. If the name contains no
	 ** path the current path will be used.
	 **
	 ** \param name File name with or without path.
	 **/
	File & operator=( const char * name );

	/** Less-than operator returns \c true if the first pathname is
	 ** lexicographical before the second.
	 **/
	OC_DSOAPI friend bool operator<( const File & file1,
                                         const File & file2 );

	/** Equality-operator returns \c true if the two abstract
	 ** pathnames refer to the same  file.
	 **/
	OC_DSOAPI friend bool operator==( const File & file1,
                                          const File & file2 );

        /** Inquality-operator returns \c true if the two abstract
         ** pathnames refer different files.
         **/
	OC_DSOAPI friend bool operator!=( const File & file1,
                                          const File & file2 );

	/** This negation operator checks whether the file is File::Null.
	 **
	 ** \return \c true if it is File::Null
	 **         \c false otherwise.
	 **/
	bool operator!() const;

	/** Checks whether the file is File::Null.
	 **
	 ** \return \c true if it is not File::Null.
	 **         \c false otherwise.
	 **/
	operator bool() const;

	/** \}
	 **/


	/** \name Helpers
	 ** \{
	 **/

    public:

	/** Print file name on stream.
	 ** \param out Stream on which the file name will be printed.
	 **/
	virtual void Print( std::ostream & out ) const;

	/** Scan file name from stream.
	 ** \param in Stream from which the file name will be scanned.
	 **/
	virtual void Scan( std::istream & in );


    protected:

	/** Rebuilds the absolute pathname attribute. This is necessary if the
	 ** instance get reinitialized by an Create() method or
	 ** assignment operation.
	 **/
	void BuildAbsoluteFile();

	/** \}
	 **/

    };

    /** Output operator for the File class. Internal it calls File::Print().
     ** This is a virtual class and can be overriden by subclass of the class
     ** File.
     **/
    OC_DSOAPI std::ostream & operator<<( std::ostream & out, const oc::File & file );

    /** Input operator for the File class. Internal it calls File::Scan().
     ** This is a virtual class and can be overriden by subclass of the class
     ** File.
     **/
    OC_DSOAPI std::istream & operator>>( std::istream & in, oc::File & file );

    /** Less-than operator returns \c true if the first pathname is
     ** lexicographical before the second.
     **/
    OC_DSOAPI bool operator<( const File & file1, const File & file2 );

    /** Equality-operator returns \c true if the two abstract
     ** pathnames refer to the same  file.
     **/
    OC_DSOAPI bool operator==( const File & file1, const File & file2 );

    /** Inquality-operator returns \c true if the two abstract
     ** pathnames refer different files.
     **/
    OC_DSOAPI bool operator!=( const File & file1, const File & file2 );

} // namespace oc




#endif



