#ifndef YY_PropertyResourceRuleParser_h_included
#define YY_PropertyResourceRuleParser_h_included

#line 1 "c:\\usr\\bin\\bison.h"
/* before anything */
#ifdef c_plusplus
#ifndef __cplusplus
#define __cplusplus
#endif
#endif
#ifdef __cplusplus
#ifndef YY_USE_CLASS
#define YY_USE_CLASS
#endif
#else
#endif
#include <stdio.h>

/* #line 14 "c:\\usr\\bin\\bison.h" */
#line 21 "..\\include\\oc\\PropertyResourceRuleParser.hh"
#line 43 "\\usr\\home\\Mawanda\\develop\\oc\\orcan\\src\\orcan\\PropertyResourceRuleParser.y"


#include <oc/config.h>
#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyResourceRuleScanner.hh>
#include <oc/Util.hh>

#include <cmath>
#include <iostream>
#include <string>
#include <vector>

#if defined(__GNUC__)
#  if OC_CHECK_GCC_VERSION(3, 0)
#    include <limits>
#  else
#    if defined(__FreeBSD__)
#      include <float.h>
#    else
#      include <values.h>
#    endif
#  endif
#endif


#if defined(MSDOS)
#  include <limits>
#endif


#define YY_PropertyResourceRuleParser_CLASS_ACCESS  OC_DSOAPI
#define YY_PropertyResourceRuleParser_MEMBERS  private:                                                          \
                                                                                  \
    std::vector< std::string > mValueList;                                        \
    bool                       mResult;                                           \
    PropertyResourceRuleScanner mPropertyResourceRuleScanner;                     \
    PropertyResourceRuleParser();                                                 \
    PropertyResourceRuleParser( PropertyResourceRuleParser & prrParser );         \
    public:                                                                       \
    bool GetResult() { return mResult; };  
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM   std::istream & in
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_INIT    : mPropertyResourceRuleScanner( in )
#define YY_PropertyResourceRuleParser_PARSE        Parse
#define YY_PropertyResourceRuleParser_PARSE_PARAM  oc::PropertyMap & pmap
#define YY_PropertyResourceRuleParser_LEX_BODY  {                                       \
                    return( mPropertyResourceRuleScanner.Scan( *this ) ); \
                 }
#define YY_PropertyResourceRuleParser_ERROR_BODY  {                                      \
                      std::cerr << std::endl              \
                           << msg                         \
                           << ", Last token was <"        \
                           << (char *) mPropertyResourceRuleScanner.yytext \
                           << ">"                         \
                           << endl;                       \
                   }
#define YY_PropertyResourceRuleParser_LSP_NEEDED 

#line 147 "\\usr\\home\\Mawanda\\develop\\oc\\orcan\\src\\orcan\\PropertyResourceRuleParser.y"
typedef union {
  bool   boolean;
  char   string[4096];
} yy_PropertyResourceRuleParser_stype;
#define YY_PropertyResourceRuleParser_STYPE yy_PropertyResourceRuleParser_stype

#line 14 "c:\\usr\\bin\\bison.h"
 /* %{ and %header{ and %union, during decl */
#ifndef YY_PropertyResourceRuleParser_COMPATIBILITY
#ifndef YY_USE_CLASS
#define  YY_PropertyResourceRuleParser_COMPATIBILITY 1
#else
#define  YY_PropertyResourceRuleParser_COMPATIBILITY 0
#endif
#endif

#if YY_PropertyResourceRuleParser_COMPATIBILITY != 0
/* backward compatibility */
#ifdef YYLTYPE
#ifndef YY_PropertyResourceRuleParser_LTYPE
#define YY_PropertyResourceRuleParser_LTYPE YYLTYPE
/* WARNING obsolete !!! user defined YYLTYPE not reported into generated header */
/* use %define LTYPE */
#endif
#endif
#ifdef YYSTYPE
#ifndef YY_PropertyResourceRuleParser_STYPE 
#define YY_PropertyResourceRuleParser_STYPE YYSTYPE
/* WARNING obsolete !!! user defined YYSTYPE not reported into generated header */
/* use %define STYPE */
#endif
#endif
#ifdef YYDEBUG
#ifndef YY_PropertyResourceRuleParser_DEBUG
#define  YY_PropertyResourceRuleParser_DEBUG YYDEBUG
/* WARNING obsolete !!! user defined YYDEBUG not reported into generated header */
/* use %define DEBUG */
#endif
#endif
#ifdef YY_PropertyResourceRuleParser_STYPE
#ifndef yystype
#define yystype YY_PropertyResourceRuleParser_STYPE
#endif
#endif
/* use goto to be compatible */
#ifndef YY_PropertyResourceRuleParser_USE_GOTO
#define YY_PropertyResourceRuleParser_USE_GOTO 1
#endif
#endif

/* use no goto to be clean in C++ */
#ifndef YY_PropertyResourceRuleParser_USE_GOTO
#define YY_PropertyResourceRuleParser_USE_GOTO 0
#endif

#ifndef YY_PropertyResourceRuleParser_PURE

/* #line 63 "c:\\usr\\bin\\bison.h" */
#line 140 "..\\include\\oc\\PropertyResourceRuleParser.hh"

#line 63 "c:\\usr\\bin\\bison.h"
/* YY_PropertyResourceRuleParser_PURE */
#endif

/* #line 65 "c:\\usr\\bin\\bison.h" */
#line 147 "..\\include\\oc\\PropertyResourceRuleParser.hh"

#line 65 "c:\\usr\\bin\\bison.h"
/* prefix */
#ifndef YY_PropertyResourceRuleParser_DEBUG

/* #line 67 "c:\\usr\\bin\\bison.h" */
#line 154 "..\\include\\oc\\PropertyResourceRuleParser.hh"

#line 67 "c:\\usr\\bin\\bison.h"
/* YY_PropertyResourceRuleParser_DEBUG */
#endif
#ifndef YY_PropertyResourceRuleParser_LSP_NEEDED

/* #line 70 "c:\\usr\\bin\\bison.h" */
#line 162 "..\\include\\oc\\PropertyResourceRuleParser.hh"

#line 70 "c:\\usr\\bin\\bison.h"
 /* YY_PropertyResourceRuleParser_LSP_NEEDED*/
#endif
/* DEFAULT LTYPE*/
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
#ifndef YY_PropertyResourceRuleParser_LTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YY_PropertyResourceRuleParser_LTYPE yyltype
#endif
#endif
/* DEFAULT STYPE*/
#ifndef YY_PropertyResourceRuleParser_STYPE
#define YY_PropertyResourceRuleParser_STYPE int
#endif
/* DEFAULT MISCELANEOUS */
#ifndef YY_PropertyResourceRuleParser_PARSE
#define YY_PropertyResourceRuleParser_PARSE yyparse
#endif
#ifndef YY_PropertyResourceRuleParser_LEX
#define YY_PropertyResourceRuleParser_LEX yylex
#endif
#ifndef YY_PropertyResourceRuleParser_LVAL
#define YY_PropertyResourceRuleParser_LVAL yylval
#endif
#ifndef YY_PropertyResourceRuleParser_LLOC
#define YY_PropertyResourceRuleParser_LLOC yylloc
#endif
#ifndef YY_PropertyResourceRuleParser_CHAR
#define YY_PropertyResourceRuleParser_CHAR yychar
#endif
#ifndef YY_PropertyResourceRuleParser_NERRS
#define YY_PropertyResourceRuleParser_NERRS yynerrs
#endif
#ifndef YY_PropertyResourceRuleParser_DEBUG_FLAG
#define YY_PropertyResourceRuleParser_DEBUG_FLAG yydebug
#endif
#ifndef YY_PropertyResourceRuleParser_ERROR
#define YY_PropertyResourceRuleParser_ERROR yyerror
#endif

#ifndef YY_PropertyResourceRuleParser_PARSE_PARAM
#ifndef __STDC__
#ifndef __cplusplus
#ifndef YY_USE_CLASS
#define YY_PropertyResourceRuleParser_PARSE_PARAM
#ifndef YY_PropertyResourceRuleParser_PARSE_PARAM_DEF
#define YY_PropertyResourceRuleParser_PARSE_PARAM_DEF
#endif
#endif
#endif
#endif
#ifndef YY_PropertyResourceRuleParser_PARSE_PARAM
#define YY_PropertyResourceRuleParser_PARSE_PARAM void
#endif
#endif

/* TOKEN C */
#ifndef YY_USE_CLASS

#ifndef YY_PropertyResourceRuleParser_PURE
extern YY_PropertyResourceRuleParser_STYPE YY_PropertyResourceRuleParser_LVAL;
#endif


/* #line 143 "c:\\usr\\bin\\bison.h" */
#line 240 "..\\include\\oc\\PropertyResourceRuleParser.hh"
#define	MATH_TAN	258
#define	MATH_SIN	259
#define	MATH_COS	260
#define	MATH_PI	261
#define	COMPARE_EQUAL	262
#define	COMPARE_UNEQUAL	263
#define	LOGICAL_AND	264
#define	LOGICAL_OR	265
#define	ASSIGN	266
#define	COMPARE_LESS	267
#define	COMPARE_LESS_OR_EQUAL	268
#define	COMPARE_GREATER	269
#define	COMPARE_GREATER_OR_EQUAL	270
#define	RANGE	271
#define	PROPSTATE	272
#define	REGEXP	273
#define	XMLEXP	274
#define	STRING	275
#define	QUOTE	276
#define	BOOL	277


#line 143 "c:\\usr\\bin\\bison.h"
 /* #defines token */
/* after #define tokens, before const tokens S5*/
#else
#ifndef YY_PropertyResourceRuleParser_CLASS
#define YY_PropertyResourceRuleParser_CLASS PropertyResourceRuleParser
#endif
#ifndef YY_PropertyResourceRuleParser_CLASS_ACCESS
#define YY_PropertyResourceRuleParser_CLASS_ACCESS
#endif

#ifndef YY_PropertyResourceRuleParser_INHERIT
#define YY_PropertyResourceRuleParser_INHERIT
#endif
#ifndef YY_PropertyResourceRuleParser_MEMBERS
#define YY_PropertyResourceRuleParser_MEMBERS 
#endif
#ifndef YY_PropertyResourceRuleParser_LEX_BODY
#define YY_PropertyResourceRuleParser_LEX_BODY  
#endif
#ifndef YY_PropertyResourceRuleParser_ERROR_BODY
#define YY_PropertyResourceRuleParser_ERROR_BODY  
#endif
#ifndef YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM
#define YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM
#endif
/* choose between enum and const */
#ifndef YY_PropertyResourceRuleParser_USE_CONST_TOKEN
#define YY_PropertyResourceRuleParser_USE_CONST_TOKEN 0
/* yes enum is more compatible with flex,  */
/* so by default we use it */ 
#endif
#if YY_PropertyResourceRuleParser_USE_CONST_TOKEN != 0
#ifndef YY_PropertyResourceRuleParser_ENUM_TOKEN
#define YY_PropertyResourceRuleParser_ENUM_TOKEN yy_PropertyResourceRuleParser_enum_token
#endif
#endif

class YY_PropertyResourceRuleParser_CLASS_ACCESS YY_PropertyResourceRuleParser_CLASS YY_PropertyResourceRuleParser_INHERIT
{
public: 
#if YY_PropertyResourceRuleParser_USE_CONST_TOKEN != 0
/* static const int token ... */

/* #line 185 "c:\\usr\\bin\\bison.h" */
#line 308 "..\\include\\oc\\PropertyResourceRuleParser.hh"
static const int MATH_TAN;
static const int MATH_SIN;
static const int MATH_COS;
static const int MATH_PI;
static const int COMPARE_EQUAL;
static const int COMPARE_UNEQUAL;
static const int LOGICAL_AND;
static const int LOGICAL_OR;
static const int ASSIGN;
static const int COMPARE_LESS;
static const int COMPARE_LESS_OR_EQUAL;
static const int COMPARE_GREATER;
static const int COMPARE_GREATER_OR_EQUAL;
static const int RANGE;
static const int PROPSTATE;
static const int REGEXP;
static const int XMLEXP;
static const int STRING;
static const int QUOTE;
static const int BOOL;


#line 185 "c:\\usr\\bin\\bison.h"
 /* decl const */
#else
enum YY_PropertyResourceRuleParser_ENUM_TOKEN { YY_PropertyResourceRuleParser_NULL_TOKEN=0

/* #line 188 "c:\\usr\\bin\\bison.h" */
#line 337 "..\\include\\oc\\PropertyResourceRuleParser.hh"
	,MATH_TAN=258
	,MATH_SIN=259
	,MATH_COS=260
	,MATH_PI=261
	,COMPARE_EQUAL=262
	,COMPARE_UNEQUAL=263
	,LOGICAL_AND=264
	,LOGICAL_OR=265
	,ASSIGN=266
	,COMPARE_LESS=267
	,COMPARE_LESS_OR_EQUAL=268
	,COMPARE_GREATER=269
	,COMPARE_GREATER_OR_EQUAL=270
	,RANGE=271
	,PROPSTATE=272
	,REGEXP=273
	,XMLEXP=274
	,STRING=275
	,QUOTE=276
	,BOOL=277


#line 188 "c:\\usr\\bin\\bison.h"
 /* enum token */
     }; /* end of enum declaration */
#endif
public:
 int YY_PropertyResourceRuleParser_PARSE(YY_PropertyResourceRuleParser_PARSE_PARAM);
 virtual void YY_PropertyResourceRuleParser_ERROR(char *msg) YY_PropertyResourceRuleParser_ERROR_BODY;
#ifdef YY_PropertyResourceRuleParser_PURE
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
 virtual int  YY_PropertyResourceRuleParser_LEX(YY_PropertyResourceRuleParser_STYPE *YY_PropertyResourceRuleParser_LVAL,YY_PropertyResourceRuleParser_LTYPE *YY_PropertyResourceRuleParser_LLOC) YY_PropertyResourceRuleParser_LEX_BODY;
#else
 virtual int  YY_PropertyResourceRuleParser_LEX(YY_PropertyResourceRuleParser_STYPE *YY_PropertyResourceRuleParser_LVAL) YY_PropertyResourceRuleParser_LEX_BODY;
#endif
#else
 virtual int YY_PropertyResourceRuleParser_LEX() YY_PropertyResourceRuleParser_LEX_BODY;
 YY_PropertyResourceRuleParser_STYPE YY_PropertyResourceRuleParser_LVAL;
#ifdef YY_PropertyResourceRuleParser_LSP_NEEDED
 YY_PropertyResourceRuleParser_LTYPE YY_PropertyResourceRuleParser_LLOC;
#endif
 int YY_PropertyResourceRuleParser_NERRS;
 int YY_PropertyResourceRuleParser_CHAR;
#endif
#if YY_PropertyResourceRuleParser_DEBUG != 0
public:
 int YY_PropertyResourceRuleParser_DEBUG_FLAG;	/*  nonzero means print parse trace	*/
#endif
public:
 YY_PropertyResourceRuleParser_CLASS(YY_PropertyResourceRuleParser_CONSTRUCTOR_PARAM);
public:
 YY_PropertyResourceRuleParser_MEMBERS 
};
/* other declare folow */
#endif


#if YY_PropertyResourceRuleParser_COMPATIBILITY != 0
/* backward compatibility */
#ifndef YYSTYPE
#define YYSTYPE YY_PropertyResourceRuleParser_STYPE
#endif

#ifndef YYLTYPE
#define YYLTYPE YY_PropertyResourceRuleParser_LTYPE
#endif
#ifndef YYDEBUG
#ifdef YY_PropertyResourceRuleParser_DEBUG 
#define YYDEBUG YY_PropertyResourceRuleParser_DEBUG
#endif
#endif

#endif
/* END */

/* #line 239 "c:\\usr\\bin\\bison.h" */
#line 414 "..\\include\\oc\\PropertyResourceRuleParser.hh"
#endif
