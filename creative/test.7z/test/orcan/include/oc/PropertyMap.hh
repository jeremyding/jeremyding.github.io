
#ifndef OC_PROPERTY_MAP_HH
#define OC_PROPERTY_MAP_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/Field.hh>
#include <oc/SFieldRef.hh>
#include <oc/SField.hh>
#include <oc/Property.hh>
#include <oc/PropertyResourceRule.hh>
#include <oc/XMLObject.hh>

// C++ include

#include <iostream>
#include <vector>
#include <string>

// on visual studio system before .net use the hashmap version
#if defined(_MSC_VER) && (_MSC_VER < 1300)
#  include <oc/hash_map.hh>
#else
#  include <map>
#endif



 
namespace oc
{


    /** \brief Datastructure to access properties by name.
     **
     ** PropertyMap is intended to be used to exchange data and access functions
     ** between two communicating modules without needing the module's class
     ** declarations at compile-time.
     **
     ** \b Example:
     **
     ** \code
     **
     ** int           i0(2);
     ** SField<float> f0(2.f);       
     **
     ** PropertyMap map;
     **
     ** map.AddProperty( "myint", i0 );
     ** map.AddProperty( Property( "myfloat", f0 ) ); 
     ** map.AddPropertyCopy("pm2", myfunc ); // you can also add function pointers (myfunc has type tFunc)
     **
     ** std::cout << map["myint"  ](FIELD_ID(int)  ) << std::endl;
     ** std::cout << map["myfloat"](FIELD_ID(float)) << std::endl;
     **
     ** // now a pointer to map can be passed to another module
     ** PropertyMap * pmap = &map;
     **
     ** (*map)["myint"]   = 3;
     ** (*map)["myfloat"] = 3.f;
     ** (*map)["pm2"](FIELD_ID(tFunc))(...);     // make function call (assumes myfunc has type tFunc)
     **
     ** std::cout << (*map)["myint"  ](FIELD_ID(int)  ) << std::endl;
     ** std::cout << (*map)["myfloat"](FIELD_ID(float)) << std::endl;
     ** // or for simple types (int,float,bool,...)
     ** std::cout << (int)(*map)["myint"] << std::endl;
     ** std::cout << (float)(*map)["myfloat"] << std::endl;
     ** 
     ** // values can also be set by string 
     ** (*map)["myfloat"].SetStringValue("2.0f",FIELD_ID(float)); 
     ** // or for simple types (int,float,bool,...)
     ** (*map)["myfloat"].SetStringValue("2.0f"); 
     **
     ** // change notification
     ** (*map)["myfloat"].AddListener( somelistener );
     ** (*map)["myfloat"] = 10;
     ** (*map)["myfloat"].NotifyListeners(); // call listener callback of 'somelistener'
     **
     ** // properties can be assigned variables or passed to function calls;
     ** // however, if the variable is changed no change notification will be triggered
     ** int   i = (int)(*map)["myint"];
     ** float f = (floatt)(*map)["myint"];
     **
     ** // callbacks
     ** map.AddPropertyCallback(); 
     **
     ** \endcode
     **
     ** \b Compiler / \b Implementation \b Notes:
     **
     ** Class Field and it's derived classes compile successfully with gcc
     ** V2.95.3 or higher on LINUX and with the the VisualStudio6-Compiler
     ** on Windows. Some restrictions apply for the code to be portable:
     **
     ** - The code for all member templates has to be inside the class
     **   declarations.
     **
     ** - No generic conversion operator could be used 
     **   INTERNAL COMPILER ERROR in VisualC++6: compiler version 12.00.0084
     **
     ** - \c std::map elements of classes within a DLL may NOT be accessed as
     **   \c std::map elements from outside the DLL .
     **
     ** In a first approach the properties were stored within the map using
     ** a \c std::map attribute. This lead to access vioalations when running
     ** the program. The cause of these violations is descripted below. To
     ** avoid this 'side-effect' of using std::map under Windows we are using hash_map
     ** from SGI instead.
     **
     ** <a href="http://support.microsoft.com/default.aspx?scid=KB;en-us;q172396">
     ** PRB: Access Violation When Accessing STL Object in DLL</a>
     ** 
     **
     ** \author Horst Hadler
     ** \date 6.4.2003
     **
     ** \nosubgrouping
     **/
    class PropertyMap : public PropertyListener
    {

	/** \name Class Types
	 ** \{
	 **/

    public:

	/** The type of the internal container for all properties consists in
	 ** a STL map of pairs of \c string and \c Property.
	 **/

#if defined(_MSC_VER) && (_MSC_VER < 1300)
	typedef oc::hash_map<std::string, Property> tMap;
#else
	typedef std::map<std::string, Property> tMap;
#endif

    public:

	/** The iterator over all properties.
	 **
	 ** \see const_iterator, reverse_iterator, begin(), end()
	 **/
	typedef tMap::iterator iterator;

	/** The constant iterator over all properties for a constant property
	 ** map instance.
	 **
	 ** \see iterator, begin(), end()
	 **/
	typedef tMap::const_iterator const_iterator;

#ifndef WIN32
	/** The reverse iterator over all properties.
	 **
	 ** \see const_reverse_iterator, iterator, rbegin(), rend()
	 **/
	typedef tMap::reverse_iterator reverse_iterator;

	/** The constant reverse iterator over all properties for a constant
	 ** property map instance.
	 **
	 ** \see reverse_iterator, rbegin(), rend()
	 **/
	typedef tMap::const_reverse_iterator const_reverse_iterator;
#endif

	/** \}
	 **/

	/** \name Attributes
	 ** \{
	 **/

    private:
    
	/** The container for all properties in the map.
	 **/
	tMap mMap;

	/** Vector for temporary SFieldRef-instances.
	 **/
	std::vector<Field *> mTmpFields;


    /** Layout description (xml-format) of property resources.
     **/
    std::string mLayoutSpec;


    std::vector<oc::PropertyResourceRule> mRules;

    /** name identifying this map.
     **/
    std::string mName;
	/** \}
	 **/


	/** \name Listen to Properties
	 ** \{
	 **/
    virtual void PropertyHasChanged( Property& prop, 
                                     bool                about_to_be_deleted );
	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    private:

	/** Copy constructor not allowed.
	 **/
	PropertyMap( PropertyMap const & );

    public:

	/** Default constructor creates an empty map.
	 **/
	OC_DSOAPI PropertyMap();

	/** Destructor cleans up temporary allocated Fields.
	 **/
	OC_DSOAPI virtual ~PropertyMap();

	/** \}
	 **/


	/** \name Operators
	 ** \{
	 **/

    private:

	/** Assignment operator not allowed.
	 **/
	PropertyMap & operator=( PropertyMap const & );

    public:

	/** Get a property.
	 **
	 ** \param name Name of the property.
	 ** \return Property if one exists with this name,
	 **         \c Property::Null otherwise.
	 **/
	OC_DSOAPI Property & operator[]( std::string const & name );

	/** Get a readonly property.
	 **
	 ** \param name Name of the property.
	 ** \return Property if property with this name exists,
	 **         \c Property::Null otherwise.
	 **/
	OC_DSOAPI Property const & operator[]( std::string const & name ) const;

	/** \}
	 **/


	/** \name Query Methods
	 ** \{
	 **/

    public:

	/** Query if property with name \a name exits.
	 **
	 ** \return \c true if property exists, \c false otherwise.
	 **/
	OC_DSOAPI bool HasProperty( std::string const & name) const;

	/** Query if property with name \a name exits and return the property.
	 **
	 ** \return The property if it exists, \c Property::Null otherwise.
	 **/
	OC_DSOAPI Property & HasPropertyRet( std::string const & name);

	/** Query if property with name \a name exits and return the property.
	 **
	 ** \return The property if it exists, \c Property::Null otherwise.
	 **/
	OC_DSOAPI const Property & HasPropertyRet( std::string const & name) const;

	/** The number of properties in the map is simple the map size.
	 **
	 ** \return Number of properties.
	 **/
	OC_DSOAPI int GetNumProperties() const;

        /** Get the i.th. property.
	 ** \param idx Index of property.
	 ** \return Property if existant,
	 **         \c Property::Null otherwise.
         **/
	OC_DSOAPI Property & GetProperty( unsigned int idx );
    
	/** Get the i.th. property readonly.
	 ** \param idx Index of property.
	 ** \return Property if existant,
	 **         \c Property::Null otherwise.
         **/
	OC_DSOAPI Property const & GetProperty( unsigned int idx ) const;

	/** \}
	 **/


	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** Add a new property \a p to map.
     ** An existing property with the same name will NOT be overwritten.
	 **
	 ** \param p Property to add 
	 ** \return \c true if property was added successfully,
	 **         \c false otherwise.
	 **/
	OC_DSOAPI bool AddProperty( Property const & p );

	/** Remove a property from the  map.
	 **
	 ** \param name name if Property to remove.
	 ** \return \c true if property was removed successfully,
	 **         \c false otherwise.
	 **/
	OC_DSOAPI bool RemoveProperty( std::string const & name );


	/** Add a new property that encapsulates the given object of type T.
	 **
	 ** \param name Name of the property.
	 ** \param aobject Pointer to object of type T.
         **/
	template <typename T>
	bool AddProperty( std::string const & name, T& aobject )
	{
	    Field * f = (Field *) new SFieldRef<T>( aobject );
	    AddProperty( Property( name, f ) );
        f->AddListener(this);

	    mTmpFields.push_back( f );

	    return true;
	}


	/** Add a new property that represents a copy to an object of type T.
	 **
	 ** \param name Name of the property.
	 ** \param aobject object of .
	 **/
	template <typename T>
	bool AddPropertyCopy( std::string const & name, T aobject )
	{
	    Field * f = (Field *) new SField<T>( aobject );

	    AddProperty( Property( name, f ) );
        f->AddListener(this);

	    mTmpFields.push_back( f );

	    return true ;
	}


        /** Add a property that represents a pointer to a callback method
         **/
 	template <typename T, typename S>
        bool AddPropertyCallback( std::string const & name, T classptr, S methodptr )
        {

            Field  *f0 = (Field *) new SField< T >( classptr );
            Field  *f1 = (Field *) new SField< S >( methodptr );
            MField *f2 = new MField();

            f2->AppendField( f0 );
            f2->AppendField( f1 );
            AddProperty( Property( name, f2 ) );
            (*this)[name].SetRTTICheck(false);

            mTmpFields.push_back( f0 );
            mTmpFields.push_back( f1 );
            mTmpFields.push_back( f2 );

            return true;
        }


	/** \}
	 **/


    

	/** \name I/O Methods
	 ** \{
	 **/

    public:

	/** Dump contents of map to output stream.
         **
	 ** \param out Output stream to print.
	 ** \return Ouput stream after print.
	 **/
	OC_DSOAPI std::ostream& DumpMap( std::ostream& out ) const;


    /** Serialization -  write propertymap to stream.
     **/
    OC_DSOAPI std::ostream& Write( std::ostream& out ) const;

    /** Deserialization -  read propertymap from stream.
     **/
    OC_DSOAPI std::istream& Read( std::istream& in );

    /** Serialization -  write propertymap to XML object.
     **/
    OC_DSOAPI bool Write( AdvXMLParser::Element& obj ) const;

    /** Deserialization -  read propertymap from XML object.
     **/
    OC_DSOAPI bool Read(AdvXMLParser::Element const& obj );


    /** Assign a name to the map - uniquely identifying it - .
     **/
    OC_DSOAPI void SetName( std::string const& );

    /** Query name from map.
     **/
    OC_DSOAPI std::string const& GetName() const;


	/** \}
	 **/

	/** \name Resource Methods
	 ** \{
	 **/

        /** Get a string (xml format) describing the global layout of the properties with resources.
         **/
        OC_DSOAPI std::string const& GetResourceLayout();

        /** Set a string (xml format ) describing the global layout of the properties with resources.
         **/
        OC_DSOAPI void SetResourceLayout( std::string const& layout_spec );



        /** How many rules are there?
         **/
        OC_DSOAPI int GetNumResourceRules() const;

        /** Get the idx.th rule.
         **/
        OC_DSOAPI PropertyResourceRule const& GetResourceRule(int idx) const;

        /** Add a rule.
         **/
        OC_DSOAPI void AddResourceRule(PropertyResourceRule const& rule);



        /** Sets the value of a Property to its PropertyResource's 'value' state-tag.
         **/
        OC_DSOAPI void EvalDefaults();

        /** Evaluate the rules.
         ** This checks the state of all PropertyResources that are used in
         ** a rule's condition and if the condition is true then the
         ** the state of all PropertyResources in the rule's action part
         ** is set.
         **/
        OC_DSOAPI void EvalRules();

        /** \}
         **/


    public:

	/** \name Iterator Methods
	 ** \{
	 **/

	/** Returns a bidrectional iterator for the first property.
	 **
	 ** \return Iterator position for the first property.
	 **
	 ** \see end(), iterator
	 **/
	OC_DSOAPI iterator begin();

	/** Returns a bidirectional iterator for the position after the
	 ** last property.
	 **
	 ** \return Iterator position after the last property.
	 **
	 ** \see begin(), iterator
	 **/
	OC_DSOAPI iterator end();

	/** Returns a bidrectional iterator for the first property for
	 ** constant property map instances.
	 **
	 ** \return Iterator position for the first property.
	 **
	 ** \see end(), const_iterator
	 **/
	OC_DSOAPI const_iterator begin() const;

	/** Returns a bidirectional iterator for the position after the
	 ** last property for constant property map instances.
	 **
	 ** \return Iterator position after the last property.
	 **
	 ** \see begin(), const_iterator
	 **/
	OC_DSOAPI const_iterator end() const;

#ifndef WIN32

	/** Returns a read/write reverse iterator that points to the last
	 ** property in the property map.
	 **
	 ** \return Iterator position of last property.
	 **
	 ** \see begin(), rend()
	 **/
	reverse_iterator rbegin();
	
	/** Returns a read/write reverse iterator that points to one before the
	 ** first property in a constant property map.
	 **
	 ** \return Iterator position before the first property.
	 **
	 ** \see begin(), iterator
	 **/
	reverse_iterator rend();

	/** Returns a read/write reverse iterator that points to the last
	 ** property in a constant property map.
	 **
	 ** \return Iterator position of last property.
	 **
	 ** \see begin(), rend()
	 **/
	const_reverse_iterator rbegin() const;
	
	/** Returns a read/write reverse iterator that points to one before the
	 ** first property in the property map.
	 **
	 ** \return Iterator position before the first property.
	 **
	 ** \see begin(), iterator
	 **/
	const_reverse_iterator rend() const;

#endif

	/** \}
	 **/

    }; // PropertyMap


    /** Global operator to dump contents of map to output stream.
     **
     ** \param out Output stream.
     ** \param map map to printed.
     ** \return Ouput stream after print.
     **/
    OC_DSOAPI std::ostream & operator<<( std::ostream & out,
                                           oc::PropertyMap const & map );

} // namespace oc


#endif


