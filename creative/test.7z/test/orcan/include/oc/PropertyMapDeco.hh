
#ifndef OC_PROPERTY_MAP_DECO_HH
#define OC_PROPERTY_MAP_DECO_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/PropertyMap.hh>


namespace oc
{

    /** This class decorates the template parameter class \a BaseClass with a
     ** property map and appropriated access methods. The base class must
     ** provide a default constructor and a virtual destructor. Because of
     ** subclassing all other constructors of the base class will get hidden.
     ** To initialize the base class use the Creator concept for the base class.
     ** Use this template class to give a set of classes the same property map
     ** behaviour. Because the property map wil be inserted as non static
     ** attribute each instance of the new class will have its own properties.
     ** If you want to have one single property map for all instances use
     ** PropertyMapStaticDeco instead.
     **
     ** \b Adds:
     **
     ** - Attribute: \c PropertyMap \c mProperties
     **
     ** - Method: \c GetProperties()
     **
     ** \b Example:
     **
     ** \code
     **
     ** // The interface class for a mesh.
     ** class IMesh;
     **
     ** // The interface class for a mesh generator.
     ** class IMeshGen;
     **
     ** // The interface class for a viewer.
     ** class IViewer;
     **
     ** // Add property map to classes IMesh and IMeshGen:
     ** typedef PropertyMapDeco< IMesh >    Mesh;
     ** typedef PropertyMapDeco< IMeshGen > MeshGen;
     **
     ** // Add static and non static property map to class Viewer:
     ** typedef PropertyMapStaticDeco< PropertyMapDeco< IViewer > > Viewer;
     **
     ** \endcode
     **
     ** \see PropertyMapStaticDeco
     **
     ** \author Michael Kellner
     ** \date 19.3.2003
     **
     ** \nosubgrouping
     **/
    template <class BaseClass>
    class PropertyMapDeco : public BaseClass
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** This is the property map that should be added to the base class.
	 **/
	PropertyMap mProperties;

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor calls the default constructor of the base
	 ** class and creates an empty property map.
	 **/
	PropertyMapDeco()
	    : BaseClass()
            , mProperties()
	{}

    private:

	/** The copy constructor is not allowed.
	 **/
	PropertyMapDeco( const PropertyMapDeco & );

    public:

	/** The destructor is empty.
	 **/
	virtual ~PropertyMapDeco()
	{}

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** Returns the properties.
	 **
	 ** \return The property map.
	 **/
	PropertyMap & GetProperties()
	{
	    return mProperties;
	}


	/** Returns the properties for a constant instance.
	 **
	 ** \return The property map.
	 **/
	const PropertyMap & GetProperties() const
	{
	    return mProperties;
	}

	/** \}
	 **/

        /** \name Adder
         ** \{
         **/

	/** Add a new property that encapsulates the given object of type T.
	 **
	 ** \param name Name of the property.
	 ** \param aobject Pointer to object of type T.
         **/
	template <typename T>
	bool AddProperty( std::string const & name, T& aobject )
        {
            return mProperties.AddProperty( name, aobject );
	}


	/** Add a new property that represents a copy to an object of type T.
	 **
	 ** \param name Name of the property.
	 ** \param aobject object of .
	 **/
	template <typename T>
	bool AddPropertyCopy( std::string const & name, T aobject )
	{
	    return mProperties.AddPropertyCopy( name, aobject );
	}


        /** Add a property that represents a pointer to a callback method
         **/
 	template <typename T, typename S>
        bool AddPropertyCallback( std::string const & name, T classptr, S methodptr )
        {
            return mProperties.AddPropertyCallback( name,  methodptr );
        }

        /** \}
         **/

    }; // class PropertyMapDeco



    /** This class decorates the template parameter class \a BaseClass with a
     ** property map and appropriated access methods. The base class must
     ** provide a default constructor and a virtual destructor. Because of
     ** subclassing all other constructors of the base class will get hidden.
     ** To initialize the base class use the Creator concept for the base class.
     ** Use this template class to give a set of classes the same property map
     ** behaviour.
     **
     ** \b Adds:
     **
     ** - Attribute: \c static \c PropertyMap \c msGlobalProperties
     **
     ** - Method: \c GetGlobalProperties()
     **
     ** \b Example:
     **
     ** \code
     **
     ** // The interface class for a mesh.
     ** class IMesh;
     **
     ** // The interface class for a mesh generator.
     ** class IMeshGen;
     **
     ** // The interface class for a viewer.
     ** class IViewer;
     **
     ** // Add property map to classes IMesh and IMeshGen:
     ** typedef PropertyMapDeco< IMesh >    Mesh;
     ** typedef PropertyMapDeco< IMeshGen > MeshGen;
     **
     ** // Add static and non static property map to class Viewer:
     ** typedef PropertyMapStaticDeco< PropertyMapDeco< IViewer > > Viewer;
     **
     ** \endcode
     **
     ** \see PropertyMapDeco
     **
     ** \author Michael Kellner
     ** \date 19.3.2003
     **
     ** \nosubgrouping
     **/
    template <class BaseClass>
    class PropertyMapStaticDeco : public BaseClass
    {

	/** \name Attributes
	 ** \{
	 **/

    protected:

	/** This is the \c static property map that should be added to the base
	 ** class.
	 **/
	static PropertyMap msGlobalProperties;

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor calls the default constructor of the base
	 ** class.
	 **/
	PropertyMapStaticDeco()
	    : BaseClass()
	{}

	/** The destructor is empty.
	 **/
	virtual ~PropertyMapStaticDeco()
	{}

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** Returns the static properties.
	 **
	 ** \return The property map.
	 **/
	static PropertyMap & GetGlobalProperties()
	{
	    return( msGlobalProperties );
	}

	/** \}
	 **/

    }; // PropertyMapStaticDeco


    template <class T>
    PropertyMap PropertyMapStaticDeco<T>::msGlobalProperties;

} // namespace oc


#endif

