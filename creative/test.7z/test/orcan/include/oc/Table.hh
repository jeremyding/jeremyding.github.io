
#ifndef OC_TABLE_HH
#define OC_TABLE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// -------

// ORCAN include

#include <oc/config.h>

// STL include

#include <string>
#include <vector>
#include <iostream>


namespace oc
{

    class OC_DSOAPI TableCell
    {
        std::string mStrVal;
    public:
        TableCell();
        TableCell(std::string const&);
        virtual ~TableCell();

        std::string const& GetStringValue() const;
        void SetStringValue(std::string const& str);
    };

    /** Table: Arrange values in rows and columns and Query and Change them.
     ** 
     ** \author Horst Hadler
     ** \date 8.2.2005
     **
     ** \nosubgrouping
     **/

    class OC_DSOAPI Table
    { 

    

	/** \name Attributes
	 ** \{
	 **/
    private:


        TableCell **mTable;
        uint8  mRowSep;
        uint8  mColSep;
        uint32 mNumRows;
        uint32 mNumCols;
        std::string mTitle;

	/** \}
	 **/

	/** \name Helpers
	 ** \{
	 **/
    private:

        /** cleanup table.
         **/
        void Destroy();

        /** parse input table in string form
         **/
        void Scan( std::string const& val );

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor. Creates an empty table with 0 rows and 0 columns. 
	 ** Use the Create() methods or another constructor for
	 ** initialization of the instance.
	 ** 
	 ** The comparision with Table::Null will return \c true for
	 ** an uninitialized instance.
	 **/
	Table();

	/** Initialize a table from a string value (like Scan). 
	 **/
    Table( std::string const& value);

	/** Initialize a table with the given number of rows and columns. 
	 **/
    Table( std::string const& title, int num_rows, int num_cols );

	/** Creates a new Table instance as copy from an existing instance.
	 **
	 ** \param table Existing instance
	 **/
	Table( const Table& table);

        /** Destructor
         **/
	virtual ~Table();

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

	/** Assigns a table object. After assignment a complete independent
	 ** copy of the assigned tabl object will exists in this instance.
	 **
	 ** \param table Table object assigned.
	 **/
	Table & operator=( const oc::Table & table );

	/** \}
	 **/

	/** \name Getter / Setter
	 ** \{
	 **/

    /** Set the table's number of rows (highest rows will be deleted first if the table's 'height' shrinks)
     **/
    void SetNumberOfRows( int num_rows );

    /** Set the table's number of columns (highest columns will be deleted first if the table's 'width' shrinks)
     **/
    void SetNumberOfCols( int num_cols );

        uint32 GetNumberOfRows() {return mNumRows;};

        uint32 GetNumberOfCols() {return mNumCols;};


    /** Set element at column col, row in string form
	 **/
	void SetCellStringValue( int col, int row, std::string const& val);

    /** Get element at column col, row row in string form
	 **/
	std::string const& GetCellStringValue(int row, int col) const;
    
    /** Set element at column col, row 
	 **/
	void SetCell( int col, int row, TableCell const&);

    /** Get element at column col, row 
	 **/
	TableCell const& GetCell(int col, int row) const;
    
    /** Set table's title.
     **/
    void SetTitle( std::string const& title );

    /** Get table's title.
     **/
    std::string const& GetTitle() const;


	/** \}
	 **/






	/** \name Helpers
	 ** \{
	 **/

    public:

    /** Set char that is used to separate columns if table is represented in string form (default ';').
     **/
    void SetColSeperatorChar( uint8 colsep );

    /** Set char that is used to separate rows if table is represented in string form (default ':').
     **/
    void SetRowSeperatorChar( uint8 colsep );


	/** Print table on stream.
	 ** \param out Stream on which the table will be printed.
	 **/
	virtual void Print( std::ostream & out ) const;

	/** Scan table from stream.
	 ** \param in Stream from which the table will be scanned.
	 **/
	virtual void Scan( std::istream & in );


	/** \}
	 **/

    };

    /** Output operator for the Table class. Internally it calls Table::Print().
     **/
    OC_DSOAPI std::ostream & operator<<( std::ostream & out, const oc::Table & table );

    /** Input operator for the Table class. Internally it calls Table::Scan().
     **/
    OC_DSOAPI std::istream & operator>>( std::istream & out, oc::Table & table );


} // namespace oc




#endif



