
#ifndef OC_OBJECT_FACTORY_INFO_HH
#define OC_OBJECT_FACTORY_INFO_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/PropertyMapDeco.hh>
#include <oc/config.h>

// C++ include

#include <string>
#include <sstream>


namespace oc
{

    /** This class is used to provide information about an object factory.
     **
     ** \author Michael Kellner
     ** \date   21.3.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI IObjectFactoryInfo
    {

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor is empty.
	 **/
	IObjectFactoryInfo();

	/** The copy constructor is empty.
	 **/
	IObjectFactoryInfo( const IObjectFactoryInfo & source );

	/** The destructor is empty.
	 **/
	virtual ~IObjectFactoryInfo();

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

	/** Returns the vendor string
	 **
	 ** \return Vendor string
	 **/
	virtual const std::string & GetVendor() const;

	/** Returns the version as integer values.
	 **
	 ** \param major Major version on return.
	 ** \param minor Minor version on return.
	 **/
	virtual void GetVersion( int & major, int & minor ) const;

	/** Returns the version as string value. This implementation uses
	 ** GetVersion( int &, int & ) and converts the version information
	 ** separated by a "." to a string value.
	 **
	 ** \return Version string
	 **/
	virtual const std::string & GetVersion() const;

	/** \}
	 **/

    }; // class IObjectFactoryInfo


    /** The ObjectFactoryInfo base class is the corresponding interface class
     ** decorated with a property map.
     **/
    typedef oc::PropertyMapDeco< IObjectFactoryInfo > ObjectFactoryInfo;

    /** A C-Pointer to an object factory info.
     **/
    typedef oc::CPtr<ObjectFactoryInfo> ObjectFactoryInfoPtr;


} // namespace oc


#endif

