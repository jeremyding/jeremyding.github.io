
#ifndef OC_CPTR_HH
#define OC_CPTR_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/NullPointerException.hh>

// C include

#include <cassert>



namespace oc
{

    /** This template class is a simple pointer class. It encapsulates a
     ** C pointer.
     **
     ** \b Example \b 1:
     **
     ** \code
     **
     ** float   a = 5.f;
     ** float * b = & a;
     **
     ** CPtr<float> aPtr( a );  // Use constructor CPtr<T>( T & )
     ** CPtr<float> bPtr( b );  // Use constructor CPtr<T>( T * )
     **
     ** *aPtr = 6.f; // change variable "a"
     ** *bPtr = 7.f; // change variable "a"
     **
     ** \endcode
     **
     ** \b Example \b 2:
     **
     ** \code
     **
     ** bool GetValue( float * value )
     ** {
     **     if( value == CPtr<float>::Null ) {
     **
     **         throw( NullPointerException )
     **     }
     ** }
     **
     **
     ** bool GetValue( CPtr<float> value )
     ** {
     **     if( value != CPtr<float>::NullPtr ) {
     **
     **         throw( NullPointerException )
     **     }
     ** }
     **
     **
     ** \endcode
     **
     ** \author Michael Kellner
     ** \date 5.3.2003
     **
     ** \nosubgrouping
     **/
    template <class T>
    class CPtr
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The C pointer to encapsulate.
	 **/
	T * mCPointer;

	/** \}
	 **/

    public:

	/** The C-Null pointer.
	 **
	 ** \see NullPtr
	 **/
	static T * const Null;

	/** The CPtr-Null pointer.
	 **
	 ** \see Null
	 **/
	static CPtr<T> const NullPtr;

	/** \name Constructors / Destructor
	 ** \{
	 **/
    public:

	/** This (default) constructor initialize the instance with the given
	 ** C-pointer \a cPointer (default: Null).
	 **
	 ** \param cPointer C-pointer to encapsulate.
	 **/
	CPtr( T * const cPointer = (T *) 0 )
	    : mCPointer( cPointer )
	{}

	/** This constructor initialize the instance with the address to the
	 ** given object \a object as C-pointer.
	 **/
	CPtr( T & object )
	    : mCPointer( & object )
	{}

	/** The copy constructor copies the encapsulated C-pointer.
	 **/
	CPtr( const CPtr & source )
	    : mCPointer( source.mCPointer )
	{}

	/** The destructor is empty.
	 **/
	~CPtr()
	{}

	/** \}
	 **/


	/** \name Accessors 
	 ** \{
	 **/

	/** Call the delete operator on the encapsulated C-pointer. It is valid
	 ** to call Delete() on a Null pointer.
	 **/
	void Delete()
	{

	    if( mCPointer != GetNull() ) {

		delete mCPointer;
		mCPointer = NULL;
	    }
	}

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** This assignment operator assigns another CPtr.
	 **
	 ** \param source The CPtr to assign.
	 ** \return Instance after assignment.
	 **/
	CPtr & operator=( const CPtr & source )
	{
	    mCPointer = source.mCPointer;

	    return( *this );
	}

	/** This assignment operator assigns a new C-pointer to the instance.
	 **
	 ** \param cPointer New C-pointer to assign.
	 ** \return Instance after assignment.
	 **/
	CPtr & operator=( T * const cPointer )
	{
	    mCPointer = cPointer;

	    return( *this );
	}

	/** This access operator returns the encapsulated C-pointer.
	 **
	 ** \return Encapsulated C-pointer.
	 **/
	T * operator->()
	{
	    return( mCPointer );
	}

	/** This access operator returns the encapsulated C-pointer
	 ** for an constant instance.
	 **
	 ** \return Encapsulated C-pointer.
	 **/
	const T * operator->() const
	{
	    return( mCPointer );
	}

	/** This access operator returns a C++-reference of the object to which
	 ** the encapsulate C-pointer reference to. No test to Null-pointer will
	 ** be done. If you access a CPtr::Null via this operator the program
	 ** will fail by a segmentation fault. Use GetRef() for a tested access.
	 **
	 ** \return C++-reference to pointed object.
	 **
	 ** \see GetRef()
	 **/
	T & operator*()
	{
	    assert( mCPointer != GetNull() );

	    return( * mCPointer );
	}

	/** This access operator returns a C++-reference of the object to which
	 ** the encapsulate C-pointer reference to. No test to Null-pointer will
	 ** be done. If you access a CPtr::Null via this operator the program
	 ** will fail by a segmentation fault. Use GetRef() for a tested access.
	 **
	 ** \return C++-reference to pointed object.
	 **
	 ** \see GetRef()
	 **/
	const T & operator*() const
	{
	    assert( mCPointer != GetNull() );

	    return( * mCPointer );
	}

	/** This negation operator checks whether the encapsulated C-pointer
	 ** is the NULL pointer.
	 **
	 ** \return \c true if the C-pointer is the NULL pointer,
	 **         \c false otherwise.
	 **/
	bool operator!() const
	{
	    return (mCPointer == GetNull());
	}

	/** Checks whether the encapsulated C-pointer is the NULL pointer.
	 **
	 ** \return \c true if the C-pointer is the NULL pointer,
	 **         \c false otherwise.
	 **/
	operator bool() const
	{
	    return (mCPointer != GetNull());
	}

	/** \}
	 **/

	/** \name Getter / Setter
	 ** \{
	 **/

	/** This method returns the encapsulated C-pointer.
	 **
	 ** \return Encapsulated C-pointer.
	 **/
	T * GetCPtr()
	{
	    return( mCPointer );
	}


	/** This method returns the encapsulated C-pointer for a constant
	 ** instance.
	 **
	 ** \return Encapsulated C-pointer.
	 **/
	const T * GetCPtr() const
	{
	    return( mCPointer );
	}

	/** This method returns a C++-reference of the object to which
	 ** the encapsulate C-pointer reference to. A test to Null-pointer will
	 ** be done and an exception will be thrown if you access a Null-pointer
	 ** thru this method.
	 **
	 ** \return C++-reference to pointed object.
	 **
	 ** \see operator*()
	 **/
	T & GetRef()
	    throw( NullPointerException )
	{
	    if( mCPointer == GetNull() ) {

		throw NullPointerException();
	    }

	    return( * mCPointer );
	}
        

	/** This method returns a C++-reference of the object to which
	 ** the encapsulate C-pointer reference to. A test to Null-pointer will
	 ** be done and an exception will be thrown if you access a Null-pointer
	 ** thru this method.
	 **
	 ** \return C++-reference to pointed object.
	 **
	 ** \see operator*()
	 **/

	const T & GetRef() const
	    throw( NullPointerException )
	{
	    if( mCPointer == GetNull() ) {

		throw NullPointerException();
	    }

	    return( * mCPointer );
	}

    /** Set the encapsulated C-pointer to the NULL pointer. No memory will
     ** be freed.
     **/
    void SetNull()
    {
        mCPointer = NULL;
    }

    /** Get Null.
     **/
    T* GetNull() const
    {
        return Null;
    }
    
    /** \}
    **/

	/** \name Query Methods
	 ** \{
	 **/

    public:

	/** Is the encapsulated C-pointer the NULL pointer?
	 **
	 ** \return \c true if the C-pointer is the NULL pointer,
	 **         \c false otherwise.
	 **/
	bool IsNull() const
	{
	    return( mCPointer == GetNull() );
	}

	/** \}
	 **/

    }; // CPtr


    /** Two pointers are equal if there C-pointers are equal, also
     ** if they are both NULL.
     **/
    template <class T>
    bool operator==( const CPtr<T> & left, const CPtr<T> & right )
    {
	return( left.GetCPtr() == right.GetCPtr() );
    }

    /** Two pointers differ if there C-pointers differ.
     **/
    template <class T>
    bool operator!=( const CPtr<T> & left, const CPtr<T> & right )
    {
	return( left.GetCPtr() != right.GetCPtr() );
    }


	/** Dump ptr's contents to ostream.
     **/

    template <class T>
    std::ostream& operator << (std::ostream& out, CPtr<T> const& cptr ) 
    {
        return (out << std::string( "CPtr=" ) <<  cptr.GetCPtr());
    }

    // Initialize static attributes
    // ----------------------------

    template <class T>
    T * const CPtr<T>::Null = (T *) 0;

    template <class T>
    CPtr<T> const CPtr<T>::NullPtr;


} // namespace oc



#endif
