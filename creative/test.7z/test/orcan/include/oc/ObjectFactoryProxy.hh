
#ifndef OC_OBJECT_FACTORY_PROXY_HH
#define OC_OBJECT_FACTORY_PROXY_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/ObjectFactory.hh>
#include <oc/ObjectFactoryTrait.hh>
#include <oc/config.h>


namespace oc
{


    /** This class provides a proxy mechanism for all object factories of kind
     ** ObjectFactory. A proxy is a surrogate or placeholder for another object
     ** to control access to it. The aim of this proxy is to retard the creation
     ** of an object factory until it is needed by the application. This has for
     ** example for the DynamicLoadModule class the advantage that the module
     ** will only be loaded if is is actual needed. This mechanism makes the
     ** application lightweighted and allows to run the application on platforms
     ** which didn't support all necessary features, i. e. OpenGL for
     ** visualization, but can execute a special kind of task, i. e. number
     ** crunching, very efficiently.
     **
     ** To use this class you do not have to make a subclass of it, instead you
     ** have to provide a specification, a subclass of ObjectFactoryTrait, for
     ** your object factory (see the example). This specification describes your
     ** object factory and is able to create an instance of your object factory
     ** out of this description. Now you can use this proxy as like as the
     ** original object factory. The code looks nearly the same but the
     ** application has the above mentioned advantages.
     **
     ** At the point in time that the embedded object factory must be created
     ** the method Connect() will automatically be called. This can be to late
     ** for error checking and so you can either call Connect() explicitly at
     ** an earlier point or you can use the method CanConnect() to test for it.
     **
     ** All instances allocated by the object factory (proxy) must be deleted by
     ** the object factory (proxy) before the factory (proxy) get destroyed.
     ** Otherwise the application may become unstable.
     ** 
     ** \b Design \b Pattern: Proxy
     **
     ** E. Gamma, R. Helm, R. Johnson, J. Vlissides, \e Design \e Patterns,
     ** Elements of Reusable Object-Oriented Software, Addison Wesley, 1995,
     ** p: 207-217.
     **
     ** \see ObjectFactoryTrait, DynamicLoadModule, ObjectFactory
     **
     ** \author Michael Kellner
     ** \date 5.3.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI ObjectFactoryProxy : public ObjectFactory
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The specification of the embedded object factory \c mRealFactory.
	 **
	 ** \see ObjectFactoryProxy( const ObjectFactoryTrait & ),
	 **      Create( const ObjectFactoryTrait & )
	 **/
        oc::ObjectFactoryTraitPtr mFactoryTraitPtr;

	/** The embedded object factory. An instance will only be created if
	 ** the application uses one of the access methods for creation or
	 ** deletion of objects or calls Connect() explicitly.
	 **
	 ** \see Connect(), Disconnect(), IsConnected()
	 **/
	oc::ObjectFactoryPtr mRealFactoryPtr;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor leaves the instance uninitialized. Use
	 ** the Create() method to initialize the instance at a later date.
	 **
	 ** \see Create()
	 **/
	ObjectFactoryProxy();

	/** Creates a proxy for an object factory described by the specification
	 ** \c trait.
	 **
	 ** \param trait Specification of the embedded object factory.
	 **/
	ObjectFactoryProxy( const ObjectFactoryTrait & trait );

    private:

	/** The copy constructor is not allowed because it would let to an
	 ** inconsistent state.
	 **
	 ** \param source Not used.
	 **/
	ObjectFactoryProxy( const ObjectFactoryProxy & source );

    public:

	/** The destructor deletes the embedded object factory \c mRealFactory.
	 ** All instances allocated by the object factory (proxy) must be deleted by
	 ** the object factory (proxy) before the factory (proxy) get destroyed.
	 ** Otherwise the application may become unstable.
	 **/
	virtual ~ObjectFactoryProxy();

	/** \}
	 **/


	/** \name Creators
	 ** \{
	 **/

    public:

	/** Use this creator to initialize an instance which was created by the
	 ** default constructor.
	 **
	 ** \param trait Specification of the embedded object factory.
	 ** \return \c true if the embedded object factory not yet created,
	 **         \c false otherwise.
	 **
	 ** \see ObjectFactoryProxy()
	 **/
	bool Create( const ObjectFactoryTrait & trait );

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    private:

	/** The assignment operator is not allowed because it would let to an
	 ** inconsistent state.
	 **
	 ** \param source Not used.
	 ** \return Invalid.
	 **/
	ObjectFactoryProxy & operator=( const ObjectFactoryProxy & source );

	/** \}
	 **/


	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** This method creates the embedded object factory. You don't need to
	 ** call this method explicitly, it will be called automatically if it
	 ** is needed, i. e. if one of the methods for creation of deletion of
	 ** objects will be invoked. If you want to check whether the
	 ** application is able to create the object factory described by the
	 ** specification use CanConnect().
	 **
	 ** \return \c true if the embedded object factory could be created
	 **         successfully, \c false otherwise.
	 **
	 ** \see CanConnect()
	 **/
	virtual bool Connect();

	/** This method deletes the embedded object factory. All instances
	 ** allocated by the object factory (proxy) must be deleted by the
	 ** object factory (proxy) before the factory (proxy) get destroyed.
	 ** Otherwise the application may become unstable.
	 **
	 ** \return \c true if the embedded object factory could be deleted
	 **         successfully, \c false otherwise.
	 **/
	virtual bool Disconnect();

	/** This method can be used to allocate a new instance of the class
	 ** named \e className.
	 **
	 ** \param  className An object of this class will be created.
	 ** \return Pointer to allocated instance on success, \c NULL on
	 **         failure.
	 **
	 ** \see ObjectFactory::NewObjectV(), NewObject()
	 **/
	virtual void * NewObjectV( const std::string & className );

	/** This template method should be used to allocate a new instance
	 ** of the class \e ClassT named \e className.
	 **
	 ** \param  className An object of this class will be created.
	 ** \param  instance  The allocated instance on success, \c NULL on
	 **                   failure.
	 ** \return \c true on success, \c false on failure
	 **
	 ** \see ObjectFactory::NewObject(), NewObjectV()
	 **/
	template <typename ClassT>
	bool NewObject( const std::string & className, oc::CPtr<ClassT> & instance )
	{

	    // Welcome to the proxy:
	    // Create the real object factory not until we need it
	    // and now we need it.
	    if( ! IsConnected() ) {
		if( ! Connect() ) {
		    return( false );
		}
	    }

	    return( GetRealFactory().NewObject( className, instance ) );
	}


	/** This method can be used to delete via NewObject() for NewObjectV()
	 ** previously allocated instances.
	 **
	 ** \param className An object of this class will be deleted.
	 ** \param instance  The previously allocated instance to delete.
	 ** \return \c true on success, \c false on failure
	 **
	 ** \see ObjectFactory::DelObjectV(), DelObject()
	 **/
	virtual bool DelObjectV( const std::string & className,
				 const void        * instance );


	/** This method can be used to delete via NewObject() previously
	 ** allocated instances.
	 **
	 ** \param className An object of this class will be deleted.
	 ** \param instance  The previously allocated instance to delete.
	 ** \return \c true on success, \c false on failure
	 **
	 ** \see ObjectFactory::DelObject(), DelObjectV()
	 **/
    	template <typename ClassT>
	bool DelObject( const std::string       & className,
			const oc::CPtr<ClassT> & instance )
	{

	    // Nothing to delete.
	    if( instance == (ClassT *) NULL ) {
		return( false );
	    }

	    // Welcome to the proxy:
	    // Create the real object factory not until we need it
	    // and now we need it.
	    if( ! IsConnected() ) {
		if( ! Connect() ) {
		    return( false );
		}
	    }

	    return( GetRealFactory().DelObject( className, instance ) );
	}


        /** \}
	 **/


        /** \name Query Methods
	 ** \{
	 **/

    public:

	/** Checks whether the object factory described by the specification
	 ** can be created. The method tries to create the real object factory
	 ** and deletes it immediatly afterward except \e keepConnection is set
	 ** to \c true.
	 **
	 ** \param keepConnection Deletes the object factory immediate after
	 **                       creation if set to \c false.
	 ** \return \c true if the object factory could be created successfully,
	 **         \c false otherwise.
	 **
	 ** \see Connect(), Disconnect()
	 **/
	virtual bool CanConnect( bool keepConnection = false);

	/** Checks whether the real object factory \c mRealFactory is already
	 ** created. The real object factory will be created either implicitly,
	 ** if one of the method for creation or deletion of an object was
	 ** invoked or explicitly by a call to Connect().
	 **
	 ** \return \c true if the real object factory exists, \c false
	 **         otherwise.
	 **
	 ** \see Connect(), Disconnect()
	 **/
	virtual bool IsConnected();

        /** \}
	 **/


        /** \name Getters / Setter
	 ** \{
	 **/

    protected:

	/** GetRealFactory()
	 **/
        ObjectFactory & GetRealFactory();

    }; // ObjectFactoryProxy


    /** Pointer to an object factory proxy.
     **/
    typedef oc::CPtr< oc::ObjectFactoryProxy > ObjectFactoryProxyPtr;

} // namespace oc


#endif


