
#ifndef OC_DLM_OBJECT_FACTORY_TRAIT_HH
#define OC_DLM_OBJECT_FACTORY_TRAIT_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>
#include <oc/ObjectFactoryTrait.hh>
#include <oc/config.h>

// C++ include

#include <string>


namespace oc
{

    /** This concrete class of a object factory specification describes a
     ** dynamic loadable module. Dynamic loadable modules are shared object
     ** libraries \b .so under UNIX and dynamic link libraries \b .dll under
     ** Windows. All kinds of dynamic loadable modules are common that they
     ** are saved in a file \c mLibrary in the file system that can be loaded
     ** during runtime to the program kernel when ever it is needed.
     **
     ** Because this class allocates resources thru the NewObjectFactory()
     ** method you should free this resource thru the DelObjectFactory() method.
     ** The class itself has no mechanism to free this resources automatically
     ** when the specification object will be destroyed. This means, if the
     ** specification of an object factory will get destroyed no factory which
     ** was created by this specification object will also be destroyed. It is
     ** in the responsibility of the user of the object factory specification
     ** that all resources will be released if they are no longer needed.
     **
     ** \b Example:
     **
     ** \code
     **
     ** // The specification for a dynamic loadable module
     ** DLMObjectFactoryLink moduleLink( "Mesh.so" );
     **
     ** // Create object factory; this will implicit load the module
     ** ObjectFactory * factory = moduleLink.NewObjectFactory();
     **
     ** if( factory != ObjectFactory::NullPtr ) {
     **
     **     // Create mesh instance in loaded module
     **     Mesh * mesh = static_cast<the_class *>((factory).NewObjectV( #Mesh ));
     **
     **     // Do something with the mesh ...
     **
     **     // Delete mesh instance
     **    factory.DelObject( #Mesh, mesh );
     **
     **    // Delete object factory
     **    moduleLink.DelObjectFactory( factory );
     ** }
     **
     ** \endcode
     **
     ** \see DynamicLoadModule
     **
     ** \author Michael Kellner
     ** \date 3.3.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI DLMObjectFactoryTrait : public ObjectFactoryTrait
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The file name of the dynamic loadable library.
	 **/
	oc::File mLibrary;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor didn't initialize the instance. To
	 ** initialize the instance afterwards use the Creator Create().
	 **
	 ** \see Create()
	 **/
	DLMObjectFactoryTrait();

	/** Initialize the instance with the file name of the dynamic loadable
	 ** library. This file name is automatically the name of the object
	 ** factory trait (ObjectFactoryTrait::GetName()).
	 **
	 ** \param library File name of the dynamic loadable library.
	 ** \see Create(), ObjectFactoryTrait
	 **/
	DLMObjectFactoryTrait( const oc::File & library );

	/** The copy constructor initialize the instance as copy from an already
	 ** existant specification \c source.
	 **
	 ** \param source Specification object from which a copy will be made
	 **               off.
	 **/
	DLMObjectFactoryTrait( const DLMObjectFactoryTrait & source );

	/** The destructor didn't release any resources allocated thru this
	 ** instance. That means, if one creates a new object factory via
	 ** NewObjectFactory() one is responsible for freeing this resource
	 ** via DelObjectFactory(). This class did not release any resources
	 ** by itself.
	 **
	 ** \see NewObjectFactory(), DelObjectFactory()
	 **/
	virtual ~DLMObjectFactoryTrait();

	/** \}
	 **/

	/** \name Creators
	 ** \{
	 **/

    public:

	/** Initialize the instance with the file name of the dynamic loadable
	 ** library. This file name is automatically the name of the object
	 ** factory trait (ObjectFactoryTrait::GetName()).
	 **
	 ** \param library File name of the dynamic loadable library.
	 ** \see DLMObjectFactoryTrait( const oc::File & )
	 **/
	bool Create( const oc::File & library );

	/** Initialize the instance with the file name of the dynamic loadable
	 ** library. This file name is automatically the name of the object
	 ** factory trait (ObjectFactoryTrait::GetName()).
	 **
	 ** \param library File name of the dynamic loadable library.
	 ** \see DLMObjectFactoryTrait( const oc::File & )
	 **/
	bool Create( const std::string & library );

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** The assignment operator overwrites a specification with another
	 ** specification \c trait.
	 **
	 ** \param trait The specification which overwrites this one.
	 ** \return The overwritten specification.
	 **/
	DLMObjectFactoryTrait & operator=( const DLMObjectFactoryTrait & trait );

	/** \}
	 **/

	/** \name Getter / Setter
	 ** \{
	 **/

	/** Get the file name of the dynamic loadable library.
	 **
	 ** \return The file name of the dynamic loadable library.
	 **/
	const oc::File & GetLibrary() const;

	/** \}
	 **/

	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** Create a copy of the current dynamic loadable module specification.
	 **
	 ** \return Copy of the current specification or
	 **         \c ObjectFactoryTrait::NullPtr on failure.
	 **/
	virtual ObjectFactoryTrait * Clone() const;

	/** Create a dynamic loadable module from the specification. Internally
	 ** the file with dynamic loadable library will get loaded and the
	 ** pointer to the encapsulated DynamicLoadModule instance will be
	 ** returned. You can \c static_cast<>() this pointer to
	 ** \c DynamicLoadModule \c * savely. It is in the responsibility of the
	 ** user that all object factories will be destroyed via
	 ** \c DelObjectFactory().
	 **
	 ** \b Example:
	 **
	 ** \code
	 **
	 ** ObjectFactoryTrait moduleTrait( "Mesh.so" );
	 **
	 ** DynamicLoadModule module = static_cast<DynamicLoadModule *>( moduleTrait.NewObjectFactory() );
	 **
	 ** \endcode
	 **
	 ** \return Instance of a dynamic loadable module on success or
	 **         \c ObjectFactory::NullPtr on failure.
	 ** \see DelObjectFactory()
	 **/
	virtual ObjectFactory * NewObjectFactory() const;

	/** Releases a previously via NewObjectFactory() allocated dynamic
	 ** loadable module. No check for correct factory type will be performed.
	 ** It is in the responsibility of the user that only instance of object
	 ** factories will be delete which are allocated by this specification.
	 **
	 ** \param factory The instance of the object factory that should
	 **                be deleted.
	 ** \return \c true if the instance is of correct type and the resources
	 **         could be freed, \c false otherwise.
	 ** \see NewObjectFactory()
	 **/
	virtual bool DelObjectFactory( const ObjectFactory * factory ) const;

	/** \}
	 **/

    }; // class DLMObjectFactoryTrait

    /** A C-pointer to dynamic load module object factory trait.
     **/
    typedef oc::CPtr<DLMObjectFactoryTrait> DLMObjectFactoryTraitPtr;

} // namespace oc




#endif

