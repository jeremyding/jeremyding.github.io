
#ifndef OC_OBJECT_BROKER_HH
#define OC_OBJECT_BROKER_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Log.hh>
#include <oc/CPtr.hh>
#include <oc/ObjectFactoryProxy.hh>
#include <oc/ObjectBrokerConfig.hh>

// C++ include

#if defined(_MSC_VER) && (_MSC_VER < 1300)
# include <oc/hash_map.hh>
#else
# include <map>
#endif

#include <string>





namespace oc
{

    /** All "important" objects - the components of the application - can
     ** only instantiated from this object broker. The software architecture
     ** was designed that the application itself did not known where the
     ** components came from, where they are located in the network and how
     ** they can be instantiated. The application did not have to take care of
     ** this. All of the object management will be done by corresponding
     ** object factories (see ObjectFactory). There are various kinds and
     ** instances of object factories conceivable. For this reason the object
     ** broker - as singleton pattern designed - is the single unique instance
     ** where the application can aquire components.
     **
     ** To create an new object instance, lets say a volumetric mesh object,
     ** simply call the corresponding New*() method, i. e. NewVolMesh(). If
     ** you want a special implementation of this object you have to specify
     ** it thru \a realizationName. The object broker tries to instantiate
     ** an object of exact this type. If no such a realization is available
     ** it falls back to the default one, that is the first object of this
     ** type which is given by the object broker config.
     **
     ** \b Adding \b new \b objects:
     **
     ** Simple use the macros like BEGIN_COMPONENT() and END_COMPONENT().
     **
     ** \b Design \b Pattern: Singleton
     **
     ** E. Gamma, R. Helm, R. Johnson, J. Vlissides, \e Design \e Patterns,
     ** Elements of Reusable Object-Oriented Software, Addison Wesley, 1995,
     ** p: 127-138.
     **
     ** \author Michael Kellner
     ** \date 03.4.2003
     **
     ** \nosubgrouping
     **/
    class ObjectBroker
    {

	/** \name Class Types
	 ** \{
	 **/

    protected:


	/** This small object description class holds all necessary information
	 ** to an object and its creation process.
	 **/
	class ObjectDesc
	{

	    /** \name Attribute
	     ** \{
	     **/

	public:

	    /** Object characteristic description.
	     **/
	    oc::ObjectTraitPtr mObjectTraitPtr;

	    /** Object factory for this object is a proxy to the real factory.
	     **/
	    oc::ObjectFactoryPtr mObjectFactoryPtr;

	    /** \}
	     **/

	    /** \name Constructors / Destructor
	     ** \{
	     **/

	public:

	    /** Default constructor
	     **/
	    ObjectDesc()
		: mObjectTraitPtr(),
		  mObjectFactoryPtr()
	    {}

	    /** Copy constructor
	     **/
	    ObjectDesc( const ObjectDesc & source )
		: mObjectTraitPtr  ( source.mObjectTraitPtr   ),
		  mObjectFactoryPtr( source.mObjectFactoryPtr )
	    {}

	    /** Destructor
	     **/
	    ~ObjectDesc()
	    {
		if( ! mObjectFactoryPtr.IsNull() ) {
		    mObjectFactoryPtr.Delete();
		}
	    }

	    /** \}
	     **/

	}; // class ObjectDesc


	/** Map of all served objects (not instances!).
	 **/
#if defined(_MSC_VER) && (_MSC_VER < 1300)
    typedef oc::hash_map< std::string, ObjectDesc * > mtObjectMap;
#else
    typedef std::map< std::string, ObjectDesc * > mtObjectMap;
#endif
	/** \}
	 **/

	/** \name Attributes
	 ** \{
	 **/

    private:

        /** The object broker config.
	 **/
	oc::ObjectBrokerConfigPtr mConfigPtr;

	/** The map of all objects.
	 **/
	mtObjectMap mObjects;

    public:

	/** The default configure XML file containing the module files
	 ** and module path specifications.
	 **/
	OC_DSOAPI static oc::File msDefaultConfigFile;

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    protected:

	/** Default constructor is protected because this class follows the
	 ** singleton pattern. To access the single instance use \c Self().
	 **
	 ** \see Self()
	 **/
	ObjectBroker();

    private:

	/** Copy constructor not allowed.
	 **/
	ObjectBroker( const ObjectBroker & source );

    public:

	/** The destructor removes all object factories.
	 **/
	OC_DSOAPI ~ObjectBroker();

	/** \}
	 **/


	/** \name Operators
	 ** \{
	 **/

    private:

	/** Assignment operator not allowed.
	 **/
	OC_DSOAPI ObjectBroker & operator=( const ObjectBroker & assignee );

	/** \}
	 **/

	/** \name Static Methods
	 ** \{
	 **/

    public:

	/** Returns the singleton instance.
	 **/
	OC_DSOAPI static ObjectBroker & Self();

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** Set the object broker config which knowns everything about available
	 ** objects and object factories.
	 **/
	OC_DSOAPI bool SetConfig( const oc::ObjectBrokerConfigPtr & config );

	/** Get the object broker config which knowns everything about available
	 ** objects and object factories.
	 **/
	OC_DSOAPI oc::ObjectBrokerConfigPtr GetConfig();

	/** Returns the module name which creates objects of the given kind.
	 **/
	OC_DSOAPI std::string GetModuleName( const std::string & componentName );

	/** \}
	 **/

	/** \name Creation Methods
	 ** \{
	 **/

    public:

	/** Generic method to create an object. If a realization name is given
         ** it creates an object of exact this type if possible. If no object
         ** with this realization could be found a default object will be
	 ** instantiated (see ObjectBrokerConfig::SetDefault()). Do not use this
         ** method directly, instead use the wrapper methods. For each object
         ** type there is such a wrapper method available, e. g. for surface
         ** meshes NewSurfMesh().
	 ** 
	 ** \param objectRef       [OUT] Reference to created object.
	 ** \param realizationName [IN]  If given, try to instantiate an object
	 **                              with exact this realization.
	 ** \return Reference to instance.
	 **/
        template < class CRef >
        bool NewObject( CRef & objectRef, const std::string & realizationName = "" )
        {

	    // Search for the object description for this object. At the end
	    // we should find one in the local object map or we will have create
	    // a new one from an object trait received from the object broker
	    // config.
	    ObjectDesc * objectDescPtr;

	    // 1. Step: If we alread have an instance of this object created
	    //          we will find the object in the object map.
	    // -------------------------------------------------------------
	    mtObjectMap::iterator pos = mObjects.find( CRef::GetName() );

	    // Object found and, optionally, it has the same realization or is
	    // still the default realization.
            if( ( pos != mObjects.end()      ) &&
                ( ( realizationName.empty() &&
                    ( pos->second->mObjectTraitPtr == mConfigPtr->GetDefault( CRef::GetName() ) )
                    ) ||
                  ( pos->second->mObjectTraitPtr->GetRealizationName() == realizationName )
                  )
                ) {
            
                OCDEBUG( "Object found in object map." );
                objectDescPtr = pos->second;
            }

	    // 2. Step: We create an instance of this object for the first time.
	    // -----------------------------------------------------------------
	    else {
		oc::ObjectTraitPtr objectTraitPtr;

		// Use the default realization for this component
		if( realizationName.empty() ) {

		    objectTraitPtr = mConfigPtr->GetDefault( CRef::GetName() );

		    if( objectTraitPtr.IsNull() ) {

			OCDEBUG( "No object for \"" << CRef::GetName() << "\" available." );
			return objectRef;
		    }
		}

		// Forward request to object broker config.
		else {

		    oc::ObjectBrokerConfig::mtObjectTraitVector objectTraitVector =
			mConfigPtr->Find( CRef::GetName(), realizationName );

		    // Object broker config also didn't know anything about it.
		    if( objectTraitVector.empty() ) {

			OCDEBUG( "No object for \"" << CRef::GetName() << "\" available." );
			return objectRef;
		    }

		    // If there are more than one realizations then use the first one.
		    objectTraitPtr = objectTraitVector[0];
		}

		// Add found object trait to local object map.
		objectDescPtr = new ObjectDesc;

		objectDescPtr->mObjectTraitPtr   = objectTraitPtr.GetCPtr();
		objectDescPtr->mObjectFactoryPtr = new oc::ObjectFactoryProxy( * (objectTraitPtr->GetObjectFactoryTrait() ) );

		mObjects.insert( std::make_pair( CRef::GetName(), objectDescPtr ) );
				  
	    }

	    // Create new instance
	    typename CRef::ObjectPtr instance;

	    objectDescPtr->mObjectFactoryPtr->NewObject( CRef::GetName(), instance );

            if( instance.IsNull() ) {

                OCDEBUG( "Can't create instance of object \"" << CRef::GetName() << "\"." );
                return objectRef;
            }

	    // Encapsulate instance in object reference
	    objectRef.Create( instance,
			      objectDescPtr->mObjectTraitPtr,
			      objectDescPtr->mObjectFactoryPtr );


            return objectRef;
        }

	/** Generic method to create an object of type \p componentName. If a realization
	 ** name is given it creates an object of exact this type if possible. If
	 ** no object with this realization could be found a default object will be
	 ** instantiated (see ObjectBrokerConfig::SetDefault()). Do not use this method
	 ** directly, instead use the wrapper methods. For each object type there is such
         ** a wrapper method available, e. g. for surface meshes NewSurfMesh().
	 ** 
	 ** \param componentName   [IN]  Object name to instantiate.
	 ** \param realizationName [IN]  If given, try to instantiate an object
	 **                              with exact this realization.
	 ** \return Reference to instance.
	 **/
	template< class T, class TRef >
        TRef
        NewObject( const std::string & componentName,
                   const std::string & realizationName = "" )
	{

            TRef objectRef;

	    // Search for the object description for this object. At the end
	    // we should find one in the local object map or we will have create
	    // a new one from an object trait received from the object broker
	    // config.
	    ObjectDesc * objectDescPtr;

	    // 1. Step: If we alread have an instance of this object created
	    //          we will find the object in the object map.
	    // -------------------------------------------------------------
	    mtObjectMap::iterator pos = mObjects.find( componentName );

	    // Object found and, optionally, it has the same realization or is
	    // still the default realization.
	    if( ( pos != mObjects.end()      ) &&
		( ( realizationName.empty() &&
		    ( pos->second->mObjectTraitPtr == mConfigPtr->GetDefault(componentName) )
		  ) ||
		  ( pos->second->mObjectTraitPtr->GetRealizationName() == realizationName )
                )
	      ) {

                OCDEBUG( "Object found in object map." );
		objectDescPtr = pos->second;
	    }

	    // 2. Step: We create an instance of this object for the first time.
	    // -----------------------------------------------------------------
	    else {
		oc::ObjectTraitPtr objectTraitPtr;

		// Use the default realization for this component
		if( realizationName.empty() ) {

		    objectTraitPtr = mConfigPtr->GetDefault( componentName );

		    if( objectTraitPtr.IsNull() ) {

			OCDEBUG( "No object for \"" << componentName << "\" available." );
			return objectRef;
		    }
		}

		// Forward request to object broker config.
		else {

		    oc::ObjectBrokerConfig::mtObjectTraitVector objectTraitVector =
			mConfigPtr->Find( componentName, realizationName );

		    // Object broker config also didn't know anything about it.
		    if( objectTraitVector.empty() ) {

			OCDEBUG( "No object for \"" << componentName << "\" available." );
			return objectRef;
		    }

		    // If there are more than one realizations then use the first one.
		    objectTraitPtr = objectTraitVector[0];
		}

		// Add found object trait to local object map.
		objectDescPtr = new ObjectDesc;

		objectDescPtr->mObjectTraitPtr   = objectTraitPtr.GetCPtr();
		objectDescPtr->mObjectFactoryPtr = new oc::ObjectFactoryProxy( * (objectTraitPtr->GetObjectFactoryTrait() ) );

		mObjects.insert( std::make_pair( componentName, objectDescPtr ) );
				  
	    }

	    // Create new instance
	    oc::CPtr<T> instance;

	    objectDescPtr->mObjectFactoryPtr->NewObject( componentName, instance );

            if( instance.IsNull() ) {

              OCDEBUG( "Can't create instance of object \"" << componentName << "\"." );
              return objectRef;
            }

	    // Encapsulate instance in object reference
	    objectRef.Create( instance,
			      objectDescPtr->mObjectTraitPtr,
			      objectDescPtr->mObjectFactoryPtr );

	    return objectRef;
	    
	}

	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

	/** Checks whether the object broker can create a component with the
	 ** given realization. If the method returns \c true an instance of
	 ** the component can be created via New<component>(realizationName).
	 **
	 ** \b Note:
	 **
	 ** The namespace in which the realization is defined is part of the
	 ** realization name. E.g.
	 ** \code
         **   HasRealization( "VolMeshGen", "VolMeshGenGR" )
         ** \endcode
	 ** will return \c false, but
	 ** \code
	 **   HasRealization( "VolMeshGen", "VolMeshGenGR" )
	 ** \endcode
	 ** will return \c true.
	 **
	 ** \param componentName   [IN] Component for which a realization should
	 **                             be looked up.
	 ** \param realizationName [IN] Searched realization.
	 ** \return \c true if the object broker can create a component with
	 **         the given realization, \c false otherwise.
	 **/
	OC_DSOAPI bool HasRealization( const std::string & componentName,
			     const std::string & realizationName );

	/** \}
	 **/

    }; // class ObjectBroker

    /** A C-pointer to the object broker.
     **/
    typedef oc::CPtr< ObjectBroker > ObjectBrokerPtr;

} // namespace oc

#endif

