
#ifndef OC_SFIELD_HH
#define OC_SFIELD_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Field.hh>



namespace oc
{

    /** Field containing a single value of type T.
     ** 
     ** Note that SField always stores the copy of a value
     ** while SFieldRef stores a pointer to a value.
     ** \code
     **
     ** //difference between SField and SFieldRef
     **
     ** float f=1.f;
     ** SField<float>    v( f );
     ** SFieldRef<float> r( f );
     ** 
     ** v = 2.f; // f is still 1.f
     ** r = 3.f; // f is 3.f
     **
     ** \endcode
     **
     ** \see Field
     **
     ** \author Horst Hadler
     ** \date 6.3.2003
     **
     ** \nosubgrouping
     **/
    template <class T>
    class SField : public Field
    {

	/** \name Attributes
	 ** \{
	 **/

    private:
    
	/** The field value.
	 **/
	T mValue;

	/** \}
	 **/

        /** \name Constructors / Destructor
         ** \{
	 **/
    
    private:
        
	/** Hidden default constructor
	 **/
	SField();

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/
    
    public:
        
	/** Create field with value given.
	 **
	 ** \param v Value assigned to this field.
	 **/
	SField( T v );

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    private:

	/** Get the reference to the contained field value.
	 **
	 ** \return Pointer to field value
	 **/
	virtual void * GetReference();

    public:

	/** Get Field type.
	 **
	 ** \return Type info of contained field value.
	 **/
	virtual inline const std::type_info & GetType() const;
    
	/** Get reference to value.
	 **
	 ** \param f Field from which the value reference should be returned.
	 ** \return Reference to contained value.
	 **/
	static T & GetRef( Field * f );
    
	/** Get Field value as string.
	 **
	 ** \return Contained field value as string.
	 **/
	virtual inline std::string GetStringValue() const;


	/** \}
	 **/
    

	/** \name Query Methods
	 ** \{
	 **/

    public:

	/** Returns \c true if field is a reference-field i.e. when it stores
	 ** a pointer to a value.
	 **
	 ** \return \c true if field is a reference-field, \c false otherwise.
	 **/
	virtual bool IsRef();

	/** \}
	 **/

    }; // template <class T> class SField

} // namespace oc


// Include the template implementation

#include "SField.in"


#endif


