
#ifndef OC_COMPONENT_HH
#define OC_COMPONENT_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/CPtr.hh>
#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyMapDeco.hh>
#include <oc/PropertyMapResourceHandler.hh>
#include <oc/ObjectBroker.hh>
#include <oc/ComponentRef.hh>
#include <oc/ComponentListenerContainer.hh>

// C++ include

#include <string>


namespace oc
{
   

    // ==================
    // COMPONENT template
    // ==================


    /** The template class to declare an OC component. Do not use this class
     ** directly, use the macros for component declarations instead:
     **
     ** \li OC_BEGIN_COMPONENT()
     ** \li OC_END_COMPONENT()
     ** \li OC_BEGIN_INTERFACES()
     ** \li OC_END_INTERFACES()
     ** \li OC_DECLARE_INTERFACE()
     **/
    template < class CObject, class CInterfaces >
    class Component
    {

    protected:

        static oc::ObjectBrokerPtr msObjectBrokerPtr;

    public:

        typedef CObject ObjectType;

        typedef CObject BaseClass;

        typedef CInterfaces Interfaces;

        typedef oc::ComponentRef<BaseClass,Interfaces> Reference;

        typedef Component<BaseClass,Interfaces> SelfType;

        typedef OC_TYPENAME ComponentListenerContainer<Reference>::Listener Listener;


        static bool SetBroker( oc::ObjectBroker & broker )
        {
            msObjectBrokerPtr = & (broker.Self());
            return true;
        }

        static bool AddListener( Listener & l )
        {
            OCDEBUG( "Adding listener to component '" << GetName() << "'." );
            oc::ComponentListenerContainer<Reference>::Add( l );
            return true;
        }

        static bool RemoveListener( Listener & l )
        {
            OCDEBUG( "Removing listener from component '" << GetName() << "'." );
            oc::ComponentListenerContainer<Reference>::Remove( l );
            return true;
        }

        static Reference New( const std::string & realizationName = "" )
        {

            // Get the object broker instance
            if( ! msObjectBrokerPtr ) {

                msObjectBrokerPtr = & (oc::ObjectBroker::Self());
            }

            // Create object
            Reference ref;

            msObjectBrokerPtr->NewObject( ref, realizationName );

            // Load and assign resources and notify listeners
            if( ref ) {

                oc::File resource_file = ref.GetResource();

                if( resource_file ) {

                    if( oc::PropertyMapResourceHandler::LoadAndAssign( resource_file,
                                                                       ref.GetProperties() ) ) {

                        OCDEBUG( "Resource file '"
                                 << resource_file
                                 << "' successfully loaded and assigned to component "
                                 << GetName()
                                 << " with realization "
                                 << ref.GetObjectTrait()->GetRealizationName()
                                 << "." );
                    }
                    else {

                        OCWARN( "Can't load and assign resource file '"
                                << resource_file
                                << "' to component "
                                << GetName()
                                << " with realization "
                                << ref.GetObjectTrait()->GetRealizationName()
                                << "." );
                    }
                }
                else {

                    OCDEBUG( "No resource file for component "
                             << GetName()
                             << " with realization "
                             << ref.GetObjectTrait()->GetRealizationName()
                             << " available." );
                }

                // Notify listeners about the new object.
                oc::ComponentListenerContainer<Reference>::NotifyForCreation( ref );
            }

            return ref;
        }

        static bool GetAllRealizations( std::vector< std::string > & realization_names )
        {

            // Get the object broker instance
            if( ! msObjectBrokerPtr ) {

                msObjectBrokerPtr = & (oc::ObjectBroker::Self());
            }

            // Clear vector with realization names
            realization_names.clear();
 
            // Search for all realizations of this component
            oc::ObjectBrokerConfig::mtObjectTraitVector traits_vector = msObjectBrokerPtr->GetConfig()->Find( GetName() );

            // Loop over all object traits and add realization name to result vector
            oc::ObjectBrokerConfig::mtObjectTraitVector::const_iterator  it = traits_vector.begin();
            oc::ObjectBrokerConfig::mtObjectTraitVector::const_iterator eit = traits_vector.end();

            for( ; it != eit; ++it ) {
                
                OCDEBUG( "Found realization '" << (*it)->GetRealizationName() << "'." );
                
                realization_names.push_back( (*it)->GetRealizationName() );
            }

            return true;
        }

        static std::string GetName()
        {
            return ObjectType::GetName();
        }

        Component()
            : CObject()
            , CInterfaces()
        {}

        virtual ~Component()
        {}

    }; // template class Component

    // Initialize static variable
    template < class CObject, class CInterfaces >
    oc::ObjectBrokerPtr Component<CObject,CInterfaces>::msObjectBrokerPtr = oc::ObjectBrokerPtr();

} // namespace oc





// ===================================================================
//                              COMPONENT macros
// ===================================================================


// -------------
// HEADER macros
// -------------


#undef OC_BEGIN_COMPONENT
/** Use this macro to start a new component declaration.
 **/
#define OC_BEGIN_COMPONENT( CompName )                              \
class C##CompName                                                \
{                                                                \
  public:                                                        \
    C##CompName()                                                \
    {}                                                           \
    C##CompName( const C##CompName & )                           \
    {}                                                           \
    virtual ~C##CompName()                                       \
    {}                                                           \
    static std::string GetName()                                 \
    {                                                            \
      return std::string( #CompName );                           \
    }

#undef OC_BEGIN_METHODS
/** Use this macro to start component methods which can be used
 ** by component realizations.
 **/
#define OC_BEGIN_METHODS( CompName )


#undef OC_END_METHODS
/** Use this macro to finish component methods.
 **/
#define OC_END_METHODS( CompName )             \
};


#undef OC_NO_METHODS

#define OC_NO_METHODS( CompName )    \
};


#undef OC_BEGIN_INTERFACES
/** Use this macro to start a new interface declaration.
 **/
#define OC_BEGIN_INTERFACES( CompName )                          \
class I##CompName                                                \
{                                                                \
  public:                                                        

#undef OC_DECLARE_INTERFACE
/** Use this macro to declare a specific interface of a component.
 **/
#define OC_DECLARE_INTERFACE( IFace, IFaceName )                   \
      typedef IFace                    IFaceName;                  \
      typedef oc::CPtr<IFaceName>      IFaceName##PtrType;         \
      IFaceName##PtrType               IFaceName##Ptr;             

#undef OC_BEGIN_INTERFACE_IMPLEMENTATIONS
#define OC_BEGIN_INTERFACE_IMPLEMENTATIONS( CompName )  \
    bool QueryInterfacesFromProperties( oc::PropertyMap & properties ) \
	{ \
      bool have_needed_interfaces = true;                                              \
      const std::string compname( #CompName );                                         \
      OCDEBUG( "Querying component '" #CompName "' for interfaces implementations:" )

#undef OC_OPTIONAL_INTERFACE
#define OC_OPTIONAL_INTERFACE( IFaceName )                   \
	OCDEBUGCONT( "-> Optional  interface '"#IFaceName"' : " );                \
	if( properties.HasProperty( "Interface:"#IFaceName) ) { \
	  this->IFaceName##Ptr = (IFaceName##PtrType)properties[ "Interface:"#IFaceName ](this->IFaceName##Ptr); \
	  OCDEBUG( "found " << IFaceName##Ptr );                            \
	}                                                                   \
    else {                                                                \
     OCDEBUG( "not implemented " );                                      \
    }

#undef OC_MUSTHAVE_INTERFACE
#define OC_MUSTHAVE_INTERFACE( IFaceName )                   \
	OCDEBUGCONT( "-> Obligatory  interface '"#IFaceName"' : " );                \
	if( properties.HasProperty( "Interface:"#IFaceName) ) { \
	  this->IFaceName##Ptr = (IFaceName##PtrType)properties[ "Interface:"#IFaceName ](this->IFaceName##Ptr); \
	  OCDEBUG( "found " << IFaceName##Ptr );                            \
	}                                                                   \
    else {                                                                \
      OCDEBUG( "not implemented " );                                      \
      OCWARN( "Component " << compname <<                                 \
           " must implement interface '"#IFaceName"'." );                 \
	  have_needed_interfaces = false;                                     \
    }


#undef OC_END_INTERFACE_IMPLEMENTATIONS
#define OC_END_INTERFACE_IMPLEMENTATIONS( CompName )  \
		return have_needed_interfaces; \
	} \
};

#undef OC_END_INTERFACES
/** Use this macro to finish an interface declaration.
 **/
#define OC_END_INTERFACES( CompName )                            



#define OC_NO_INTERFACES( CompName )                                     \
class I##CompName                                                        \
{                                                                        \
  public:                                                                \
    bool QueryInterfacesFromProperties( oc::PropertyMap & properties )  \
    {                                                                    \
      OCDEBUG( "Querying component '" #CompName "' for interfaces implementations:" ) \
      OCDEBUG( "No interfaces defined for this component." )             \
      return true;                                                       \
    }                                                                    \
};



#undef OC_END_COMPONENT
/** Use this macro to finish a component declaration.
 **/
#define OC_END_COMPONENT( CompName )                           \
typedef oc::PropertyMapDeco< C##CompName > B##CompName;     \
typedef oc::Component<B##CompName, I##CompName > CompName;  \
typedef CompName::Reference                  CompName##Ref;


/*

// ---------------------
// IMPLEMENTATION macros
// ---------------------

#undef OC_BEGIN_COMPONENT_IMPLEMENTATION
#define OC_BEGIN_COMPONENT_IMPLEMENTATION( CompName )


#undef OC_BEGIN_METHOD_IMPLEMENTATIONS
#define OC_BEGIN_METHOD_IMPLEMENTATIONS( CompName )


#undef OC_END_METHOD_IMPLEMENTATIONS
#define OC_END_METHOD_IMPLEMENTATIONS( CompName )

#undef OC_BEGIN_INTERFACE_IMPLEMENTATIONS
#define OC_BEGIN_INTERFACE_IMPLEMENTATIONS( CompName )                              \
bool                                                                  \
I##CompName::QueryInterfacesFromProperties( oc::PropertyMap & properties )          \
{                                                                                   \
   bool have_needed_interfaces = true;                                              \
   const std::string compname( #CompName );                                         \
   OCDEBUG( "Querying component '" #CompName "' for interfaces implementations:" )

#undef OC_MUSTHAVE_INTERFACE
#define OC_MUSTHAVE_INTERFACE( IFace )                                \
OCDEBUGCONT( "-> Must have interface '"#IFace"' : " );                \
if( QueryInterfaceFromProperties( this->IFace##Ptr, properties ) ) {  \
  OCDEBUG( "found" );                                                 \
}                                                                     \
else {                                                                \
  OCDEBUG( "failed" );                                                \
  OCWARN( "Component " << compname <<                                 \
           " must implement interface '"#IFace"'." );                 \
  have_needed_interfaces = false;                                     \
}

#undef OC_OPTIONAL_INTERFACE
#define OC_OPTIONAL_INTERFACE( IFace )                                \
OCDEBUGCONT( "-> Optional  interface '"#IFace"' : " );                \
if( QueryInterfaceFromProperties( this->IFace##Ptr, properties ) ) {  \
  OCDEBUG( "found " << this->IFace##Ptr );                            \
}                                                                     \
else {                                                                \
  OCDEBUG( "not implemented " );                                      \
}

#undef OC_END_INTERFACE_IMPLEMENTATIONS
#define OC_END_INTERFACE_IMPLEMENTATIONS( CompName ) \
  return have_needed_interfaces;                     \
}


#undef OC_END_COMPONENT_IMPLEMENTATION
#define OC_END_COMPONENT_IMPLEMENTATION( CompName )



#define OC_COMPONENT( CompName ) C##CompName

*/
#endif

