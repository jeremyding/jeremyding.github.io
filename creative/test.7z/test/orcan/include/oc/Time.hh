
#ifndef OC_TIME_HH
#define OC_TIME_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

#include <oc/config.h>

#include <iostream>


namespace oc
{
    /**
     ** The class time, can be used to compare two times, to add seconds to a time, to subtracts seconds of a time,
     ** to get the number of days in a managed day and to count up days.
     ** 
     ** \author Kathrin Reisloehner
     ** \date 20.9.2004
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI Time {

	/** \name Attributes
	 ** \{
	 **/

    private:

        /** Hours in [0,23].
         **/
        int mHour;

        /** Minutes in [0,59].
         **/
        int mMinute;

        /** Seconds in [0,59].
         **/
        int mSecond;

        /** \}
         **/


        /** \name Constructors / Destructor
         ** \{
         **/

    public:
    
        /** Constructor (default). Initialize the time to 0:0:0
         **/
        Time();
    
        /** Copy - Constructor, copies the date of one time to another
         **/
        Time(Time const & b);

        /** Constructor, initialize the date to \p hour \p minute \p second.
         **
         **\param hour Hour in [0,23]
         **\param minute Minute in [0,59]
         **\param second Second in [0,59]
         **/
        Time(int hour, int minute, int second );
    
        /** Constructor, initialize the time with a string.
         **
         **\param time Time string
         **/
        Time( const std::string & time);
        
        /** Destructor is empty.
         **/
        ~Time();

        /** \}
         **/


        /** \name Getter / Setter
         ** \{
         **/

    public:

        /** It makes a wrong time to a useful time
         **
         ** \return true if it is a correct time else return false
         **/
        bool SetTime(int h, int m, int s);

        /** It makes a wrong time to a useful time
         **
         ** \return true if it is a correct time else return false
         **/
        bool SetTime(const std::string &);
        
        /** Returns the number of days of the managed year.
         **
         ** \b Example:
         **
         ** 3:2:3 means 10923 seconds of a day.
         **
         **\return Number of days of the managed year.
         **/
        int GetSecondsOfDay() const;

        /** Returns the hours of a time
         **/
        int GetHour() const;

        /** Returns the minutes of a time
         **/
        int GetMinute() const;

        /** Returns the seconds of a time
         **/
        int GetSecond() const;

        /** From a number of seconds it can say what for a time it is of a day.
         **
         **\return the time with the wanted number
         **/
        Time & SetSecondsOfDay(int n);

        /** It returns the current time
         **/
        static Time GetCurrent();

        /** \}
         **/


        /** \name Operators
         ** \{
         **/

    public:

        /**It set the left date equal with the right date
         **
         **\return a date
         **/
        Time & operator = (Time const & rhs);

        /**
         **It compare to times
         **
         **\returns true if the left time is earlier on a day than the right time, else it returns false
         **/
        bool operator<(Time const & a);

        /**
         **It compare to times
         **
         **\returns true if the left time is later on a day than the right time, else it returns false
         **/
        bool operator>(Time const & a);

        /**
         **It compare to times
         **
         **\returns true if the two times are equal, else it returns false.
         **/
        bool operator==(Time const & a);

        /**
         ** It compare to times
         **
         **\returns true if the left time is earlier on a day or the same time, else it returns false
         **/
        bool operator<=(Time const & a);

        /**
         **It compare to times
         **
         **\returns true if the left time is later on a day or the same time, else it returns false
         **/
        bool operator>=(Time const & a);

        /**
         **To a time a number of seconds will be added
         **
         **\returns the new time
         **/
        Time operator + (int t);

        /**
         ** Of a time a number of seconds will be subtracted.
         **
         **\returns the new time
         **/
        Time operator - (int t);

        /**
         **To a time a number of seconds will be added
         **The time is changed into that
         **
         **\returns the changed time
         **/
        Time & operator += (int t);
    
        /**
         ** Of a time of number of seconds will be subtracted.
         **The time is changed into that
         **
         **\returns the changed time
         **/
        Time & operator -= (int t);

        /**It is the prefix - operator of the addition.
         **After to the time 1 is added, it will be used.
         **
         **\return the changed time.
         **/
        Time & operator ++();

        /**
         **It is the postfix - operator of the addition.
         **That means after time is been used, to the time 1 second will be added
         **
         **\return a time before 1 second is added
         **/
        Time operator ++ ( int );

        /**It is the prefix - operator of the subtraction.
         **After 1 second will be subtracted of the time, it will be used.
         **
         ** \return the changed time.
         **/
        Time & operator --();

        /**
         **It is the postfix - operator of the subtraction.
         ** That means after date is been used, of the time 1 second will be subtracted.
         **
         ** \return a time before 1 second is subtracted.
         **/
        Time operator -- (int );

        /** \}
         **/

    }; // class Time

    /** Prints a time on outstream in a special way.
     **/
    std::ostream & operator<<( std::ostream & out, const oc::Time & d );

    /** Requires a time in a special way, otherwise it can not set the variables so and can not write it on instream.
     **/
    std::istream & operator>>( std::istream & in, oc::Time & time);

} // namespace oc

#endif
