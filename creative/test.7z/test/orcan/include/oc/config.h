
#ifndef OC_CONFIG_H
#define OC_CONFIG_H

/* ==========================================================================
 *                                                                              
 *  Crystal Growth Laboratory                                                   
 *                                                                              
 *  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
 *  Department of Material Science         Institute of Integrated Systems      
 *  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
 *  Martensstrasse 7                       Schottkystrasse 10                   
 *  91058 Erlangen                         91058 Erlangen                       
 *  Germany                                Germany                              
 *                                                                              
 *  In cooperation with                                                         
 *                                                                              
 *  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
 *  Department of Computer Science 9       Department of Computer Science 10    
 *  Computer Graphics                      System Simulation Group              
 *  Am Weichselgarten 9                    Cauerstra�e 6                        
 *  91058 Erlangen                         91058 Erlangen                       
 *  Germany                                Germany                              
 *                                                                              
 * ==========================================================================
 *                                                                              
 * Copyright 2004 (c) by
 * (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
 * (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
 * (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
 * (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
 * 
 * For Licensing regulations see the accompanying LICENSE file.
 * If this file does not exist and/or does not apply to you, please contact
 * the copyright holders.           
 *                                                                              
 * ========================================================================== */

#undef PACKAGE
#undef PACKAGE_BUGREPORT
#undef PACKAGE_NAME
#undef PACKAGE_STRING
#undef PACKAGE_TARNAME
#undef PACKAGE_VERSION

/* All platforms include */
#include <oc/config_all.h>

/* OS specific include */
#if defined(WIN32) || defined(MSDOS)
#  include <oc/config_w32.h>
#else
#  include <oc/config_am.h>
#endif

#endif

