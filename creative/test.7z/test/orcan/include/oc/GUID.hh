
#ifndef OC_GUID_HH
#define OC_GUID_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// C++ include

#include <iostream>

// STL include

#include <string>

// ORCAN includes

#include <oc/config.h>

namespace oc
{

    /** This class is used generate and manage global unique identifiers (GUID)
     ** - also known as universal unique idenfier (UUID) - for objects that may
     ** be accessible beyond the local system.
     **
     ** \author Michael Kellner
     ** \date 06.11.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI GUID
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The five integer values of the GUID
	 **/
	int mValues[5];

	/** The GUID as string.
	 **/
	std::string mStringValue;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor creates a void GUID. Use the static method
	 ** Generate() to create a new valid GUID.
	 **/
	GUID();

	/** Copy constructor
	 **/
	GUID( const GUID & source );

	/** Constructs a GUID given as a string. The input GUID is a string of
	 ** the form 1b4e28ba-2fa1-11d2-883f-b9a761bde3fb (in printf format
	 ** "%08x-%04x-%04x-%04x-%012x").
	 **/
	GUID( const std::string & guid );

	/** Constructs a GUID given as the five interger values.
	 **/
	GUID( int first, int second, int third, int fourth, int fifth );

	/** Destructor is empty.
	 **/
	~GUID();

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** Assignment operator
	 **/
	GUID & operator=( const GUID & rhs );	

	/** \}
	 **/

	/** \name Static Methods
	 ** \{
	 **/

    public:

	/** Create
	 **/
	static GUID Generate();

	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** Returns the GUID as string.
	 **/
	const std::string & GetString() const;

	/** Returns the first integer value of the GUID.
	 **/
	int GetFirst() const;

	/** Returns the second integer value of the GUID.
	 **/
	int GetSecond() const;

	/** Returns the third integer value of the GUID.
	 **/
	int GetThird() const;

	/** Returns the fourth integer value of the GUID.
	 **/
	int GetFourth() const;

	/** Returns the fifth integer value of the GUID.
	 **/
	int GetFifth() const;

	/** \}
	 **/


	/** \name Query Methods
	 ** \{
	 **/

	/** Checks whether the GUID is initialized with a valid unique ID.
	 **/
	bool IsNull() const;

	/** \}
	 **/


    }; // class GUID

    /** Equality operator.
     **/
    OC_DSOAPI bool operator==( const GUID & lhs, const GUID & rhs );

    /** Output operator.
     **/
    OC_DSOAPI std::ostream &
    operator<<( std::ostream & out, const GUID & guid );

} // namespace oc

#endif

