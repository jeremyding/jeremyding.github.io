
#ifndef OC_MFIELD_HH
#define OC_MFIELD_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/Field.hh>

// C++ include

#include <vector>




namespace oc
{

    /** Field containing an array of other fields.
     **
     ** Contained fields can be SFields or other MFields.
     **
     ** \author Horst Hadler
     ** \date 6.3.2003
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI MField : public Field
    {

	/** \name Attributes
	 ** \{
	 **/

    private:
    
	/** Array of fields
	 **/
	std::vector<Field *> mFields;
 
	/** \}
	 **/


	/** \name Getter / Setter
	 ** \{
	 **/

    private:

	/** Get the reference to the contained field value.
	 **
	 ** \return Pointer to field value
	 **/
	virtual inline void * GetReference();

    public:

	/** Returns MField type.
	 **
	 ** \return Type info of MField.
	 **/
	virtual inline const std::type_info & GetType() const;

	/** Get array as string.
	 **
	 ** \return Contained array as string.
	 **/
	virtual inline std::string GetStringValue() const;
    
	/** \}
	 **/


	/** \name Access Methods
	 ** \{
	 **/

    public:
    
	/** Add a field to the array; it can be accessed by the name given.
	 **
	 ** \param value Value to be added to the array.
	 **/
	void inline AppendField( Field * const & value );

	/** \}
	 **/


	/** \name Operators
	 ** \{
	 **/

    public:
    
	/** Get a field by index.
	 **
	 ** \param idx Return idx-th field.
	 ** \return idx-the Field in array or \c NULL if index out of range.
	 **/
	virtual inline Field * operator[]( int const & idx );

	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

    public:
    
	/** Only valid for single value fields i.e. returns always \c false.
	 **
	 ** \return Always \c false.
	 **/
	virtual inline bool IsRef(); 

	/** \}
	 **/

    }; // class MField

} // namespace oc

#include "MField.in"



#endif

