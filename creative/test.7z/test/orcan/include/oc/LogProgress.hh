
#ifndef OC_LOG_PROGRESS_HH
#define OC_LOG_PROGRESS_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN includes

#include <oc/config.h>

// C++ includes

#include <algorithm>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>



namespace oc
{

    
    /** LogProgess is a simple class used to report the progress of a subroutine.
     ** Classes that are interested in the progress should derive from 
     ** oc::LogProgress::Listener. 
     ** By deriving from oc::LogProgress::Listener they will automatically 
     ** get notified via the HaveReport listener method. If automatic notification
     ** is not wanted it can  be turned of by calling RemoveListener(this) and 
     ** turned on again later calling AddListener(this);
     ** <pre>
     ** // in the subroutine
     ** oc::LogProgress myprogress("mytask");
     ** 
     ** myprogress.Report("done 45 percent");
     ** //or
     ** int percent = 45;
     ** myprogress << "done " << percent << "%" << oc::report;
     ** </pre>
     ** 
     ** Note that he output-operator '<<' is buffering all output. The
     ** output is flushed using the oc::report manipulator. Without
     ** oc::report nothing will be reported to registered listeners.
     ** 
     ** The class that should be notified about the progress must
     ** derive from oc::LogProgress::Listener. This implies it
     ** must define the method: 'HaveReport' which is pure virtual
     ** in oc::LogProgress::Listener. HaveReport will be called 
     ** whenever any instance of oc::LogProgress 'reports' something.
     ** 
     ** <pre>
     ** class MainClass : public oc::LogProgress::Listener
     ** {
     ** public:
     ** void HaveReport( std::string const& name, std::string const& msg)
     ** {
     ** // print msg on statusbar
     ** }
     ** 
     ** };
     ** 
     ** </pre>
     ** 
     ** \author Horst Hadler
     **
     **/

    class LogProgress
    {

    public:

        /** Listener interface for reports. Classes that
         ** are interested in getting progress reports must derive
         ** from this class. The constructor will automatically make a call
         ** to AddListener and the destructor will call RemoveListener.
         **/
        class Listener {

        public:
            /** Create listener and add it to the report listeners vector (AddListener).
             **/
            OC_DSOAPI Listener();
            /** Destroy listener and remove it from the report listeners vector (RemoveListener).
             **/
            OC_DSOAPI ~Listener();
            /** Pure Virtual progress report callback; must be implemented by derived class.
             **/
            virtual void HaveReport( std::string const& name, std::string const& msg )=0;
        };

    private:
        /** array of listeners.
         **/
        static  std::vector<Listener *> mListeners;

        /** array of report-string buffers.
         **/
        static std::vector< std::pair< std::string, std::string > > mStreams;

        /** create new report-string buffer.
         **/
        static void AddStream(std::string const& name);

        /** destroy report-string buffer.
         **/
        static void RemoveStream(std::string const& name);

    private:
        
        /** name unique identifier.
         **/
        std::string mName;

        
    public:
        
        /** Create a progress reporter.
         ** \param name unique identifier
         **/
        OC_DSOAPI LogProgress(std::string const& name);

        /** Destroy a progress reporter.
         **/
        OC_DSOAPI ~LogProgress();

        /** Report progress 'text' to all listeners.
         ** \param text progress-message to be sent to listeners.
         **/
        OC_DSOAPI bool Report(std::string const & text);

        /** Add a progress listener.
         ** \param l listener
         ** \ref Listener
         **/
        OC_DSOAPI static bool AddListener(Listener* l);
 
        /** Add a progress listener.
         ** \param l listener
         ** \ref Listener
         **/
        OC_DSOAPI static bool RemoveListener(Listener *l);
 
    public:

        /** Helper: Get output buffer for a progress reporter.
         **/
        OC_DSOAPI static std::string& GetStream(std::string const & name);

        /** Manipulator that flushes the progress output buffer.
         **/
        friend OC_DSOAPI LogProgress& report( LogProgress& lp );

        /** Manipulator output-operator.
         **/
        OC_DSOAPI LogProgress& operator<<(LogProgress& (*manip)(LogProgress&));

        /** Output value to progress output buffer.
         ** The buffered values will not be reported unless the report manipulator is sent.
         **/
        template<class T>
        LogProgress& operator<<( const T & value )
        {
            std::stringstream sstrm;
            sstrm << value;
            GetStream(mName).append(sstrm.str());
            return (*this);
        }

    }; // LogProgress

    /** Manipulator that flushes the progress output buffer.
     **/
    OC_DSOAPI LogProgress& report( LogProgress& lp );

} // namespace oc



#endif



