
#ifndef OC_MODULE_HH
#define OC_MODULE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/DLMObjectFactoryInfo.hh>

// C++ include

#include <vector>



// MODULE STATIC
// =============

#if defined(_DEBUG) || defined(DEBUG)
static const std::string & GetRuntimeInfo()  \
{                                            \
  static std::string runtimeInfo( "debug" ); \
  return runtimeInfo;                        \
}
#else
static const std::string & GetRuntimeInfo()    \
{                                              \
  static std::string runtimeInfo( "release" ); \
  return runtimeInfo;                          \
}
#endif

// DEFINE
// ======

#ifdef WIN32
#  ifdef OC_MODULE_DLL
#    define MOD_DSOAPI  __declspec(dllexport)
#    define MOD_STATICDSOAPI __declspec(dllexport) extern
#  else
#    define MOD_DSOAPI  __declspec(dllimport)
#    define MOD_STATICDSOAPI __declspec(dllimport) 
#  endif
#else
#  define MOD_DSOAPI
#  define MOD_STATICDSOAPI
#endif

namespace oc
{
    /** The module information is nothing else than a DlmObjectFactoryInfo, a
     ** information class for object factories of kind dynamic loadable module.
     **/
    typedef oc::DLMObjectFactoryInfo ModuleInfo;
}

/** The default class for module information is simply the corresponding base
 ** class for dynamic loadable modules: DlmObjectFactoryInfo.
 **/
#define DEFAULT_MODULE_INFO oc::DLMObjectFactoryInfo


// TYPEDEF
// =======

/** The C function to get an instance of the module info class provided by
 ** the module developer. The module info class can be the default (base)
 ** class (DEFAULT_MODULE_INFO) or a subclass of it provided by the module
 ** developer.
 **
 ** \see tGetModuleInfoFPtr
 **/
extern "C" MOD_DSOAPI oc::ObjectFactoryInfo * GetModuleInfo( void );

/** The helper function (called by the REGISTER_REALIZATION macro) adds
 ** all necessary properties to the module info instance.
 **/
bool ocRegisterModuleClass( const char * baseClass,
                            const char * derivedClass,
                            const char * globalUID,
                            const char * infoString,
                            void * (*newClass)(void),
                            bool   (*delClass)(const void *) );

/** The pointer to the C function to get an instance of the module info class
 ** provided by the module developler.
 **
 ** \see GetModuleInfo()
 **/
typedef oc::ObjectFactoryInfo * (*tGetModuleInfoFPtr)( void );



// MACRO
// =====



/** This macro must be used once in each module. It registers a module info
 ** class which provides (unique) information about the module. The module
 ** info class can be the DEFAULT_MODULE_INFO class or a derived class of
 ** it. The macro call must appear in a source file (not in a header file)
 ** because it defines a function which would lead to duplicated symbols.
 **
 ** \b Example
 **
 ** \code
 **
 ** ------ MyModuleInfo.hh --------
 **
 ** class MyModuleInfo : public ModuleInfo
 ** {
 **     ....
 ** };
 **
 ** ------ MyModuleInfo.cpp --------
 **
 ** #include "MyModuleInfo.hh"
 **
 ** REGISTER_MODULE_INFO(MyModuleInfo)
 **
 ** ....
 **
 ** \endcode
 **/
#undef OC_REGISTER_MODULE_INFO
#define OC_REGISTER_MODULE_INFO(ModuleInfoClass)                                                 \
static oc::DLMObjectFactoryInfo * theModuleInfo = NULL;                                          \
extern "C" MOD_DSOAPI oc::DLMObjectFactoryInfo * GetModuleInfo( void )                           \
{                                                                                                \
                                                                                                 \
    if( theModuleInfo == NULL ) {                                                                \
      theModuleInfo = new ModuleInfoClass();                                                     \
      theModuleInfo->GetProperties().AddPropertyCopy( "Runtime", std::string( GetRuntimeInfo()));\
    }                                                                                            \
                                                                                                 \
    return theModuleInfo;                                                                        \
}                                                                                                \
                                                                                                 \
bool ocRegisterModuleClass( const char * baseClass,                          \
                            const char * derivedClass,                       \
                            const char * globalUID,                          \
                            const char * infoString,                         \
                            void * (*newClass)(void),                        \
                            bool   (*delClass)(const void *) )               \
{                                                                                                \
  std::string  theClassProp ( std::string("Class:" ) + baseClass + ":" + globalUID );            \
  std::string  newClassProp ( std::string("New:"   ) + globalUID );                              \
  std::string  delClassProp ( std::string("Del:"   ) + globalUID );                              \
  std::string  infoClassProp( std::string("Info:"  ) + globalUID );                              \
                                                                                                 \
  oc::PropertyMap& pmap = GetModuleInfo()->GetProperties();           \
                                                                      \
  pmap.AddPropertyCopy( theClassProp,  std::string(derivedClass)   ); \
  pmap.AddPropertyCopy( newClassProp,  newClass   );                  \
  pmap.AddPropertyCopy( delClassProp,  delClass   );                  \
  pmap.AddPropertyCopy( infoClassProp, std::string(infoString)   );   \
                                                                      \
  return true;                                                        \
}
 

/** This marco must be used once for each class which is implemented in a
 ** dynamic loadable module. The macro call must appear in a source file
 ** (not in a header file) because it defines functions and static variables
 ** which would lead to duplicated symbols. Do not use a namespace specification
 ** for \p Component because this parameter will only be used for function
 ** and variable names and "::" are not allowed for naming. You can/must use
 ** the namespace specification for the realization name \p Realization.
 **
 ** \b Example
 **
 ** \code
 **
 ** ------ SimpleSurfMesh.hh --------
 **
 ** class SimpleSurfMesh
 **   : public ocs::SurfMesh::BaseClass
 ** {
 **     ....
 ** };
 **
 ** ------ SimpleSurfMesh.cpp --------
 **
 ** #include <SimpleSurfMesh.hh>
 **
 ** REGISTER_REALIZATION(SurfMesh,SimpleSurfMesh,d9145f36-3911-4077-976b-d6f517b85bad,"My own mesh class")
 **
 ** ....
 **
 ** \endcode
 **/
#undef OC_REGISTER_REALIZATION_DEPRECATED
#define OC_REGISTER_REALIZATION_DEPRECATED(Component, Realization, PGlobalUID, PInfoString)  \
extern "C" MOD_DSOAPI void * New##Component( void )                            \
{                                                                              \
    return (void *)(new Realization());                                        \
}                                                                              \
extern "C" MOD_DSOAPI bool Del##Component( const void * instance )             \
{                                                                              \
    delete (const Realization *) instance;                                     \
    return true;                                                               \
}                                                                              \
static bool dummy##Component = ocRegisterModuleClass( #Component, #Realization, PGlobalUID, PInfoString, New##Component, Del##Component);
 

/** This marco must be used once for each class which is implemented in a
 ** dynamic loadable module. The macro call must appear in a source file
 ** (not in a header file) because it defines functions and static variables
 ** which would lead to duplicated symbols. Do not use a namespace specification
 ** for \p Component because this parameter will only be used for function
 ** and variable names and "::" are not allowed for naming. For the same
 ** reason no namespace specification is allowed for \p Realization. Instead
 ** set the namespace as \p Namespace for the \p Realization.
 **
 ** \b Example
 **
 ** \code
 **
 ** ------ SimpleSurfMesh.hh --------
 **
 ** namespace ocs {
 **
 **   class SimpleSurfMesh
 **     : public ocs::SurfMesh::BaseClass
 **   {
 **       ....
 **   };
 ** }
 **
 ** ------ SimpleSurfMesh.cpp --------
 **
 ** #include <SimpleSurfMesh.hh>
 **
 ** REGISTER_REALIZATION(SurfMesh,ocs,SimpleSurfMesh,d9145f36-3911-4077-976b-d6f517b85bad,"My own mesh class")
 **
 ** ....
 **
 ** \endcode
 **/
#undef OC_REGISTER_REALIZATION
#define OC_REGISTER_REALIZATION(Component, Namespace, Realization, PGlobalUID, PInfoString)     \
extern "C" MOD_DSOAPI void * New##Component##Namespace##Realization( void )                     \
{                                                                                               \
    return (void *)(new Namespace::Realization());                                              \
}                                                                                               \
extern "C" MOD_DSOAPI bool Del##Component##Namespace##Realization( const void * instance )      \
{                                                                                               \
    delete (const Namespace::Realization *) instance;                                           \
    return true;                                                                                \
}                                                                                               \
static bool dummy##Component##Namespace##Realization =                                          \
     ocRegisterModuleClass( #Component,                             \
                            #Namespace"::"#Realization,             \
                            PGlobalUID, PInfoString,                \
                            New##Component##Namespace##Realization, \
                            Del##Component##Namespace##Realization);




/** This macro must be used in the default constructor of the realization to
 ** register an interface implementation.
 **
 ** \b Example:
 **
 ** \code
 **
 ** ------ SimpleSurfMesh.hh --------
 **
 ** class SimpleSurfMesh : public Mesh::BaseClass, public Mesh
 ** {
 **     ....
 ** };
 **
 ** ------ MyMesh.cpp --------
 **
 ** #include "MyMesh.hh"
 **
 **   OC_REGISTER_INTERFACE( ocs::SurfMesh, Query );
 **
 **/
#undef OC_REGISTER_INTERFACE
#define OC_REGISTER_INTERFACE(CObject,IFace)                                      \
AddPropertyCopy( "Interface:"#IFace, CObject::Interfaces::IFace##PtrType(*this) );


/** This marcro must be used in the default constructor of the realization to
 ** register a non direct interface implementation.
 **/
#undef OC_ADD_INTERFACE
#define OC_ADD_INTERFACE( IFace, PropertyName )                                                             \
AddPropertyCopy( "Interface:"PropertyName, oc::OCInterfacePtr( dynamic_cast<oc::OCInterface *>( this ) ) );

#endif


