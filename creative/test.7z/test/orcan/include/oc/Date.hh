
#ifndef OC_DATE_HH
#define OC_DATE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// C++ include
#include <oc/config.h>

#include <iostream>

namespace oc
{
    /**
     ** The class date, can be used to compare to dates, to add days to a date, to subtract days from a date,
     **  to get the number of days in a managed year and to count up days.
     **
     ** \author Kathrin Reisloehner
     ** \date 20.9.2004
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI Date {
        
    /** \name Attributes
     ** \{
     **/

    private:
        
        /** Day in [1,31]
         **/
        int mDay;
        
        /** Month in [1,12]
         **/
        int mMonth;
        
        /** Year could be any number, negative means before christ, positive after christ.
         **/
        int mYear;
        
        /** \}
         **/

        /** \name Private method
         **\{
         **/
    private:
        /**
         ** It initialize an array which is used in the method SetNumberOfDays, to get easier the wanted date.
         **/
        void InitialDate(int * MonthsLeapYear, int * DaysLeapYear,int * MonthsNormalYear, int * DaysNormalYear);
        
        /**\}
         **/
        
        /** \name Constructors / Destructor
         ** \{
         **/
    public:
        
        /** Constructor (default). Initialize the date to 1.1.0000
         **/
        Date();
        
        /** Constructor, initialize the date to \p day, \p month, \p year.
         **
         ** \param day Day in [1,31]
         ** \param month Month in [1,12]
         ** \param year Year could be any number, negative means before christi, positive after christi.
         **/
        Date(int day, int month, int year);
        
        /** Constructor, initialize the date with string value.
         **
         ** \param day Day string
         **/
        Date(const std::string & day);
        
        /**Copy - Constructor, copies the data of one date to another
         **/
        Date ( Date  const & b);
        
        /**Destructor, is empty
         **/
        ~Date();
        /**\}
         **/
        
        /** \name Getter and Setter
         **\{
         **/
    public:
        
        /** Returns the number of days of the managed year.
         **
         ** \b Example:
         **
         ** 12.2.2004 means 43 days of year 2004.
         **
         ** \return Number of days of the managed year.
         **/
        int GetDaysOfYear() const;
        
        /**From a number it can say what for a date of a year it is.
         **
         ** \return the date with the wanted number
         **/
        Date & SetNumberOfDays(int num_days);
        
        /**It makes a wrong date to a useful one.
         **
         ** \return true if is a correct date else return false
         **/
        bool SetDate(int day, int month, int year);
        
        /**It makes a wrong date to a useful one.
         **
         ** \return true if is a correct date else return false
         **/
        bool SetDate(const std::string &);
        
        /**Returns the day, month and year of a date.
         **/
        void Get(int & day, int & month, int & year) const;
        
        /**Returns the day of a date.
         **/
        int GetDay() const;
        
        /**Returns the month of a date.
         **/
        int GetMonth() const;
        
        /**Returns the year of a date.
         **/
        int GetYear() const;
        
        /**Returns the current date.
         **/
        static Date GetCurrent();
        
        /** \}
         **/

        /** \name Operator
         **\{
         **/

    public:
        
        /**It set the left date equal with right date
         **
         **\return a date
         **/
        Date & operator= (Date const &rhs);
        
        /** Compare to dates.
         ** 
         ** \return true if the left date is earlier than the right date,
         **         return false if the left date is later than the right date.
         **/
        bool operator<(Date const & a);
        
        /** Compare to dates.
         ** 
         ** \return true if the left date is later than the right date,
         **         return false if the left date is earlier than the right date.
         **/
        bool operator>(Date const & a);
        
        /** Compare to dates.
         ** 
         ** \return true if the left date and the right date are the same,
         **         return false if the left date and the right date are not the same.
         **/
        bool operator==(Date const & a);
        
        /** Compare to dates.
         ** 
         ** \return true if the left date is earlier than or equal with the right date,
         **         return false if the left date is later than the right date.
         **/
        bool operator<=(Date const & a);

        /** Compare to dates.
         ** 
         ** \return true if the left date is later than or equal with the right date,
         **         return false if the left date is earlier than the right date.
         **/
        bool operator>=(Date const & a);
        
        /** To a date a number will be added.
         **
         ** \return the changed date.
         **/
        Date operator+(int t);
        
        /** Of a date a number will be subtracted.
         **
         ** \return the changed date.
         **/
        Date operator-(int t);
        
        /**To a  date a number will be added.
         **The date is changed to that date.
         **
         ** \return the changed date.
         **/
        Date & operator+=(int t);
        
        /** Of a date a number will be subtracted
         ** The Date is changed to that date.
         **
         ** \return the changed date.
         **/
        Date & operator-=(int t);
        
        /**It is the prefix - operator of the addition.
         **After to the date 1 day  will be added, it will be used.
         **
         ** \return the changed date.
         **/
        Date & operator++();
        
        /**
         **It is the postfix - operator of the addition.
         **That means after date is been used, to the Date 1 day will be added.
         **
         ** \return a date before 1 day is added.
         **/
        Date   operator++( int );
        
        /**It is the prefix - operator of the subtraction.
         **After 1 day date will be subtracted, it will be used.
         **
         ** \return the changed date.
         **/
        Date & operator--();
        
        /**
         **It is the postfix - operator of the subtraction.
         ** That means after date is been used, of the Date 1 day will be subtracted.
         **
         ** \return a date before 1 day is subtracted.
         **/
        Date   operator--( int );
        
        /**It can say if it is a leap year or not
         **
         **\param The year you wanted to know if it is a leap year or not!
         **
         **\return true if it is one else he return false
         **/

        /** \}
         **/

        /** \name Query Methods
        **\{
         **/
    public:
        static  bool IsLeapYear( int year );
        
        /**It can say if it is a leap year or not
         **
         **\return true if it is one else he return false
         **/
        bool IsLeapYear() const;
        /** \}
         **/
        
    }; // class Date

    /** Prints a time on outstream in a special way.
     **/
    std::ostream & operator<<( std::ostream & out, const oc::Date & d );

    /** Requires a time in a special way, otherwise it can not set the variables so and can not write it on instream.
     **/
    std::istream & operator>>(std::istream & in, oc::Date & d);
    
}// namespace oc

#endif
