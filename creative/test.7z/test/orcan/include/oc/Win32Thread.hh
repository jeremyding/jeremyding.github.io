
#ifndef OC_WIN32_THREADER_HH
#define OC_WIN32_THREADER_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/Threader.hh>

// System include

#include <windows.h>


namespace oc {

    /** Thread Implementation used by oc::Threader on Win32 systems.
     ** \see Threader
     **/
    class OC_DSOAPI Win32Thread : public oc::ThreadImplementation
    {
    private:
        HANDLE         mThreadHandle;    
        DWORD          mThreadID;
        bool           mIsRunning;
        oc::Threader *mThreader;
        uint32         mPriority100;
    private:
        Win32Thread();

        static DWORD WINAPI RunMe(void *arg);

        bool CallThreadMethod();

    public:

        Win32Thread( oc::Threader *threader );

        virtual ~Win32Thread();

        void Cleanup();

        virtual bool CreateAndSuspend();

        virtual bool Suspend();

        virtual bool Resume();

        virtual bool Wait();

        virtual bool Kill();

        virtual bool IsRunning();

        virtual bool IsSuspended();

        virtual bool IsAlive();

        virtual bool SetPriority(uint32 priority100);

        virtual uint32 GetPriority();

    };

} // namespace oc

#endif


