
#ifndef OC_ERRNO_HH
#define OC_ERRNO_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/RuntimeException.hh>

// C include

#include <cerrno>



namespace oc
{


    // ===========
    // CLASS Errno
    // ===========

    /** This exception class encapsulates the error handling by errno.
     ** 
     ** The integer errno is set by system calls (and some library
     ** functions) to indicate what went wrong. Its value is significant
     ** only when the call returned an error (usually -1), and a library
     ** function that does succeed is allowed to change errno.
     ** 
     ** Sometimes, when -1 is also a legal return value one has to zero
     ** errno before the call in order to detect possible errors. errno
     ** is defined by the ISO C standard to be a modifiable lvalue of type
     ** int, and must not be explicitly declared; errno may be a macro.
     ** errno is thread-local; setting it in one thread does not affect its
     ** value in any other thread.
     ** 
     ** Example:
     ** 
     ** To make use of the errno error handling as simple as possible you
     ** can throw an instance of this class when a C library function went
     ** wrong.
     ** <pre>
     ** string MyClass::GetCurrentPath()
     **   throw( oc::Errno )
     ** {
     ** 
     **   char current_path[ oc::System::Path::sMaxNameLength ];
     ** 
     **   if( getcwd( current_path, oc::System::Path::sMaxNameLength ) == NULL )
     **     throw oc::Errno();
     ** 
     **   return( string( current_path ) );
     ** 
     ** }
     ** </pre>
     **/
    class OC_DSOAPI Errno : public RuntimeException
    {

	// ----------
	// Attributes
	// ----------

    private:

	/** Saves the global defined errno value. 
	 **/
	int mErrno;

	// -------------------------
	// Constructors / Destructor
	// -------------------------

    public:

	/** Creates a new exception instance using the global defined errno.
	 **/
	Errno();

	/** Copy constructor not allowed.
	 **/
	Errno( const Errno & err );

	/** Creates a new exception instance with the given errno.
	 ** @param errorNumber The errno integer value
	 **/
	Errno( int errorNumber );

	/** Destructor has nothing to do.
	 **/
	virtual ~Errno()
	    throw();

	// -----------------
	// Getters / Setters
	// -----------------

    public:

	/** Returns the errno value represented by the instance.
	 ** @return The errno integer value 
	 **/
	int GetErrorNumber();

	/** Returns a description string to the error number represented
	 ** by the instance. The descriptions are taken from the manual
	 ** pages of the system.
	 ** @return Description string corresponding to error number 
	 **/
	const std::string & GetErrorString();

	// ------------
	// Info methods
	// ------------

    public:

	/** Returns a description string to the error number represented
	 ** by the instance. The descriptions are taken from the manual
	 ** pages of the system.
	 ** @return Description string corresponding to error number
	 **/
	virtual const char * what() const
	    throw();

	// ----------------
	// Access operators
	// ----------------

    public:

	/** Assigns an errno exception to this instance.
	 ** @param err Assigned exception
	 ** @return Reference to instance with new assigned values
	 **/
	Errno & operator=( const Errno & err );

	// --------------
	// Static methods
	// --------------

    public:

        /** Returns a description string to the given error number. The
	 ** descriptions are taken from the manual pages of the system.
	 ** @param errorNb Error number for which the string should be looked up
         ** @return Description string corresponding to error number 
         **/
        static const std::string & GetErrnoString( int errorNb );

    }; // class Errno

} // namespace oc



#endif


