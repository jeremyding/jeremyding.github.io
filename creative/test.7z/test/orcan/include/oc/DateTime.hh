
#ifndef OC_DATETIME_HH
#define OC_DATETIME_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

#include <oc/Time.hh>
#include <oc/Date.hh>



namespace oc
{
    /**
     ** The class DateTime, defines an instanz which includes the classes date and time.
     ** It can set the date, time or both.
     ** Also it can return the date, time or both.
     **
     **\author Kathrin Reisloehner
     ** \date 24.9.2004
     **
     ** \nosubgrouping
     **/

    class DateTime {

        /** \name Attributes
         ** \{
         **/
    private:

        /** Dates in the format dd.mm.yyyy
         **/
        Date mDate;
    
        /** Times between [(0,0,0),(23,59,59)]
         **/
        Time mTime;
        /** \}
         **/
        
        /** \name Constructors / Destructor
         **\{
         **/
    public:
    
        /** Constructor (default). Initialize the DateTime to 1.1.0 and to 0:0:0
         **/
        DateTime();

        /** Constructor, initialize the DateTime to \p Date \p Time
         **
         ** It needs an instanz DateTime.
         **\param dt every useful datetime
         **/
        DateTime( const DateTime & dt );

        /** Constructor, initialize the DateTime to \p Date \p Time
         **
         ** It needs a Date and a time.
         **\param d every useful date
         **\param t every useful time between (0:0:0) and (23:59:59)
         **/
        DateTime( const Date & d, const Time & t );

        /** Destructor is empty.
         **/
        ~DateTime();
        
        /**\}
         **/

        /** \name Operators
         ** \{
         **/
        
    public:
        /** It set the left DateTime equal with the right date
         **
         **\return a date
         **/
        DateTime & operator=( const DateTime & rhs );

        /** It compares two DateTimes.
         **
         **\return true if is equal, return false if they are different.
         **/
        bool operator==(const DateTime dt);

        /** It compares two DateTimes:
         **
         **\return true if they are differnt, return false if they are equal.
         **/
        bool operator!=(const DateTime dt);

        /** \}
         **/

        /** \name Getter / Setter
         ** \{
         **/
        
    public:
        
        /** It set in DateTime the part Date to the date you wanted.
         **/
        bool Set( const Date & d );

        /** It set in DateTime the part Time to the time you wanted.
         **/
        bool Set( const Time & t );

        /** It set DateTime to Date and Time.
         **/
        bool Set( const Date & d, const Time & t );

        /** It returns the date.
         **/
        const Date & GetDate() const;

        /** It returns the time.
         **/
        const Time & GetTime() const;

        /** Returns the date and time of DateTime
         **/
        bool Get( Date & d, Time & t ) const;

        /** Returns the current date and time
         **/
        static DateTime GetCurrent();

        /** \}
         **/
    }; // class DateTime

} // namespace oc

#endif

    
