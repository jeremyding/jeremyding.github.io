
#ifndef OC_DYNAMIC_LOAD_MODULE_HH
#define OC_DYNAMIC_LOAD_MODULE_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/CPtr.hh>
#include <oc/File.hh>

// C++ include

#include <map>
#include <string>


#ifdef WIN32
  #include <windows.h>
#endif


namespace oc
{

    /** This class lets you easily handles external modules. External modules
     ** are shared object libraries \e .so under UNIX/Linux and dynamic load
     ** libraries \e .dll under Windows. This kind of libraries can be loaded
     ** during runtime when they are needed by the application. Another
     ** advantage is that they can also be unloaded during runtime and
     ** dynamically replaced by another implementation.
     **
     ** But care must be taken if one wants to unload the module during runtime.
     ** All instances allocated by this module must be deleted by the module
     ** before the module can savely be unloaded. If not all instances are
     ** deleted before unload, the application will fail in using this instance,
     ** in particular when it calles the destructor for the instance. There is
     ** no reference counting implemented in this class.
     **
     ** \b Path:
     **
     ** If you don't specify an absolute path to the module, i. e. if you use
     ** the constructor DynamicLoadModule( const std::string & ) or the
     ** corresponding creator Create( const std::string & ), than the system
     ** function which loads the module, \c dlopen() on UNIX and
     ** \c LoadLibrary() on Microsoft Windows, searches the module in the
     ** directories listed in the enviroment variables
     ** \c $LD_LIBRARY_PATH on UNIX and \c %PATH% on Microsoft Windows.
     **
     ** \b Example \b 1:
     **
     ** \code
     **
     ** // The C-function we are looking for.
     ** typedef double (*tCosFunc)(double);
     **
     ** // Load the module
     ** DynamicLoadModule module( File( "/usr/lib/libm.so" ) );
     **
     ** // Search for the C-function
     ** DynamicLoadModule::tSymbolPtr symbol = module.GetSymbol( "cos" );
     **
     ** if( symbol != DynamicLoadModule::tSymbolPtr::NullPtr ) {
     **
     **     // Cast the symbol to the correct type
     **     tCosFunc cosine = (tCosFunc) symbol.GetCPtr();
     **
     **     // Evaluate the C-function
     **     cout << "cos(2.) = " << (*cosine)(2.) << endl;
     ** }
     **
     ** \endcode
     **
     **
     ** \b Example \b 2:
     **
     ** \code
     **
     ** // The C-function we are looking for.
     ** typedef double (*tCosFunc)(double);
     **
     ** // Load the module
     ** DynamicLoadModule module( File( "/usr/lib/libm.so" ) );
     **
     ** // Search for the C-function
     ** tCosFunc cosine;
     **
     ** if( module.GetSymbol( "cos", cosine ) ) {
     **
     **     // Evaluate the C-function
     **     cout << "cos(2.) = " << (*cosine)(2.) << endl;
     ** }
     **
     ** \endcode
     **
     ** \author Michael Kellner
     ** \date 28.2.2003
     **
     ** \nosubgrouping
     **/
    class DynamicLoadModule
    {

	/** \name Class Types
	 ** \{
	 **/

    public:

	/** The system handle to a loaded dynamic library (.dll/.so)
	 **/
#ifdef WIN32
	typedef HMODULE tModuleHandle;
#else
	typedef void * tModuleHandle;
#endif

	/** A symbol in the module. Usually a symbol returned by the system call
	 ** is \c void \c *. But for using the Ptr<T> class we can't use \c void
	 ** as template parameter instead we use \c unsigned \c int.
	 **/
#ifdef _AIX
        typedef char  tSymbol;
#else
	typedef unsigned int tSymbol;
#endif

	/** A pointer to a symbol in the module.
	 **/
	typedef CPtr<tSymbol> tSymbolPtr;

	/** A symbol name in the module.
	 **/
	typedef std::string tSymbolName;

    protected:

	/** The cache table for already found symbols in the module. Once, the
	 ** symbol is looked up in the module by the system the pointer to the
	 ** corresponding symbol will be saved in this map and further
	 ** accesses to the same symbol are served from this cache.
	 **/
	typedef std::map<tSymbolName,tSymbolPtr> tSymbolTable;

	/** \}
	 **/

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The system handle for the dynamically loaded module. The type
	 ** \c tModuleHandle is defined in Compat.hh.
	 **/
	tModuleHandle mModuleHandle;

	/** The file name of the dynamic loadable module.
	 **/
	oc::File mModuleFile;

	/** The cache table for already found symbols in the module. This cache
	 ** holds pairs of the symbol name and corresponding pointers to
	 ** symbol in the module.
	 ** \see tSymbolPtr
	 **/
	tSymbolTable mSymbolTable;

	/** \}
	 **/

	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** The default constructor leaves the object uninitialized. You must
	 ** use the method Create() to initialize the instance.
	 **
	 ** \see Create(), DynamicLoadModule( const oc::File & )
	 **/
	OC_DSOAPI DynamicLoadModule();

	/** This constructor loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsLoaded() for the valid state.
	 **
	 ** Because of the lack of the class File to not allow file names
	 ** without path specification one can't specify a module like
	 ** DynamicLoadModule( File( "libm.so" ) ). The File class would
	 ** prefix the file name with the current path automatically and this
	 ** is not the correct path to \c libm.so in most cases. In such a
	 ** situation you must use the constructor with the module file as
	 ** \c std::string.
	 **
	 ** \param moduleFile File of the dynamic loadable module.
	 ** \see Create( const oc::File & ),
	 **      DynamicLoadModule( const std::string & )
	 **/
	OC_DSOAPI DynamicLoadModule( const oc::File & moduleFile );

	/** This constructor loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsLoaded() for the valid state.
	 **
	 ** \param moduleFile File of the dynamic loadable module.
	 ** \see Create( const std::string & ),
	 **      DynamicLoadModule( const oc::File & )
	 **/
	OC_DSOAPI DynamicLoadModule( const std::string & moduleFile );

	/** The copy constructor makes a copy all class attributes. Use the
	 ** copy constructor with care because only the actual state of the
	 ** module will be copied and not the module itself. That means if the
	 ** destructor of one of the two DynamicLoadModule instances are invoked
	 ** the module will be unloaded and so the system handle of the other
	 ** instance get invalid.
	 ** \param source The instance which will be copied.
	 ** \see ~DynamicLoadModule()
	 **/
	OC_DSOAPI DynamicLoadModule( const DynamicLoadModule & source );

	/** The destructor unloads the module.
	 ** \see UnloadModule(), DynamicLoadModule( const DynamicLoadModule & )
	 **/
	OC_DSOAPI virtual ~DynamicLoadModule();

	/** \}
	 **/

	/** \name Creators
	 ** \{
	 **/

    public:

	/** This creator loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsLoaded() for the valid state.
	 ** Do not use this method if the instance is already initialized, e. g.
	 ** IsLoaded() returns \c true.
	 **
	 ** Because of the lack of the class File to not allow file names
	 ** without path specification one can't specify a module like
	 ** DynamicLoadModule( File( "libm.so" ) ). The File class would
	 ** prefix the file name with the current path automatically and this
	 ** is not the correct path to \c libm.so in most cases. In such a
	 ** situation you must use the constructor with the module file as
	 ** \c std::string.
	 **
	 ** \param moduleFile File of the dynamic loadable module.
	 ** \return \c true if the module file could be loaded, \c false on
	 **         failure.
	 ** \see Create( const std::string & ),
	 **      DynamicLoadModule( const oc::File & )
	 **/
	OC_DSOAPI bool Create( const oc::File & moduleFile );

	/** This creator loads the dynamic loadable module from the given
	 ** file \e moduleFile. If the module file doesn't exists or is for any
	 ** other reason not loadable no exception will be thrown. Instead the
	 ** user can query the instance via IsLoaded() for the valid state.
	 ** Do not use this method if the instance is already initialized, e. g.
	 ** IsLoaded() returns \c true.
	 **
	 ** \param moduleFile File name of the dynamic loadable module.
	 ** \return \c true if the module file could be loaded, \c false on
	 **         failure.
	 ** \see Create( const oc::File & ),
	 **      DynamicLoadModule( const std::string & ),
	 **/
	OC_DSOAPI bool Create( const std::string & moduleFile );

	/** \}
	 **/

	/** \name Operators
	 ** \{
	 **/

    public:

	/** The assignment operator makes a copy of all class attributes. Use
	 ** this assignment operator with care because only the actual state of
	 ** the module will be copied and not the module itself. That means if
	 ** the destructor of one of the two DynamicLoadModule instances are
	 ** invokded the module will be unloaded and so the system handle of the
	 ** other instance get invalid.
	 ** \param source The instance which will be assigned.
	 ** \return The assigned dynamic load module instance.
	 **/
	OC_DSOAPI DynamicLoadModule & operator=( const DynamicLoadModule & source );

	/** \}
	 **/

	/** \name Getters / Setters
	 ** \{
	 **/

    public:

	/** Returns the file name of the module.
	 **
	 ** \return The file name of the module.
	 **/
	OC_DSOAPI const oc::File & GetModuleFile() const;

	// const oc::File & GetModuleFile() const;

	/** Returns the pointer to a symbol. The module will be queried for
	 ** the symbol named \a symbolName. Usually the symbol name corresponds
	 ** to a variable or function with C name mangling. Because of internal
	 ** caching of already found symbols the lookup will be done in two
	 ** steps:
	 **
	 ** 1. Lookup in the symbol table \c mSymbolTable for already found
	 **    symbols and if not found
	 **
	 ** 2. Lookup in the module symbol table of the system and save found
	 **    symbol in local table \c mSymbolTable.
	 **
	 ** \param symbolName Search for symbol with this name.
	 ** \return Pointer to the symbol or tSymbolPtr::NullPtr if the symbol
	 **         couldn't be found.
	 **/
	OC_DSOAPI tSymbolPtr GetSymbol( const std::string & symbolName );

	/** Returns the pointer to a symbol. The module will be queried for
	 ** the symbol named \a symbolName. Usually the symbol name corresponds
	 ** to a variable or function with C name mangling. Because of internal
	 ** caching of already found symbols the lookup will be done in two
	 ** steps:
	 **
	 ** 1. Lookup in the symbol table \c mSymbolTable for already found
	 **    symbols and if not found
	 **
	 ** 2. Lookup in the module symbol table of the system. BUT: The found
	 **    symbol will not saved in local table \c mSymbolTable because
	 **    this is the constant version of \c GetSymbol().
	 **
	 ** \param symbolName Search for symbol with this name.
	 ** \return Pointer to the symbol or tSymbolPtr::NullPtr if the symbol
	 **         couldn't be found.
	 **/
	OC_DSOAPI tSymbolPtr GetSymbol( const std::string & symbolName ) const;

	/** Get the pointer to a symbol. The module will be queried for
	 ** the symbol name \a symbolName. Usually the symbol name corresponds
	 ** to a variable or function with C name mangling. In order to get
	 ** this pointer in the correct type you can use this template method
	 ** which will cast the usually void function pointer to the expected
	 ** function signature.
	 **
	 ** \param symbolName Search for symbol with this name.
	 ** \param cFuncPtr C function pointer as expected type.
	 ** \return \c true if the symbol was found, \c false otherwise.
	 **/
	template <typename CFuncPtr>
	bool GetSymbol( const std::string & symbolName, CFuncPtr & cFuncPtr ) const
	{
	    cFuncPtr = (CFuncPtr) GetSymbol( symbolName ).GetCPtr();

	    return( cFuncPtr != (CFuncPtr) 0 );
	}

    protected:

	/** Returns the system handle of the loaded modul.
	 ** \return System handle of the modul if it was successfully loaded
	 **         or \c NULL.
	 **/
	OC_DSOAPI const tModuleHandle & GetModuleHandle() const;

	/** \}
	 **/

	/** \name Access Methods
	 ** \{
	 **/

    public:

	/** Load the module from the file \e mModuleFile into memory.
	 ** \return \c true if the module was loaded successfully. \c false
	 **         on failure.
	 ** \see UnloadModule(), GetModuleHandle(), GetModuleFile()
	 **/
	OC_DSOAPI bool LoadModule();

	/** Unload the previously loaded module.
	 ** \see ~DynamicLoadModule(), Create(), IsLoaded()
	 **/
	OC_DSOAPI bool UnloadModule();

	/** \}
	 **/

	/** \name Query Methods
	 ** \{
	 **/

    public:

	/** Checks whether the module file \c mModuleFile was loaded
	 ** successfully.
	 ** \return \c true if the module file was successful loaded,
	 **         \c false otherwise.
	 **/
	OC_DSOAPI bool IsLoaded() const;

	/** \}
	 **/

    }; // DynamicLoadModule

} // namespace oc



#endif

