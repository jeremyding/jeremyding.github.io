
#ifndef OC_OBJECT_BROKER_CONFIG_RESOURCE_LOADER
#define OC_OBJECT_BROKER_CONFIG_RESOURCE_LOADER

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>
#include <oc/ObjectBrokerConfig.hh>


namespace oc
{
    /** This is the resource loader for the object broker config. It reads the
     ** XML configuration file given by the SetInput() method and calls the
     ** appropriated methods of the object broker config given bye the
     ** SetOutput() method. The idea is that multiple object broker config
     ** with different configurations may be initialized by different config
     ** files. This object broker config instances can be set during runtime to
     ** the object broker for reconfiguration.
     **
     ** \author Michael Kellner
     ** \date 20.11.2003
     **
     ** \nosubgrouping
     **/

    class ObjectBrokerConfigResourceLoader
    {

	/** \name Attributes
	 ** \{
	 **/

    private:

	/** The XML resource file.
	 **/
	const oc::File * mInputXMLFile;

	/** The object broker config.
	 **/
	oc::ObjectBrokerConfigPtr mOutputOBConfigPtr;

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor (empty)
	 **/
	ObjectBrokerConfigResourceLoader();


	/**  Copy constructor
	 **/
	ObjectBrokerConfigResourceLoader( const ObjectBrokerConfigResourceLoader & source );

	/** Destructor
	 **/
	~ObjectBrokerConfigResourceLoader();

	/** \}
	 **/


	/** \name Operators
	 ** \{
	 **/

	/** Assignment operator
	 **/
	ObjectBrokerConfigResourceLoader & operator=( const ObjectBrokerConfigResourceLoader & rhs );

	/** \}
	 **/


	/** \name Command Methods
	 ** \{
	 **/

    public:

	/** Defines the input operand, the XML file, for this command.
	 **
	 ** \b Attention:
	 **
	 ** Only a reference to the XML resource file will be saved, so do not
	 ** delete the file object before deleting this instance.
	 **
	 ** \param xmlFile Resource file with the configuration data
	 **/
	virtual bool SetInput( const oc::File & xmlFile );

	/** Defines the output operand, the object broker config, for this
	 ** command.
	 **
	 ** \b Attention:
	 **
	 ** Only a reference to the object broker config will be saved, so do not
	 ** delete the config before deleting this instance.
	 **
	 ** \param obConfig Object broker config which will be configured
	 **                 by the XML file \p mInputXMLFile
	 **/
	virtual bool SetOutput( oc::ObjectBrokerConfig & obConfig );

	/** Execute the command by loading the resource file and applying
	 ** them to the object broker config.
	 **/
	virtual bool Execute();

	/** \}
	 **/

    }; // class ObjectBrokerConfigResourceLoader

} // namespace oc


#endif


