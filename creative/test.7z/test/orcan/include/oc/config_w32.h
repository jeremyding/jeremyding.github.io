
// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================



// This package
// ------------

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT
#define PACKAGE_BUGREPORT "orcan@ww.uni-erlangen.de"

/* Define to the full name of this package. */
#undef PACKAGE_NAME
#define PACKAGE_NAME "ORCAN"

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING
#define PACKAGE_STRING "ORCAN 0.0.1"

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME
#define PACKAGE_TARNAME "ocan"

/* Define to the version of this package. */
#undef PACKAGE_VERSION
#define PACKAGE_VERSION "0.0.1"




// Tools/package
// -------------

/* Define to 1 if you have bison++ */
#define HAVE_BISONPLUSPLUS 1

/* Define to 1 if you have flex++ */
#define HAVE_FLEXPLUSPLUS 1





// PRAGMA
// ------

//get rid of anoying warning:

// ... identifier was truncated to '255' characters in the debug information
// must be defined on every include !!!
#pragma warning (disable : 4786)

// ... needs to have a dll-interface to be used by client of class '<...>'
#pragma warning (disable : 4251)

// ... non dll-interface class '<..>' used as base for dll-interface class '<...>' 
#pragma warning (disable : 4275)

// ... C++ exception specification ignored except to indicate a function is not __declspec(nothrow)
#pragma warning (disable : 4290)


// 32-Bit architecture number types 
// ---------------------------------
typedef signed   __int64 int64;
typedef unsigned __int64 uint64;




// DEFINE
// ------

// M_PI is not defined in VC6s math.h
#ifndef M_PI
#  define M_PI 3.14159265358979323846
#endif


// Sometimes 'typename' is not valid on Win32 platforms. In that case
// use OC_TYPENAME which is defined to empty.
#if defined(_MSC_VER) && (_MSC_VER < 1300)
#  define OC_TYPENAME
#else
#  define OC_TYPENAME typename
#endif


// STL
// ---

// min and max are not defined in VC6s stl 
#if defined(_MSC_VER) && (_MSC_VER < 1300)
namespace std
{
#undef min
#undef max
// min and max are not defined in VC6s stl 
   //template< class T > const T& min(const T& _a_, const T& _b_ ) { if(_a_<_b_) return _a_; else return _b_; }
   //template< class T > const T& max(const T& _a_, const T& _b_ ) { if(_a_>_b_) return _a_; else return _b_; }

   inline double min(double _a_, double _b_); 
   inline double max(double _a_, double _b_); 

}
inline double std::min(double _a_, double _b_) { return (_a_<_b_) ? _a_ : _b_; }
inline double std::max(double _a_, double _b_) { return (_a_>_b_) ? _a_ : _b_; }

namespace std{
#undef abs
    inline float abs(float _a_);

    inline double abs(double _a_);

    inline int abs(int _a_);

}
inline float std::abs(float _a_) { if(_a_<0.f) return -_a_; else return _a_; }
inline double std::abs(double _a_) { if(_a_<0.) return -_a_; else return _a_; }
inline int std::abs(int _a_) { if(_a_<0.f) return -_a_; else return _a_; }

#else if defined(_MSC_VER) // version VC7 and newer
namespace std 
{
#undef min
	template <class T> 
		T const& min( T const& a, T const& b);
#undef max
	template <class T> 
		T const& max( T const& a, T const& b);
}

#endif




// ORCAN
// -----

#ifdef BUILD_ORCAN_DLL // create the orcan.dll
#  ifdef _USRDLL
#    define OC_DSOAPI        __declspec(dllexport)
#  else
#    define OC_DSOAPI 
#  endif
#elif ORCAN_STATIC //use/build the static version: orcan_*s.lib
#  define OC_DSOAPI
#else // use the orcan.dll 
#  define OC_DSOAPI        __declspec(dllimport)
#endif

#undef MOD_DSOIMPORT
#ifdef OC_MODULE_DLL
# define MOD_DSOIMPORT  __declspec(dllimport)
#else
# define MOD_DSOIMPORT  __declspec(dllexport)
#endif


