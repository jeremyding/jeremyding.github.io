
#ifndef OC_PROPERTY_HH
#define OC_PROPERTY_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>
#include <oc/Field.hh>
#include <oc/MField.hh>
#include <oc/SFieldRef.hh>
#include <oc/PropertyResource.hh>
#include <oc/PropertyListener.hh>
#include <oc/File.hh>

// C include

#include <cassert>



namespace oc
{


    /** Datastructure for a pointer to class Field with string ID.
     ** You can use a Property to store a value with an attached ID, in a type-safe way.
     ** That means if the property references an int and you assign a non-int to
     ** the Property or if you try to read the Property into a non_int, an exception
     ** will be thrown.
     ** Property can be used directly, however it is much more comfortable to use a PropertyMap.
     ** PropertyMap will hide all the annoying SField/MField calls from you !!!!
     ** It is allowed to create copies of a property, it will still access the same
     ** field.
     **
     ** \code
     **     //Example:
     **     int   v1 = 5;
     **     float f1 = 2.5f;
     **     std::string s1 = "huhu";
     **     int   v2 = 6;
     ** 
     **     oc::Property p0("pv1",new oc::SFieldRef<int>(v1));
     **     oc::Property p1("pf1",new oc::SFieldRef<float>(f1));
     **     oc::Property p2("ps1",new oc::SFieldRef<std::string>(s1));
     **     oc::Property p3("pv2",new oc::SField<int>(v2));
     ** 
     **     // pv1=5 v1=5, pf1=2.5 f1=2.5, ps1=huhu s1=huhu, pv2=6  v2=6
     ** 
     **     v1 = 2; 
     **     f1 = 2.1f;
     **     s1 = std::string("aha");
     **     v2 = 3;
     ** 
     **     // pv1=2 v1=2, pf1=2.1 f1=2.1, ps1=aha s1=aha, pv2=6  v2=3
     **   
     **     p0.SetStringValue("10",FIELD_ID(int));
     **     p1.SetStringValue("10",FIELD_ID(float));
     **     p2.SetStringValue("10",FIELD_ID(std::string));
     **     p3.SetStringValue("10",FIELD_ID(int));
     ** 
     **     // pv1=10 v1=10, pf1=10 f1=10, ps1=10 s1=10, pv2=10  v2=3
     **    
     **     p0 = 1;
     **     p1 = 3.14f;
     **     p2 = std::string("end");
     **     p3 = 42;
     ** 
     **     // pv1=1 v1=1, pf1=3.14 f1=3.14, ps1=end s1=end, pv2=42  v2=3
     **
     **     // type-safe
     **     //v1 = 2.f; // this might work, assuming an automatic cast
     **     //p0 = 2.f; // this will result in an exception, as p0 references an int
     **
     **     // for basic-types no FIELD_ID is needed (see SetStringValue)
     **     p0.SetStringValue("11");
     **     p1.SetStringValue("11");
     **     p2.SetStringValue("11");
     **     p3.SetStringValue("11");
     **     
     ** \endcode
     **
     ** \see PropertyMap
     **
     ** \author Horst Hadler
     ** \date 6.3.2003
     **
     ** \nosubgrouping
     **/
    class Property
    {

    protected:



	/** Field-Pointer Wrapper that can be used to access the Field-Pointers
	 ** in a 'non-pointer' way.
	 **
	 ** \author Horst Hadler
	 ** \date 6.3.2003
	 **
	 ** \nosubgrouping
	 **/
	class FieldPtr
	{

        private:

            OC_DSOAPI FieldPtr();

        public:
	    /** \name Attributes
	     ** \{
	     **/

            /** parent property.
             **/
            Property *mProp;

            /** The C pointer to wrap.
            **/
            Field    *mPtr;

            /** Compare RTTI
             **/
            bool      mCheckRTTI;
        
            /** \}
	     **/

	    /** \name Constructors / Destructor
	     ** \{
	     **/

	    /** Create a Field-Pointer Wrapper.
	     **
             ** \param prop property
	     ** \param fp C pointer to wrap.
             ** \param check_rtti use RTTI of stored field, whenever this field is queried or set
	     **/
	    OC_DSOAPI FieldPtr( Property* prop, Field * fp, bool check_rtti )
            {
                mProp      = prop;
                mPtr       = fp;
                mCheckRTTI = check_rtti;
            }


	    /** \}
	     **/


	    /** \name Operators
	     ** \{
	     **/

	    /** Get a reference to the value stored by the Field this instance
	     ** points to.
	     **
	     ** \param dummy Unused.
	     ** \return Reference to field's value.
	     **/
	    template <typename T>
	    T & operator()( T const & dummy )
	    {
                return mCheckRTTI ? mPtr->GetRef(FIELD_ID(T)) : mPtr->GetRefForced(FIELD_ID(T));
	    }

	    /** Get a reference to the value stored by the Field this instance
	     ** points to.
	     **
	     ** \param dummy Unused.
	     ** \return Reference to field's value.
	     **/
	    template <typename T>
	    const T & operator()( T const & dummy ) const
	    {
                return mCheckRTTI ? mPtr->GetRef(FIELD_ID(T)) : mPtr->GetRefForced(FIELD_ID(T));
	    }

	    /** Assign a value to the Field this instance points to.
	     ** \param v Value to assign.
	     ** \return Reference to assigned value in the field.
	     **/
	    template <typename T>
	    T & operator=( T const & v )
	    {        

                mPtr->GetRefForced(FIELD_ID(T)) = v;
                mPtr->NotifyListeners( *mProp, false );

                return mCheckRTTI ? mPtr->GetRef(FIELD_ID(T)) : mPtr->GetRefForced(FIELD_ID(T));
	    }


	    /** Assign a value to the Field this instance points to.
	     ** \param val Value to assign.
             ** \param name Name identifying the field.
	     ** \return Reference to assigned value in the field.
	     **/
	    template <typename T>
            void Assign( T const & val, std::string const& name )
                throw( std::bad_cast )
            {
                mPtr->GetRef(FIELD_ID(T)) = val;
                mPtr->NotifyListeners( *mProp, false );
            }

	    /** Get the idx-th sub-value of the MField this instance points to
	     ** (only valid for MField-Wrappers).
	     **
	     ** \param idx Return idx-th sub value.
	     ** \return FieldPtr to idx-th sub value.
	     **/
	    OC_DSOAPI FieldPtr operator[]( int const & idx )
		throw( std::bad_cast )
	    {
                if( mCheckRTTI ) {
                    if( ::strcmp( mPtr->GetType().name(),
                                  typeid( MField ).name() ) != 0 ) {

                        throw std::bad_cast();
                    }
                }

                return FieldPtr( mProp, (*((MField*)mPtr))[idx], mCheckRTTI);
            
	    }



	    /** \}
	     **/

	}; // struct FieldPtr

    


	/** \name Attributes
	 ** \{
	 **/

    private:

	/** Name, identifying this property
	 **/
	std::string mName;

	/** Pointer to encapsulated value(s).
	 **/
	FieldPtr mTheField;

        /** Resource, describing this property.
         **/
        oc::PropertyResource mResource;



    public:

        /** Get the NULL Property.
         ** Empty property (returned when unititialized or on failure).
         **/
        OC_DSOAPI static Property & Null();

	/** \}
	 **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default ctor/ creates Null property.
	 **
	 **/
	OC_DSOAPI Property();


	/** Standard constructor.
	 **
	 ** \param name Name identifying the field.
	 ** \param field Pointer to a field-instance.
	 **/
	OC_DSOAPI Property( std::string const & name,
                              Field *     const & field);


        /** Copy ctor.
         **/
        OC_DSOAPI Property( Property const& cp );

        /** Dtor.
         **/
        OC_DSOAPI virtual ~Property();

	/** \}
	 **/


        /** \name Resources
         ** \{
         **/

        /** Set resource describing this property.
         **/
        OC_DSOAPI bool SetResource(PropertyResource const & res);

        /** Get readonly resource describing this property.
         **/
        OC_DSOAPI PropertyResource const & GetResource() const;

        /** Get readonly resource describing this property.
         **/
        OC_DSOAPI PropertyResource& GetResource();

	/** \}
	 **/





	/** \name Getter / Setter
	 ** \{
	 **/

    public:

	/** Get name identifying the field.
	 **
	 ** \return Name of the field.
	 **/
	OC_DSOAPI std::string & GetName();

	/** Get readonly name identifying the field.
	 **
	 ** \return Name of the field.
	 **/
	OC_DSOAPI const std::string & GetName() const;


        /** Enable/Disable RTTI-Check when assigning values to/from this Property.
         ** \param checkrtti true = enable RTTI-Check
         **/
        OC_DSOAPI void SetRTTICheck(bool checkrtti);

	/** Get string-form of the value encapsulated by this property .
	 **
	 ** \return value string
	 **/
	OC_DSOAPI std::string GetStringValue() const;

	/** Set a field value to the value given by a string
	 **
         ** \param strval value to be set, interpreted as value of type T
         ** \param dummy Unused.
	 **/
	template <typename T>
        void SetStringValue( std::string const& strval, T const & dummy ) 

	{
            // make sure we don't operate on an uninitialized field
	    assert( mTheField.mPtr != NULL );

            // 'parse' the value
            std::istringstream sstrm(strval);
            T tempval;
            sstrm >> tempval;

            // set the value
            mTheField = tempval;
	}

	/** Set a field value to the value given by a string.
         ** This method will try to set the value using runtime typeinfo of the
         ** stored field. It will only work for the following types:
         ** signed|unsigned int, float,double, signed|unsigned char, 
         ** uint32,int32, real32, real64, std::string and bool. If the contained field
         ** is of any other type std::bad_cast exception will be thrown. If 
         ** efficiency is important the SetStringValue member template should be
         ** used
	 **
         ** \param strval value to be set
	 **/
        OC_DSOAPI void SetStringValue( std::string const& strval ) throw( std::bad_cast );

        /** Get RunTimeTimeInformation of encapsulated value.
         **/
        OC_DSOAPI const std::type_info & GetType() const;

	/** \}
	 **/

	/** \name Query methods
	 ** \{
	 **/

        /** Test if this field has the given type_info.
         ** \param info type info 
         ** \return true if type info identical
         **/
	OC_DSOAPI bool IsType(const std::type_info & info) const;

        /** Test if the property is the Null property.
         **
         ** \return true if it is the Null property.
         **/
        OC_DSOAPI bool IsNull() const;

	/** \}
	 **/




	/** \name Operators
	 ** \{
	 **/

    public:    
    
	/** Get pointer to a sub-field (of a MField)
	 **
	 ** \param idx Return idx-th. sub-field.
	 ** \return idx-th. subfield.
	 **/
	OC_DSOAPI Property::FieldPtr operator[]( int const & idx )
	    throw( std::bad_cast );

        /** Get a reference of type T to the object represented by the Field.
	 **
	 ** \param dummy Unused.
	 ** \return Reference to contained field.
	 **/
	template <typename T>
	T & operator()( T const & dummy )
	{
	    assert( mTheField.mPtr != NULL );

            return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(dummy) : mTheField.mPtr->GetRefForced(dummy);
	}

	/** Get a reference of type T to the object represented by the Field.
	 **
	 ** \param dummy Unused.
	 ** \return Reference to contained field.
	 **/
	template <typename T>
	const T & operator()( T const & dummy ) const
	{
	    assert( mTheField.mPtr != NULL );

            return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(dummy) : mTheField.mPtr->GetRefForced(dummy);
	}

	/** Assign a value of type T to the object represented by the Field:
	 **
	 ** \param val Value to assign.
	 ** \return Property after assignment.
	 **/
	template <typename T>
	Property & operator=( T const & val )
	    throw( std::bad_cast )
	{
	    assert( mTheField.mPtr != NULL );

            mTheField.Assign(val,mName);

	    return *this;
	}

        /** Property assignment op.
         **/
        OC_DSOAPI Property& operator=( Property const& cp ) throw( std::bad_cast );

	/** \}
	 **/

	/** \name Conversion Operators
         ** generic conversion operator resulted in INTERNAL COMPILER ERROR (VS6,C++12.0,Win32)
	 ** \{
	 **/
#if (defined(_MSC_VER) && (_MSC_VER > 1300)) 
	template <typename T>
	operator T const& () const 
	{ 
		return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(T)) : mTheField.mPtr->GetRefForced(FIELD_ID(T)); 
	} 
	template <typename T>
	operator T & () 
	{ 
		return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(T)) : mTheField.mPtr->GetRefForced(FIELD_ID(T)); 
	} 
#else
        operator uint32 const& () const      { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(uint32))      : mTheField.mPtr->GetRefForced(FIELD_ID(uint32)); } 
        operator uint32& ()                  { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(uint32))      : mTheField.mPtr->GetRefForced(FIELD_ID(uint32)); }
        operator int32 const& () const       { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(int32))       : mTheField.mPtr->GetRefForced(FIELD_ID(int32)); } 
        operator int32& ()                   { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(int32))       : mTheField.mPtr->GetRefForced(FIELD_ID(int32)); }
        operator uint8 const& () const       { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(uint8))       : mTheField.mPtr->GetRefForced(FIELD_ID(uint8)); } 
        operator uint8& ()                   { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(uint8))       : mTheField.mPtr->GetRefForced(FIELD_ID(uint8)); }
        operator int8 const& () const        { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(int8))        : mTheField.mPtr->GetRefForced(FIELD_ID(int8)); } 
        operator int8& ()                    { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(int8))        : mTheField.mPtr->GetRefForced(FIELD_ID(int8)); }
        operator std::string const& () const { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(std::string)) : mTheField.mPtr->GetRefForced(FIELD_ID(std::string)); } 
        operator std::string& ()             { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(std::string)) : mTheField.mPtr->GetRefForced(FIELD_ID(std::string)); }
        operator bool const& () const        { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(bool))        : mTheField.mPtr->GetRefForced(FIELD_ID(bool)); } 
        operator bool& ()                    { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(bool))        : mTheField.mPtr->GetRefForced(FIELD_ID(bool)); }
        operator real32 const& () const      { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(real32))      : mTheField.mPtr->GetRefForced(FIELD_ID(real32)); } 
        operator real32& ()                  { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(real32))      : mTheField.mPtr->GetRefForced(FIELD_ID(real32)); }
        operator real64 const& () const      { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(real64))      : mTheField.mPtr->GetRefForced(FIELD_ID(real64)); } 
        operator real64& ()                  { return mTheField.mCheckRTTI ? mTheField.mPtr->GetRef(FIELD_ID(real64))      : mTheField.mPtr->GetRefForced(FIELD_ID(real64)); }
#endif

	/** \}
	 **/



        /** \name Change Listener.
         ** \{
         **/

    public:
        /** Add a listener.
         ** Listeners will be added to the contained field!!!
         **/
        OC_DSOAPI void AddListener(PropertyListener * l);

        /** Remove a listener.
         **/
        OC_DSOAPI void RemoveListener(PropertyListener * l);

        /** Call listener callback of all registered listeners.
         ** NotifyListeners is autmatically called by the assignment op.
         ** \param about_to_be_delete true if this Property is deleted and the listener should stop listening (it will be removed automatically)
         **/
        OC_DSOAPI void NotifyListeners(bool about_to_be_delete = false);

	/** \}
	 **/


	/** \name Callback mechanism
	 ** \{
	 **/

    public:    

        /** Invoke 'bool dosth( std::string const&)' callback.
         **/
        OC_DSOAPI bool Callback( std::string const& msg );


        /** Invoke 'void dosth( void *)' callback.
         **/
        OC_DSOAPI void Callback( void *data);

	/** \}
	 **/

    }; // class Property

    /** Callback Mechanism for 'calling classes' that have properties.
     ** 
     ** \code
     **
     ** // use callbacks without having to derive from a callback interface-class
     ** // Only callbacks with one of the prededfined signatures may be used.
     **
     ** // add callback to some component
     ** mProperties.AddProperty( "Parameter:TestCallback", this, &Call  );
     **
     ** // now the callback can be called via that property,
     ** // for example to signal a change: Call-Method get's called.
     ** return somecomponent.GetProperties()["Parameter:TestCallback"].Callback("some msg");
     **
     ** \endcode
     **/
    class PropertyCallback {};


    /** Two properties are equal if they have the same property name.
     **/
    OC_DSOAPI
    bool
    operator==( const oc::Property & lhs, const oc::Property & rhs );

    /** Two properties are unequal if they did not have the same property name.
     **/
    OC_DSOAPI
    bool
    operator!=( const oc::Property & lhs, const oc::Property & rhs );

} // namespace oc


#endif
