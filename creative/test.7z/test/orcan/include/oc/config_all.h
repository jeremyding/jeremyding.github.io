
#ifndef OC_CONFIG_ALL_H
#define OC_CONFIG_ALL_H

/* ==========================================================================
 *
 *  Crystal Growth Laboratory
 *
 *  University Erlangen-Nuremberg          Fraunhofer Gesellschaft
 *  Department of Material Science         Institute of Integrated Systems
 *  Electrical Engineering Martials        Device Technology Devision (IIS-B)
 *  Martensstrasse 7                       Schottkystrasse 10
 *  91058 Erlangen                         91058 Erlangen
 *  Germany                                Germany
 *
 *  In cooperation with
 *
 *  University Erlangen-Nuremberg          University Erlangen-Nuremberg
 *  Department of Computer Science 9       Department of Computer Science 10
 *  Computer Graphics                      System Simulation Group
 *  Am Weichselgarten 9                    Cauerstra�e 6
 *  91058 Erlangen                         91058 Erlangen
 *  Germany                                Germany
 *
 * ==========================================================================
 *
 * Copyright 2004 (c) by
 * (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
 * (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
 * (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
 * (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
 *
 * For Licensing regulations see the accompanying LICENSE file.
 * If this file does not exist and/or does not apply to you, please contact
 * the copyright holders.
 *
 * ========================================================================== */


// STL include

#include <vector>
#include <string>

#if defined(_MSC_VER) && (_MSC_VER < 1300)
#include <oc/hash_map.hh>
#else
#include <map>
#endif

/*
  From wxWindows/wxWidgets:

  This macro can be used to test the gcc version and can be used like this:

  #if OC_CHECK_GCC_VERSION(3, 1)
    ... we have gcc 3.1 or later ...
  #else
    ... no gcc at all or gcc < 3.1 ...
  #endif
*/
#define OC_CHECK_GCC_VERSION( major, minor ) \
    ( defined(__GNUC__) && defined(__GNUC_MINOR__) \
    && ( ( __GNUC__ > (major) ) \
        || ( __GNUC__ == (major) && __GNUC_MINOR__ >= (minor) ) ) )

// --------------------------------
// 32-Bit architecture number types
// --------------------------------

typedef signed char    int8;
typedef signed short   int16;
typedef signed int     int32;
typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned int   uint32;
typedef float          real32;
typedef double         real64;



// Abbreviations
// -------------
typedef std::vector<int>         tVecInt;
typedef std::vector<float>       tVecFloat;
typedef std::vector<double>      tVecDouble;
typedef std::vector<std::string> tVecString;

#if defined(_MSC_VER) && (_MSC_VER < 1300)
typedef oc::hash_map<uint32,uint32>   tMapUInt32UInt32;
typedef oc::hash_map<int,int>         tMapIntInt;
typedef oc::hash_map<int,std::string> tMapIntString;
typedef oc::hash_map<std::string,int> tMapStringInt;
#else
typedef std::map<uint32,uint32>   tMapUInt32UInt32;
typedef std::map<int,int>         tMapIntInt;
typedef std::map<int,std::string> tMapIntString;
typedef std::map<std::string,int> tMapStringInt;
#endif



// define RAD2DEG and DEG2RAD
#ifndef RAD2DEG
#define RAD2DEG( ANG ) (ANG*180./M_PI)
#endif

#ifndef DEG2RAD 
#define DEG2RAD( ANG ) (ANG*M_PI/180.)
#endif


#endif
