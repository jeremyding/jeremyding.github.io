
#ifndef OC_TERM_HH
#define OC_TERM_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>

// STL include

#include <string>



namespace oc
{

    // CLASS Term
    // ==========

    /** The terminal class encapsulates all terminal output specific data and
     ** functions.<br>
     ** <br>
     ** Inner class is EscSeq which holds escape sequences for colored
     ** terminal output.
     ** 
     ** \author Michael B. Kellner
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI Term
    {

        /** \name Constructors / Destructor
         ** \{
         **/

	// Should be private but in order to avoid the warning:
	// "all member functions in class `oc::Term' are private"
	// during compilation the constructors/destructor are "only" protected.

    protected:

	/** Default constructor not allowed
	 **/
	Term();

	/** Copy constructor not allowed.
	 **/
	Term( const Term & term );

	/** Destructor not allowed.
	 **/
	~Term();

        /** \}
         **/

        /** \name Operators
         ** \{
         **/

    private:

	/** Assignment not allowed.
	 **/
	Term & operator=( const Term & term );

        /** \}
         **/

    public:

	// CLASS Term::EscSeq
	// ==================

	/** The EscSeq class allows colored terminal output. Most terminals
	 ** allow colored fonts. In order to activate a particular color one
	 ** have to specify escape sequences into the output stream. This class
	 ** contains only <tt>static string</tt> attributes which can easily be
	 ** passed to the output stream. The escape sequences are separated into
	 ** <i>foreground</i> and <i>background colors</i> and <i>attributes</i>
	 ** for blinking and underlining.
	 ** 
         ** \author Michael B. Kellner
         ** \nosubgrouping
	 **/
	class OC_DSOAPI EscSeq
	{

            /** \name Static Attributes
             ** \{
             **/

	public:

	    // Foreground colors
	    // -----------------

	    /** The grey foreground color escape sequence.
	     **/
	    static const std::string msFgGrey;

	    /** The red foreground color escape sequence.
	     **/
	    static const std::string msFgRed;

	    /** The green foreground color escape sequence.
	     **/
	    static const std::string msFgGreen;

	    /** The yellow foreground color escape sequence.
	     **/
	    static const std::string msFgYellow;

	    /** The blue foreground color escape sequence.
	     **/
	    static const std::string msFgBlue;

	    /** The magenta foreground color escape sequence.
	     **/
	    static const std::string msFgMagenta;

	    /** The cyan foreground color escape sequence.
	     **/
	    static const std::string msFgCyan;

	    /** The white foreground color escape sequence.
	     **/
	    static const std::string msFgWhite;

	    /** The black foreground color escape sequence.
	     **/
	    static const std::string msFgBlack;


	    // Background colors
	    // -----------------

	    /** The grey background color escape sequence.
	     **/
	    static const std::string msBgGrey;

	    /** The red background color escape sequence.
	     **/
	    static const std::string msBgRed;

	    /** The green background color escape sequence.
	     **/
	    static const std::string msBgGreen;

	    /** The yellow background color escape sequence.
	     **/
	    static const std::string msBgYellow;

	    /** The blue background color escape sequence.
	     **/
	    static const std::string msBgBlue;

	    /** The magenta background color escape sequence.
	     **/
	    static const std::string msBgMagenta;

	    /** The cyan background color escape sequence.
	     **/
	    static const std::string msBgCyan;

	    /** The white background color escape sequence.
	     **/
	    static const std::string msBgWhite;

	    /** The black background color escape sequence.
	     **/
	    static const std::string msBgBlack;


	    // Attributes
	    // ----------

	    /** The escape sequence for blinking font.
	     **/
	    static const std::string msBlinking;

	    /** The escape sequence for underlined font.
	     **/
	    static const std::string msUnderline;

	    /** The escape sequence for normal font.
	     **/
	    static const std::string msNormal;

            /** \}
             **/

            /** \name Constructors / Destructor
             ** \{
             **/

	    // Should be private but in order to avoid the warning:
	    // "all member functions in class `oc::Term::EscSeq' are private"
	    // during compilation the constructors/destructor are "only" protected.

	protected:

	    /** Default constructor not allowed
	     **/
	    EscSeq();

	    /** Copy constructor not allowed.
	     **/
	    EscSeq( const EscSeq & escSeq );

	    /** Destructor not allowed.
	     **/
	    ~EscSeq();


            /** \name Operators
             ** \{
             **/

	private:

	    /** Assignment not allowed.
	     **/
	    EscSeq & operator=( const EscSeq & escSeq );

            /** \}
             **/

	}; // CLASS Term::EscSeq

    }; // CLASS Term

} // namespace oc


#endif

