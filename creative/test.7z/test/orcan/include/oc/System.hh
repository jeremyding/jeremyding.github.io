
#ifndef OC_SYSTEM_HH
#define OC_SYSTEM_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/File.hh>
#include <oc/Errno.hh>
#include <oc/config.h>

// STL include

#include <string>
#include <map>



namespace oc
{

    // ============
    // CLASS System
    // ============

    /** The <i>System</i> class contains system-dependent properties and
     ** operations.
     ** 
     ** Among the facilities provided by the <i>System</i> class are standard
     ** input, standard output, and error output streams; access to externally
     ** defined "properties"; a means of loading files and libraries;
     ** 
     ** \author Michael B. Kellner
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI System
    {

        /** \name Constructors / Destructor
         ** \{
         **/

	// Should be private but in order to avoid the warning:
	// "all member functions in class `oc::System' are private"
	// during compilation the constructors/destructor are "only" protected.

    protected:

	/** No instances allowed, use only the static methods.
	 **/
	System();

	/** No instances allowed, use only the static methods.
	 **/
	System( const System & system );

	/** No instances allowed, use only the static methods.
	 **/
	~System();

        /** \}
         **/

        /** \name Operators
         ** \{
         **/

    private:

	/** No instances allowed, use only the static methods.
	 **/
	System & operator=( const System & system );

        /** \}
         **/


        /** \name System calls
         ** \{
         **/

    public:


        /** Create a beeping sound for duration milliseconds in frequence freq.
         ** \param freq frequency
         ** \param duration duration
         **/
        static void Beep(uint32 freq, uint32 duration);

        /** Stop task execution for ms milliseconds
         **/
        static void Sleep( uint32 ms );

        /** \}
         **/




	// ==================
	// CLASS System::File
	// ==================

        /** This inner class holds all system-dependent values concerning files. 
         **
         ** \author Michael B. Kellner
         ** \nosubgrouping
         **/
	class OC_DSOAPI File
	{

            /** \name Static Attributes
             ** \{
             **/

        public:

            /** The maximal length of the filename string.
             **/
	    static const int msMaxNameLength;

            /** The system-dependent default name-separator character
	     ** <tt>'/'</tt> on UNIX systems. 
             **/
            static const char msSeparatorCharUnix;

            /** The system-dependent default name-separator character
	     ** <tt>"/"</tt> on UNIX systems, represented as a string for
	     ** convenience.
             **/
            static const std::string msSeparatorUnix;

            /** The system-dependent default name-separator character
	     ** <tt>'\'</tt> on Win32 systems. 
             **/
            static const char msSeparatorCharWin32;

            /** The system-dependent default name-separator character
	     ** <tt>"\"</tt> on Win32 systems, represented as a string for
	     ** convenience. 
             **/
            static const std::string msSeparatorWin32;

            /** The system-dependent default name-separator character. On UNIX
	     ** systems the value of this field is <tt>'/'</tt>; on Win32
	     ** systems it is <tt>'\'</tt>.
             **/
            static const char msSeparatorChar;

            /** The system-dependent default name-separator character,
	     ** represented as a string for convenience. On UNIX systems the
	     ** value of this field is <tt>"/"</tt>; on Win32 systems it is
	     ** <tt>"\"</tt>.
             **/
            static const std::string msSeparator;

            /** \}
             **/

            /** \name Constructors / Destructor
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    File();

	    /** No instances allowed, use only the static methods.
	     **/
	    File( const File & file );

	    /** No instances allowed, use only the static methods.
	     **/
	    ~File();

            /** \}
             **/


            /** \name Operators
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    File & operator=( const File & file );

            /** \}
             **/

            /** \name Static Methods
             ** \{
             **/

	public:

	    /** Creates a new empty file in the specified directory, using the
	     ** given prefix string to generate its name. If this method returns
	     ** successfully then it is guaranteed that:
	     ** <ol>
	     **   <li>The file denoted by the returned abstract pathname did not
	     **       exist before this method was invoked, and
	     **   </li>
	     **   <li>Neither this method nor any of its variants will return the
	     **       same abstract pathname again in the current program run.
	     **   </li>
	     ** </ol>
	     ** If the directory argument is <i>File::Null</i> then the
	     ** system-dependent default temporary-file directory will be used.
	     ** The default temporary-file directory is specified by
	     ** <i>oc::System::Path::sTempDirectory</i>. On UNIX systems the
	     ** default value of this property is typically <tt>"/tmp"</tt> or
	     ** <tt>"/var/tmp"</tt>; on Win32 systems it is typically
	     ** <tt>"c:\\temp"</tt>. If the system-dependent default
	     ** temporary-file directory doesn't exists the environment variables
	     ** <tt>"TMP"</tt> and <tt>"TEMP"</tt> will be looked up. It this
	     ** provides also no useable directory the current directory will be
	     ** looked up.
	     ** @param namePrefix The prefix string is used to generate the file
	     **        name. If empty string the prefix <tt>tmp</tt> will be used.
	     ** @param directory The directory in which the file is to be created,
	     **        if <i>File::Null</i> the default temporary-file directory
	     **        or the environment variables <tt>"TMP"</tt> and
	     **        <tt>"TEMP"</tt> will be used
	     ** @return An abstract pathname denoting a newly-created empty file
	     **/
	    static oc::File CreateTempFile(const std::string & namePrefix = std::string(""),
                                             const oc::File  & directory  = oc::File::Null);

        /** Get a 'File' 'pointing' to the temp director.
         ** \return temp directory (or oc::File::Null  in case of error)
         ** \author horst (splitted up CreateTempFile)
         **/
        static oc::File GetTempFileDir();

            /** \}
             **/



        }; // CLASS System::File




	// ==================
	// CLASS System::Path
	// ==================
    
	/** This inner class holds all system-dependent values concerning paths.
         **
         ** \author Michael B. Kellner
         ** \nosubgrouping
         **/
	class OC_DSOAPI Path
	{
        
            /** \name Static Attributes
             ** \{
             **/
            
	public:

            /** The maximal length of the pathname string.
             **/
            static const int msMaxNameLength;

            /** The system-dependent default temporary-file directory. On UNIX
	     ** systems the default value is typically <tt>"/tmp"</tt> or
	     ** <tt>"/var/tmp"</tt>; on Win32 systems it is typically
	     ** "c:\\temp".
             **/
            static const oc::File msTempDirectory;

            /** The system-dependent default path-separator character
	     ** <tt>':'</tt> on UNIX systems.
             **/
            static const char msSeparatorCharUnix;

            /** The system-dependent default path-separator character
	     ** <tt>":"</tt> on UNIX systems.
             **/
            static const std::string msSeparatorUnix;

            /** The system-dependent default path-separator character
	     ** <tt>';'</tt> on Win32 systems.
             **/
            static const char msSeparatorCharWin32;

            /** The system-dependent default path-separator character
	     ** <tt>";"</tt> on Win32 systems.
             **/
            static const std::string msSeparatorWin32;

            /** The system-dependent default path-separator character. On UNIX
	     ** systems the value of this field is <tt>':'</tt>; on Win32
	     ** systems it is <tt>';'</tt>.
             **/
            static const char msSeparatorChar;

            /** The system-dependent default path-separator character,
	     ** represented as a string for convenience. On UNIX systems the
	     ** value of this field is <tt>":"</tt>; on Win32 systems it is
	     ** <tt>";"</tt>.
             **/
            static const std::string msSeparator;

            /** \}
             **/

            /** \name Constructors / Destructor
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    Path();

	    /** No instances allowed, use only the static methods.
	     **/
	    Path( const Path & path );

	    /** No instances allowed, use only the static methods.
	     **/
	    ~Path();

            /** \}
             **/


            /** \name Operators
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    Path & operator=( const Path & path );

            /** \}
             **/

            /** \name Static Methods
             ** \{
             **/

        public:            

            /** Returns the current working directory of the application.
             ** @return Current working directory
             **/
            static std::string GetCurrentPath()
		throw( oc::Errno );

            /** \}
             **/

        }; // CLASS System::Path



	// =================
	// CLASS System::Env
	// =================

        /** This inner class holds all system-dependent values concerning the
	 ** enviroment.
         **
         ** \author Michael B. Kellner
         ** \nosubgrouping
         **/
	class OC_DSOAPI Env
	{

            /** \name Constructors / Destructor
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    Env();

	    /** No instances allowed, use only the static methods.
	     **/
	    Env( const Env & env );

	    /** No instances allowed, use only the static methods.
	     **/
	    ~Env();

            /** \}
             **/


            /** \name Operators
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    Env & operator=( const Env & env );

            /** \}
             **/

            /** \name Static Methods
             ** \{
             **/

        public:            

	    /** The method searches the environment list for a string that matches
	     ** the string pointed to by the given name.
	     ** @param name The name of the environment variable to query
	     ** @param value The value of the environment variable if it exists,
	     **        empty string otherwise.
	     ** @return <tt>true</tt> if environment variable exists,
	     **         <tt>false</tt> otherwise
	     **/
	    static bool GetProperty( const std::string & name,
				     std::string       & value );

	    /** The method adds the variable name to the environment with the
	     ** given value, if the variable does not already exist. If the
	     ** variable does exist in the environment, then its value is changed
	     ** to the given value.
	     ** @param name The name of the environment variable to set
	     ** @param value The new value of the environment variable
	     ** @return <tt>true</tt> on success, <tt>false</tt> if there was
	     **         insufficient space in the environment
	     **/
	    static bool SetProperty( const std::string & name,
				     const std::string & value );
	    
	    /** The method remove the variable with the given name from the
	     ** environment list.
	     ** @param name The name of the environment variable to remove
	     ** @return <tt>true</tt> if the variable was successfully removed,
	     **         <tt>false</tt> otherwise
	     **/
	    static bool RemoveProperty( const std::string & name );

            /** \}
             **/

	}; // CLASS System::Env


	// =================
	// CLASS System::Net
	// =================

        /** This inner class holds all system-dependent values concerning the
	 ** network.
         **
         ** \author Michael B. Kellner
         ** \nosubgrouping
         **/
	class OC_DSOAPI Net
	{

            /** \name Constructors / Destructor
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    Net();

	    /** No instances allowed, use only the static methods.
	     **/
	    Net( const Net & net );

	    /** No instances allowed, use only the static methods.
	     **/
	    ~Net();

            /** \}
             **/


            /** \name Operators
             ** \{
             **/

	private:

	    /** No instances allowed, use only the static methods.
	     **/
	    Net & operator=( const Net & net );

            /** \}
             **/

            /** \name Static Methods
             ** \{
             **/

        public:

	    /** The method returns the name of local host.
	     **
	     ** \return Name of the local host.
	     ** \see oc::InetAddress
	     **/
	    static std::string GetHostname();

	    /** The method returns the name of the operating system. This may be
	     **
	     ** \li win32
	     ** \li linux
	     ** \li aix
	     **
	     ** \return Name of the operting system.
	     **/
	    static const std::string & GetOSName();

            /** \}
             **/

	}; // Class: System::Net



	// ==================
	// CLASS System::Path
	// ==================
    
	/** This inner class holds all system-dependent values concerning paths.
         **
         ** \author Horst H. Hadler
         ** \nosubgrouping
         **/
	class OC_DSOAPI Directory
	{
 	private:

	    /** No instances allowed.
	     **/
	    Directory();

	    /** No instances allowed.
	     **/
	    Directory( const Directory & net );

	    /** No instances allowed.
	     **/
	    ~Directory();

	    /** No instances allowed.
	     **/
  	    Directory & operator=( const Directory & net );

		/** \name Static Methods
		** \{
		**/

        public:

	    /** Create a directory.
	     **/
		static bool CreateDir(std::string const& fullpath);

        /** \}
         **/

	};

    }; // CLASS System

} // namespace oc



#endif


