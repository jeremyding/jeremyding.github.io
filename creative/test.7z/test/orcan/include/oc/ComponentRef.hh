
#ifndef OC_COMPONENT_REF_HH
#define OC_COMPONENT_REF_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/ObjectRef.hh>
#include <oc/ComponentListenerContainer.hh>


namespace oc
{

    /** Wrapper class for all component instances.
     **
     ** \see ObjectRef, CommandRef
     **
     ** \author Michael Kellner
     ** \date 1.7.2004
     ** \nosubgrouping
     **/
    template < class Object, class ObjectInterfaces >
    class ComponentRef : public oc::ObjectRef<Object>
    {

	/** \name Class Types
	 ** \{
	 **/

    public:

	/** The type of the embedded object.
	 **/
	typedef Object ObjectType;

        /** The type of the interfaces of the object.
         **/
        typedef ObjectInterfaces Interfaces;

        /** The type of the base class.
         **/
        typedef oc::ObjectRef<Object> BaseClassType;

	/** The type of the instantiated template class.
	 **/
	typedef ComponentRef<Object,ObjectInterfaces> SelfType;

        /** \}
         **/


	/** \name Attributes
	 ** \{
	 **/

    public:

        /** The interfaces of the object.
         **/
        Interfaces I;

        /** \}
         **/


	/** \name Constructors / Destructor
	 ** \{
	 **/

    public:

	/** Default constructor leaves the instance uninitialized. Use creator
	 ** methods or assignment operators to initialize the instance.
	 **
	 ** \see Create( Object & )
	 **      Create( oc::CPtr<Object> &,
	 **              oc::ObjectTraitPtr,
	 **              oc::ObjectFactoryPtr )
	 **      operator=( Object & )
	 **/
	ComponentRef()
	    : BaseClassType()
	{}

	/** Initialize the instance with an object \a instance to manage,
	 ** the object trait description and the object factory which
	 ** created the instance.
	 **
	 ** \param instance Object instance to manage.
	 ** \param objectTrait Description to this object kind.
	 ** \param objectFactory Factory which has created the instance.
	 **
	 ** \see Create( Object & )
	 **/
	ComponentRef( oc::CPtr<Object> &   instance,
                      oc::ObjectTraitPtr   objectTrait   = oc::ObjectTraitPtr(),
                      oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr())
	    : BaseClassType( instance, objectTrait, objectFactory )
	{
            if( *this ) {
                if( ! I.QueryInterfacesFromProperties( BaseClassType::GetProperties() ) ) {
                    
                    OCWARN( "Component realization "
			    << BaseClassType::GetName()
			    << " could not be used because of missing interface implementation." );
                    BaseClassType::Delete();
                }
            }
        }

	/** Initialize the instance with an object \a instance to manage,
	 ** the object trait description and the object factory which
	 ** created the instance.
	 **
	 ** \param instance Object instance to manage.
	 ** \param objectTrait Description to this object kind.
	 ** \param objectFactory Factory which has created the instance.
	 **
	 ** \see Create( Object & )
	 **/
	ComponentRef( Object *               instance,
                      oc::ObjectTraitPtr   objectTrait   = oc::ObjectTraitPtr(),
                      oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr())
	    :  BaseClassType( instance, objectTrait, objectFactory )
	{
            if( *this ) {
                if( ! I.QueryInterfacesFromProperties( BaseClassType::GetProperties() ) ) {
                    
                    OCWARN( "Component realization "
			    <<BaseClassType:: GetName()
			    << " could not be used because of missing interface implementation." );
                    BaseClassType::Delete();
                }
            }
        }

	/** The copy constructor did not make a copy of the instance (of
	 ** course), it copies only the reference to it.
	 **
	 ** \param source Object reference from which a copy will be made off.
	 **/
	ComponentRef( ComponentRef const & source )
	    : BaseClassType( source )
            , I( source.I )
	{}

	/** The destructor is empty, it does not need to free any resources.
	 **/
	virtual ~ComponentRef()
	{}

	/** \}
	 **/


        /** \name Operators
         ** \{
         **/
   
    public:

        /** Initialize the reference with the given object \a instance to manage. If the
         ** object reference has already an instance, this instance will NOT be
         ** deleted. The user is responsible for deletion.
         **
         ** \param instance Object instance to manage.
         ** \return Reference to assigned object.
         **
         ** \see Create( Object & )
         **/
        ComponentRef & operator=( Object & instance )
        {
            BaseClassType::operator=( instance );

            if( *this ) {
                if( ! I.QueryInterfacesFromProperties( BaseClassType::GetProperties() ) ) {
                    
                    OCWARN( "Component realization "
			    << BaseClassType::GetName()
			    << " could not be used because of missing interface implementation." );
                    BaseClassType::Delete();
                }
            }

            return *this;
        }

        /** Assignes the reference to one object to another reference, so both
         ** instances references to the same object after assignment. If the
         ** object reference has already an instance, this instance will NOT be
         ** deleted. The user is responsible for deletion.
         **
         ** \param assignee Object reference assigned.
         ** \return Reference to assigned object.
         **
         ** \see Create( const ObjectRef & )
         **/
        ComponentRef & operator=( const ComponentRef & assignee )
        {
            BaseClassType::operator=( assignee );
            I = assignee.I;

            return *this;
        }


        /** \}
         **/

        /** \name Creators
         ** \{
         **/

    public:

        /** Initialize the instance with the given object \a instance to manage. If the
         ** object reference has already an instance, this instance will NOT be
         ** deleted. The user is responsible for deletion.
         **
         ** \param instance      Object instance to manage.
         ** \param objectTrait   Object trait which describes the instance.
         ** \param objectFactory Object factory which has created the instance.
         ** \return \c true if the initialization was successfully, \c false
         **         otherwise.
         **
         ** \see ObjectRef( Object &,
         **                 oc::ObjectTraitPtr,
         **                 oc::ObjectFactoryPtr )
         **      Create( oc::CPtr<Object> & )
         **/
        bool Create( Object &             instance,
                     oc::ObjectTraitPtr   objectTrait   = oc::ObjectTraitPtr::NullPtr,
                     oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr::NullPtr )
        {

            BaseClassType::Create( instance, objectTrait, objectFactory );

            if( *this ) {
                if( ! I.QueryInterfacesFromProperties( BaseClassType::GetProperties() ) ) {
                    
                    OCWARN( "Component realization "
			    << BaseClassType::GetName()
			    << " could not be used because of missing interface implementation." );
                    BaseClassType::Delete();
                }
            }

            return ! (*this);
        }


        /** Initialize the instance with the given object \a instance to manage,
         ** the object trait description and the object factory which has
         ** created the instance. If the object reference has already an
         ** instance, this instance will NOT be deleted. The user is
         ** responsible for deletion.
         **
         ** \param instance Object instance to manage.
         ** \param objectTrait   Object trait which describes the instance.
         ** \param objectFactory Object factory which has created the instance.
         ** \return \c true if the initialization was successfully, \c false
         **         otherwise.
         **
         ** \see ObjectRef( oc::CPtr<Object> & )
         **      Create( Object & )
         **/
        bool Create( oc::CPtr<Object> &   instance,
                     oc::ObjectTraitPtr   objectTrait   = oc::ObjectTraitPtr::NullPtr,
                     oc::ObjectFactoryPtr objectFactory = oc::ObjectFactoryPtr::NullPtr )
        {

            BaseClassType::Create( instance, objectTrait, objectFactory );

            if( *this ) {
                if( ! I.QueryInterfacesFromProperties( BaseClassType::GetProperties() ) ) {
                    
                    OCWARN( "Component realization "
			    << BaseClassType::GetName()
			    << " could not be used because of missing interface implementation." );
                    BaseClassType::Delete();
                }
            }

            return ! (*this);
        }

        /** Delete the managed instance. If an object factory is specified the instance
         ** will be deleted by this factory, if not the normal C++ delete operator will
         ** be called.
         **/
        bool Delete()
        {

            // Notify listeners about object deletion.
            oc::ComponentListenerContainer<ComponentRef>::NotifyForDeletion( *this );
 
            return BaseClassType::Delete();
        }
 
        /** \}
         **/

    }; // class ComponentRef

} // namespace oc


#endif

