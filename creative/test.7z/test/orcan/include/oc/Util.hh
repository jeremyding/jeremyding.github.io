
#ifndef OC_UTIL_HH
#define OC_UTIL_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/config.h>

// STL include

#include <vector>
#include <string>



namespace oc
{


    // ==========
    // CLASS Util
    // ==========

    /** This utitilty class provides some useful methods which still not
     ** provided by the standard libraries.
     **
     ** \author Michael B. Kelner
     **
     ** \nosubgrouping
     **/
    class OC_DSOAPI Util
    {

        /** \name Constructors / Destructor
         ** \{
         **/

    private:

	/** No instances allowed, use only the static methods.
	 **/
	Util();

	/** No instances allowed, use only the static methods.
	 **/
	Util( const Util & util );

	/** No instances allowed, use only the static methods.
	 **/
	~Util();

        /** \}
         **/


        /** \name Operators
         ** \{
         **/

    private:

	/** No instances allowed, use only the static methods.
	 **/
	Util & operator=( const Util & util );

        /** \}
         **/



        /** \name Static Methods
         ** \{
         **/

    public:        

        /** Breaks up the given string into tokens using the separator character
	 ** and returns the tokens in an array.
         ** @param s   [IN] The string to tokenize
         ** @param sep [IN] The separator character
         ** @param allowEmptyTokens [IN] Sequence of separators allowed (default: false)
         ** @return An array of strings
         **/
        static tVecString Tokenize( const std::string & s,
				    char sep = ' ',
                                    bool allowEmptyTokens = false );

        /** Breaks up the given string into tokens using each character in the
	 ** separator string as possible separation character and returns the
	 ** tokens in an array.
         ** @param s   [IN} The string to tokenize
         ** @param sep [IN] The string with separators
         ** @param allowEmptyTokens [IN] Sequence of separators allowed (default: false)
         ** @return An array of strings
         **/
        static tVecString Tokenize( const std::string & s,
				    const std::string & sep,
                                    bool allowEmptyTokens = false );

	/** Converts the string \p s to lower cases in place.
	 ** \param s [IN,OUT] String to convert
	 **/
	static std::string & ToLower( std::string & s );

	/** Converts the string \p s to lower cases by creating
	 ** a new string with the converted string.
	 ** \param s [IN] String to convert
	 ** \return New string with lower cases
	 **/
	static std::string ToLower( const std::string & s );

	/** Converts the string \p s to upper cases in place.
	 ** \param s [IN,OUT] String to convert
	 ** \return String \p s after conversion.
	 **/
	static std::string & ToUpper( std::string & s );

	/** Converts the string \p s to upper cases by creating
	 ** a new string with the converted string.
	 ** \param s [IN] String to convert
	 ** \return New string with upper cases
	 **/
	static std::string ToUpper( const std::string & s );

        /** Get the value of a string description of a bool: 
         ** the values "no", "false" and "0" speficy the value false ,
         ** the values "yes", "true","1" and all other values which's integer-conversion
         ** has a value != 0 specify a value of true.
         ** Case is ignored.
         ** \param s [IN] string to be parsed.
         ** \return boolean value described by s
         **/
        static bool ToBool( std::string const & s );

        /** Get the value of a string as double i.e. perform atof.
         **/
        static double ToDouble( std::string const & s );

        /** Get the value of a string as double i.e. perform atof.
         **/
        static double ToDouble( const char * s );

        /** Get the value of a double as string i.e. perform ftoa.
         **/
        static std::string ToString( double const & d );

        /** Get the value of a string as int i.e. perform atoi.
         **/
        static int ToInt( std::string const & s );

        /** Get the value of a string as int i.e. perform atoi.
         **/
        static int ToInt( const char * s );

        /** Get the value of a int as string i.e. perform itoa.
         **/
        static std::string ToString( int const & i );


        /** Test if a string represents a floating point number (s.th. with a decimal point).
         **/
        static bool IsDouble( std::string const & s);

	/** Counts number decimal digits in a 32 bit signed number.
	 ** 0 => 1, 9 => 1, 99 => 2, ...
	 ** @param x number whose digits you wish to count.
	 **        Must lie in range 0 .. Integer.MAX_VALUE;
	 ** @return Number of digits in x
	 **/
        static int WidthInDigits( const int x );

	/** Strips leading and trailing whitechars.
	 ** \param s [IN] string with leading and trailing whitechars
         ** \return stripped string
	 **/
	static std::string ToStripped( std::string const & s );

	/** Strips leading and trailing whitechars in place.
	 ** \param s [IN,OUT] String to convert
	 ** \return stripped string
	 **/
	static std::string & ToStripped( std::string & s );

        /** \}
         **/

    }; // class Util

} // namespace oc

#endif

