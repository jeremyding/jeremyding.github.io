
#ifndef OC_THREADER_HH
#define OC_THREADER_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Materials       Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstra�e 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
//  
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================

// INCLUDE
// =======

// ORCAN include

#include <oc/PropertyMap.hh>


namespace oc 
{


    //fwd. decl
    class ThreadImplementation;

    /** Create threads without deriving from a thread class.
     ** Threads are joinable by default. 
     **
     ** \code
     ** class myclass {
     ** public:
     **   void do_sth() {   
     **     int i=10000;
     **     while(i-->0) {
     **         std::cout << "huhu" << std::endl;
     **     }
     **   }
     ** };
     ** 
     ** myclass mc;
     ** Threader t1;
     ** t1.CreateAndRun(&mc, &myclass::do_sth);
     ** ...
     ** \endcode
     ** \author Horst Hadler
     ** \date 13.11.2003
     **
     ** \nosubgrouping
     **/
    class Threader
    {
    private:
        oc::PropertyMap mProperties;

        ThreadImplementation *mThreadImplementation;

    public:

        /** Called by implementation, when thread starts running.
         ** Should not be called directly or from outside the implementation. 
         **/
        OC_DSOAPI bool Run();

    public:

	/** \name Ctor/Dtor/Create
	 ** \{
	 **/

        OC_DSOAPI Threader();

        OC_DSOAPI virtual ~Threader();

        /** Create a new thread, running method s of instance t.
         ** If another thread is still served by this threader, this thread will be killed.
         ** \return false on error
         **/
        template <class T,class S>
        bool CreateAndRun( T t, S s)
        {
            mProperties.AddPropertyCopy("mInstancePtr",t);
            mProperties.AddPropertyCopy("mMethodPtr",s);

            return CreateAndRun();
        }

        /** Create a new thread - intially suspended -, running method s of instance t.
         ** If another thread is still served by this threader, this thread will be killed.
         ** \return false on error
         **/
        template <class T,class S>
        bool CreateAndSuspend( T t, S s)
        {
            mProperties.AddPropertyCopy("mInstancePtr",t);
            mProperties.AddPropertyCopy("mMethodPtr",s);

            return CreateAndSuspend();
        }

        /** Create and run thread (using instance-pointer and entry-method 
            previous call to CreateAndRun(t,s) or CreateAndSuspend(t,s)).
            ** \return false on error
            **/
        OC_DSOAPI bool CreateAndRun();

        /** Create suspended thread (using instance-pointer and entry-method 
            previous call to CreateAndRun(t,s) or CreateAndSuspend(t,s)).
            ** \return false on error
            **/
        OC_DSOAPI bool CreateAndSuspend();


	/** \}
	 **/


	/** \name Control State Setter/Getter 
	 ** \{
	 **/
    
        template <class T,class S>
        bool SetReportExit( T t, S s)
        {
            mProperties.AddPropertyCopy("mReportExitInstancePtr",t );
            mProperties.AddPropertyCopy("mReportExitMethodPtr",s);

            return true;
        }

        /** Block until thread has finished.
         ** \return false on error
         **/
        OC_DSOAPI bool Wait();

        /** Suspend thread.
         ** Suspend calls are accumulated.
         ** \return false on error
         **/
        OC_DSOAPI bool Suspend();

        /** Resume thread.
         ** Resume calls are accumulated.
         ** \return false on error
         **/
        OC_DSOAPI bool Resume();

        /** Kill thread.
         ** \return false on error
         **/
        OC_DSOAPI bool Kill();

        /** Set thread priority from 0 (lowest) to 100 (highest).
         ** \return false on error
         **/
        OC_DSOAPI bool SetPriority(uint32 priority100);

        /** Get thread priority.
         ** A value > 100 will be returned on error.
         **/
        OC_DSOAPI uint32 GetPriority();
   
        /** \}
	 **/

	/** \name Query State
	 ** \{
	 **/

        /** Is the thread running?
         ** The result of IsRunning is undefined when the thread has finished.
         ** \return false on error
         **/
        OC_DSOAPI bool IsRunning();

        /** Is the thread suspended?
         ** The result of IsSuspended is undefined when the thread has finished.
         ** \return false on error
         **/
        OC_DSOAPI bool IsSuspended();

        /** Is the thread still working (not finished)?
         ** \return false on error
         **/
        OC_DSOAPI bool IsAlive();

        /** \}
	 **/

    }; // Threader

    /** Thread methods that have to be implemented on each operating system.
     ** Class Threader uses ThreadImplementation as a level of abstraction
     ** to the OS-specific thread functions.
     **/
    class ThreadImplementation
    {
    public:
        /** Create a new thread in suspended mode.
         **/
        virtual bool CreateAndSuspend() = 0;

        /** Suspend thread.
         **/
        virtual bool Suspend() = 0;

        /** Resume thread.
         **/
        virtual bool Resume() = 0;

        /** Wait for thread to finish.
         **/
        virtual bool Wait() = 0;

        /** Kill thread.
         **/
        virtual bool Kill() = 0;

        /** Set thread priority from 0 (lowest) to 100 (highest).
         **/
        virtual bool SetPriority(uint32 priority100)= 0;

        /** Get thread priority from 0 (lowest) to 100 (highest).
         ** A value > 100 will be returned on error.
         **/
        virtual uint32 GetPriority() = 0;

        /** Is the thread running?
         ** The result of IsRunning is undefined when the thread has finished.
         **/
        virtual bool IsRunning() = 0;

        /** Is the thread suspended?
         ** The result of IsSuspended is undefined when the thread has finished.
         **/
        virtual bool IsSuspended() = 0;

        /** Is the thread still working (not finished)?
         **/
        virtual bool IsAlive() = 0;

    }; // ThreadImplementation

} // namespace oc



#endif
