
#ifndef OC_COMMAND_HH
#define OC_COMMAND_HH

// =============================================================================
//                                                                              
//  Crystal Growth Laboratory                                                   
//                                                                              
//  University Erlangen-Nuremberg          Fraunhofer Gesellschaft              
//  Department of Material Science         Institute of Integrated Systems      
//  Electrical Engineering Martials        Device Technology Devision (IIS-B)   
//  Martensstrasse 7                       Schottkystrasse 10                   
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
//  In cooperation with                                                         
//                                                                              
//  University Erlangen-Nuremberg          University Erlangen-Nuremberg        
//  Department of Computer Science 9       Department of Computer Science 10    
//  Computer Graphics                      System Simulation Group              
//  Am Weichselgarten 9                    Cauerstrasse 6                        
//  91058 Erlangen                         91058 Erlangen                       
//  Germany                                Germany                              
//                                                                              
// =============================================================================
//                                                                              
//  Copyright 2004 (c) by
//  (1) Department of Material Science 6  University Erlangen-Nuremberg, M.Kellner
//  (2) Department of Computer Science 9  University Erlangen-Nuremberg, H.Hadler
//  (3) Department of Computer Science 10 University Erlangen-Nuremberg, J.Treibig
//  (4) Fraunhofer IISb Erlangen Department of Crystal Growth, Dr.Th.Jung
// 
//  For Licensing regulations see the accompanying LICENSE file.
//  If this file does not exist and/or does not apply to you, please contact
//  the copyright holders.          
//                                                                              
// =============================================================================


// INCLUDE
// =======

// ORCAN include

#include <oc/CPtr.hh>
#include <oc/Log.hh>
#include <oc/PropertyMap.hh>
#include <oc/PropertyMapDeco.hh>
#include <oc/ObjectBroker.hh>
#include <oc/CommandRef.hh>
#include <oc/Component.hh>
#include <oc/ComponentListenerContainer.hh>

// C++ include

#include <string>
#include <list>


namespace oc
{

    // ================
    // COMMAND template
    // ================
    

    /** The template class to declare an OC command. Do not use this class
     ** directly, use the macros for command declarations instead:
     **
     ** \li OC_BEGIN_COMMAND()
     ** \li OC_END_COMMAND()
     ** \li OC_BEGIN_OPERANDS()
     ** \li OC_END_OPERANDS()
     ** \li OC_DECLARE_INPUT_OPERAND()
     ** \li OC_DECLARE_OUTPUT_OPERAND()
     **/
    template < class CObject, class CInterfaces >
    class Command
    {

    protected:

        static oc::ObjectBrokerPtr msObjectBrokerPtr;

     public:

        typedef CObject ObjectType;

        typedef CObject BaseClass;

        typedef CInterfaces Interfaces;

        typedef oc::CommandRef<BaseClass,Interfaces> Reference;

        typedef Command<BaseClass,Interfaces> SelfType;

        typedef OC_TYPENAME ComponentListenerContainer<Reference>::Listener Listener;


        static bool SetBroker( oc::ObjectBroker & broker )
        {
            msObjectBrokerPtr = & (broker.Self());
            return true;
        }

        static bool AddListener( Listener & l )
        {
            OCDEBUG( "Adding listener to component '" << GetName() << "'." );
            oc::ComponentListenerContainer<Reference>::Add( l );
            return true;
        }

        static bool RemoveListener( Listener & l )
        {
            OCDEBUG( "Removing listener from component '" << GetName() << "'." );
            oc::ComponentListenerContainer<Reference>::Remove( l );
            return true;
        }

        static Reference New( const std::string & realizationName = "" )
        {
            // Get the object broker instance
            if( ! msObjectBrokerPtr ) {

                msObjectBrokerPtr = & (oc::ObjectBroker::Self());
            }

            // Create object
            Reference ref;

            msObjectBrokerPtr->NewObject( ref, realizationName );

            // Load and assign resources
            if( ref ) {

                oc::File resource_file = ref.GetResource();

                if( resource_file ) {

                    if( oc::PropertyMapResourceHandler::LoadAndAssign( resource_file,
                                                                       ref.GetProperties() ) ) {

                        OCDEBUG( "Resource file '"
                                 << resource_file
                                 << "' successfully loaded and assigned to command "
                                 << GetName()
                                 << " with realization "
                                 << ref.GetObjectTrait()->GetRealizationName()
                                 << "." );
                    }
                    else {

                        OCWARN( "Can't load and assign resource file '"
                                << resource_file
                                << "' to command "
                                << GetName()
                                << " with realization "
                                << ref.GetObjectTrait()->GetRealizationName()
                                << "." );
                    }
                }
                else {

                    OCDEBUG( "No resource file for command "
                             << GetName()
                             << " with realization "
                             << ref.GetObjectTrait()->GetRealizationName()
                             << " available." );
                }

                // Notify listeners about the new object.
                oc::ComponentListenerContainer<Reference>::NotifyForCreation( ref );
            }

            return ref;
        }

        static bool GetAllRealizations( std::vector< std::string > & realization_names )
        {

            // Get the object broker instance
            if( ! msObjectBrokerPtr ) {

                msObjectBrokerPtr = & (oc::ObjectBroker::Self());
            }

            // Clear vector with realization names
            realization_names.clear();
 
            // Search for all realizations of this component
            oc::ObjectBrokerConfig::mtObjectTraitVector traits_vector = msObjectBrokerPtr->GetConfig()->Find( GetName() );

            // Loop over all object traits and add realization name to result vector
            oc::ObjectBrokerConfig::mtObjectTraitVector::const_iterator  it = traits_vector.begin();
            oc::ObjectBrokerConfig::mtObjectTraitVector::const_iterator eit = traits_vector.end();

            for( ; it != eit; ++it ) {
                
                OCDEBUG( "Found realization '" << (*it)->GetRealizationName() << "'." );
                
                realization_names.push_back( (*it)->GetRealizationName() );
            }

            return true;
        }

        static std::string GetName()
        {
            return ObjectType::GetName();
        }

        Command()
            : CObject()
            , CInterfaces()
       {}

        virtual ~Command()
        {}

    }; // template class Command

    // Initialize static variable
    template < class CObject, class CInterfaces >
    oc::ObjectBrokerPtr Command<CObject,CInterfaces>::msObjectBrokerPtr = oc::ObjectBrokerPtr();

} // namespace oc





// ===================================================================
//                              COMMAND macros
// ===================================================================


// -------------
// HEADER macros
// -------------

/** Use this macro to start a new command declaration.
 **/
#define OC_BEGIN_COMMAND( CmdName )                              \
class C##CmdName                                                 \
{                                                                \
  public:                                                        \
    C##CmdName()                                                 \
    {}                                                           \
    C##CmdName( const C##CmdName & )                             \
    {}                                                           \
    virtual ~C##CmdName()                                        \
    {}                                                           \
    static std::string GetName()                                 \
    {                                                            \
      return std::string( #CmdName );                            \
    }                                                            \
    virtual bool Execute() = 0;


/** Use this macro to start a operands declaration.
 **/
#define OC_BEGIN_OPERANDS( CmdName )


/** Use this macro to declare a specific input operand.
 **/
#define OC_DECLARE_INPUT_OPERAND( parameter )                       \
      virtual bool SetInput( parameter ) = 0;


/** Use this macro to declare a specific output operand.
 **/
#define OC_DECLARE_OUTPUT_OPERAND( parameter )                      \
      virtual bool SetOutput( parameter ) = 0;



/** Use this macro to finish an operands declaration.
 **/
#define OC_END_OPERANDS( CmdName )





#undef OC_NO_COMMAND_INTERFACES
/** Use this macro if you do not have any interfaces.
 **/
#define OC_NO_COMMAND_INTERFACES( CompName )                   \
};                                                             \
OC_NO_INTERFACES( CompName )


/** Use this macro to finish a command declaration.
 **/
#define OC_END_COMMAND( CmdName )                                \
typedef oc::PropertyMapDeco< C##CmdName > B##CmdName;            \
typedef oc::Command< B##CmdName, I##CmdName > CmdName;           \
typedef CmdName::Reference                  CmdName##Ref;




// ---------------------
// IMPLEMENTATION macros
// ---------------------


#define OC_BEGIN_COMMAND_IMPLEMENTATION( CompName )

#define OC_BEGIN_OPERAND_IMPLEMENTATIONS( CompName )

#define OC_IMPLEMENT_INPUT_OPERAND( parameter )

#define OC_IMPLEMENT_OUTPUT_OPERAND( parameter )

#define OC_END_OPERAND_IMPLEMENTATIONS( CompName )

#define OC_END_COMMAND_IMPLEMENTATION( CompName )




#endif

